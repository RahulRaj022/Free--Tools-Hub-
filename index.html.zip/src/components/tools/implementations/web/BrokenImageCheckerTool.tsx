import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Image as ImageIcon, CheckCircle, XCircle, Download, AlertCircle, Loader2, RotateCcw, ExternalLink } from 'lucide-react';

interface ImageItem {
  url: string;
  alt: string;
  statusCode: number;
  status: 'working' | 'broken' | 'timeout';
}

export const BrokenImageCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState<ImageItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'working' | 'broken'>('all');
  const [error, setError] = useState<string | null>(null);

  const scanImages = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a webpage URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setImages([]);

    try {
      // 1. Fetch page HTML
      const pageRes = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const pageData = await pageRes.json();

      if (!pageRes.ok || pageData.error) {
        throw new Error(pageData.error || 'Failed to fetch webpage.');
      }

      const html = pageData.html || '';
      const baseUrl = new URL(pageData.url || target);

      // Extract <img> tags with src and alt
      const imgRegex = /<img\b[^>]*>/gi;
      const foundList: { url: string; alt: string }[] = [];
      let match;

      while ((match = imgRegex.exec(html)) !== null) {
        const tag = match[0];
        const srcMatch = tag.match(/\bsrc=["']([^"']+)["']/i);
        const altMatch = tag.match(/\balt=["']([^"']*)["']/i);

        if (srcMatch && srcMatch[1]) {
          const rawSrc = srcMatch[1].trim();
          if (!rawSrc.startsWith('data:') && !rawSrc.startsWith('blob:')) {
            try {
              const fullUrl = new URL(rawSrc, baseUrl).toString();
              if (fullUrl.startsWith('http')) {
                foundList.push({
                  url: fullUrl,
                  alt: altMatch ? altMatch[1] : '(No alt attribute)',
                });
              }
            } catch {}
          }
        }
      }

      // Deduplicate up to 20 images
      const uniqueMap = new Map<string, string>();
      foundList.forEach((item) => {
        if (!uniqueMap.has(item.url)) uniqueMap.set(item.url, item.alt);
      });

      const uniqueUrls = Array.from(uniqueMap.keys()).slice(0, 20);
      if (uniqueUrls.length === 0) {
        setError('No standard image elements (<img>) were found on this webpage.');
        return;
      }

      // 2. Check HTTP statuses in batch
      const checkRes = await fetch('/api/web/check-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urls: uniqueUrls }),
      });
      const checkData = await checkRes.json();

      if (!checkRes.ok || checkData.error) {
        throw new Error(checkData.error || 'Failed to test image links.');
      }

      const verifiedImages: ImageItem[] = (checkData.results || []).map((r: any) => ({
        url: r.url,
        alt: uniqueMap.get(r.url) || '',
        statusCode: r.statusCode,
        status: r.status === 'working' ? 'working' : 'broken',
      }));

      setImages(verifiedImages);
      showToast(`Scanned ${verifiedImages.length} image assets!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error scanning images.');
    } finally {
      setLoading(false);
    }
  };

  const workingCount = images.filter((i) => i.status === 'working').length;
  const brokenCount = images.filter((i) => i.status === 'broken').length;

  const filtered = images.filter((img) => {
    if (filter === 'working') return img.status === 'working';
    if (filter === 'broken') return img.status === 'broken';
    return true;
  });

  const exportCsv = () => {
    const header = 'Image URL,Alt Text,Status Code,Status\n';
    const rows = images
      .map((img) => `"${img.url}","${img.alt.replace(/"/g, '""')}",${img.statusCode},${img.status}`)
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `broken_image_report_${url.replace(/[^a-z0-9]/gi, '_')}.csv`;
    a.click();
    URL.revokeObjectURL(u);
    showToast('Exported CSV report!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage Address to Audit for Images
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && scanImages()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={scanImages}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImageIcon className="h-4 w-4" />}
            <span>{loading ? 'Scanning Images...' : 'Scan Images'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setImages([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {images.length > 0 && (
        <div className="space-y-4 animate-in fade-in">
          {/* Summary Pills */}
          <div className="grid grid-cols-3 gap-3">
            <div
              onClick={() => setFilter('all')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'all'
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <span className="text-xs text-slate-500">Total Images</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                {images.length}
              </div>
            </div>

            <div
              onClick={() => setFilter('working')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'working'
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                <CheckCircle className="h-3.5 w-3.5" />
                <span>Working</span>
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
                {workingCount}
              </div>
            </div>

            <div
              onClick={() => setFilter('broken')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'broken'
                  ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400 font-semibold">
                <XCircle className="h-3.5 w-3.5" />
                <span>Broken / Dead</span>
              </div>
              <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-0.5">
                {brokenCount}
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          {/* Images Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500">
                  <tr>
                    <th className="px-4 py-3 font-semibold w-16">Preview</th>
                    <th className="px-4 py-3 font-semibold w-24">Status</th>
                    <th className="px-4 py-3 font-semibold">Image Asset URL</th>
                    <th className="px-4 py-3 font-semibold">Alt Text</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {filtered.map((img, i) => (
                    <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-2.5">
                        <div className="h-10 w-10 rounded-lg bg-slate-100 dark:bg-slate-800 overflow-hidden border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                          {img.status === 'working' ? (
                            <img
                              src={img.url}
                              alt=""
                              className="h-full w-full object-cover"
                              onError={(e) => ((e.target as any).style.display = 'none')}
                            />
                          ) : (
                            <XCircle className="h-4 w-4 text-rose-500" />
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {img.status === 'working' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-sans font-semibold">
                            <CheckCircle className="h-3 w-3" /> 200 OK
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 font-sans font-semibold">
                            <XCircle className="h-3 w-3" /> Broken
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 max-w-sm truncate font-sans">
                        <a
                          href={img.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:underline flex items-center gap-1 text-slate-900 dark:text-slate-100"
                        >
                          <span className="truncate">{img.url}</span>
                          <ExternalLink className="h-3 w-3 shrink-0 opacity-40" />
                        </a>
                      </td>
                      <td className="px-4 py-3 font-sans text-slate-500 max-w-xs truncate">
                        {img.alt}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
