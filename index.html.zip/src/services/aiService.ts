import { ChatMessage, Conversation, ToolContext, AIServiceStatus } from '../types/ai';

const CONV_META_KEY = 'fth_ai_conv_meta_v2';
const CONV_MSG_PREFIX = 'fth_ai_conv_msg_';
const ACTIVE_CONV_KEY = 'fth_ai_active_conv_id';
const LEGACY_STORAGE_KEY = 'fth_ai_conversations_v1';

export interface StreamStats {
  ttftMs?: number | null;
  totalMs?: number;
  model?: string;
  charCount?: number;
}

export interface StreamChatParams {
  messages: { role: string; content: string }[];
  toolContext?: ToolContext;
  onBatchedText: (text: string) => void;
  onStats?: (stats: StreamStats) => void;
  signal?: AbortSignal;
}

// In-memory cache for active conversations
const conversationMessageCache = new Map<string, ChatMessage[]>();

export async function checkAIStatus(): Promise<AIServiceStatus> {
  try {
    const res = await fetch('/api/ai/status');
    if (!res.ok) throw new Error('Status endpoint failed');
    return await res.json();
  } catch {
    return {
      available: false,
      provider: 'Google Gemini',
      model: 'gemini-3.8-flash',
      status: 'unconfigured',
      message: 'AI Assistant server endpoint is not responding.',
    };
  }
}

/**
 * High-performance streaming client with 40ms token batching.
 * Prevents React thread-locking and guarantees 60fps UI responsiveness.
 */
export async function streamAIChat({
  messages,
  toolContext,
  onBatchedText,
  onStats,
  signal,
}: StreamChatParams): Promise<string> {
  const response = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
    },
    body: JSON.stringify({
      messages,
      toolContext,
      stream: true,
    }),
    signal,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => null);
    throw new Error(errorData?.error || `AI Request failed with status ${response.status}`);
  }

  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error('Response stream is not readable.');
  }

  const decoder = new TextDecoder();
  let fullText = '';
  let buffer = '';
  let streamStats: StreamStats = {};

  // 40ms token batching buffer
  let batchTimeout: any = null;
  let hasPendingUpdate = false;

  const flushBatchedUpdate = () => {
    if (batchTimeout) {
      clearTimeout(batchTimeout);
      batchTimeout = null;
    }
    hasPendingUpdate = false;
    onBatchedText(fullText);
  };

  const scheduleBatchedUpdate = () => {
    hasPendingUpdate = true;
    if (!batchTimeout) {
      batchTimeout = setTimeout(() => {
        batchTimeout = null;
        if (hasPendingUpdate) {
          hasPendingUpdate = false;
          onBatchedText(fullText);
        }
      }, 40);
    }
  };

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith('data:')) continue;
        const dataStr = trimmed.slice(5).trim();

        if (dataStr === '[DONE]') {
          break;
        }

        try {
          const parsed = JSON.parse(dataStr);
          if (parsed.error) {
            throw new Error(parsed.error);
          }
          if (parsed.text) {
            fullText += parsed.text;
            scheduleBatchedUpdate();
          }
          if (parsed.stats) {
            streamStats = { ...streamStats, ...parsed.stats };
          }
        } catch (e: any) {
          if (e.message !== 'Unexpected end of JSON input') {
            // ignore partial JSON parse warnings during stream
          }
        }
      }
    }
  } finally {
    // Flush any remaining tokens immediately
    flushBatchedUpdate();
    if (onStats) {
      streamStats.charCount = fullText.length;
      onStats(streamStats);
    }
  }

  return fullText;
}

// ==========================================
// LAZY-LOADED CHAT HISTORY (Zero-Startup Lag)
// ==========================================

export interface ConversationMeta {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messageCount: number;
  toolContext?: ToolContext;
}

/**
 * Loads only metadata on startup (fast O(1) parse).
 */
export function loadConversationsMeta(): ConversationMeta[] {
  try {
    const raw = localStorage.getItem(CONV_META_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }

    // Migrate from legacy single-key storage if exists
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacy: Conversation[] = JSON.parse(legacyRaw);
      if (Array.isArray(legacy) && legacy.length > 0) {
        const metaList: ConversationMeta[] = [];
        for (const c of legacy) {
          metaList.push({
            id: c.id,
            title: c.title,
            createdAt: c.createdAt,
            updatedAt: c.updatedAt,
            messageCount: c.messages?.length || 0,
            toolContext: c.toolContext,
          });
          localStorage.setItem(`${CONV_MSG_PREFIX}${c.id}`, JSON.stringify(c.messages || []));
          conversationMessageCache.set(c.id, c.messages || []);
        }
        localStorage.setItem(CONV_META_KEY, JSON.stringify(metaList));
        localStorage.removeItem(LEGACY_STORAGE_KEY);
        return metaList;
      }
    }

    return [];
  } catch {
    return [];
  }
}

export function saveConversationsMeta(metaList: ConversationMeta[]): void {
  try {
    localStorage.setItem(CONV_META_KEY, JSON.stringify(metaList));
  } catch (err) {
    console.error('Failed to save conversation metadata:', err);
  }
}

/**
 * Loads conversation messages on demand (Lazy Loading).
 */
export function loadConversationMessages(id: string): ChatMessage[] {
  if (conversationMessageCache.has(id)) {
    return conversationMessageCache.get(id)!;
  }
  try {
    const raw = localStorage.getItem(`${CONV_MSG_PREFIX}${id}`);
    if (raw) {
      const msgs: ChatMessage[] = JSON.parse(raw);
      conversationMessageCache.set(id, msgs);
      return msgs;
    }
  } catch {
    // fallback
  }
  return [];
}

/**
 * Saves conversation messages and updates cached state.
 */
export function saveConversationMessages(id: string, messages: ChatMessage[]): void {
  conversationMessageCache.set(id, messages);
  try {
    localStorage.setItem(`${CONV_MSG_PREFIX}${id}`, JSON.stringify(messages));
  } catch (err) {
    console.error('Failed to save messages to localStorage:', err);
  }
}

export function deleteConversationData(id: string): void {
  conversationMessageCache.delete(id);
  try {
    localStorage.removeItem(`${CONV_MSG_PREFIX}${id}`);
  } catch {
    // ignore
  }
}

export function clearAllConversationsData(metaList: ConversationMeta[]): void {
  for (const m of metaList) {
    deleteConversationData(m.id);
  }
  conversationMessageCache.clear();
  try {
    localStorage.removeItem(CONV_META_KEY);
    localStorage.removeItem(ACTIVE_CONV_KEY);
  } catch {
    // ignore
  }
}

export function getActiveConversationId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_CONV_KEY);
  } catch {
    return null;
  }
}

export function setActiveConversationId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_CONV_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_CONV_KEY);
    }
  } catch {
    // ignore
  }
}

export function createNewConversationMeta(toolContext?: ToolContext): ConversationMeta {
  return {
    id: `conv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    title: toolContext ? `Help with ${toolContext.name}` : 'New Conversation',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messageCount: 0,
    toolContext,
  };
}

export function generateTitleFromPrompt(prompt: string): string {
  const clean = prompt.trim().replace(/^[^a-zA-Z0-9]+/, '');
  if (!clean) return 'New Conversation';
  const firstSentence = clean.split('\n')[0].split(/[.?!]/)[0];
  return firstSentence.length > 36 ? `${firstSentence.substring(0, 36)}...` : firstSentence;
}
