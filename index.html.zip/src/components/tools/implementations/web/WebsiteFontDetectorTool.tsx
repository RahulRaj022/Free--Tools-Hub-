import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Type, Copy, Check, AlertCircle, Loader2, RotateCcw, ExternalLink } from 'lucide-react';

interface DetectedFont {
  family: string;
  fallbacks: string[];
  weights: string[];
  isGoogleFont: boolean;
  sourceUrl?: string;
}

export const WebsiteFontDetectorTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [fonts, setFonts] = useState<DetectedFont[]>([]);
  const [previewText, setPreviewText] = useState('The quick brown fox jumps over the lazy dog 12345');
  const [fontSize, setFontSize] = useState(24);
  const [copiedFont, setCopiedFont] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const detectFonts = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setFonts([]);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to access webpage.');
      }

      const html = data.html || '';
      const detectedMap = new Map<string, DetectedFont>();

      // 1. Detect Google Fonts links
      const googleFontRegex = /href=["'](https?:\/\/fonts\.googleapis\.com\/css2?\?[^"']+)["']/gi;
      let gMatch;
      while ((gMatch = googleFontRegex.exec(html)) !== null) {
        const fontHref = gMatch[1];
        const familyParamMatch = fontHref.match(/family=([^&:]+)/);
        if (familyParamMatch) {
          const fontName = decodeURIComponent(familyParamMatch[1].replace(/\+/g, ' '));
          detectedMap.set(fontName.toLowerCase(), {
            family: fontName,
            fallbacks: ['sans-serif'],
            weights: ['400', '600', '700'],
            isGoogleFont: true,
            sourceUrl: fontHref,
          });
        }
      }

      // 2. Detect font-family declarations in CSS / inline styles
      const fontFamilyRegex = /font-family\s*:\s*([^;!}]+)/gi;
      let match;
      while ((match = fontFamilyRegex.exec(html)) !== null) {
        const rawList = match[1];
        const parts = rawList.split(',').map((p) => p.trim().replace(/^['"]|['"]$/g, ''));
        if (parts.length > 0) {
          const primaryFont = parts[0];
          // Filter generic CSS keywords
          if (
            primaryFont &&
            !['inherit', 'initial', 'unset', 'sans-serif', 'serif', 'monospace', 'system-ui', 'ui-sans-serif'].includes(
              primaryFont.toLowerCase()
            )
          ) {
            const key = primaryFont.toLowerCase();
            if (!detectedMap.has(key)) {
              detectedMap.set(key, {
                family: primaryFont,
                fallbacks: parts.slice(1),
                weights: ['400', '500', '700'],
                isGoogleFont: false,
              });
            }
          }
        }
      }

      const foundFonts = Array.from(detectedMap.values());
      if (foundFonts.length === 0) {
        setError('No explicit custom font-family or Google Fonts links were detected on this page.');
        return;
      }

      setFonts(foundFonts);
      showToast(`Detected ${foundFonts.length} font families!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error detecting fonts.');
    } finally {
      setLoading(false);
    }
  };

  const copyFontSnippet = (font: DetectedFont) => {
    const snippet = `font-family: '${font.family}', ${font.fallbacks.join(', ') || 'sans-serif'};`;
    navigator.clipboard.writeText(snippet);
    setCopiedFont(font.family);
    showToast(`Copied CSS font-family declaration!`, 'success');
    setTimeout(() => setCopiedFont(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage Address
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && detectFonts()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
          <button
            type="button"
            onClick={detectFonts}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Type className="h-4 w-4" />}
            <span>{loading ? 'Scanning...' : 'Detect Fonts'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setFonts([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {fonts.length > 0 && (
        <div className="space-y-6 animate-in fade-in">
          {/* Interactive Typography Sandbox */}
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Interactive Typography Sandbox
              </h4>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  {fontSize}px
                </span>
                <input
                  type="range"
                  min="14"
                  max="48"
                  value={fontSize}
                  onChange={(e) => setFontSize(Number(e.target.value))}
                  className="w-32 accent-indigo-600 cursor-pointer"
                />
              </div>
            </div>

            <input
              type="text"
              value={previewText}
              onChange={(e) => setPreviewText(e.target.value)}
              placeholder="Type custom text to preview..."
              className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2 text-sm text-slate-900 dark:text-white"
            />
          </div>

          {/* Detected Fonts List */}
          <div className="space-y-4">
            {fonts.map((font) => {
              const isCopied = copiedFont === font.family;
              return (
                <div
                  key={font.family}
                  className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="font-bold text-base text-slate-900 dark:text-white">
                        {font.family}
                      </span>
                      {font.isGoogleFont && (
                        <span className="px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/50 text-[10px] font-semibold text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                          Google Font
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {font.sourceUrl && (
                        <a
                          href={font.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          <span>Stylesheet</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => copyFontSnippet(font)}
                        className="flex items-center gap-1.5 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        {isCopied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                        <span>{isCopied ? 'Copied' : 'Copy CSS'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Live Rendered Sample */}
                  <div
                    className="py-3 text-slate-900 dark:text-slate-100 overflow-x-auto"
                    style={{
                      fontFamily: `"${font.family}", ${font.fallbacks.join(', ')}, sans-serif`,
                      fontSize: `${fontSize}px`,
                    }}
                  >
                    {previewText}
                  </div>

                  {/* Fallbacks & Weight tags */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-slate-500 dark:text-slate-400">
                    <span className="font-medium">Fallbacks:</span>
                    <span className="font-mono text-[11px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                      {font.fallbacks.join(', ') || 'sans-serif'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
