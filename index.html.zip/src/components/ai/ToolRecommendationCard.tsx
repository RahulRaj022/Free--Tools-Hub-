import React from 'react';
import { ArrowRight, Lightbulb, Wrench } from 'lucide-react';
import { ToolRecommendation } from '../../types/ai';

interface ToolRecommendationCardProps {
  recommendation: ToolRecommendation;
  onOpenTool: (path: string) => void;
}

export const ToolRecommendationCard: React.FC<ToolRecommendationCardProps> = ({
  recommendation,
  onOpenTool,
}) => {
  return (
    <div className="my-2.5 p-3.5 sm:p-4 rounded-2xl border border-indigo-200 dark:border-indigo-900/70 bg-gradient-to-r from-indigo-50/70 to-purple-50/50 dark:from-indigo-950/40 dark:to-purple-950/30 shadow-2xs hover:shadow-xs transition-all">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-2xs shrink-0 mt-0.5">
            <Lightbulb className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Recommended Tool
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-100 dark:bg-indigo-900/60 text-slate-600 dark:text-slate-300">
                {recommendation.category}
              </span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
              {recommendation.name}
            </h4>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2">
              {recommendation.description}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onOpenTool(recommendation.path)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-2xs shrink-0 cursor-pointer"
        >
          <span>Open Tool</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};
