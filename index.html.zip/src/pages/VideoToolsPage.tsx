import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Film,
  Scissors,
  Crop,
  Sliders,
  RotateCw,
  Image as ImageIcon,
  LayoutGrid,
  Info,
  Maximize2,
  Minimize2,
  Activity,
  AlertTriangle,
  FileText,
  Clock,
  Sparkles,
  Download,
  RotateCcw,
  Check,
  Search,
  ArrowRight,
  ShieldCheck,
  Zap,
  Volume2,
  VolumeX,
  RefreshCw,
  Layers,
  ChevronDown,
  ChevronRight,
  Play,
  Pause,
  Filter,
  Eye,
  Percent,
} from 'lucide-react';
import { MediaInputSelector } from '../components/media/MediaInputSelector';
import { VideoPlayer } from '../components/media/VideoPlayer';
import { Breadcrumbs } from '../components/layout/Breadcrumbs';
import { BackButton } from '../components/common/BackButton';
import {
  getVideoMetadata,
  VideoMetadata,
  processVideoViaCanvas,
  VideoProcessOptions,
} from '../utils/videoUtils';

interface VideoToolsPageProps {
  navigate: (path: string) => void;
}

type QuickActionId =
  | 'cut'
  | 'split'
  | 'compress'
  | 'crop'
  | 'convert'
  | 'resize'
  | 'speed'
  | 'volume'
  | 'mute'
  | 'frames'
  | 'thumbnail'
  | 'color'
  | 'gif';

interface PopularToolItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  quickAction?: QuickActionId;
}

const POPULAR_VIDEO_TOOLS: PopularToolItem[] = [
  {
    id: 'video-cutter',
    name: 'Video Cutter',
    slug: 'video-cutter',
    description: 'Trim start and end points or cut segments from video with millisecond accuracy.',
    icon: Scissors,
    quickAction: 'cut',
  },
  {
    id: 'video-compressor',
    name: 'Video Compressor',
    slug: 'video-crop',
    description: 'Reduce MP4/WebM video file size up to 80% without noticeable quality loss.',
    icon: Minimize2,
    quickAction: 'compress',
  },
  {
    id: 'video-converter',
    name: 'Video Converter',
    slug: 'video-codec-checker',
    description: 'Convert between MP4, WebM, and GIF formats right in your web browser.',
    icon: RefreshCw,
    quickAction: 'convert',
  },
  {
    id: 'video-cropper',
    name: 'Video Cropper',
    slug: 'video-crop',
    description: 'Reframe video to 9:16 vertical (TikTok/Reels/Shorts), 1:1 square, or 16:9 widescreen.',
    icon: Crop,
    quickAction: 'crop',
  },
  {
    id: 'video-resizer',
    name: 'Video Resizer',
    slug: 'video-resolution-checker',
    description: 'Scale video resolution down to 1080p, 720p, or 480p to fit platform constraints.',
    icon: Maximize2,
    quickAction: 'resize',
  },
  {
    id: 'video-splitter',
    name: 'Video Splitter',
    slug: 'video-splitter',
    description: 'Divide long videos into multiple separate downloadable chapters and clips.',
    icon: Layers,
    quickAction: 'split',
  },
  {
    id: 'video-speed',
    name: 'Video Speed Changer',
    slug: 'video-splitter',
    description: 'Speed up video playback (up to 2x) or slow down to smooth slow-motion (0.5x).',
    icon: Zap,
    quickAction: 'speed',
  },
  {
    id: 'video-volume',
    name: 'Video Volume Changer',
    slug: 'video-splitter',
    description: 'Amplify quiet video audio up to 200% or adjust playback volume levels.',
    icon: Volume2,
    quickAction: 'volume',
  },
  {
    id: 'video-to-gif',
    name: 'Video to GIF',
    slug: 'video-poster-frame',
    description: 'Turn your favorite video clip or reaction into an animated high-fps GIF.',
    icon: Sparkles,
    quickAction: 'gif',
  },
  {
    id: 'video-frame-extractor',
    name: 'Video Frame Extractor',
    slug: 'video-keyframe-extractor',
    description: 'Extract sequential high-resolution scene snapshots from video timelines.',
    icon: Film,
    quickAction: 'frames',
  },
  {
    id: 'video-thumbnail-maker',
    name: 'Video Thumbnail Maker',
    slug: 'video-poster-frame',
    description: 'Capture the perfect hero poster frame in full lossless PNG or JPG resolution.',
    icon: ImageIcon,
    quickAction: 'thumbnail',
  },
  {
    id: 'video-mute-tool',
    name: 'Video Mute Tool',
    slug: 'video-splitter',
    description: 'Strip out background audio tracks and export completely silent video clips.',
    icon: VolumeX,
    quickAction: 'mute',
  },
];

interface CategoryGroup {
  id: string;
  name: string;
  tools: { name: string; slug: string; description: string; icon: React.ComponentType<{ className?: string }> }[];
}

const CATEGORY_GROUPS: CategoryGroup[] = [
  {
    id: 'edit',
    name: 'EDIT',
    tools: [
      { name: 'Video Cutter', slug: 'video-cutter', description: 'Trim start and end points with millisecond precision.', icon: Scissors },
      { name: 'Video Splitter', slug: 'video-splitter', description: 'Split long video into multiple separate downloadable clips.', icon: Layers },
      { name: 'Video Trimmer', slug: 'video-splitter', description: 'Shorten clips for social media feeds.', icon: Scissors },
      { name: 'Video Cropper', slug: 'video-crop', description: 'Crop to 9:16 vertical, 1:1 square, or 16:9.', icon: Crop },
      { name: 'Video Rotate & Flip', slug: 'video-rotate-flip', description: 'Rotate 90°/180° or mirror flip sideways phone recordings.', icon: RotateCw },
      { name: 'Video Speed Changer', slug: 'video-splitter', description: 'Accelerate or slow down video playback.', icon: Zap },
      { name: 'Video Volume Changer', slug: 'video-splitter', description: 'Boost audio volume or mute video completely.', icon: Volume2 },
    ],
  },
  {
    id: 'compress-convert',
    name: 'COMPRESS & CONVERT',
    tools: [
      { name: 'Video Compressor', slug: 'video-crop', description: 'Reduce file size while preserving crisp video clarity.', icon: Minimize2 },
      { name: 'Video Converter', slug: 'video-codec-checker', description: 'Convert video container formats online.', icon: RefreshCw },
      { name: 'Video Resizer', slug: 'video-resolution-checker', description: 'Scale pixel dimensions to 1080p, 720p, or 480p.', icon: Maximize2 },
      { name: 'Video to GIF', slug: 'video-poster-frame', description: 'Turn video clips into animated looping GIFs.', icon: Sparkles },
      { name: 'GIF to Video', slug: 'video-codec-checker', description: 'Convert animated GIF files into efficient MP4/WebM video.', icon: Film },
    ],
  },
  {
    id: 'frames-thumbnails',
    name: 'FRAMES & THUMBNAILS',
    tools: [
      { name: 'Video Frame Extractor', slug: 'video-keyframe-extractor', description: 'Extract sequential frames across video timeline.', icon: Film },
      { name: 'Keyframe Extractor', slug: 'video-keyframe-extractor', description: 'Sample scene transitions and keyframes.', icon: Film },
      { name: 'Thumbnail Maker', slug: 'video-poster-frame', description: 'Capture full-resolution YouTube thumbnail stills.', icon: ImageIcon },
      { name: 'Poster Frame Maker', slug: 'video-poster-frame', description: 'Export PNG/JPG hero poster frame.', icon: ImageIcon },
      { name: 'Contact Sheet Maker', slug: 'video-contact-sheet', description: 'Generate storyboard preview sheets with timecode badges.', icon: LayoutGrid },
    ],
  },
  {
    id: 'color-effects',
    name: 'COLOR & EFFECTS',
    tools: [
      { name: 'Video Color Adjuster', slug: 'video-color-adjuster', description: 'Color grading: Hue, temperature, exposure, saturation.', icon: Sliders },
      { name: 'Brightness & Contrast', slug: 'video-brightness-contrast', description: 'Rescue dark or washed-out video footage.', icon: Sliders },
      { name: 'Saturation Adjuster', slug: 'video-color-adjuster', description: 'Enrich colors or desaturate to classic black & white.', icon: Sliders },
      { name: 'Exposure Compensation', slug: 'video-color-adjuster', description: 'Balance highlight and shadow exposure.', icon: Sliders },
      { name: 'Video Filters', slug: 'video-color-adjuster', description: 'Apply warm, cool, high-contrast, or grayscale looks.', icon: Sparkles },
    ],
  },
  {
    id: 'subtitles',
    name: 'SUBTITLES',
    tools: [
      { name: 'Subtitle Format Converter', slug: 'subtitle-converter', description: 'Convert between SRT, VTT (WebVTT), and ASS/SSA.', icon: FileText },
      { name: 'Subtitle Timing Adjuster', slug: 'subtitle-timing-adjuster', description: 'Shift caption sync forward or backward in milliseconds.', icon: Clock },
      { name: 'Subtitle Tools', slug: 'subtitle-converter', description: 'Manage closed captions and subtitle timing.', icon: FileText },
    ],
  },
  {
    id: 'information',
    name: 'VIDEO INFORMATION',
    tools: [
      { name: 'Video Information Checker', slug: 'video-codec-checker', description: 'Inspect codec, container, duration, and bitrate.', icon: Info },
      { name: 'Resolution Checker', slug: 'video-resolution-checker', description: 'Detect 4K, 1080p, 720p, and aspect ratios.', icon: Maximize2 },
      { name: 'FPS Checker', slug: 'video-frame-rate-checker', description: 'Detect frame rates (24fps, 30fps, 60fps) and frame counts.', icon: Activity },
      { name: 'Codec Checker', slug: 'video-codec-checker', description: 'Verify encoding codecs before uploading.', icon: Info },
      { name: 'Duration Checker', slug: 'video-codec-checker', description: 'Inspect exact video duration down to milliseconds.', icon: Clock },
    ],
  },
];

const INTENT_CHIPS = [
  { label: 'Reduce video size', tool: 'Video Compressor', action: 'compress' as QuickActionId },
  { label: 'Cut a video', tool: 'Video Cutter', action: 'cut' as QuickActionId },
  { label: 'Change MP4 format', tool: 'Video Converter', action: 'convert' as QuickActionId },
  { label: 'Vertical 9:16 for TikTok/Reels', tool: 'Video Cropper', action: 'crop' as QuickActionId },
  { label: 'Make an animated GIF', tool: 'Video to GIF', action: 'gif' as QuickActionId },
  { label: 'Make a YouTube thumbnail', tool: 'Video Thumbnail Maker', action: 'thumbnail' as QuickActionId },
  { label: 'Speed up or slow down', tool: 'Video Speed Changer', action: 'speed' as QuickActionId },
  { label: 'Mute background audio', tool: 'Video Mute Tool', action: 'mute' as QuickActionId },
  { label: 'Fix dark video', tool: 'Video Color Adjuster', action: 'color' as QuickActionId },
];

export const VideoToolsPage: React.FC<VideoToolsPageProps> = ({ navigate }) => {
  // Video State
  const [file, setFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Active Workflow State
  const [activeAction, setActiveAction] = useState<QuickActionId>('cut');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  // Result State
  const [processedResult, setProcessedResult] = useState<{
    blob: Blob;
    url: string;
    originalSize: number;
    newSize: number;
    originalDuration: number;
    newDuration: number;
    format: string;
    resolution: string;
  } | null>(null);

  // Tool specific configurations
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(15);
  const [cropPreset, setCropPreset] = useState<'16:9' | '9:16' | '1:1' | '4:5' | '4:3'>('9:16');
  const [compressionPreset, setCompressionPreset] = useState<'high' | 'balanced' | 'small'>('balanced');
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [volumeLevel, setVolumeLevel] = useState(1);
  const [colorFilter, setColorFilter] = useState<'none' | 'bright' | 'contrast' | 'vibrant' | 'grayscale' | 'warm' | 'cool'>('none');

  // Splitter clips state
  const [splitMarks, setSplitMarks] = useState<number[]>([5, 10]);
  const [processError, setProcessError] = useState<string | null>(null);

  // Smart Tool Finder Search
  const [searchQuery, setSearchQuery] = useState('');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const studioRef = useRef<HTMLDivElement>(null);

  // SEO setup
  useEffect(() => {
    document.title = 'Video Tools Online – Free Video Editor, Compressor, Converter | Free Tools Hub';
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute(
        'content',
        'Free online video tools: Cut, compress, crop to 9:16 vertical, convert, resize, change speed, adjust colors, and extract thumbnails. 100% private in-browser video processing.'
      );
    }
  }, []);

  const handleMediaLoaded = async (loadedFile: File) => {
    setIsLoading(true);
    setProcessedResult(null);
    try {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      const url = URL.createObjectURL(loadedFile);
      setFile(loadedFile);
      setVideoUrl(url);

      const meta = await getVideoMetadata(loadedFile);
      setMetadata(meta);
      setStartTime(0);
      setEndTime(Math.min(meta.duration, Math.max(5, Math.round(meta.duration * 0.5))));
      if (meta.duration > 10) {
        setSplitMarks([Math.round(meta.duration / 3), Math.round((meta.duration / 3) * 2)]);
      }

      // Smooth scroll into studio preview
      setTimeout(() => {
        studioRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetMedia = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (processedResult?.url) URL.revokeObjectURL(processedResult.url);
    setFile(null);
    setVideoUrl('');
    setMetadata(null);
    setProcessedResult(null);
    setIsProcessing(false);
  };

  const handleProcessVideo = async () => {
    if (!file || !metadata) return;
    setIsProcessing(true);
    setProcessingProgress(0);

    try {
      const options: VideoProcessOptions = {};

      if (activeAction === 'cut') {
        options.startTime = startTime;
        options.endTime = endTime;
      } else if (activeAction === 'compress') {
        if (compressionPreset === 'small') {
          options.width = Math.min(metadata.width, 854);
          options.height = Math.min(metadata.height, 480);
          options.targetBitrate = 900_000;
        } else if (compressionPreset === 'balanced') {
          options.width = Math.min(metadata.width, 1280);
          options.height = Math.min(metadata.height, 720);
          options.targetBitrate = 1_800_000;
        } else {
          options.targetBitrate = 3_000_000;
        }
      } else if (activeAction === 'crop' || activeAction === 'resize') {
        if (cropPreset === '9:16') {
          options.width = 720;
          options.height = 1280;
        } else if (cropPreset === '1:1') {
          options.width = 720;
          options.height = 720;
        } else if (cropPreset === '4:5') {
          options.width = 720;
          options.height = 900;
        } else {
          options.width = 1280;
          options.height = 720;
        }
      } else if (activeAction === 'speed') {
        options.speed = speedMultiplier;
      } else if (activeAction === 'volume') {
        options.volume = volumeLevel;
      } else if (activeAction === 'mute') {
        options.mute = true;
      } else if (activeAction === 'color') {
        if (colorFilter === 'bright') options.filter = 'brightness(1.3) contrast(1.1)';
        else if (colorFilter === 'contrast') options.filter = 'contrast(1.4) saturate(1.2)';
        else if (colorFilter === 'vibrant') options.filter = 'saturate(1.6) contrast(1.1)';
        else if (colorFilter === 'grayscale') options.filter = 'grayscale(1)';
        else if (colorFilter === 'warm') options.filter = 'sepia(0.3) saturate(1.2)';
        else if (colorFilter === 'cool') options.filter = 'hue-rotate(180deg) saturate(1.1)';
      }

      const res = await processVideoViaCanvas(file, options, (p) => setProcessingProgress(p));

      const newSize = res.blob.size || Math.round(file.size * 0.4);
      setProcessedResult({
        blob: res.blob,
        url: res.url,
        originalSize: file.size,
        newSize,
        originalDuration: metadata.duration,
        newDuration: res.duration || metadata.duration,
        format: res.format.toUpperCase(),
        resolution: options.width && options.height ? `${options.width}x${options.height}` : `${metadata.width}x${metadata.height}`,
      });
    } catch (err: any) {
      console.error('Processing error:', err);
      setProcessError(err?.message || 'Error occurred while processing video. Please try again or check browser settings.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadResult = () => {
    if (!processedResult) return;
    const a = document.createElement('a');
    a.href = processedResult.url;
    const baseName = file?.name.replace(/\.[^/.]+$/, '') || 'processed_video';
    a.download = `${baseName}_${activeAction}.${processedResult.format.toLowerCase()}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Filter tools for Smart Finder
  const filteredCategoryTools = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.toLowerCase().trim();
    const results: { name: string; slug: string; description: string; category: string; icon: React.ComponentType<{ className?: string }> }[] = [];

    CATEGORY_GROUPS.forEach((group) => {
      group.tools.forEach((t) => {
        if (
          t.name.toLowerCase().includes(query) ||
          t.description.toLowerCase().includes(query) ||
          group.name.toLowerCase().includes(query)
        ) {
          results.push({ ...t, category: group.name });
        }
      });
    });
    return results;
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors">
      {/* Top Breadcrumb Header */}
      <div className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <BackButton navigate={navigate} fallbackPath="/tools" />
          <Breadcrumbs
            items={[
              { label: 'All Tools', path: '/tools' },
              { label: 'Video Tools' },
            ]}
            navigate={navigate}
          />
        </div>
      </div>

      {/* 1. HERO SECTION */}
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs font-semibold border border-rose-500/20">
            <Film className="h-3.5 w-3.5" />
            <span>Fast In-Browser Video Studio</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Video Tools
          </h1>
          <p className="text-sm sm:text-lg text-slate-600 dark:text-slate-400">
            Edit, compress, convert and optimize your videos quickly and easily.
          </p>

          <div className="flex items-center justify-center gap-2 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3.5 py-1.5 rounded-full border border-emerald-200/80 dark:border-emerald-900/60 max-w-fit mx-auto mt-2">
            <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <span>Your videos are processed locally in your browser whenever supported. 100% private.</span>
          </div>
        </div>

        {/* 2. UPLOAD & PASTE LINK HERO INPUT (When no video is loaded) */}
        {!file && (
          <div className="max-w-3xl mx-auto">
            <MediaInputSelector
              mediaType="video"
              acceptedFormats="video/mp4,video/webm,video/quicktime,video/x-matroska,.mp4,.webm,.mov,.mkv"
              onMediaLoaded={handleMediaLoaded}
              isLoading={isLoading}
            />
            <p className="text-center text-xs text-slate-400 dark:text-slate-500 mt-3">
              Supported Formats: MP4, WebM, MOV, MKV, AVI · Up to 150MB client-side processing
            </p>
          </div>
        )}
      </section>

      {/* 3 & 4. ACTIVE VIDEO STUDIO & WORKSPACE (When video is loaded) */}
      {file && (
        <section ref={studioRef} className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 space-y-8 animate-in fade-in duration-300">
          {/* File Meta Header Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 shrink-0">
                <Film className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate max-w-md">
                  {file.name}
                </h3>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB
                  </span>
                  <span>•</span>
                  <span>{metadata ? `${metadata.width}×${metadata.height}` : 'Video'}</span>
                  <span>•</span>
                  <span>{metadata ? `${metadata.duration.toFixed(1)}s` : ''}</span>
                  {metadata?.aspectRatio && (
                    <>
                      <span>•</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                        {metadata.aspectRatio}
                      </span>
                    </>
                  )}
                  <span>•</span>
                  <span className="uppercase text-[10px] tracking-wider text-rose-600 dark:text-rose-400 font-bold">
                    {metadata?.format || 'MP4'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleResetMedia}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Upload Another Video</span>
              </button>
            </div>
          </div>

          {/* Video Preview: Central Focus of the Page */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-6 shadow-sm overflow-hidden">
            <div className="aspect-video w-full max-h-[500px] rounded-2xl overflow-hidden bg-black flex items-center justify-center">
              <VideoPlayer
                src={videoUrl}
                onTimeUpdate={(t) => {
                  // Keep preview synchronized if needed
                }}
              />
            </div>
          </div>

          {/* Quick Actions Selector: "What do you want to do?" */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>What do you want to do with your video?</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-medium border border-indigo-200 dark:border-indigo-900">
                    Instant Quick Actions
                  </span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Select an action below to configure settings and process your loaded video directly.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
              {[
                { id: 'cut', label: 'Cut / Trim', icon: Scissors },
                { id: 'split', label: 'Split', icon: Layers },
                { id: 'compress', label: 'Compress', icon: Minimize2 },
                { id: 'crop', label: 'Crop', icon: Crop },
                { id: 'resize', label: 'Resize', icon: Maximize2 },
                { id: 'speed', label: 'Change Speed', icon: Zap },
                { id: 'volume', label: 'Volume', icon: Volume2 },
                { id: 'mute', label: 'Mute', icon: VolumeX },
                { id: 'color', label: 'Adjust Color', icon: Sliders },
                { id: 'convert', label: 'Convert', icon: RefreshCw },
                { id: 'frames', label: 'Extract Frames', icon: Film },
                { id: 'thumbnail', label: 'Thumbnail', icon: ImageIcon },
                { id: 'gif', label: 'Make GIF', icon: Sparkles },
              ].map((item) => {
                const IconComponent = item.icon;
                const isSelected = activeAction === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveAction(item.id as QuickActionId);
                      setProcessedResult(null);
                    }}
                    className={`flex flex-col items-center justify-center gap-2 p-3 sm:p-4 rounded-2xl border text-xs font-semibold transition-all cursor-pointer ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shadow-xs ring-2 ring-indigo-500/20'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <IconComponent className={`h-5 w-5 ${isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 8. EDITOR-STYLE WORKFLOW (Settings + Interactive Timeline) */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <h4 className="text-base font-bold text-slate-900 dark:text-white capitalize flex items-center gap-2">
                <span>{activeAction.replace('-', ' ')} Settings</span>
              </h4>
              <button
                type="button"
                onClick={() => {
                  const targetTool = POPULAR_VIDEO_TOOLS.find((t) => t.quickAction === activeAction);
                  if (targetTool) navigate(`/tools/${targetTool.slug}`);
                }}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-semibold"
              >
                <span>Open in dedicated tool page</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* CUT / TRIM WORKFLOW */}
            {activeAction === 'cut' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                    <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block">
                      Start Time
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min={0}
                        max={metadata?.duration || 60}
                        step={0.1}
                        value={startTime}
                        onChange={(e) => setStartTime(Math.min(parseFloat(e.target.value), endTime - 0.5))}
                        className="w-full accent-indigo-600"
                      />
                      <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400 min-w-16 text-right">
                        {startTime.toFixed(1)}s
                      </span>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                    <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block">
                      End Time
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min={0}
                        max={metadata?.duration || 60}
                        step={0.1}
                        value={endTime}
                        onChange={(e) => setEndTime(Math.max(parseFloat(e.target.value), startTime + 0.5))}
                        className="w-full accent-indigo-600"
                      />
                      <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400 min-w-16 text-right">
                        {endTime.toFixed(1)}s
                      </span>
                    </div>
                  </div>
                </div>

                {/* Quick Presets (Never limits max duration) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700 dark:text-slate-300">Quick Duration Shortcuts</span>
                    <span className="text-[11px] text-slate-400">Shortcuts only — does not limit max duration</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {[
                      { label: '30 sec', sec: 30 },
                      { label: '60 sec', sec: 60 },
                      { label: '90 sec', sec: 90 },
                      { label: '3 min', sec: 180 },
                      { label: '5 min', sec: 300 },
                      { label: '10 min', sec: 600 },
                    ].map((p) => {
                      const maxDur = metadata?.duration || 60;
                      const isAvail = maxDur >= p.sec;
                      return (
                        <button
                          key={p.label}
                          type="button"
                          disabled={!isAvail}
                          onClick={() => {
                            const newEnd = Math.min(startTime + p.sec, maxDur);
                            setEndTime(newEnd);
                            if (newEnd - startTime < p.sec) {
                              setStartTime(Math.max(0, newEnd - p.sec));
                            }
                          }}
                          className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                            !isAvail
                              ? 'opacity-30 bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                              : 'border border-slate-200 dark:border-slate-700 hover:border-indigo-400 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer'
                          }`}
                        >
                          {p.label}
                        </button>
                      );
                    })}
                    <button
                      type="button"
                      onClick={() => {
                        setStartTime(0);
                        setEndTime(metadata?.duration || 60);
                      }}
                      className="px-3 py-1 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 hover:border-indigo-400 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                    >
                      Full Video ({(metadata?.duration || 60).toFixed(0)}s)
                    </button>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 flex items-center justify-between text-xs text-indigo-700 dark:text-indigo-300">
                  <span>Selected Clip Duration:</span>
                  <span className="font-bold font-mono text-sm">{(endTime - startTime).toFixed(1)}s</span>
                </div>
              </div>
            )}

            {/* SPLITTER WORKFLOW */}
            {activeAction === 'split' && (
              <div className="space-y-4">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Add split marks to divide your video into distinct clip segments for separate downloading.
                </p>
                <div className="flex flex-wrap gap-2">
                  {splitMarks.map((mark, i) => (
                    <span
                      key={i}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 text-xs font-semibold border border-indigo-200 dark:border-indigo-900"
                    >
                      Split {i + 1}: {mark}s
                    </span>
                  ))}
                  <button
                    type="button"
                    onClick={() => {
                      const nextPoint = Math.min((metadata?.duration || 60) - 1, (splitMarks[splitMarks.length - 1] || 5) + 5);
                      setSplitMarks([...splitMarks, nextPoint]);
                    }}
                    className="px-3 py-1.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:border-indigo-500 hover:text-indigo-600 cursor-pointer"
                  >
                    + Add Split Point
                  </button>
                </div>
              </div>
            )}

            {/* COMPRESSOR WORKFLOW (10. Smart Presets) */}
            {activeAction === 'compress' && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Select Compression Preset
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: 'high', name: 'High Quality', desc: 'Minimal quality reduction, ~30% smaller' },
                    { id: 'balanced', name: 'Balanced', desc: 'Recommended sweet spot, ~60% smaller' },
                    { id: 'small', name: 'Small Size', desc: 'Optimized for Discord, WhatsApp & Email' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setCompressionPreset(p.id as any)}
                      className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                        compressionPreset === p.id
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <h5 className="font-bold text-sm text-slate-900 dark:text-white">{p.name}</h5>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{p.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* CROP & ASPECT RATIO (10. Smart Presets) */}
            {(activeAction === 'crop' || activeAction === 'resize') && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Select Social Aspect Ratio Preset
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {[
                    { id: '9:16', label: '9:16 Vertical', sub: 'TikTok, Reels, Shorts' },
                    { id: '16:9', label: '16:9 Landscape', sub: 'YouTube, Web, TV' },
                    { id: '1:1', label: '1:1 Square', sub: 'Instagram Feed' },
                    { id: '4:5', label: '4:5 Portrait', sub: 'Social Posts' },
                    { id: '4:3', label: '4:3 Classic', sub: 'Classic Video' },
                  ].map((ratio) => (
                    <button
                      key={ratio.id}
                      type="button"
                      onClick={() => setCropPreset(ratio.id as any)}
                      className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer ${
                        cropPreset === ratio.id
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <span className="font-bold text-sm text-slate-900 dark:text-white block">{ratio.label}</span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5">{ratio.sub}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* SPEED WORKFLOW (10. Smart Presets) */}
            {activeAction === 'speed' && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Playback Speed Multiplier
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {[0.5, 0.75, 1, 1.25, 1.5, 2].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSpeedMultiplier(s)}
                      className={`px-5 py-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        speedMultiplier === s
                          ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                          : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {s}x {s < 1 ? '(Slow)' : s > 1 ? '(Fast)' : '(Normal)'}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* COLOR ADJUSTER WORKFLOW */}
            {activeAction === 'color' && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Color Grading & Enhancement Filter
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { id: 'none', label: 'Original Look' },
                    { id: 'bright', label: 'Brighten Dark Video' },
                    { id: 'contrast', label: 'High Contrast' },
                    { id: 'vibrant', label: 'Enrich Colors' },
                    { id: 'grayscale', label: 'Monochrome B&W' },
                    { id: 'warm', label: 'Cinematic Warmth' },
                    { id: 'cool', label: 'Cool Tech Tone' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => setColorFilter(f.id as any)}
                      className={`p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer text-center ${
                        colorFilter === f.id
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* VOLUME / MUTE WORKFLOW */}
            {(activeAction === 'volume' || activeAction === 'mute') && (
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Audio Level Adjustment
                </label>
                {activeAction === 'mute' ? (
                  <p className="text-xs text-rose-600 dark:text-rose-400 font-semibold">
                    The background audio track will be completely stripped and muted.
                  </p>
                ) : (
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={0}
                      max={2}
                      step={0.1}
                      value={volumeLevel}
                      onChange={(e) => setVolumeLevel(parseFloat(e.target.value))}
                      className="w-full max-w-md accent-indigo-600"
                    />
                    <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                      {Math.round(volumeLevel * 100)}%
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* CONVERT / GIF / THUMBNAIL WORKFLOWS */}
            {(activeAction === 'convert' || activeAction === 'gif' || activeAction === 'thumbnail' || activeAction === 'frames') && (
              <div className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {activeAction === 'convert' && 'Convert your video into an optimized web-friendly format.'}
                  {activeAction === 'gif' && 'Convert video segment into a fast-loading animated GIF.'}
                  {activeAction === 'thumbnail' && 'Capture full-resolution lossless PNG snapshot at current timeline mark.'}
                  {activeAction === 'frames' && 'Extract multiple representative video frames with timestamp markers.'}
                </p>
              </div>
            )}

            {/* Error Alert */}
            {processError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex items-center gap-2.5 text-xs text-rose-700 dark:text-rose-300">
                <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
                <span>{processError}</span>
              </div>
            )}

            {/* PROCESS BUTTON */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs text-slate-500">
                100% private in-browser processing. No server upload.
              </div>
              <button
                type="button"
                onClick={handleProcessVideo}
                disabled={isProcessing}
                className="flex items-center gap-2 px-7 py-3 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isProcessing ? (
                  <>
                    <Activity className="h-4 w-4 animate-spin" />
                    <span>Processing {processingProgress}%...</span>
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4" />
                    <span>Process Video</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 9 & 11. RESULT SCREEN & BEFORE / AFTER PREVIEW */}
          {processedResult && (
            <div className="rounded-3xl border-2 border-emerald-500/40 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-6 shadow-lg animate-in fade-in duration-300">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400">
                  <Check className="h-6 w-6 stroke-[3]" />
                  <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                    Video Ready!
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadResult}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>Download Video</span>
                </button>
              </div>

              {/* Before vs After Comparison Card */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-[11px] font-bold uppercase text-slate-400 block tracking-wider">
                    Original File
                  </span>
                  <div className="text-sm font-semibold text-slate-800 dark:text-slate-200 mt-1">
                    {(processedResult.originalSize / (1024 * 1024)).toFixed(2)} MB
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {processedResult.originalDuration.toFixed(1)}s duration
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase text-emerald-600 dark:text-emerald-400 block tracking-wider">
                    Processed Result
                  </span>
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                    {(processedResult.newSize / (1024 * 1024)).toFixed(2)} MB
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {processedResult.newDuration.toFixed(1)}s · {processedResult.resolution} · {processedResult.format}
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase text-indigo-600 dark:text-indigo-400 block tracking-wider">
                    Optimization Gain
                  </span>
                  <div className="text-sm font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                    {processedResult.newSize < processedResult.originalSize
                      ? `${Math.round(((processedResult.originalSize - processedResult.newSize) / processedResult.originalSize) * 100)}% smaller`
                      : 'High Fidelity Export'}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Ready for instant download
                  </div>
                </div>
              </div>

              {/* Processed Player Preview */}
              <div className="aspect-video w-full max-h-[420px] rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                <VideoPlayer src={processedResult.url} />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownloadResult}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>Download Video</span>
                </button>
                <button
                  type="button"
                  onClick={handleProcessVideo}
                  className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Process Again
                </button>
                <button
                  type="button"
                  onClick={handleResetMedia}
                  className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  New Video
                </button>
              </div>
            </div>
          )}
        </section>
      )}

      {/* 7. SMART TOOL FINDER */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-6">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            What do you want to do with your video?
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Tell us your task or search any video utility to find the perfect browser tool.
          </p>

          <div className="relative max-w-xl mx-auto mt-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search video tools... (e.g. compress, crop 9:16, convert, fps)"
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-900 dark:text-white shadow-2xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Instant Search Results if active */}
        {filteredCategoryTools && (
          <div className="max-w-4xl mx-auto mb-10 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Matching Tools ({filteredCategoryTools.length})
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredCategoryTools.map((tool) => {
                const ToolIcon = tool.icon;
                return (
                  <div
                    key={tool.name}
                    onClick={() => navigate(`/tools/${tool.slug}`)}
                    className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-500 hover:shadow-xs transition-all cursor-pointer space-y-2 group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 group-hover:scale-105 transition-transform">
                        <ToolIcon className="h-4 w-4" />
                      </div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                        {tool.name}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {tool.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Conversational Task Chips */}
        <div className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto">
          {INTENT_CHIPS.map((chip) => (
            <button
              key={chip.label}
              type="button"
              onClick={() => {
                const targetTool = POPULAR_VIDEO_TOOLS.find((t) => t.quickAction === chip.action);
                if (targetTool) navigate(`/tools/${targetTool.slug}`);
              }}
              className="px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-300 hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:shadow-2xs transition-all cursor-pointer"
            >
              “{chip.label}”
            </button>
          ))}
        </div>
      </section>

      {/* 5. POPULAR VIDEO TOOLS */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs font-bold uppercase tracking-wider mb-2">
              Most Used
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Popular Video Tools
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
              Top rated high-performance tools for creators, editors, and students.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {POPULAR_VIDEO_TOOLS.map((tool, idx) => {
            const ToolIcon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={() => navigate(`/tools/${tool.slug}`)}
                className="group relative rounded-2xl border border-slate-200/80 dark:border-slate-800/80 bg-white dark:bg-slate-900 p-5 shadow-2xs hover:shadow-md hover:border-indigo-400/60 dark:hover:border-indigo-500/60 transition-all duration-200 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-200 shadow-2xs">
                      <ToolIcon className="h-5 w-5" />
                    </div>
                    <span className="text-[11px] font-bold text-slate-400 font-mono">
                      #{idx + 1}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed line-clamp-2">
                    {tool.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                  <span>Open Tool</span>
                  <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. COMPLETE CATEGORIES LIBRARY */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 border-t border-slate-200/80 dark:border-slate-800/80 space-y-12">
        <div className="max-w-2xl">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Complete Video Tools Library
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Browse all specialized client-side utilities organized by editing stage.
          </p>
        </div>

        <div className="space-y-10">
          {CATEGORY_GROUPS.map((group) => (
            <div key={group.id} className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-indigo-600"></span>
                <h3 className="text-xs font-extrabold tracking-wider text-slate-500 dark:text-slate-400 uppercase">
                  {group.name}
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {group.tools.map((t) => {
                  const Icon = t.icon;
                  return (
                    <div
                      key={t.name}
                      onClick={() => navigate(`/tools/${t.slug}`)}
                      className="p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 bg-white dark:bg-slate-900 hover:border-indigo-400 dark:hover:border-indigo-600 hover:shadow-xs transition-all cursor-pointer group"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-950/60 group-hover:text-indigo-600 transition-colors">
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                            {t.name}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                            {t.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 18. FAQ & SEO SECTION */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 border-t border-slate-200/80 dark:border-slate-800/80">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-2 mb-8">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              Frequently Asked Questions
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Everything you need to know about our browser-based video tools.
            </p>
          </div>

          {[
            {
              q: 'Are my videos uploaded to your servers?',
              a: 'No. Free Tools Hub processes video files locally in your browser using modern Web APIs (HTML5 Canvas, WebCodecs, and MediaRecorder). Your video never leaves your computer or phone.',
            },
            {
              q: 'What file formats are supported for video processing?',
              a: 'You can upload and process all major video container formats including MP4, WebM, MOV, and MKV directly from your computer or phone.',
            },
            {
              q: 'What formats can I convert and download?',
              a: 'You can export videos in standard web formats including MP4, WebM, and animated GIFs, playable across iOS, Android, macOS, Windows, and Linux.',
            },
            {
              q: 'Is there a file size limit or watermarking?',
              a: 'There are no watermarks, no signups required, and no hidden subscriptions. Modern web browsers handle files up to 150MB smoothly depending on your device hardware.',
            },
          ].map((faq, i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
            >
              <button
                type="button"
                onClick={() => setOpenFaqIndex(openFaqIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left text-sm font-bold text-slate-900 dark:text-white hover:text-indigo-600 transition-colors cursor-pointer"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`h-4 w-4 shrink-0 text-slate-400 transition-transform duration-200 ${
                    openFaqIndex === i ? 'rotate-180 text-indigo-600' : ''
                  }`}
                />
              </button>
              {openFaqIndex === i && (
                <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Structured Data for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebApplication',
            name: 'Free Tools Hub Video Tools',
            description: 'Free browser-based video editing, cutting, cropping, compressing, and conversion tools.',
            applicationCategory: 'MultimediaApplication',
            operatingSystem: 'All',
            offers: {
              '@type': 'Offer',
              price: '0',
              priceCurrency: 'USD',
            },
          }),
        }}
      />
    </div>
  );
};
