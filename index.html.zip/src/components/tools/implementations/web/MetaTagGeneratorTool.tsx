import React, { useState, useMemo } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Tags, Copy, Check, Download, Eye, Globe } from 'lucide-react';

export const MetaTagGeneratorTool: React.FC = () => {
  const { showToast } = useTools();
  const [title, setTitle] = useState('Free Tools Hub – 100% Free Online Toolkit');
  const [description, setDescription] = useState(
    'Powerful browser-based tools for PDF, images, text, calculators, developers, and everyday tasks. No sign up required.'
  );
  const [keywords, setKeywords] = useState('free online tools, pdf tools, web tools, calculators');
  const [author, setAuthor] = useState('Free Tools Hub');
  const [canonicalUrl, setCanonicalUrl] = useState('https://freetoolshub.com');
  const [ogImageUrl, setOgImageUrl] = useState('https://freetoolshub.com/og-image.png');
  const [twitterHandle, setTwitterHandle] = useState('@freetoolshub');
  const [robotsIndex, setRobotsIndex] = useState('index');
  const [robotsFollow, setRobotsFollow] = useState('follow');
  const [themeColor, setThemeColor] = useState('#4f46e5');
  const [copied, setCopied] = useState(false);

  const generatedHtml = useMemo(() => {
    return `<!-- Primary Meta Tags -->
<title>${title}</title>
<meta name="title" content="${title}">
<meta name="description" content="${description}">
<meta name="keywords" content="${keywords}">
<meta name="author" content="${author}">
<meta name="robots" content="${robotsIndex}, ${robotsFollow}">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="${themeColor}">
<link rel="canonical" href="${canonicalUrl}">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="${canonicalUrl}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:image" content="${ogImageUrl}">

<!-- Twitter / X -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="${canonicalUrl}">
<meta property="twitter:title" content="${title}">
<meta property="twitter:description" content="${description}">
<meta property="twitter:image" content="${ogImageUrl}">
<meta property="twitter:site" content="${twitterHandle}">`;
  }, [
    title,
    description,
    keywords,
    author,
    canonicalUrl,
    ogImageUrl,
    twitterHandle,
    robotsIndex,
    robotsFollow,
    themeColor,
  ]);

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedHtml);
    setCopied(true);
    showToast('HTML meta tags copied!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const fullDoc = `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n${generatedHtml
      .split('\n')
      .map((l) => '  ' + l)
      .join('\n')}\n</head>\n<body>\n  <!-- Your page content here -->\n</body>\n</html>`;
    const blob = new Blob([fullDoc], { type: 'text/html' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = 'meta-tags.html';
    a.click();
    URL.revokeObjectURL(u);
    showToast('meta-tags.html downloaded!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3.5">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Page Title (Max 60 chars)
                </label>
                <span className={`text-[11px] font-mono ${title.length > 60 ? 'text-amber-500 font-bold' : 'text-slate-400'}`}>
                  {title.length}/60
                </span>
              </div>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Meta Description (Max 160 chars)
                </label>
                <span className={`text-[11px] font-mono ${description.length > 160 ? 'text-amber-500 font-bold' : 'text-slate-400'}`}>
                  {description.length}/160
                </span>
              </div>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Canonical URL
                </label>
                <input
                  type="text"
                  value={canonicalUrl}
                  onChange={(e) => setCanonicalUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Author
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  OG Image URL (1200x630)
                </label>
                <input
                  type="text"
                  value={ogImageUrl}
                  onChange={(e) => setOgImageUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Twitter / X Handle
                </label>
                <input
                  type="text"
                  value={twitterHandle}
                  onChange={(e) => setTwitterHandle(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Indexing
                </label>
                <select
                  value={robotsIndex}
                  onChange={(e) => setRobotsIndex(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                >
                  <option value="index">index</option>
                  <option value="noindex">noindex</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Following
                </label>
                <select
                  value={robotsFollow}
                  onChange={(e) => setRobotsFollow(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                >
                  <option value="follow">follow</option>
                  <option value="nofollow">nofollow</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Theme Color
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={themeColor}
                    onChange={(e) => setThemeColor(e.target.value)}
                    className="h-8 w-8 rounded-lg cursor-pointer border-0 p-0"
                  />
                  <input
                    type="text"
                    value={themeColor}
                    onChange={(e) => setThemeColor(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2 py-1 text-xs font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Output & Previews */}
        <div className="lg:col-span-6 space-y-4">
          {/* Simulated Google Search Snippet */}
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Globe className="h-3.5 w-3.5" />
              Google Search Snippet Preview
            </span>
            <div className="space-y-1 font-sans">
              <div className="text-xs text-emerald-700 dark:text-emerald-400 truncate">
                {canonicalUrl || 'https://example.com'}
              </div>
              <div className="text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer line-clamp-1">
                {title || 'Page Title'}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                {description || 'Page description will appear here as a snippet for search engine users.'}
              </div>
            </div>
          </div>

          {/* HTML Code Output */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Generated &lt;head&gt; Markup
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy HTML'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download .html</span>
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-100 p-4 font-mono text-xs overflow-x-auto max-h-[360px] scrollbar-thin">
              <pre>{generatedHtml}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
