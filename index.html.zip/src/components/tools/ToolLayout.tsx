import React, { useEffect, useState } from 'react';
import { ToolItem } from '../../types';
import { Breadcrumbs } from '../layout/Breadcrumbs';
import { BackButton } from '../common/BackButton';
import { ToolCard } from './ToolCard';
import { ToolAppIcon } from '../common/ToolAppIcon';
import { useTools } from '../../context/ToolsContext';
import { TextTools } from './implementations/TextTools';
import { Calculators } from './implementations/Calculators';
import { DeveloperTools } from './implementations/DeveloperTools';
import { SecurityTools } from './implementations/SecurityTools';
import { StudentTools } from './implementations/StudentTools';
import { ImageTools } from './implementations/ImageTools';
import { PdfTools } from './implementations/PdfTools';
import { QrCodeTool } from './implementations/QrCodeTool';
import { DesignTools } from './implementations/DesignTools';
import { DataTools } from './implementations/DataTools';
import { SeoTools } from './implementations/SeoTools';
import { FinanceTools } from './implementations/FinanceTools';
import { ProductivityTools } from './implementations/ProductivityTools';
import { SocialTools } from './implementations/SocialTools';
import { EducationTools } from './implementations/EducationTools';
import { SmartTools } from './implementations/SmartTools';
import { AdvancedPdfTools } from './implementations/AdvancedPdfTools';
import { VideoTools } from './implementations/VideoTools';
import { AudioTools } from './implementations/AudioTools';
import { WebTools } from './implementations/WebTools';
import { FloatingAskAI } from '../ai/FloatingAskAI';
import { QuickTipTooltip } from './QuickTipTooltip';
import { Star, ChevronDown, ChevronUp, ShieldCheck, Zap, Clock, Check } from 'lucide-react';
import { TOOLS_DATA, CATEGORIES } from '../../data/toolsData';

interface ToolLayoutProps {
  tool: ToolItem;
  navigate: (path: string) => void;
}

export const ToolLayout: React.FC<ToolLayoutProps> = ({ tool, navigate }) => {
  const { isFavorite, toggleFavorite, addRecentTool } = useTools();
  const favorited = isFavorite(tool.id);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Track recent tool and update SEO document title & meta description dynamically
  useEffect(() => {
    addRecentTool(tool.id);

    // Update document title
    document.title = tool.seoTitle;

    // Update meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', tool.seoDescription);
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [tool.id, tool.seoTitle, tool.seoDescription, addRecentTool]);

  const categoryInfo = CATEGORIES.find((c) => c.id === tool.category);
  const categoryPath = categoryInfo ? `/${categoryInfo.slug}` : '/tools';

  // Find related tools
  const relatedTools = TOOLS_DATA.filter((t) => tool.relatedSlugs.includes(t.slug) && t.id !== tool.id).slice(0, 3);

  // Render the appropriate functional tool component
  const renderToolComponent = () => {
    if (
      tool.category === 'web' ||
      tool.slug === 'website-screenshot' ||
      tool.slug === 'website-color-extractor' ||
      tool.slug === 'website-font-detector' ||
      tool.slug === 'website-link-checker' ||
      tool.slug === 'sitemap-generator' ||
      tool.slug === 'robots-generator' ||
      tool.slug === 'canonical-url-generator' ||
      tool.slug === 'open-graph-preview' ||
      tool.slug === 'html-live-preview' ||
      tool.slug === 'http-status-checker' ||
      tool.slug === 'redirect-checker' ||
      tool.slug === 'dns-lookup' ||
      tool.slug === 'ssl-checker' ||
      tool.slug === 'website-technology-detector' ||
      tool.slug === 'website-word-counter' ||
      tool.slug === 'website-accessibility-checker' ||
      tool.slug === 'website-performance' ||
      tool.slug === 'broken-image-checker' ||
      tool.slug === 'link-extractor' ||
      tool.slug === 'meta-tag-generator'
    ) {
      return <WebTools toolSlug={tool.slug} />;
    }

    if (tool.slug === 'qr-code-generator') {
      return <QrCodeTool />;
    }

    if (
      tool.slug === 'word-counter' ||
      tool.slug === 'character-counter' ||
      tool.slug === 'case-converter' ||
      tool.slug === 'remove-extra-spaces' ||
      tool.slug === 'text-reverser' ||
      tool.slug === 'slug-generator' ||
      tool.slug === 'lorem-ipsum-generator' ||
      tool.slug === 'text-sorter' ||
      tool.slug === 'duplicate-line-remover'
    ) {
      return <TextTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'percentage-calculator' ||
      tool.slug === 'age-calculator' ||
      tool.slug === 'discount-calculator' ||
      tool.slug === 'bmi-calculator' ||
      tool.slug === 'tip-calculator' ||
      tool.slug === 'average-calculator' ||
      tool.slug === 'gpa-calculator' ||
      tool.slug === 'unit-converter' ||
      tool.slug === 'ratio-calculator' ||
      tool.slug === 'simple-interest-calculator' ||
      tool.slug === 'compound-interest-calculator'
    ) {
      return <Calculators toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'json-formatter' ||
      tool.slug === 'base64-encoder' ||
      tool.slug === 'url-encoder-decoder' ||
      tool.slug === 'uuid-generator' ||
      tool.slug === 'hash-generator' ||
      tool.slug === 'timestamp-converter' ||
      tool.slug === 'color-converter' ||
      tool.slug === 'regex-tester'
    ) {
      return <DeveloperTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'password-generator' ||
      tool.slug === 'password-strength-checker' ||
      tool.slug === 'random-string-generator'
    ) {
      return <SecurityTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'pomodoro-timer' ||
      tool.slug === 'random-number-generator'
    ) {
      return <StudentTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'image-compressor' ||
      tool.slug === 'image-resizer' ||
      tool.slug === 'image-cropper' ||
      tool.slug === 'jpg-to-png' ||
      tool.slug === 'png-to-jpg' ||
      tool.slug === 'webp-converter' ||
      tool.slug === 'image-effects'
    ) {
      return <ImageTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'pdf-merger' ||
      tool.slug === 'pdf-splitter' ||
      tool.slug === 'jpg-to-pdf' ||
      tool.slug === 'pdf-to-jpg' ||
      tool.slug === 'pdf-compressor'
    ) {
      return <PdfTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'color-palette-generator' ||
      tool.slug === 'contrast-checker' ||
      tool.slug === 'gradient-generator' ||
      tool.slug === 'box-shadow-generator' ||
      tool.slug === 'color-shades-generator'
    ) {
      return <DesignTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'csv-to-json' ||
      tool.slug === 'json-to-csv' ||
      tool.slug === 'csv-viewer-filter' ||
      tool.slug === 'xml-to-json' ||
      tool.slug === 'json-to-xml' ||
      tool.slug === 'yaml-json-converter'
    ) {
      return <DataTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'meta-tag-generator' ||
      tool.slug === 'robots-txt-generator' ||
      tool.slug === 'xml-sitemap-generator' ||
      tool.slug === 'open-graph-previewer' ||
      tool.slug === 'keyword-density-checker'
    ) {
      return <SeoTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'loan-mortgage-calculator' ||
      tool.slug === 'sales-tax-vat-calculator' ||
      tool.slug === 'roi-calculator' ||
      tool.slug === 'break-even-calculator' ||
      tool.slug === 'salary-hourly-calculator'
    ) {
      return <FinanceTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'world-clock-converter' ||
      tool.slug === 'stopwatch-timer' ||
      tool.slug === 'event-countdown-timer' ||
      tool.slug === 'work-hours-calculator'
    ) {
      return <ProductivityTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'youtube-thumbnail-grabber' ||
      tool.slug === 'social-post-formatter' ||
      tool.slug === 'hashtag-generator' ||
      tool.slug === 'bio-link-generator'
    ) {
      return <SocialTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'roman-numeral-converter' ||
      tool.slug === 'morse-code-translator' ||
      tool.slug === 'binary-text-converter' ||
      tool.slug === 'fraction-calculator'
    ) {
      return <EducationTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'headline-analyzer' ||
      tool.slug === 'ai-prompt-generator' ||
      tool.slug === 'text-summarizer'
    ) {
      return <SmartTools toolSlug={tool.slug} />;
    }

    if (
      tool.slug === 'pdf-to-word' ||
      tool.slug === 'word-to-pdf' ||
      tool.slug === 'pdf-page-rotator' ||
      tool.slug === 'pdf-page-numberer' ||
      tool.slug === 'pdf-watermark'
    ) {
      return <AdvancedPdfTools toolSlug={tool.slug} />;
    }

    if (tool.category === 'video') {
      return <VideoTools toolSlug={tool.slug} />;
    }

    if (tool.category === 'audio') {
      return <AudioTools toolSlug={tool.slug} />;
    }

    return null;
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Top Navigation Row: Back Button & Breadcrumbs */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <BackButton navigate={navigate} fallbackPath={categoryPath} />
        <Breadcrumbs
          items={[
            { label: categoryInfo?.name || 'Tools', path: categoryPath },
            { label: tool.name },
          ]}
          navigate={navigate}
        />
      </div>

      {/* Tool Header */}
      <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200/80 pb-6 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-4">
            <ToolAppIcon
              slug={tool.slug}
              category={tool.category}
              size="xl"
              alt={tool.name}
              interactive={false}
            />
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                {tool.name}
              </h1>
              <div className="mt-1 flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                <span>{categoryInfo?.name}</span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  100% Private (Runs in Browser)
                </span>
                <span aria-hidden="true">·</span>
                <span>No Signup Required</span>
              </div>
            </div>
          </div>
          <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 max-w-3xl leading-relaxed">
            {tool.description}
          </p>
        </div>

        {/* Action Controls: Quick Tip Tooltip & Favorites */}
        <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0">
          <QuickTipTooltip toolSlug={tool.slug} fallbackTip={tool.quickTip} />
          <button
            onClick={() => toggleFavorite(tool.id)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors ${
              favorited
                ? 'border-amber-200 bg-amber-50 text-amber-600 dark:border-amber-900/60 dark:bg-amber-950/40'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
            }`}
          >
            <Star className={`h-4 w-4 ${favorited ? 'fill-amber-500 text-amber-500' : ''}`} />
            <span>{favorited ? 'Favorited' : 'Add to Favorites'}</span>
          </button>
        </div>
      </div>

      {/* Main Tool Workspace */}
      <div className="mb-14">
        {renderToolComponent()}
      </div>

      {/* SEO & Instructional Content Sections */}
      <div className="mt-16 space-y-12 border-t border-slate-200/80 pt-12 dark:border-slate-800">
        
        {/* How to use */}
        <section>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-6">
            How to use {tool.name}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {tool.steps.map((step, idx) => (
              <div
                key={idx}
                className="p-5 rounded-xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs"
              >
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 font-mono font-bold text-xs mb-3">
                  0{idx + 1}
                </div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-1.5">
                  {step.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Features list */}
        <section className="rounded-2xl border border-slate-200/80 bg-white p-6 sm:p-8 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
            Key Features of {tool.name}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {tool.features.map((feat, idx) => (
              <div key={idx} className="flex items-center gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                  <Check className="h-3 w-3" />
                </div>
                <span>{feat}</span>
              </div>
            ))}
          </div>
        </section>

        {/* FAQs */}
        {tool.faqs.length > 0 && (
          <section>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
              Frequently Asked Questions
            </h2>
            <div className="divide-y divide-slate-200/80 dark:divide-slate-800 rounded-xl border border-slate-200/80 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs">
              {tool.faqs.map((faq, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div key={idx} className="p-4 sm:p-5">
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="flex w-full items-center justify-between text-left gap-4"
                    >
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">
                        {faq.question}
                      </span>
                      {isOpen ? (
                        <ChevronUp className="h-4 w-4 text-slate-400 shrink-0" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-slate-400 shrink-0" />
                      )}
                    </button>
                    {isOpen && (
                      <p className="mt-3 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed pr-6">
                        {faq.answer}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Related Tools */}
        {relatedTools.length > 0 && (
          <section>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
              Related Online Tools
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {relatedTools.map((relTool) => (
                <ToolCard
                  key={relTool.id}
                  tool={relTool}
                  onSelect={(slug) => navigate(`/tools/${slug}`)}
                  compact
                />
              ))}
            </div>
          </section>
        )}

      </div>

      {/* Floating Contextual AI Assistant Button & Slide-over Drawer */}
      <FloatingAskAI tool={tool} navigate={navigate} />
    </div>
  );
};
