import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Scissors,
  Play,
  Pause,
  RotateCcw,
  Download,
  Check,
  Clock,
  Sparkles,
  Layers,
  Trash2,
  Eye,
  Sliders,
  Maximize2,
  Volume2,
  VolumeX,
  ShieldCheck,
  AlertCircle,
  Film,
} from 'lucide-react';
import { MediaInputSelector } from '../../media/MediaInputSelector';
import {
  getVideoMetadata,
  VideoMetadata,
  processVideoViaCanvas,
} from '../../../utils/videoUtils';

interface VideoSegment {
  id: string;
  name: string;
  start: number;
  end: number;
  duration: number;
  resultUrl?: string;
  isProcessing?: boolean;
}

const PRESET_DURATIONS = [
  { label: '30 sec', seconds: 30 },
  { label: '60 sec', seconds: 60 },
  { label: '90 sec', seconds: 90 },
  { label: '3 min', seconds: 180 },
  { label: '5 min', seconds: 300 },
  { label: '10 min', seconds: 600 },
];

export function formatTimeCode(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds < 0) return '00:00:00';
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = Math.floor(totalSeconds % 60);
  return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export function parseTimeCode(timeStr: string): number | null {
  if (!timeStr || !timeStr.trim()) return null;
  const parts = timeStr.trim().split(':').map((p) => parseFloat(p));
  if (parts.some((p) => isNaN(p))) return null;
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  }
  if (parts.length === 1) {
    return parts[0];
  }
  return null;
}

export const VideoCutterTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Playback state
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  // Cutting range state
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const [activePreset, setActivePreset] = useState<string>('Custom');
  const [validationError, setValidationError] = useState<string | null>(null);

  // Formatted string inputs for precision typing
  const [startTimeInput, setStartTimeInput] = useState('00:00:00');
  const [endTimeInput, setEndTimeInput] = useState('00:00:00');

  // Preview selection state
  const [isPreviewingSelection, setIsPreviewingSelection] = useState(false);
  const previewCheckRef = useRef<number | null>(null);

  // Timeline dragging
  const timelineRef = useRef<HTMLDivElement>(null);
  const [draggingHandle, setDraggingHandle] = useState<'start' | 'end' | null>(null);

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState<string>('');

  // Result state
  const [cutResult, setCutResult] = useState<{
    blob: Blob;
    url: string;
    originalDuration: number;
    selectedDuration: number;
    format: string;
    size: number;
  } | null>(null);

  // Multiple segments state (Requirement 12)
  const [segments, setSegments] = useState<VideoSegment[]>([]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      if (cutResult?.url) URL.revokeObjectURL(cutResult.url);
      segments.forEach((s) => {
        if (s.resultUrl) URL.revokeObjectURL(s.resultUrl);
      });
      if (previewCheckRef.current) cancelAnimationFrame(previewCheckRef.current);
    };
  }, [videoUrl, cutResult, segments]);

  const handleMediaLoaded = async (loadedFile: File) => {
    setIsLoading(true);
    setCutResult(null);
    setSegments([]);
    setValidationError(null);
    try {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      const url = URL.createObjectURL(loadedFile);
      setFile(loadedFile);
      setVideoUrl(url);

      const meta = await getVideoMetadata(loadedFile);
      setMetadata(meta);
      const vidDuration = meta.duration || 10;
      setDuration(vidDuration);

      // Default start to 0 and end to full duration (or 30s if longer)
      const initialEnd = vidDuration;
      setStartTime(0);
      setEndTime(initialEnd);
      setStartTimeInput('00:00:00');
      setEndTimeInput(formatTimeCode(initialEnd));
      setActivePreset('Custom');
    } catch (err) {
      console.error(err);
      setValidationError('Failed to load video. The format may not be supported by your browser.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (cutResult?.url) URL.revokeObjectURL(cutResult.url);
    segments.forEach((s) => {
      if (s.resultUrl) URL.revokeObjectURL(s.resultUrl);
    });
    setFile(null);
    setVideoUrl('');
    setMetadata(null);
    setCutResult(null);
    setSegments([]);
    setDuration(0);
    setCurrentTime(0);
    setIsPlaying(false);
    setIsPreviewingSelection(false);
    setValidationError(null);
  };

  // Keep string inputs in sync when numbers change
  const updateRange = (newStart: number, newEnd: number, presetName: string = 'Custom') => {
    const validStart = Math.max(0, Math.min(newStart, duration - 0.2));
    const validEnd = Math.max(validStart + 0.2, Math.min(newEnd, duration));

    setStartTime(validStart);
    setEndTime(validEnd);
    setStartTimeInput(formatTimeCode(validStart));
    setEndTimeInput(formatTimeCode(validEnd));
    setActivePreset(presetName);
    setValidationError(null);
  };

  // Manual time input commit
  const handleStartTimeBlur = () => {
    const parsed = parseTimeCode(startTimeInput);
    if (parsed === null) {
      setStartTimeInput(formatTimeCode(startTime));
      setValidationError('Invalid time format. Please use HH:MM:SS or MM:SS.');
      return;
    }
    if (parsed >= endTime) {
      setValidationError('Start Time must be less than End Time.');
      setStartTimeInput(formatTimeCode(startTime));
      return;
    }
    if (parsed < 0 || parsed > duration) {
      setValidationError(`Start Time must be between 00:00:00 and ${formatTimeCode(duration)}.`);
      setStartTimeInput(formatTimeCode(startTime));
      return;
    }
    updateRange(parsed, endTime, 'Custom');
  };

  const handleEndTimeBlur = () => {
    const parsed = parseTimeCode(endTimeInput);
    if (parsed === null) {
      setEndTimeInput(formatTimeCode(endTime));
      setValidationError('Invalid time format. Please use HH:MM:SS or MM:SS.');
      return;
    }
    if (parsed <= startTime) {
      setValidationError('End Time must be greater than Start Time.');
      setEndTimeInput(formatTimeCode(endTime));
      return;
    }
    if (parsed > duration) {
      setValidationError(`End Time cannot exceed video duration (${formatTimeCode(duration)}).`);
      setEndTimeInput(formatTimeCode(endTime));
      return;
    }
    updateRange(startTime, parsed, 'Custom');
  };

  // Quick Preset Selection (Requirement 5 & 6: Never limits maximum duration)
  const applyPreset = (seconds: number, label: string) => {
    if (duration <= 0) return;
    if (duration < seconds) return;

    // Apply preset starting from current start time if it fits, otherwise shift window
    let newStart = startTime;
    let newEnd = newStart + seconds;
    if (newEnd > duration) {
      newEnd = duration;
      newStart = Math.max(0, duration - seconds);
    }
    updateRange(newStart, newEnd, label);
  };

  const applyFullVideoPreset = () => {
    updateRange(0, duration, 'Full Video');
  };

  // Timeline dragging logic
  const handleTimelineInteraction = useCallback(
    (clientX: number, targetHandle?: 'start' | 'end') => {
      if (!timelineRef.current || duration <= 0) return;
      const rect = timelineRef.current.getBoundingClientRect();
      const clickRatio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const targetTime = clickRatio * duration;

      const active = targetHandle || draggingHandle;

      if (active === 'start') {
        const newStart = Math.min(targetTime, endTime - 0.2);
        updateRange(newStart, endTime, 'Custom');
        if (videoRef.current) {
          videoRef.current.currentTime = newStart;
        }
      } else if (active === 'end') {
        const newEnd = Math.max(targetTime, startTime + 0.2);
        updateRange(startTime, newEnd, 'Custom');
        if (videoRef.current) {
          videoRef.current.currentTime = newEnd;
        }
      } else {
        // Click on timeline bar -> move closest handle or seek
        const distToStart = Math.abs(targetTime - startTime);
        const distToEnd = Math.abs(targetTime - endTime);
        if (distToStart < distToEnd) {
          updateRange(Math.min(targetTime, endTime - 0.2), endTime, 'Custom');
        } else {
          updateRange(startTime, Math.max(targetTime, startTime + 0.2), 'Custom');
        }
        if (videoRef.current) {
          videoRef.current.currentTime = targetTime;
        }
      }
    },
    [duration, startTime, endTime, draggingHandle]
  );

  const onPointerDownHandle = (handle: 'start' | 'end', e: React.PointerEvent) => {
    e.stopPropagation();
    setDraggingHandle(handle);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onPointerMoveTimeline = (e: React.PointerEvent) => {
    if (draggingHandle) {
      handleTimelineInteraction(e.clientX, draggingHandle);
    }
  };

  const onPointerUpTimeline = (e: React.PointerEvent) => {
    if (draggingHandle) {
      setDraggingHandle(null);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  };

  // Selection Preview Loop
  const togglePreviewSelection = () => {
    if (!videoRef.current) return;

    if (isPreviewingSelection) {
      videoRef.current.pause();
      setIsPreviewingSelection(false);
      setIsPlaying(false);
      if (previewCheckRef.current) cancelAnimationFrame(previewCheckRef.current);
    } else {
      videoRef.current.currentTime = startTime;
      videoRef.current.play();
      setIsPreviewingSelection(true);
      setIsPlaying(true);

      const checkLoop = () => {
        if (!videoRef.current) return;
        if (videoRef.current.currentTime >= endTime || videoRef.current.ended) {
          videoRef.current.currentTime = startTime;
          videoRef.current.pause();
          setIsPreviewingSelection(false);
          setIsPlaying(false);
          return;
        }
        previewCheckRef.current = requestAnimationFrame(checkLoop);
      };
      previewCheckRef.current = requestAnimationFrame(checkLoop);
    }
  };

  // Video cutter processing (Real progress, Requirement 9 & 10)
  const handleCutVideo = async () => {
    if (!file || !metadata) return;
    if (startTime >= endTime) {
      setValidationError('Start Time must be less than End Time.');
      return;
    }

    setIsProcessing(true);
    setProcessingProgress(0);
    setProcessingStatus('Preparing video...');
    setValidationError(null);

    try {
      setProcessingStatus('Processing selected section...');
      const res = await processVideoViaCanvas(
        file,
        {
          startTime,
          endTime,
        },
        (progress) => {
          setProcessingProgress(progress);
          if (progress > 85) {
            setProcessingStatus('Finalizing video clip...');
          }
        }
      );

      setProcessingStatus('Video ready!');
      setCutResult({
        blob: res.blob,
        url: res.url,
        originalDuration: duration,
        selectedDuration: endTime - startTime,
        format: res.format.toUpperCase(),
        size: res.blob.size,
      });
    } catch (err: any) {
      console.error('Cut failed:', err);
      setValidationError(err.message || 'Error occurred while cutting video.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!cutResult) return;
    const a = document.createElement('a');
    a.href = cutResult.url;
    const originalName = file?.name.replace(/\.[^/.]+$/, '') || 'video';
    a.download = `${originalName}_cut_${formatTimeCode(startTime).replace(/:/g, '-')}_to_${formatTimeCode(endTime).replace(/:/g, '-')}.${cutResult.format.toLowerCase()}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Add to Multiple Segments (Requirement 12)
  const handleAddSegment = () => {
    const newSeg: VideoSegment = {
      id: Math.random().toString(36).substring(2, 9),
      name: `Segment ${segments.length + 1}`,
      start: startTime,
      end: endTime,
      duration: endTime - startTime,
    };
    setSegments([...segments, newSeg]);
  };

  const handleProcessSegment = async (segId: string) => {
    if (!file) return;
    const seg = segments.find((s) => s.id === segId);
    if (!seg) return;

    setSegments((prev) =>
      prev.map((s) => (s.id === segId ? { ...s, isProcessing: true } : s))
    );

    try {
      const res = await processVideoViaCanvas(file, {
        startTime: seg.start,
        endTime: seg.end,
      });
      setSegments((prev) =>
        prev.map((s) =>
          s.id === segId ? { ...s, resultUrl: res.url, isProcessing: false } : s
        )
      );
    } catch (err) {
      console.error(err);
      setSegments((prev) =>
        prev.map((s) => (s.id === segId ? { ...s, isProcessing: false } : s))
      );
    }
  };

  const handleDownloadSegment = (seg: VideoSegment) => {
    if (!seg.resultUrl) return;
    const a = document.createElement('a');
    a.href = seg.resultUrl;
    const originalName = file?.name.replace(/\.[^/.]+$/, '') || 'video';
    a.download = `${originalName}_${seg.name.replace(/\s+/g, '_')}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Selected Duration calculation
  const selectedDurationSec = Math.max(0, endTime - startTime);

  return (
    <div className="w-full space-y-8 animate-in fade-in duration-300">
      {/* 1. UPLOAD STATE (When no video is uploaded) */}
      {!file && (
        <div className="max-w-3xl mx-auto">
          <MediaInputSelector
            mediaType="video"
            acceptedFormats="video/mp4,video/webm,video/quicktime,video/x-matroska,.mp4,.webm,.mov,.mkv"
            onMediaLoaded={handleMediaLoaded}
            isLoading={isLoading}
          />
          <p className="text-center text-xs text-slate-400 dark:text-slate-500 mt-3">
            Cut videos of any duration: 30s, 5m, 10m, 1 hour, or longer. 100% private in-browser cutting.
          </p>
        </div>
      )}

      {/* 2. ACTIVE VIDEO CUTTER STUDIO */}
      {file && (
        <div className="space-y-6">
          {/* Top Video Metadata Banner */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 shrink-0">
                <Scissors className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate max-w-sm sm:max-w-md">
                  {file.name}
                </h3>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Duration: {formatTimeCode(duration)}
                  </span>
                  <span>•</span>
                  <span>{metadata ? `${metadata.width}×${metadata.height}` : 'Video'}</span>
                  <span>•</span>
                  <span>{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                  <span>•</span>
                  <span className="uppercase text-[10px] text-indigo-600 dark:text-indigo-400 font-bold px-1.5 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/50">
                    {metadata?.format || 'MP4'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Change Video</span>
            </button>
          </div>

          {/* Validation Alert */}
          {validationError && (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex items-center gap-2.5 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
              <span>{validationError}</span>
            </div>
          )}

          {/* 2. VIDEO PREVIEW PLAYER */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-6 shadow-sm">
            <div className="relative aspect-video w-full max-h-[480px] rounded-2xl overflow-hidden bg-black flex items-center justify-center group">
              <video
                ref={videoRef}
                src={videoUrl}
                playsInline
                className="h-full w-full object-contain"
                onTimeUpdate={() => {
                  if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
                }}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
              />

              {/* Player Overlay Controls */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 flex flex-wrap items-center justify-between gap-3 text-white">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (!videoRef.current) return;
                      if (isPlaying) videoRef.current.pause();
                      else videoRef.current.play();
                    }}
                    className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm transition-colors cursor-pointer"
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-white" />}
                  </button>

                  <div className="text-xs font-mono font-semibold tracking-wider">
                    <span>{formatTimeCode(currentTime)}</span>
                    <span className="text-white/60"> / {formatTimeCode(duration)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {/* Volume */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (!videoRef.current) return;
                        videoRef.current.muted = !isMuted;
                        setIsMuted(!isMuted);
                      }}
                      className="text-white/80 hover:text-white"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </button>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={isMuted ? 0 : volume}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        setVolume(val);
                        setIsMuted(false);
                        if (videoRef.current) {
                          videoRef.current.volume = val;
                          videoRef.current.muted = false;
                        }
                      }}
                      className="w-16 sm:w-20 accent-indigo-500"
                    />
                  </div>

                  {/* Playback Speed */}
                  <select
                    value={playbackSpeed}
                    onChange={(e) => {
                      const spd = parseFloat(e.target.value);
                      setPlaybackSpeed(spd);
                      if (videoRef.current) videoRef.current.playbackRate = spd;
                    }}
                    className="bg-black/50 text-white border border-white/20 rounded-lg px-2 py-1 text-xs font-semibold focus:outline-none cursor-pointer"
                  >
                    <option value={0.5}>0.5x</option>
                    <option value={0.75}>0.75x</option>
                    <option value={1}>1.0x</option>
                    <option value={1.25}>1.25x</option>
                    <option value={1.5}>1.5x</option>
                    <option value={2}>2.0x</option>
                  </select>

                  {/* Fullscreen */}
                  <button
                    type="button"
                    onClick={() => {
                      if (videoRef.current) {
                        if (document.fullscreenElement) document.exitFullscreen();
                        else videoRef.current.requestFullscreen();
                      }
                    }}
                    className="p-1.5 text-white/80 hover:text-white"
                  >
                    <Maximize2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4. DRAGGABLE TIMELINE WITH TWO HANDLES */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Interactive Timeline Range</span>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-mono font-semibold">
                    Drag handles to cut
                  </span>
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Drag the start and end handles to select any portion of the video.
                </p>
              </div>

              {/* 7. SELECTED DURATION DISPLAY */}
              <div className="px-4 py-2 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-900 text-right">
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block">
                  Selected Duration
                </span>
                <span className="text-base sm:text-lg font-mono font-extrabold text-indigo-700 dark:text-indigo-300">
                  {formatTimeCode(selectedDurationSec)}
                </span>
              </div>
            </div>

            {/* Custom Interactive Timeline Slider */}
            <div className="pt-4 pb-2">
              <div
                ref={timelineRef}
                onPointerDown={(e) => handleTimelineInteraction(e.clientX)}
                onPointerMove={onPointerMoveTimeline}
                onPointerUp={onPointerUpTimeline}
                className="relative h-12 w-full rounded-2xl bg-slate-100 dark:bg-slate-800 cursor-pointer select-none overflow-visible touch-none border border-slate-200 dark:border-slate-700"
              >
                {/* Visual Audio/Video Filmstrip Mock Track */}
                <div className="absolute inset-0 flex items-center justify-between px-3 opacity-25 pointer-events-none">
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div key={i} className="h-6 w-0.5 bg-slate-400 dark:bg-slate-500 rounded-full" />
                  ))}
                </div>

                {/* Selected Active Cut Range Highlight */}
                {duration > 0 && (
                  <div
                    className="absolute top-0 bottom-0 bg-indigo-500/30 dark:bg-indigo-600/30 border-y-2 border-indigo-600 backdrop-blur-2xs transition-all pointer-events-none"
                    style={{
                      left: `${(startTime / duration) * 100}%`,
                      width: `${((endTime - startTime) / duration) * 100}%`,
                    }}
                  />
                )}

                {/* Playhead Needle */}
                {duration > 0 && (
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-rose-500 pointer-events-none z-10"
                    style={{ left: `${(currentTime / duration) * 100}%` }}
                  >
                    <div className="absolute -top-2 -translate-x-1/2 w-2.5 h-2.5 bg-rose-500 rotate-45" />
                  </div>
                )}

                {/* START HANDLE */}
                {duration > 0 && (
                  <div
                    onPointerDown={(e) => onPointerDownHandle('start', e)}
                    style={{ left: `${(startTime / duration) * 100}%` }}
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-10 w-7 rounded-xl bg-indigo-600 text-white flex flex-col items-center justify-center shadow-lg ring-4 ring-indigo-500/20 cursor-ew-resize hover:scale-110 active:scale-95 transition-transform z-20"
                  >
                    <div className="w-1 h-4 bg-white/70 rounded-full" />
                    <span className="absolute -top-7 px-1.5 py-0.5 rounded bg-slate-900 text-[10px] text-white font-mono font-bold whitespace-nowrap shadow-sm pointer-events-none">
                      {formatTimeCode(startTime)}
                    </span>
                  </div>
                )}

                {/* END HANDLE */}
                {duration > 0 && (
                  <div
                    onPointerDown={(e) => onPointerDownHandle('end', e)}
                    style={{ left: `${(endTime / duration) * 100}%` }}
                    className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-10 w-7 rounded-xl bg-indigo-600 text-white flex flex-col items-center justify-center shadow-lg ring-4 ring-indigo-500/20 cursor-ew-resize hover:scale-110 active:scale-95 transition-transform z-20"
                  >
                    <div className="w-1 h-4 bg-white/70 rounded-full" />
                    <span className="absolute -top-7 px-1.5 py-0.5 rounded bg-slate-900 text-[10px] text-white font-mono font-bold whitespace-nowrap shadow-sm pointer-events-none">
                      {formatTimeCode(endTime)}
                    </span>
                  </div>
                )}
              </div>

              {/* Timeline duration boundary indicators */}
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-2">
                <span>00:00:00</span>
                <span>Total: {formatTimeCode(duration)}</span>
              </div>
            </div>

            {/* 3. PRECISE START & END TIME INPUTS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Start Time
                  </label>
                  <span className="text-[11px] text-slate-400 font-mono">HH:MM:SS</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={startTimeInput}
                    onChange={(e) => setStartTimeInput(e.target.value)}
                    onBlur={handleStartTimeBlur}
                    onKeyDown={(e) => e.key === 'Enter' && handleStartTimeBlur()}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="00:00:00"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (videoRef.current) {
                        updateRange(videoRef.current.currentTime, endTime, 'Custom');
                      }
                    }}
                    className="px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0 cursor-pointer"
                    title="Set to current video playhead"
                  >
                    Current
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    End Time
                  </label>
                  <span className="text-[11px] text-slate-400 font-mono">HH:MM:SS</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={endTimeInput}
                    onChange={(e) => setEndTimeInput(e.target.value)}
                    onBlur={handleEndTimeBlur}
                    onKeyDown={(e) => e.key === 'Enter' && handleEndTimeBlur()}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono text-sm font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="00:00:00"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (videoRef.current) {
                        updateRange(startTime, videoRef.current.currentTime, 'Custom');
                      }
                    }}
                    className="px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0 cursor-pointer"
                    title="Set to current video playhead"
                  >
                    Current
                  </button>
                </div>
              </div>
            </div>

            {/* 5. QUICK DURATION PRESETS (Never limits max duration, handles 30s to 1h+) */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Quick Duration Shortcuts
                </label>
                <span className="text-[11px] text-slate-400">
                  Shortcuts only — you can cut any duration using Custom/Timeline
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-1">
                {PRESET_DURATIONS.map((preset) => {
                  const isAvailable = duration >= preset.seconds;
                  const isSelected = activePreset === preset.label;
                  return (
                    <button
                      key={preset.label}
                      type="button"
                      disabled={!isAvailable}
                      onClick={() => applyPreset(preset.seconds, preset.label)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        !isAvailable
                          ? 'opacity-40 bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-transparent'
                          : isSelected
                          ? 'border border-indigo-600 bg-indigo-600 text-white shadow-xs'
                          : 'border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-indigo-400'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}

                <button
                  type="button"
                  onClick={applyFullVideoPreset}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activePreset === 'Full Video'
                      ? 'border border-indigo-600 bg-indigo-600 text-white shadow-xs'
                      : 'border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-indigo-400'
                  }`}
                >
                  Full Video ({formatTimeCode(duration)})
                </button>

                <button
                  type="button"
                  onClick={() => setActivePreset('Custom')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activePreset === 'Custom'
                      ? 'border border-indigo-600 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                      : 'border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-indigo-400'
                  }`}
                >
                  Custom Range
                </button>
              </div>
            </div>

            {/* 8 & 9. ACTIONS BAR (Preview Selection & Cut Video Button) */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {/* 8. Quick Preview Button */}
                <button
                  type="button"
                  onClick={togglePreviewSelection}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs sm:text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  {isPreviewingSelection ? (
                    <>
                      <Pause className="h-4 w-4 text-indigo-600" />
                      <span>Stop Preview</span>
                    </>
                  ) : (
                    <>
                      <Eye className="h-4 w-4 text-indigo-600" />
                      <span>Preview Selection</span>
                    </>
                  )}
                </button>

                {/* 12. Add to Multiple Segments */}
                <button
                  type="button"
                  onClick={handleAddSegment}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl border border-dashed border-indigo-400 text-indigo-600 dark:text-indigo-400 font-semibold text-xs sm:text-sm hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors cursor-pointer"
                >
                  <Layers className="h-4 w-4" />
                  <span>+ Add to Segments</span>
                </button>
              </div>

              {/* 9. Prominent Cut Video Action */}
              <button
                type="button"
                onClick={handleCutVideo}
                disabled={isProcessing || startTime >= endTime}
                className="flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-indigo-600 text-white font-bold text-sm shadow-md hover:bg-indigo-700 hover:shadow-lg transition-all disabled:opacity-50 cursor-pointer"
              >
                <Scissors className="h-4 w-4" />
                <span>✂ Cut Video</span>
              </button>
            </div>

            {/* Selected Summary Tag Before Processing */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-3">
                <span>Start: <strong className="text-slate-900 dark:text-white font-mono">{formatTimeCode(startTime)}</strong></span>
                <span>•</span>
                <span>End: <strong className="text-slate-900 dark:text-white font-mono">{formatTimeCode(endTime)}</strong></span>
              </div>
              <div>
                Selected Duration: <strong className="text-indigo-600 dark:text-indigo-400 font-mono text-sm">{formatTimeCode(selectedDurationSec)}</strong>
              </div>
            </div>
          </div>

          {/* 10. REAL PROCESSING STATUS */}
          {isProcessing && (
            <div className="p-6 rounded-3xl border border-indigo-200 dark:border-indigo-900/60 bg-white dark:bg-slate-900 shadow-md space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Scissors className="h-4 w-4 animate-spin text-indigo-600" />
                  <span>{processingStatus || 'Processing selected section...'}</span>
                </span>
                <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400">
                  {processingProgress}%
                </span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-indigo-600 transition-all duration-150 rounded-full"
                  style={{ width: `${processingProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* 11. RESULT SCREEN */}
          {cutResult && (
            <div className="rounded-3xl border-2 border-emerald-500/40 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-6 shadow-lg animate-in fade-in duration-300">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400">
                  <Check className="h-6 w-6 stroke-[3]" />
                  <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                    Video Cut Successfully
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>Download Video</span>
                </button>
              </div>

              {/* Details Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider">
                    Original Duration
                  </span>
                  <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200">
                    {formatTimeCode(cutResult.originalDuration)}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-400 block tracking-wider">
                    Selected Duration
                  </span>
                  <span className="text-sm font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {formatTimeCode(cutResult.selectedDuration)}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider">
                    Output Format
                  </span>
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {cutResult.format}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider">
                    File Size
                  </span>
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {(cutResult.size / (1024 * 1024)).toFixed(2)} MB
                  </span>
                </div>
              </div>

              {/* Cut Video Preview Player */}
              <div className="aspect-video w-full max-h-[420px] rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                <video src={cutResult.url} controls playsInline className="h-full w-full object-contain" />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>Download Video</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCutResult(null)}
                  className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cut Another Section
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  New Video
                </button>
              </div>
            </div>
          )}

          {/* 12. MULTIPLE SECTIONS LIST */}
          {segments.length > 0 && (
            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 space-y-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Layers className="h-4 w-4 text-indigo-600" />
                    <span>Cut Multiple Segments ({segments.length})</span>
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Process individual clips or export multiple segments from this video.
                  </p>
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {segments.map((seg, idx) => (
                  <div
                    key={seg.id}
                    className="py-3.5 flex flex-wrap items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                        {seg.name}
                      </div>
                      <div className="text-xs font-mono text-slate-500 mt-0.5">
                        {formatTimeCode(seg.start)} → {formatTimeCode(seg.end)} (Duration: {formatTimeCode(seg.duration)})
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (videoRef.current) {
                            videoRef.current.currentTime = seg.start;
                            videoRef.current.play();
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Preview
                      </button>

                      <button
                        type="button"
                        onClick={() => updateRange(seg.start, seg.end, 'Custom')}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Edit
                      </button>

                      {seg.resultUrl ? (
                        <button
                          type="button"
                          onClick={() => handleDownloadSegment(seg)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 cursor-pointer"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>Download</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={seg.isProcessing}
                          onClick={() => handleProcessSegment(seg.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
                        >
                          <Scissors className="h-3.5 w-3.5" />
                          <span>{seg.isProcessing ? 'Cutting...' : 'Process'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => setSegments(segments.filter((s) => s.id !== seg.id))}
                        className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                        title="Remove segment"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
