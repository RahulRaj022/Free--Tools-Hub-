import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Share2, Copy, Check, Globe, AlertCircle, Loader2, Edit3, Image as ImageIcon } from 'lucide-react';

export const OpenGraphPreviewTool: React.FC = () => {
  const { showToast } = useTools();
  const [fetchUrl, setFetchUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Editable Card Data
  const [title, setTitle] = useState('Free Tools Hub – 100% Free Online Utilities');
  const [description, setDescription] = useState(
    'Convert, edit, compress, and calculate with 70+ free browser tools. Fast, private, and client-side with no registration.'
  );
  const [imageUrl, setImageUrl] = useState(
    'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&h=630&q=80'
  );
  const [domain, setDomain] = useState('freetoolshub.com');
  const [activePlatform, setActivePlatform] = useState<'facebook' | 'twitter' | 'discord'>('facebook');
  const [copied, setCopied] = useState(false);

  const fetchLiveOgData = async () => {
    let target = fetchUrl.trim();
    if (!target) {
      setError('Please enter a target URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setFetchUrl(target);
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch webpage.');
      }

      const html = data.html || '';
      const urlObj = new URL(data.url || target);
      setDomain(urlObj.hostname);

      // Extract OG / Twitter tags via regex
      const getMeta = (prop: string) => {
        const regex = new RegExp(`<meta\\s+(?:property|name)=["']${prop}["']\\s+content=["']([^"']*)["']`, 'i');
        const match = html.match(regex);
        return match ? match[1] : null;
      };

      const extractedTitle =
        getMeta('og:title') ||
        getMeta('twitter:title') ||
        (html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] || '');

      const extractedDesc =
        getMeta('og:description') ||
        getMeta('twitter:description') ||
        getMeta('description') ||
        '';

      let extractedImg = getMeta('og:image') || getMeta('twitter:image');
      if (extractedImg && !extractedImg.startsWith('http')) {
        try {
          extractedImg = new URL(extractedImg, urlObj).toString();
        } catch {}
      }

      if (extractedTitle) setTitle(extractedTitle);
      if (extractedDesc) setDescription(extractedDesc);
      if (extractedImg) setImageUrl(extractedImg);

      showToast('Fetched live Open Graph tags!', 'success');
    } catch (err: any) {
      setError(`${err?.message || 'Could not fetch live metadata'}. You can still customize details manually below.`);
    } finally {
      setLoading(false);
    }
  };

  const copyTags = () => {
    const tags = `<!-- Open Graph / Social Sharing Tags -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://${domain}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:image" content="${imageUrl}">

<!-- Twitter / X -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${title}">
<meta name="twitter:description" content="${description}">
<meta name="twitter:image" content="${imageUrl}">`;

    navigator.clipboard.writeText(tags);
    setCopied(true);
    showToast('Open Graph tags copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Fetch URL Bar */}
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Fetch Live URL (or Edit Manually Below)
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={fetchUrl}
            onChange={(e) => setFetchUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchLiveOgData()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={fetchLiveOgData}
            disabled={loading || !fetchUrl.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Globe className="h-4 w-4" />}
            <span>{loading ? 'Fetching...' : 'Fetch Open Graph'}</span>
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Metadata Editor */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <Edit3 className="h-3.5 w-3.5 text-indigo-500" />
                Live Card Fields
              </span>
              <button
                type="button"
                onClick={copyTags}
                className="flex items-center gap-1 text-xs text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Tags'}</span>
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Domain / Brand
              </label>
              <input
                type="text"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                og:title
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                og:description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2.5 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                og:image URL (1200 × 630 recommended)
              </label>
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Right: Mockup Card Viewports */}
        <div className="lg:col-span-7 space-y-4">
          {/* Platform Tabs */}
          <div className="flex rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 p-1 w-fit">
            <button
              type="button"
              onClick={() => setActivePlatform('facebook')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activePlatform === 'facebook'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs font-semibold'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Facebook / LinkedIn
            </button>
            <button
              type="button"
              onClick={() => setActivePlatform('twitter')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activePlatform === 'twitter'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs font-semibold'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Twitter / X Card
            </button>
            <button
              type="button"
              onClick={() => setActivePlatform('discord')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                activePlatform === 'discord'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs font-semibold'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Discord / Slack
            </button>
          </div>

          {/* 1. Facebook Mockup */}
          {activePlatform === 'facebook' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 overflow-hidden shadow-md max-w-lg mx-auto">
              <div className="aspect-[1.91/1] w-full bg-slate-100 dark:bg-slate-800 overflow-hidden relative">
                {imageUrl ? (
                  <img src={imageUrl} alt="Social Card Preview" className="w-full h-full object-cover" />
                ) : (
                  <div className="flex items-center justify-center h-full text-slate-400 text-xs">
                    <ImageIcon className="h-6 w-6 mr-2" /> No image defined
                  </div>
                )}
              </div>
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-700/80 space-y-1">
                <div className="text-[11px] uppercase tracking-wider text-slate-500 font-mono">
                  {domain}
                </div>
                <div className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
                  {title}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                  {description}
                </div>
              </div>
            </div>
          )}

          {/* 2. Twitter / X Mockup */}
          {activePlatform === 'twitter' && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-black text-white overflow-hidden shadow-md max-w-lg mx-auto">
              <div className="aspect-[1.91/1] w-full bg-slate-900 overflow-hidden relative">
                {imageUrl && <img src={imageUrl} alt="Twitter card" className="w-full h-full object-cover" />}
              </div>
              <div className="p-3 space-y-1">
                <div className="text-[11px] text-zinc-400 font-mono">{domain}</div>
                <div className="text-sm font-bold line-clamp-1">{title}</div>
                <div className="text-xs text-zinc-400 line-clamp-2">{description}</div>
              </div>
            </div>
          )}

          {/* 3. Discord Mockup */}
          {activePlatform === 'discord' && (
            <div className="rounded-xl border-l-4 border-indigo-500 bg-[#2f3136] text-[#dcddde] p-3.5 max-w-lg mx-auto space-y-2 font-sans text-xs">
              <div className="text-[11px] text-[#00b0f4] hover:underline cursor-pointer">{domain}</div>
              <div className="text-sm font-bold text-white hover:underline cursor-pointer line-clamp-1">
                {title}
              </div>
              <div className="text-xs text-[#b9bbbe] line-clamp-3">{description}</div>
              {imageUrl && (
                <div className="rounded-lg overflow-hidden max-h-48 mt-2">
                  <img src={imageUrl} alt="Discord embed" className="w-full h-auto object-cover" />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
