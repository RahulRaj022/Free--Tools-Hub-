import React from 'react';
import { ToolItem } from '../../types';
import { ToolAppIcon } from '../common/ToolAppIcon';
import { useTools } from '../../context/ToolsContext';
import { Star, ArrowRight } from 'lucide-react';

interface ToolCardProps {
  tool: ToolItem;
  onSelect: (slug: string) => void;
  compact?: boolean;
}

const CATEGORY_NAMES: Record<string, string> = {
  pdf: 'PDF & Documents',
  image: 'Image Tools',
  design: 'Design & Color',
  text: 'Text Tools',
  calculator: 'Calculators',
  developer: 'Developer Tools',
  data: 'Data & CSV',
  seo: 'SEO & Website',
  finance: 'Finance & Business',
  productivity: 'Time & Productivity',
  social: 'Social Media',
  education: 'Education',
  conversion: 'Conversion',
  security: 'Security & Privacy',
  ai: 'AI & Smart Tools',
  student: 'Student Tools',
  other: 'Utilities',
};

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onSelect, compact = false }) => {
  const { isFavorite, toggleFavorite } = useTools();
  const favorited = isFavorite(tool.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(tool.id);
  };

  return (
    <div
      onClick={() => onSelect(tool.slug)}
      className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-5 sm:p-6 text-left shadow-xs transition-all duration-200 hover:-translate-y-1 hover:border-indigo-300/80 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500/50 cursor-pointer"
    >
      <div>
        {/* Header row: Large Professional Tool Icon & Favorite Toggle */}
        <div className="flex items-start justify-between gap-3">
          <ToolAppIcon
            slug={tool.slug}
            category={tool.category}
            size="lg"
            alt={tool.name}
            interactive={true}
          />
          
          <button
            onClick={handleFavoriteClick}
            className={`p-2 rounded-xl border transition-all duration-200 ${
              favorited
                ? 'border-amber-200 bg-amber-50 text-amber-500 shadow-2xs dark:border-amber-900/60 dark:bg-amber-950/40'
                : 'border-slate-100 bg-slate-50/80 text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-500 dark:hover:text-slate-300 dark:hover:bg-slate-800'
            }`}
            title={favorited ? 'Remove from favorites' : 'Add to favorites'}
            aria-label={favorited ? `Remove ${tool.name} from favorites` : `Add ${tool.name} to favorites`}
          >
            <Star className={`h-4 w-4 ${favorited ? 'fill-amber-500' : ''}`} />
          </button>
        </div>

        {/* Quiet zero-pill metadata line */}
        <div className="mt-3.5 flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400">
          <span>{CATEGORY_NAMES[tool.category] || tool.category}</span>
          {tool.popular && (
            <>
              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>
              <span className="text-indigo-600 dark:text-indigo-400">Popular</span>
            </>
          )}
        </div>

        {/* Title */}
        <h3 className="mt-1 text-base font-semibold tracking-tight text-slate-900 group-hover:text-indigo-600 dark:text-white dark:group-hover:text-indigo-400 transition-colors">
          {tool.name}
        </h3>

        {/* Description */}
        <p className={`mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed ${compact ? 'line-clamp-2' : 'line-clamp-3'}`}>
          {tool.shortDescription}
        </p>
      </div>

      {/* Action link */}
      <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
        <span>Open Tool</span>
        <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform duration-200" />
      </div>
    </div>
  );
};
