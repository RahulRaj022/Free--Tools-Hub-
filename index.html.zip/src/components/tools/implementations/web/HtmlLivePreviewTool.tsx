import React, { useState, useEffect, useMemo } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Code, Play, RotateCcw, Copy, Check, Download, Monitor, Tablet, Smartphone } from 'lucide-react';

const PRESETS = {
  hero: {
    html: `<div class="hero">
  <span class="badge">🚀 Built with Free Tools Hub</span>
  <h1>Design Faster with Modern Web Utilities</h1>
  <p>Free, client-side, browser-powered tools designed for developers, designers, and students.</p>
  <button onclick="greet()">Click for Interactive Demo</button>
</div>`,
    css: `body {
  margin: 0;
  font-family: system-ui, -apple-system, sans-serif;
  background: #0f172a;
  color: #f8fafc;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  text-align: center;
  padding: 20px;
  box-sizing: border-box;
}
.hero {
  max-width: 600px;
}
.badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 9999px;
  background: rgba(99, 102, 241, 0.2);
  color: #818cf8;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 16px;
  border: 1px solid rgba(99, 102, 241, 0.4);
}
h1 {
  font-size: 32px;
  font-weight: 800;
  letter-spacing: -0.02em;
  margin: 0 0 16px 0;
  line-height: 1.2;
}
p {
  color: #94a3b8;
  font-size: 16px;
  line-height: 1.6;
  margin-bottom: 24px;
}
button {
  background: #4f46e5;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);
  transition: transform 0.15s ease, background 0.15s ease;
}
button:hover {
  background: #4338ca;
  transform: translateY(-2px);
}`,
    js: `function greet() {
  alert('Hello from the sandboxed preview!');
}`,
  },
  counter: {
    html: `<div class="card">
  <h2>Interactive Counter</h2>
  <div id="count" class="counter">0</div>
  <div class="btn-group">
    <button onclick="decrement()">-</button>
    <button onclick="reset()">Reset</button>
    <button onclick="increment()">+</button>
  </div>
</div>`,
    css: `body {
  margin: 0;
  font-family: system-ui, sans-serif;
  background: #f1f5f9;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}
.card {
  background: white;
  padding: 32px;
  border-radius: 20px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.05);
  text-align: center;
  min-width: 260px;
}
.counter {
  font-size: 56px;
  font-weight: 800;
  color: #4f46e5;
  margin: 20px 0;
}
.btn-group {
  display: flex;
  gap: 8px;
  justify-content: center;
}
button {
  background: #e2e8f0;
  color: #334155;
  border: none;
  padding: 8px 18px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
}
button:last-child {
  background: #4f46e5;
  color: white;
}`,
    js: `let count = 0;
function update() { document.getElementById('count').innerText = count; }
function increment() { count++; update(); }
function decrement() { count--; update(); }
function reset() { count = 0; update(); }`,
  },
};

export const HtmlLivePreviewTool: React.FC = () => {
  const { showToast } = useTools();
  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'js'>('html');
  const [htmlCode, setHtmlCode] = useState(PRESETS.hero.html);
  const [cssCode, setCssCode] = useState(PRESETS.hero.css);
  const [jsCode, setJsCode] = useState(PRESETS.hero.js);
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [copied, setCopied] = useState(false);

  // Debounced composite document for sandboxed preview
  const [srcDoc, setSrcDoc] = useState('');

  const fullDocument = useMemo(() => {
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    ${cssCode}
  </style>
</head>
<body>
  ${htmlCode}
  <script>
    try {
      ${jsCode}
    } catch (e) {
      console.error(e);
    }
  </script>
</body>
</html>`;
  }, [htmlCode, cssCode, jsCode]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setSrcDoc(fullDocument);
    }, 250);
    return () => clearTimeout(timer);
  }, [fullDocument]);

  const loadPreset = (key: 'hero' | 'counter') => {
    setHtmlCode(PRESETS[key].html);
    setCssCode(PRESETS[key].css);
    setJsCode(PRESETS[key].js);
    showToast(`Loaded ${key} template!`, 'success');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(fullDocument);
    setCopied(true);
    showToast('Full HTML document copied!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([fullDocument], { type: 'text/html' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = 'preview.html';
    a.click();
    URL.revokeObjectURL(u);
    showToast('preview.html downloaded!', 'success');
  };

  return (
    <div className="space-y-4">
      {/* Top Controls Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 mr-1 hidden sm:inline">
            Templates:
          </span>
          <button
            type="button"
            onClick={() => loadPreset('hero')}
            className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Landing Hero
          </button>
          <button
            type="button"
            onClick={() => loadPreset('counter')}
            className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Counter App
          </button>
        </div>

        {/* Viewport Width Controls */}
        <div className="flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 p-1">
          <button
            type="button"
            onClick={() => setViewport('desktop')}
            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
              viewport === 'desktop'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Desktop (100% width)"
          >
            <Monitor className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('tablet')}
            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
              viewport === 'tablet'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Tablet (768px)"
          >
            <Tablet className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('mobile')}
            className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
              viewport === 'mobile'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Mobile (375px)"
          >
            <Smartphone className="h-4 w-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
            <span>Copy Code</span>
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download HTML</span>
          </button>
        </div>
      </div>

      {/* Split Interface: Left Editor, Right Sandboxed Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[650px]">
        {/* Left Column: Code Editor */}
        <div className="lg:col-span-6 flex flex-col rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 overflow-hidden shadow-xs">
          {/* Tabs */}
          <div className="flex items-center border-b border-slate-800 bg-slate-900/80 px-2 py-1.5">
            <button
              type="button"
              onClick={() => setActiveTab('html')}
              className={`px-3 py-1 rounded-md text-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'html'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              HTML
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('css')}
              className={`px-3 py-1 rounded-md text-xs font-semibold cursor-pointer transition-colors ml-1 ${
                activeTab === 'css'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CSS
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('js')}
              className={`px-3 py-1 rounded-md text-xs font-semibold cursor-pointer transition-colors ml-1 ${
                activeTab === 'js'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              JavaScript
            </button>
          </div>

          {/* Active Editor Textarea */}
          <div className="flex-1 p-3">
            {activeTab === 'html' && (
              <textarea
                value={htmlCode}
                onChange={(e) => setHtmlCode(e.target.value)}
                spellCheck={false}
                className="w-full h-full bg-transparent text-emerald-400 font-mono text-xs focus:outline-none resize-none scrollbar-thin"
              />
            )}
            {activeTab === 'css' && (
              <textarea
                value={cssCode}
                onChange={(e) => setCssCode(e.target.value)}
                spellCheck={false}
                className="w-full h-full bg-transparent text-cyan-400 font-mono text-xs focus:outline-none resize-none scrollbar-thin"
              />
            )}
            {activeTab === 'js' && (
              <textarea
                value={jsCode}
                onChange={(e) => setJsCode(e.target.value)}
                spellCheck={false}
                className="w-full h-full bg-transparent text-amber-300 font-mono text-xs focus:outline-none resize-none scrollbar-thin"
              />
            )}
          </div>
        </div>

        {/* Right Column: Live Sandboxed Iframe */}
        <div className="lg:col-span-6 flex flex-col rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900/60 overflow-hidden shadow-xs">
          {/* Header */}
          <div className="flex items-center justify-between px-3 py-1.5 bg-slate-200/80 dark:bg-slate-800 border-b border-slate-300 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 font-medium">
            <span>Live Sandboxed Browser Preview</span>
            <span className="text-[10px] text-slate-400 uppercase font-mono">
              {viewport === 'desktop' ? '100% Full' : viewport === 'tablet' ? '768px' : '375px'}
            </span>
          </div>

          {/* Iframe Viewport Container */}
          <div className="flex-1 flex items-center justify-center p-2 bg-slate-200/40 dark:bg-slate-950/40 overflow-auto">
            <div
              className={`h-full bg-white rounded-xl shadow-md overflow-hidden transition-all duration-200 ${
                viewport === 'mobile'
                  ? 'w-[375px]'
                  : viewport === 'tablet'
                  ? 'w-[768px]'
                  : 'w-full'
              }`}
            >
              <iframe
                srcDoc={srcDoc}
                title="Live Sandboxed Preview"
                sandbox="allow-scripts"
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
