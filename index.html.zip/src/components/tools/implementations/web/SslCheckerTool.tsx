import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { ShieldCheck, ShieldAlert, Clock, Lock, AlertCircle, Loader2, RotateCcw } from 'lucide-react';

interface SslCertData {
  domain: string;
  valid: boolean;
  issuer: string;
  subject: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  protocol: string;
  cipher: string;
  san: string[];
  status: 'valid' | 'expiring_soon' | 'expired' | 'invalid';
}

export const SslCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [domain, setDomain] = useState('freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [cert, setCert] = useState<SslCertData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const checkSsl = async () => {
    let clean = domain.trim().replace(/^https?:\/\//i, '').split('/')[0];
    if (!clean) {
      setError('Please enter a domain name.');
      return;
    }
    setDomain(clean);

    setLoading(true);
    setError(null);
    setCert(null);

    try {
      const res = await fetch(`/api/web/ssl?domain=${encodeURIComponent(clean)}`);
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to inspect SSL certificate.');
      }

      setCert(data);
      showToast('SSL certificate retrieved!', 'success');
    } catch (err: any) {
      setError(err?.message || 'Error connecting over SSL port 443.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          HTTPS Domain to Inspect
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && checkSsl()}
            placeholder="example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={checkSsl}
            disabled={loading || !domain.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
            <span>{loading ? 'Inspecting TLS...' : 'Check SSL'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setDomain('');
              setCert(null);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {cert && (
        <div className="space-y-6 animate-in fade-in">
          {/* Main Status Header Card */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {cert.valid ? (
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck className="h-7 w-7" />
                  </div>
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
                    <ShieldAlert className="h-7 w-7" />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {cert.domain}
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
                        cert.status === 'valid'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                          : cert.status === 'expiring_soon'
                          ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300'
                          : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300'
                      }`}
                    >
                      {cert.status === 'valid'
                        ? 'Valid & Trusted'
                        : cert.status === 'expiring_soon'
                        ? 'Expiring Soon'
                        : 'Expired / Invalid'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Issuer: {cert.issuer}
                  </p>
                </div>
              </div>

              {/* Days countdown */}
              <div className="text-right">
                <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
                  {cert.daysRemaining} days
                </div>
                <div className="text-xs text-slate-400">remaining until renewal</div>
              </div>
            </div>

            {/* Metrics Breakdown Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-400">Valid From</span>
                <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-1">
                  {cert.validFrom}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-400">Valid Until</span>
                <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-1">
                  {cert.validTo}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-400">Protocol</span>
                <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-1">
                  {cert.protocol}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <span className="text-slate-400">Cipher Suite</span>
                <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 truncate">
                  {cert.cipher}
                </div>
              </div>
            </div>

            {/* SAN (Subject Alternative Names) */}
            {cert.san && cert.san.length > 0 && (
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Secured Hostnames (SAN):
                </span>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {cert.san.map((s, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 font-mono text-[11px] text-slate-700 dark:text-slate-300"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
