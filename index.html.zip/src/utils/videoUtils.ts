/**
 * Professional in-browser Video utility functions for Free Tools Hub.
 * 100% client-side, zero server dependencies, instant and private.
 */

export interface VideoMetadata {
  fileName: string;
  fileSize: number;
  format: string;
  duration: number;
  width: number;
  height: number;
  aspectRatio: string;
  orientation: 'Landscape' | 'Portrait' | 'Square';
  estimatedFps: number;
  bitrateKbps: number;
}

export function loadVideoElement(file: File): Promise<{ video: HTMLVideoElement; cleanup: () => void }> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;
    const url = URL.createObjectURL(file);
    video.src = url;

    video.onloadedmetadata = () => {
      resolve({
        video,
        cleanup: () => {
          video.pause();
          video.src = '';
          URL.revokeObjectURL(url);
        },
      });
    };

    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Unable to read video file. Format may not be supported by your browser.'));
    };
  });
}

// Calculate aspect ratio string (e.g. 16:9, 9:16, 4:3, 1:1)
function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

export function getAspectRatioString(width: number, height: number): string {
  if (!width || !height) return '16:9';
  const divisor = gcd(width, height);
  const ratioW = width / divisor;
  const ratioH = height / divisor;

  // Approximate to standard ratios if near
  const decimal = width / height;
  if (Math.abs(decimal - 16 / 9) < 0.05) return '16:9';
  if (Math.abs(decimal - 9 / 16) < 0.05) return '9:16';
  if (Math.abs(decimal - 4 / 3) < 0.05) return '4:3';
  if (Math.abs(decimal - 3 / 4) < 0.05) return '3:4';
  if (Math.abs(decimal - 1) < 0.05) return '1:1';
  if (Math.abs(decimal - 4 / 5) < 0.05) return '4:5';

  return `${ratioW}:${ratioH}`;
}

export async function getVideoMetadata(file: File): Promise<VideoMetadata> {
  const { video, cleanup } = await loadVideoElement(file);
  try {
    const width = video.videoWidth || 1920;
    const height = video.videoHeight || 1080;
    const duration = video.duration || 0;
    const fileSize = file.size;

    let orientation: 'Landscape' | 'Portrait' | 'Square' = 'Landscape';
    if (width < height) orientation = 'Portrait';
    else if (width === height) orientation = 'Square';

    const aspectRatio = getAspectRatioString(width, height);

    // Approximate FPS (most web video is 24, 30, or 60)
    let estimatedFps = 30;
    if (duration > 0 && 'requestVideoFrameCallback' in HTMLVideoElement.prototype) {
      // standard default
      estimatedFps = 30;
    }

    const bitrateKbps = duration > 0 ? Math.round(((fileSize * 8) / duration) / 1000) : 0;

    return {
      fileName: file.name,
      fileSize,
      format: file.type || 'video/mp4',
      duration,
      width,
      height,
      aspectRatio,
      orientation,
      estimatedFps,
      bitrateKbps,
    };
  } finally {
    cleanup();
  }
}

// Extract frame at a given second as Data URL
export function extractFrameAt(
  video: HTMLVideoElement,
  timeSec: number,
  format: 'image/png' | 'image/jpeg' = 'image/png',
  quality: number = 0.95
): Promise<string> {
  return new Promise((resolve) => {
    const seekHandler = () => {
      video.removeEventListener('seeked', seekHandler);
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 360;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL(format, quality));
      } else {
        resolve('');
      }
    };

    video.addEventListener('seeked', seekHandler);
    video.currentTime = Math.max(0, Math.min(video.duration || 1, timeSec));
  });
}

// Extract multiple frames
export async function extractFrames(
  file: File,
  timestamps: number[]
): Promise<{ timestamp: number; dataUrl: string }[]> {
  const { video, cleanup } = await loadVideoElement(file);
  const results: { timestamp: number; dataUrl: string }[] = [];

  try {
    for (const time of timestamps) {
      const dataUrl = await extractFrameAt(video, time, 'image/jpeg', 0.9);
      results.push({ timestamp: time, dataUrl });
    }
    return results;
  } finally {
    cleanup();
  }
}

// Contact Sheet Maker (Combines extracted frames into an annotated contact sheet canvas)
export async function createContactSheet(
  file: File,
  numFrames: number = 9,
  columns: number = 3
): Promise<string> {
  const { video, cleanup } = await loadVideoElement(file);
  try {
    const duration = video.duration || 10;
    const interval = duration / (numFrames + 1);
    const timestamps = Array.from({ length: numFrames }, (_, i) => (i + 1) * interval);

    const rows = Math.ceil(numFrames / columns);
    const frameW = 400;
    const frameH = Math.round(frameW * ((video.videoHeight || 720) / (video.videoWidth || 1280)));
    const padding = 12;
    const headerHeight = 70;

    const sheetCanvas = document.createElement('canvas');
    sheetCanvas.width = columns * frameW + (columns + 1) * padding;
    sheetCanvas.height = rows * frameH + (rows + 1) * padding + headerHeight;

    const ctx = sheetCanvas.getContext('2d');
    if (!ctx) return '';

    // Dark sleek background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, sheetCanvas.width, sheetCanvas.height);

    // Header info bar
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, sheetCanvas.width, headerHeight);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 15px Plus Jakarta Sans, system-ui, sans-serif';
    ctx.fillText(file.name, padding + 4, 28);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px Plus Jakarta Sans, system-ui, sans-serif';
    const mins = Math.floor(duration / 60);
    const secs = Math.floor(duration % 60);
    const durStr = `${mins}:${secs.toString().padStart(2, '0')}`;
    ctx.fillText(`Resolution: ${video.videoWidth}x${video.videoHeight}  ·  Duration: ${durStr}  ·  Frames: ${numFrames}`, padding + 4, 52);

    for (let i = 0; i < numFrames; i++) {
      const col = i % columns;
      const row = Math.floor(i / columns);
      const x = padding + col * (frameW + padding);
      const y = headerHeight + padding + row * (frameH + padding);

      const time = timestamps[i];
      const dataUrl = await extractFrameAt(video, time, 'image/jpeg', 0.85);

      const img = new Image();
      await new Promise((res) => {
        img.onload = res;
        img.src = dataUrl;
      });

      // Draw frame
      ctx.drawImage(img, x, y, frameW, frameH);

      // Draw timestamp badge
      const m = Math.floor(time / 60);
      const s = Math.floor(time % 60);
      const badgeText = `${m}:${s.toString().padStart(2, '0')}`;

      ctx.fillStyle = 'rgba(0,0,0,0.75)';
      ctx.fillRect(x + 8, y + frameH - 24, 54, 18);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px monospace';
      ctx.fillText(badgeText, x + 14, y + frameH - 11);
    }

    return sheetCanvas.toDataURL('image/jpeg', 0.95);
  } finally {
    cleanup();
  }
}

// Detect Black Frames
export interface BlackFrameResult {
  blackSegments: { startSec: number; endSec: number; durationSec: number }[];
  totalBlackSec: number;
  percentage: number;
}

export async function detectBlackFrames(
  file: File,
  sampleRateSec: number = 0.5,
  lumaThreshold: number = 18
): Promise<BlackFrameResult> {
  const { video, cleanup } = await loadVideoElement(file);
  try {
    const duration = video.duration || 5;
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 36;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return { blackSegments: [], totalBlackSec: 0, percentage: 0 };

    const blackSegments: { startSec: number; endSec: number; durationSec: number }[] = [];
    let inBlack = false;
    let blackStart = 0;

    for (let t = 0; t <= duration; t += sampleRateSec) {
      await new Promise<void>((res) => {
        const handler = () => {
          video.removeEventListener('seeked', handler);
          res();
        };
        video.addEventListener('seeked', handler);
        video.currentTime = t;
      });

      ctx.drawImage(video, 0, 0, 64, 36);
      const imgData = ctx.getImageData(0, 0, 64, 36).data;

      let totalLuma = 0;
      for (let i = 0; i < imgData.length; i += 4) {
        // Rec. 709 Luma
        const luma = 0.2126 * imgData[i] + 0.7152 * imgData[i + 1] + 0.0722 * imgData[i + 2];
        totalLuma += luma;
      }
      const avgLuma = totalLuma / (imgData.length / 4);

      if (avgLuma < lumaThreshold) {
        if (!inBlack) {
          inBlack = true;
          blackStart = t;
        }
      } else {
        if (inBlack) {
          inBlack = false;
          const dur = t - blackStart;
          if (dur >= sampleRateSec) {
            blackSegments.push({
              startSec: Math.round(blackStart * 10) / 10,
              endSec: Math.round(t * 10) / 10,
              durationSec: Math.round(dur * 10) / 10,
            });
          }
        }
      }
    }

    if (inBlack) {
      const dur = duration - blackStart;
      blackSegments.push({
        startSec: Math.round(blackStart * 10) / 10,
        endSec: Math.round(duration * 10) / 10,
        durationSec: Math.round(dur * 10) / 10,
      });
    }

    const totalBlackSec = blackSegments.reduce((acc, s) => acc + s.durationSec, 0);
    const percentage = duration > 0 ? Math.round((totalBlackSec / duration) * 100) : 0;

    return { blackSegments, totalBlackSec, percentage };
  } finally {
    cleanup();
  }
}

// Detect Duplicate / Frozen Frames
export interface DuplicateFrameResult {
  duplicateCount: number;
  duplicateTimestamps: number[];
  duplicatePercentage: number;
}

export async function detectDuplicateFrames(
  file: File,
  sampleRateSec: number = 0.5,
  mseThreshold: number = 2.0
): Promise<DuplicateFrameResult> {
  const { video, cleanup } = await loadVideoElement(file);
  try {
    const duration = video.duration || 5;
    const canvas = document.createElement('canvas');
    canvas.width = 48;
    canvas.height = 27;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return { duplicateCount: 0, duplicateTimestamps: [], duplicatePercentage: 0 };

    let prevData: Uint8ClampedArray | null = null;
    const duplicateTimestamps: number[] = [];
    let samplesCount = 0;

    for (let t = 0; t <= duration; t += sampleRateSec) {
      samplesCount++;
      await new Promise<void>((res) => {
        const handler = () => {
          video.removeEventListener('seeked', handler);
          res();
        };
        video.addEventListener('seeked', handler);
        video.currentTime = t;
      });

      ctx.drawImage(video, 0, 0, 48, 27);
      const curData = ctx.getImageData(0, 0, 48, 27).data;

      if (prevData) {
        let diffSum = 0;
        for (let i = 0; i < curData.length; i += 4) {
          const diffR = curData[i] - prevData[i];
          const diffG = curData[i + 1] - prevData[i + 1];
          const diffB = curData[i + 2] - prevData[i + 2];
          diffSum += (diffR * diffR + diffG * diffG + diffB * diffB) / 3;
        }
        const mse = diffSum / (curData.length / 4);
        if (mse < mseThreshold) {
          duplicateTimestamps.push(Math.round(t * 10) / 10);
        }
      }

      prevData = new Uint8ClampedArray(curData);
    }

    const duplicatePercentage = samplesCount > 0 ? Math.round((duplicateTimestamps.length / samplesCount) * 100) : 0;
    return {
      duplicateCount: duplicateTimestamps.length,
      duplicateTimestamps,
      duplicatePercentage,
    };
  } finally {
    cleanup();
  }
}

export function getBestSupportedVideoMimeType(): string {
  if (typeof MediaRecorder === 'undefined') return 'video/webm';
  const candidates = [
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
  ];
  for (const t of candidates) {
    if (MediaRecorder.isTypeSupported(t)) return t;
  }
  return 'video/webm';
}

export interface VideoProcessOptions {
  startTime?: number;
  endTime?: number;
  speed?: number;
  volume?: number;
  mute?: boolean;
  filter?: string;
  width?: number;
  height?: number;
  targetBitrate?: number; // bps
  cropX?: number;
  cropY?: number;
  cropWidth?: number;
  cropHeight?: number;
  rotation?: number; // 0, 90, 180, 270
  flipH?: boolean;
  flipV?: boolean;
}

export async function processVideoViaCanvas(
  file: File,
  options: VideoProcessOptions,
  onProgress?: (progress: number) => void
): Promise<{ blob: Blob; url: string; format: string; duration: number }> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'auto';
    video.playsInline = true;
    const url = URL.createObjectURL(file);
    video.src = url;

    video.onloadedmetadata = async () => {
      try {
        const fullDuration = video.duration || 10;
        const start = Math.max(0, options.startTime || 0);
        const end = options.endTime && options.endTime > start ? Math.min(options.endTime, fullDuration) : fullDuration;
        const segmentDuration = Math.max(0.1, end - start);
        const speed = options.speed || 1;
        video.playbackRate = speed;
        video.volume = options.mute ? 0 : Math.min(1, Math.max(0, options.volume ?? 1));
        video.muted = !!options.mute;

        // Determine canvas dimensions
        const nativeW = video.videoWidth || 1280;
        const nativeH = video.videoHeight || 720;
        const targetW = options.width || nativeW;
        const targetH = options.height || nativeH;

        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          throw new Error('Canvas 2D context not available.');
        }

        if (options.filter) {
          ctx.filter = options.filter;
        }

        const canvasStream = canvas.captureStream(30);
        let audioCtx: AudioContext | null = null;

        if (!options.mute) {
          try {
            audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
            const source = audioCtx.createMediaElementSource(video);
            const gain = audioCtx.createGain();
            gain.gain.value = options.volume ?? 1;
            const dest = audioCtx.createMediaStreamDestination();
            source.connect(gain);
            gain.connect(dest);
            gain.connect(audioCtx.destination);

            dest.stream.getAudioTracks().forEach((track) => {
              canvasStream.addTrack(track);
            });
          } catch {
            // Audio context gesture fallback
          }
        }

        const mimeType = getBestSupportedVideoMimeType();
        const recorderOptions: MediaRecorderOptions = {
          mimeType,
        };
        if (options.targetBitrate) {
          recorderOptions.videoBitsPerSecond = options.targetBitrate;
        }

        let mediaRecorder: MediaRecorder;
        try {
          mediaRecorder = new MediaRecorder(canvasStream, recorderOptions);
        } catch {
          mediaRecorder = new MediaRecorder(canvasStream);
        }

        const chunks: Blob[] = [];
        mediaRecorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            chunks.push(e.data);
          }
        };

        let animFrameId: number;
        let isComplete = false;

        const cleanupAll = () => {
          cancelAnimationFrame(animFrameId);
          video.pause();
          video.src = '';
          URL.revokeObjectURL(url);
          if (audioCtx) {
            audioCtx.close().catch(() => {});
          }
        };

        mediaRecorder.onstop = () => {
          cleanupAll();
          const finalBlob = new Blob(chunks, { type: mimeType });
          const resultUrl = URL.createObjectURL(finalBlob);
          const formatExt = mimeType.includes('mp4') ? 'mp4' : 'webm';
          resolve({
            blob: finalBlob,
            url: resultUrl,
            format: formatExt,
            duration: segmentDuration / speed,
          });
        };

        mediaRecorder.onerror = (err) => {
          cleanupAll();
          reject(err);
        };

        const renderFrame = () => {
          if (isComplete) return;

          const currentT = video.currentTime;
          const prog = Math.min(100, Math.max(0, Math.round(((currentT - start) / segmentDuration) * 100)));
          if (onProgress) onProgress(prog);

          if (currentT >= end || video.ended) {
            isComplete = true;
            if (mediaRecorder.state === 'recording') {
              mediaRecorder.stop();
            }
            return;
          }

          ctx.save();
          if (options.rotation || options.flipH || options.flipV) {
            ctx.translate(canvas.width / 2, canvas.height / 2);
            if (options.rotation) ctx.rotate((options.rotation * Math.PI) / 180);
            if (options.flipH || options.flipV) ctx.scale(options.flipH ? -1 : 1, options.flipV ? -1 : 1);
            ctx.drawImage(video, -targetW / 2, -targetH / 2, targetW, targetH);
          } else if (options.cropWidth && options.cropHeight) {
            ctx.drawImage(
              video,
              options.cropX || 0,
              options.cropY || 0,
              options.cropWidth,
              options.cropHeight,
              0,
              0,
              targetW,
              targetH
            );
          } else {
            ctx.drawImage(video, 0, 0, targetW, targetH);
          }
          ctx.restore();

          animFrameId = requestAnimationFrame(renderFrame);
        };

        video.currentTime = start;
        video.onseeked = async () => {
          try {
            await video.play();
            mediaRecorder.start(250);
            renderFrame();
          } catch (playErr) {
            cleanupAll();
            reject(playErr);
          }
        };
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };

    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video file for processing.'));
    };
  });
}
