import React, { useState } from 'react';
import { Copy, Check, ExternalLink } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
  navigate?: (path: string) => void;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content, navigate }) => {
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);

  const handleCopyCode = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeIndex(index);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  const renderContent = () => {
    if (!content) return null;

    // Split content by code blocks: ```lang ... ```
    const segments = content.split(/(```[\s\S]*?```)/g);
    let codeIndex = 0;

    return segments.map((segment, segIdx) => {
      // 1. Code Block
      if (segment.startsWith('```') && segment.endsWith('```')) {
        const firstLineEnd = segment.indexOf('\n');
        const language = firstLineEnd !== -1 ? segment.substring(3, firstLineEnd).trim() : '';
        const code = firstLineEnd !== -1 ? segment.substring(firstLineEnd + 1, segment.length - 3) : segment.substring(3, segment.length - 3);
        const currentIndex = codeIndex++;
        const isCopied = copiedCodeIndex === currentIndex;

        return (
          <div
            key={segIdx}
            className="my-4 rounded-xl overflow-hidden border border-slate-700/80 bg-slate-900 text-slate-100 shadow-sm"
          >
            <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-800/90 border-b border-slate-700/70 text-xs font-mono text-slate-400">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-300">
                {language || 'code'}
              </span>
              <button
                type="button"
                onClick={() => handleCopyCode(code, currentIndex)}
                className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs"
              >
                {isCopied ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-400" />
                    <span className="text-[11px] text-emerald-400 font-medium">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" />
                    <span className="text-[11px]">Copy Code</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 text-xs font-mono overflow-x-auto leading-relaxed whitespace-pre scrollbar-thin">
              <code>{code}</code>
            </pre>
          </div>
        );
      }

      // 2. Standard Text, Lists, Tables, Blockquotes & Headings
      const lines = segment.split('\n');
      const renderedElements: React.ReactNode[] = [];
      let listBuffer: { type: 'ul' | 'ol'; items: string[] } | null = null;
      let tableBuffer: string[] = [];

      const flushList = () => {
        if (!listBuffer || listBuffer.items.length === 0) return;
        const currentList = listBuffer;
        listBuffer = null;

        if (currentList.type === 'ol') {
          renderedElements.push(
            <ol key={`ol-${renderedElements.length}`} className="my-3 pl-6 list-decimal space-y-1.5 text-sm sm:text-[15px] leading-relaxed">
              {currentList.items.map((item, idx) => (
                <li key={idx} className="pl-1">
                  {formatInline(item)}
                </li>
              ))}
            </ol>
          );
        } else {
          renderedElements.push(
            <ul key={`ul-${renderedElements.length}`} className="my-3 pl-6 list-disc space-y-1.5 text-sm sm:text-[15px] leading-relaxed">
              {currentList.items.map((item, idx) => (
                <li key={idx} className="pl-1">
                  {formatInline(item)}
                </li>
              ))}
            </ul>
          );
        }
      };

      const flushTable = () => {
        if (tableBuffer.length === 0) return;
        const tableLines = [...tableBuffer];
        tableBuffer = [];

        // Check if table has at least header and separator
        if (tableLines.length >= 2) {
          const headerCells = tableLines[0]
            .split('|')
            .map((c) => c.trim())
            .filter((c, i, arr) => !(i === 0 && c === '') && !(i === arr.length - 1 && c === ''));

          const bodyRows = tableLines.slice(2).map((row) =>
            row
              .split('|')
              .map((c) => c.trim())
              .filter((c, i, arr) => !(i === 0 && c === '') && !(i === arr.length - 1 && c === ''))
          );

          renderedElements.push(
            <div key={`table-${renderedElements.length}`} className="my-4 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs sm:text-sm border-collapse">
                <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    {headerCells.map((h, i) => (
                      <th key={i} className="px-3.5 py-2.5 font-semibold text-slate-900 dark:text-white">
                        {formatInline(h)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {bodyRows.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="px-3.5 py-2 text-slate-700 dark:text-slate-300">
                          {formatInline(cell)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
          return;
        }

        // Otherwise render as regular lines
        tableLines.forEach((tLine, i) => {
          renderedElements.push(
            <p key={`p-t-${renderedElements.length}-${i}`} className="my-1.5 text-sm leading-relaxed">
              {formatInline(tLine)}
            </p>
          );
        });
      };

      lines.forEach((line, lineIdx) => {
        const trimmed = line.trim();

        // Check if inside a table row
        if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
          flushList();
          tableBuffer.push(trimmed);
          return;
        } else if (tableBuffer.length > 0) {
          flushTable();
        }

        if (!trimmed) {
          flushList();
          return;
        }

        // Headings
        if (trimmed.startsWith('#### ')) {
          flushList();
          renderedElements.push(
            <h5 key={lineIdx} className="text-sm font-semibold text-slate-900 dark:text-white mt-3 mb-1.5">
              {formatInline(trimmed.substring(5))}
            </h5>
          );
          return;
        }

        if (trimmed.startsWith('### ')) {
          flushList();
          renderedElements.push(
            <h4 key={lineIdx} className="text-base font-bold text-slate-900 dark:text-white mt-4 mb-2">
              {formatInline(trimmed.substring(4))}
            </h4>
          );
          return;
        }

        if (trimmed.startsWith('## ')) {
          flushList();
          renderedElements.push(
            <h3 key={lineIdx} className="text-lg font-bold text-slate-900 dark:text-white mt-5 mb-2.5">
              {formatInline(trimmed.substring(3))}
            </h3>
          );
          return;
        }

        if (trimmed.startsWith('# ')) {
          flushList();
          renderedElements.push(
            <h2 key={lineIdx} className="text-xl font-extrabold text-slate-900 dark:text-white mt-6 mb-3">
              {formatInline(trimmed.substring(2))}
            </h2>
          );
          return;
        }

        // Blockquotes
        if (trimmed.startsWith('> ')) {
          flushList();
          renderedElements.push(
            <blockquote
              key={lineIdx}
              className="my-3 pl-3.5 border-l-2 border-indigo-500 text-slate-600 dark:text-slate-400 text-sm sm:text-[15px] italic"
            >
              {formatInline(trimmed.substring(2))}
            </blockquote>
          );
          return;
        }

        // Numbered list items
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
        if (numMatch) {
          if (!listBuffer || listBuffer.type !== 'ol') {
            flushList();
            listBuffer = { type: 'ol', items: [] };
          }
          listBuffer.items.push(numMatch[2]);
          return;
        }

        // Bullet list items
        if (/^[-*•]\s+/.test(trimmed)) {
          if (!listBuffer || listBuffer.type !== 'ul') {
            flushList();
            listBuffer = { type: 'ul', items: [] };
          }
          listBuffer.items.push(trimmed.replace(/^[-*•]\s+/, ''));
          return;
        }

        // Standard Paragraph
        flushList();
        renderedElements.push(
          <p key={lineIdx} className="mb-3.5 text-sm sm:text-[15px] leading-7 text-slate-800 dark:text-slate-200">
            {formatInline(line)}
          </p>
        );
      });

      flushList();
      if (tableBuffer.length > 0) flushTable();

      return <React.Fragment key={segIdx}>{renderedElements}</React.Fragment>;
    });
  };

  // Inline formatting: Bold, Italic, Inline Code, Links
  const formatInline = (text: string): React.ReactNode => {
    // Split on inline patterns: links, code, bold, italic
    const parts = text.split(/(\[.*?\]\(.*?\)|`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);

    return parts.map((part, i) => {
      // 1. Links: [Label](url)
      const linkMatch = part.match(/^\[(.*?)\]\((.*?)\)$/);
      if (linkMatch) {
        const [, label, href] = linkMatch;
        const isInternal = href.startsWith('/') || href.includes('freetoolshub.com');
        return (
          <a
            key={i}
            href={href}
            onClick={(e) => {
              if (isInternal && navigate) {
                e.preventDefault();
                navigate(href.replace('https://freetoolshub.com', ''));
              }
            }}
            className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline inline-flex items-center gap-0.5"
            target={isInternal ? undefined : '_blank'}
            rel="noopener noreferrer"
          >
            <span>{label}</span>
            {!isInternal && <ExternalLink className="h-3 w-3 inline" />}
          </a>
        );
      }

      // 2. Inline code: `code`
      if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
        return (
          <code
            key={i}
            className="px-1.5 py-0.5 mx-0.5 rounded bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-300 font-mono text-[13px] border border-slate-200 dark:border-slate-700/80"
          >
            {part.slice(1, -1)}
          </code>
        );
      }

      // 3. Bold: **bold**
      if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
        return (
          <strong key={i} className="font-semibold text-slate-900 dark:text-white">
            {part.slice(2, -2)}
          </strong>
        );
      }

      // 4. Italic: *italic*
      if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
        return <em key={i} className="italic text-slate-800 dark:text-slate-200">{part.slice(1, -1)}</em>;
      }

      return part;
    });
  };

  return <div className="space-y-0">{renderContent()}</div>;
};
