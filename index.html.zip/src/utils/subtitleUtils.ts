/**
 * Subtitle format parser and converter for SRT, VTT, ASS, SSA.
 * 100% client-side.
 */

export interface SubtitleCue {
  id: number;
  startSec: number;
  endSec: number;
  text: string;
}

// Convert seconds to SRT time format: 00:01:23,456
export function secondsToSrtTime(sec: number): string {
  const s = Math.max(0, sec);
  const hours = Math.floor(s / 3600);
  const minutes = Math.floor((s % 3600) / 60);
  const seconds = Math.floor(s % 60);
  const ms = Math.floor((s % 1) * 1000);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')},${ms.toString().padStart(3, '0')}`;
}

// Convert seconds to VTT time format: 00:01:23.456
export function secondsToVttTime(sec: number): string {
  return secondsToSrtTime(sec).replace(',', '.');
}

// Parse time string (e.g. 00:01:23,456 or 00:01:23.456)
export function parseTimeString(timeStr: string): number {
  const normalized = timeStr.trim().replace(',', '.');
  const parts = normalized.split(':');
  if (parts.length === 3) {
    const hours = parseFloat(parts[0]);
    const minutes = parseFloat(parts[1]);
    const seconds = parseFloat(parts[2]);
    return hours * 3600 + minutes * 60 + seconds;
  } else if (parts.length === 2) {
    const minutes = parseFloat(parts[0]);
    const seconds = parseFloat(parts[1]);
    return minutes * 60 + seconds;
  }
  return 0;
}

// Parse SRT or VTT content into SubtitleCue[]
export function parseSubtitle(content: string): SubtitleCue[] {
  const cues: SubtitleCue[] = [];
  const normalized = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const blocks = normalized.split(/\n\s*\n/);

  let cueCount = 1;
  for (const block of blocks) {
    const lines = block.trim().split('\n');
    if (lines.length < 2) continue;

    let timeLineIdx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].includes('-->')) {
        timeLineIdx = i;
        break;
      }
    }

    if (timeLineIdx !== -1) {
      const timeLine = lines[timeLineIdx];
      const [startStr, endStr] = timeLine.split('-->');
      if (startStr && endStr) {
        const startSec = parseTimeString(startStr.trim().split(' ')[0]);
        const endSec = parseTimeString(endStr.trim().split(' ')[0]);
        const text = lines.slice(timeLineIdx + 1).join('\n');
        cues.push({
          id: cueCount++,
          startSec,
          endSec,
          text,
        });
      }
    }
  }

  return cues;
}

// Format cues to SRT
export function cuesToSrt(cues: SubtitleCue[]): string {
  return cues
    .map((cue, idx) => `${idx + 1}\n${secondsToSrtTime(cue.startSec)} --> ${secondsToSrtTime(cue.endSec)}\n${cue.text}\n`)
    .join('\n');
}

// Format cues to VTT
export function cuesToVtt(cues: SubtitleCue[]): string {
  const body = cues
    .map((cue, idx) => `${idx + 1}\n${secondsToVttTime(cue.startSec)} --> ${secondsToVttTime(cue.endSec)}\n${cue.text}\n`)
    .join('\n');
  return `WEBVTT\n\n${body}`;
}

// Format cues to ASS/SSA
export function cuesToAss(cues: SubtitleCue[]): string {
  const header = `[Script Info]
Title: Subtitle converted via Free Tools Hub
ScriptType: v4.00+
Collisions: Normal
PlayDepth: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,10,10,10,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const formatAssTime = (sec: number) => {
    const s = Math.max(0, sec);
    const hours = Math.floor(s / 3600);
    const minutes = Math.floor((s % 3600) / 60);
    const seconds = Math.floor(s % 60);
    const cs = Math.floor((s % 1) * 100);
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${cs.toString().padStart(2, '0')}`;
  };

  const events = cues
    .map((c) => {
      const sanitizedText = c.text.replace(/\n/g, '\\N');
      return `Dialogue: 0,${formatAssTime(c.startSec)},${formatAssTime(c.endSec)},Default,,0,0,0,,${sanitizedText}`;
    })
    .join('\n');

  return header + events;
}

// Adjust subtitle timing by offset in seconds (+ or -)
export function shiftSubtitleTiming(cues: SubtitleCue[], offsetSeconds: number): SubtitleCue[] {
  return cues.map((c) => ({
    ...c,
    startSec: Math.max(0, c.startSec + offsetSeconds),
    endSec: Math.max(0.1, c.endSec + offsetSeconds),
  }));
}
