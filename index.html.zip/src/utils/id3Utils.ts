/**
 * ID3 Tag Editor & Album Art Remover utility for MP3 files.
 * 100% client-side pure binary parsing.
 */

export interface ID3Metadata {
  title: string;
  artist: string;
  album: string;
  year: string;
  genre: string;
  track: string;
  hasArtwork: boolean;
}

export function parseID3Tags(arrayBuffer: ArrayBuffer): ID3Metadata {
  const meta: ID3Metadata = {
    title: '',
    artist: '',
    album: '',
    year: '',
    genre: '',
    track: '',
    hasArtwork: false,
  };

  const view = new DataView(arrayBuffer);
  // Check for ID3v2 header: 'ID3' at byte 0
  if (
    view.getUint8(0) === 0x49 &&
    view.getUint8(1) === 0x44 &&
    view.getUint8(2) === 0x33
  ) {
    const majorVersion = view.getUint8(3);
    const tagSize =
      ((view.getUint8(6) & 0x7f) << 21) |
      ((view.getUint8(7) & 0x7f) << 14) |
      ((view.getUint8(8) & 0x7f) << 7) |
      (view.getUint8(9) & 0x7f);

    let offset = 10;
    while (offset < tagSize + 10 && offset + 10 < arrayBuffer.byteLength) {
      const frameId = String.fromCharCode(
        view.getUint8(offset),
        view.getUint8(offset + 1),
        view.getUint8(offset + 2),
        view.getUint8(offset + 3)
      );

      if (frameId.charCodeAt(0) === 0) break;

      const frameSize =
        majorVersion === 4
          ? ((view.getUint8(offset + 4) & 0x7f) << 21) |
            ((view.getUint8(offset + 5) & 0x7f) << 14) |
            ((view.getUint8(offset + 6) & 0x7f) << 7) |
            (view.getUint8(offset + 7) & 0x7f)
          : view.getUint32(offset + 4);

      if (frameSize <= 0 || offset + 10 + frameSize > arrayBuffer.byteLength) break;

      if (frameId === 'TIT2') {
        meta.title = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'TPE1') {
        meta.artist = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'TALB') {
        meta.album = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'TYER' || frameId === 'TDRC') {
        meta.year = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'TCON') {
        meta.genre = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'TRCK') {
        meta.track = readTextFrame(view, offset + 10, frameSize);
      } else if (frameId === 'APIC') {
        meta.hasArtwork = true;
      }

      offset += 10 + frameSize;
    }
  }

  return meta;
}

function readTextFrame(view: DataView, offset: number, size: number): string {
  if (size <= 1) return '';
  const encoding = view.getUint8(offset);
  let text = '';
  // UTF-8 or ISO-8859-1
  if (encoding === 0 || encoding === 3) {
    for (let i = 1; i < size; i++) {
      const code = view.getUint8(offset + i);
      if (code === 0) break;
      text += String.fromCharCode(code);
    }
  } else {
    // UCS-2 / UTF-16
    for (let i = 1; i < size - 1; i += 2) {
      const code = view.getUint16(offset + i, true);
      if (code === 0) break;
      text += String.fromCharCode(code);
    }
  }
  return text.trim();
}

// Remove APIC (album artwork) frame from MP3
export function removeAlbumArt(arrayBuffer: ArrayBuffer): Blob {
  const view = new DataView(arrayBuffer);
  // If not ID3v2, return original
  if (
    view.getUint8(0) !== 0x49 ||
    view.getUint8(1) !== 0x44 ||
    view.getUint8(2) !== 0x33
  ) {
    return new Blob([arrayBuffer], { type: 'audio/mp3' });
  }

  const tagSize =
    ((view.getUint8(6) & 0x7f) << 21) |
    ((view.getUint8(7) & 0x7f) << 14) |
    ((view.getUint8(8) & 0x7f) << 7) |
    (view.getUint8(9) & 0x7f);

  let offset = 10;
  const filteredChunks: Uint8Array[] = [new Uint8Array(arrayBuffer.slice(0, 10))];
  let newTagSize = 0;

  while (offset < tagSize + 10 && offset + 10 < arrayBuffer.byteLength) {
    const frameId = String.fromCharCode(
      view.getUint8(offset),
      view.getUint8(offset + 1),
      view.getUint8(offset + 2),
      view.getUint8(offset + 3)
    );

    if (frameId.charCodeAt(0) === 0) break;

    const frameSize = view.getUint32(offset + 4);
    if (frameSize <= 0 || offset + 10 + frameSize > arrayBuffer.byteLength) break;

    if (frameId !== 'APIC') {
      const chunk = new Uint8Array(arrayBuffer.slice(offset, offset + 10 + frameSize));
      filteredChunks.push(chunk);
      newTagSize += 10 + frameSize;
    }

    offset += 10 + frameSize;
  }

  // Update tag size in header chunk
  const header = filteredChunks[0];
  header[6] = (newTagSize >> 21) & 0x7f;
  header[7] = (newTagSize >> 14) & 0x7f;
  header[8] = (newTagSize >> 7) & 0x7f;
  header[9] = newTagSize & 0x7f;

  // Append remaining audio payload
  const audioPayload = new Uint8Array(arrayBuffer.slice(tagSize + 10));
  filteredChunks.push(audioPayload);

  return new Blob(filteredChunks as unknown as BlobPart[], { type: 'audio/mp3' });
}

// Build new ID3v2 header and tags
export function writeID3Tags(
  arrayBuffer: ArrayBuffer,
  meta: Partial<ID3Metadata>
): Blob {
  const frames: Uint8Array[] = [];

  const addTextFrame = (id: string, value?: string) => {
    if (!value || !value.trim()) return;
    const textBytes = new TextEncoder().encode(value.trim());
    const frameData = new Uint8Array(1 + textBytes.length);
    frameData[0] = 3; // UTF-8 encoding
    frameData.set(textBytes, 1);

    const frameHeader = new Uint8Array(10);
    for (let i = 0; i < 4; i++) frameHeader[i] = id.charCodeAt(i);
    // Size as 32-bit big endian
    const size = frameData.length;
    frameHeader[4] = (size >> 24) & 0xff;
    frameHeader[5] = (size >> 16) & 0xff;
    frameHeader[6] = (size >> 8) & 0xff;
    frameHeader[7] = size & 0xff;

    frames.push(frameHeader);
    frames.push(frameData);
  };

  addTextFrame('TIT2', meta.title);
  addTextFrame('TPE1', meta.artist);
  addTextFrame('TALB', meta.album);
  addTextFrame('TYER', meta.year);
  addTextFrame('TCON', meta.genre);
  addTextFrame('TRCK', meta.track);

  let totalFramesSize = 0;
  for (const f of frames) totalFramesSize += f.length;

  const header = new Uint8Array(10);
  header[0] = 0x49; // 'I'
  header[1] = 0x44; // 'D'
  header[2] = 0x33; // '3'
  header[3] = 4; // version 2.4
  header[4] = 0;
  header[5] = 0; // flags
  // Synchsafe size
  header[6] = (totalFramesSize >> 21) & 0x7f;
  header[7] = (totalFramesSize >> 14) & 0x7f;
  header[8] = (totalFramesSize >> 7) & 0x7f;
  header[9] = totalFramesSize & 0x7f;

  // Determine where audio payload begins in source
  const view = new DataView(arrayBuffer);
  let audioStart = 0;
  if (
    view.getUint8(0) === 0x49 &&
    view.getUint8(1) === 0x44 &&
    view.getUint8(2) === 0x33
  ) {
    const existingTagSize =
      ((view.getUint8(6) & 0x7f) << 21) |
      ((view.getUint8(7) & 0x7f) << 14) |
      ((view.getUint8(8) & 0x7f) << 7) |
      (view.getUint8(9) & 0x7f);
    audioStart = existingTagSize + 10;
  }

  const audioPayload = new Uint8Array(arrayBuffer.slice(audioStart));
  return new Blob([header, ...frames, audioPayload] as unknown as BlobPart[], { type: 'audio/mp3' });
}
