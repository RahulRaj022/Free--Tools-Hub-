import React, { useState, useEffect, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, Trash2, Check, Sparkles, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';

interface DeveloperToolsProps {
  toolSlug: string;
}

export const DeveloperTools: React.FC<DeveloperToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // JSON Formatter states
  const [jsonInput, setJsonInput] = useState<string>(
    JSON.stringify(
      {
        site: 'Free Tools Hub',
        features: ['100% Free', 'Client-side', 'No signup'],
        metrics: { toolsCount: 35, privacyScore: 100 },
        active: true,
      },
      null,
      2
    )
  );
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Base64 states
  const [b64Mode, setB64Mode] = useState<'encode' | 'decode'>('encode');
  const [b64Input, setB64Input] = useState<string>('Hello World! 🚀 Free Tools Hub');
  const [b64Output, setB64Output] = useState<string>('');
  const [b64Error, setB64Error] = useState<string | null>(null);

  // URL Encoder states
  const [urlMode, setUrlMode] = useState<'encode' | 'decode'>('encode');
  const [urlInput, setUrlInput] = useState<string>('https://example.com/search?query=free tools&category=pdf');
  const [urlOutput, setUrlOutput] = useState<string>('');

  // UUID Generator states
  const [uuidCount, setUuidCount] = useState<number>(5);
  const [uuidUppercase, setUuidUppercase] = useState<boolean>(false);
  const [uuidHyphens, setUuidHyphens] = useState<boolean>(true);
  const [generatedUuids, setGeneratedUuids] = useState<string[]>([]);

  // Hash Generator states
  const [hashInput, setHashInput] = useState<string>('Free Tools Hub');
  const [hashes, setHashes] = useState<{ sha256: string; sha1: string; sha384: string; sha512: string }>({
    sha256: '',
    sha1: '',
    sha384: '',
    sha512: '',
  });

  // Timestamp states
  const [currentEpoch, setCurrentEpoch] = useState<number>(Math.floor(Date.now() / 1000));
  const [timestampInput, setTimestampInput] = useState<string>(String(Math.floor(Date.now() / 1000)));
  const [dateInput, setDateInput] = useState<string>(() => new Date().toISOString().slice(0, 16));

  // Color Converter states
  const [hexColor, setHexColor] = useState<string>('#5B5BF7');

  // Regex Tester states
  const [regexPattern, setRegexPattern] = useState<string>('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}');
  const [regexFlags, setRegexFlags] = useState<string>('g');
  const [regexText, setRegexText] = useState<string>(
    'Contact support@freetoolshub.com or hello@example.org for quick assistance.'
  );
  const [regexReplace, setRegexReplace] = useState<string>('[email protected]');

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // 1. JSON FORMATTER LOGIC
  const formatJson = (spaces: number) => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonInput(JSON.stringify(parsed, null, spaces));
      setJsonError(null);
      showToast('JSON formatted successfully', 'success');
    } catch (e: any) {
      setJsonError(e.message);
      showToast('Invalid JSON syntax', 'error');
    }
  };

  const minifyJson = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonInput(JSON.stringify(parsed));
      setJsonError(null);
      showToast('JSON minified', 'success');
    } catch (e: any) {
      setJsonError(e.message);
      showToast('Invalid JSON syntax', 'error');
    }
  };

  // 2. BASE64 LOGIC
  useEffect(() => {
    if (!b64Input) {
      setB64Output('');
      setB64Error(null);
      return;
    }
    if (b64Mode === 'encode') {
      try {
        const encoded = btoa(unescape(encodeURIComponent(b64Input)));
        setB64Output(encoded);
        setB64Error(null);
      } catch (err: any) {
        setB64Error(err.message);
      }
    } else {
      try {
        const decoded = decodeURIComponent(escape(atob(b64Input.trim())));
        setB64Output(decoded);
        setB64Error(null);
      } catch (err: any) {
        setB64Error('Invalid Base64 sequence');
      }
    }
  }, [b64Input, b64Mode]);

  // 3. URL ENCODER LOGIC
  useEffect(() => {
    if (!urlInput) {
      setUrlOutput('');
      return;
    }
    try {
      if (urlMode === 'encode') {
        setUrlOutput(encodeURIComponent(urlInput));
      } else {
        setUrlOutput(decodeURIComponent(urlInput));
      }
    } catch {
      setUrlOutput('Malformed URL component');
    }
  }, [urlInput, urlMode]);

  // 4. UUID LOGIC
  const generateUuids = () => {
    const list: string[] = [];
    for (let i = 0; i < uuidCount; i++) {
      let id: string = crypto.randomUUID();
      if (!uuidHyphens) {
        id = id.replace(/-/g, '');
      }
      if (uuidUppercase) {
        id = id.toUpperCase();
      }
      list.push(id);
    }
    setGeneratedUuids(list);
  };

  useEffect(() => {
    generateUuids();
  }, [uuidCount, uuidUppercase, uuidHyphens]);

  // 5. HASH GENERATOR LOGIC
  useEffect(() => {
    const computeHashes = async () => {
      if (!hashInput) {
        setHashes({ sha256: '', sha1: '', sha384: '', sha512: '' });
        return;
      }
      const encoder = new TextEncoder();
      const data = encoder.encode(hashInput);

      const bufToHex = (buf: ArrayBuffer) =>
        Array.from(new Uint8Array(buf))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');

      try {
        const [h256, h1, h384, h512] = await Promise.all([
          crypto.subtle.digest('SHA-256', data),
          crypto.subtle.digest('SHA-1', data),
          crypto.subtle.digest('SHA-384', data),
          crypto.subtle.digest('SHA-512', data),
        ]);

        setHashes({
          sha256: bufToHex(h256),
          sha1: bufToHex(h1),
          sha384: bufToHex(h384),
          sha512: bufToHex(h512),
        });
      } catch (err) {
        console.error('Hash calculation failed', err);
      }
    };
    computeHashes();
  }, [hashInput]);

  // 6. TIMESTAMP LOGIC
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentEpoch(Math.floor(Date.now() / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const convertedTimestamp = useMemo(() => {
    const num = parseInt(timestampInput);
    if (isNaN(num)) return null;
    const ms = timestampInput.length > 11 ? num : num * 1000;
    const d = new Date(ms);
    if (isNaN(d.getTime())) return null;

    return {
      utc: d.toUTCString(),
      local: d.toLocaleString(),
      iso: d.toISOString(),
      relative: `${Math.round((Date.now() - d.getTime()) / (1000 * 60))} minutes ago`,
    };
  }, [timestampInput]);

  // 7. COLOR CONVERTER LOGIC
  const colorFormats = useMemo(() => {
    let cleanHex = hexColor.trim().replace(/^#/, '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map((c) => c + c).join('');
    }
    if (cleanHex.length !== 6) return null;

    const r = parseInt(cleanHex.substring(0, 2), 16);
    const g = parseInt(cleanHex.substring(2, 4), 16);
    const b = parseInt(cleanHex.substring(4, 6), 16);

    if (isNaN(r) || isNaN(g) || isNaN(b)) return null;

    // Convert to HSL
    const rNorm = r / 255;
    const gNorm = g / 255;
    const bNorm = b / 255;
    const max = Math.max(rNorm, gNorm, bNorm);
    const min = Math.min(rNorm, gNorm, bNorm);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case rNorm:
          h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0);
          break;
        case gNorm:
          h = (bNorm - rNorm) / d + 2;
          break;
        case bNorm:
          h = (rNorm - gNorm) / d + 4;
          break;
      }
      h /= 6;
    }

    return {
      hex: `#${cleanHex.toUpperCase()}`,
      rgb: `rgb(${r}, ${g}, ${b})`,
      rgba: `rgba(${r}, ${g}, ${b}, 1)`,
      hsl: `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`,
      r,
      g,
      b,
    };
  }, [hexColor]);

  // 8. REGEX TESTER LOGIC
  const regexResult = useMemo(() => {
    if (!regexPattern) return null;
    try {
      const re = new RegExp(regexPattern, regexFlags);
      const matches = Array.from(regexText.matchAll(re));
      const replaced = regexText.replace(re, regexReplace);

      return {
        valid: true,
        matchCount: matches.length,
        matches: matches.map((m) => ({
          text: m[0],
          index: m.index,
          groups: m.slice(1),
        })),
        replaced,
      };
    } catch (err: any) {
      return {
        valid: false,
        error: err.message,
        matchCount: 0,
        matches: [],
        replaced: regexText,
      };
    }
  }, [regexPattern, regexFlags, regexText, regexReplace]);

  return (
    <div className="space-y-6">
      {/* 1. JSON FORMATTER */}
      {toolSlug === 'json-formatter' && (
        <div className="rounded-xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900 overflow-hidden space-y-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs">
              <button
                onClick={() => formatJson(2)}
                className="px-3 py-1 font-semibold rounded-md bg-white dark:bg-slate-700 text-indigo-600 shadow-xs"
              >
                Format (2 Spaces)
              </button>
              <button
                onClick={() => formatJson(4)}
                className="px-3 py-1 font-medium rounded-md text-slate-700 dark:text-slate-300 hover:text-indigo-600"
              >
                Format (4 Spaces)
              </button>
              <button
                onClick={minifyJson}
                className="px-3 py-1 font-medium rounded-md text-slate-700 dark:text-slate-300 hover:text-indigo-600"
              >
                Minify JSON
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => copyToClipboard(jsonInput, 'json')}
                className="flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400"
              >
                {copiedKey === 'json' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                Copy JSON
              </button>
              <button
                onClick={() => setJsonInput('')}
                className="p-1 text-slate-400 hover:text-rose-500 rounded"
                title="Clear"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>

          {jsonError && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-50 border border-rose-200 dark:bg-rose-950/50 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{jsonError}</span>
            </div>
          )}

          <textarea
            value={jsonInput}
            onChange={(e) => {
              setJsonInput(e.target.value);
              setJsonError(null);
            }}
            rows={14}
            className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            placeholder="Paste your JSON here..."
          />
        </div>
      )}

      {/* 2. BASE64 ENCODER & DECODER */}
      {toolSlug === 'base64-encoder' && (
        <div className="space-y-6">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-semibold w-fit">
            <button
              onClick={() => setB64Mode('encode')}
              className={`px-4 py-1.5 rounded-md transition-colors ${
                b64Mode === 'encode' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Encode to Base64
            </button>
            <button
              onClick={() => setB64Mode('decode')}
              className={`px-4 py-1.5 rounded-md transition-colors ${
                b64Mode === 'decode' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Decode Base64
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {b64Mode === 'encode' ? 'Plain Text Input' : 'Base64 Input'}
              </label>
              <textarea
                value={b64Input}
                onChange={(e) => setB64Input(e.target.value)}
                rows={8}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-slate-900 dark:text-white"
                placeholder={b64Mode === 'encode' ? 'Enter text to encode...' : 'Paste base64 string...'}
              />
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {b64Mode === 'encode' ? 'Base64 Output' : 'Decoded Plain Text'}
                </label>
                <button
                  onClick={() => copyToClipboard(b64Output, 'b64')}
                  className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400"
                >
                  {copiedKey === 'b64' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  Copy
                </button>
              </div>
              <textarea
                readOnly
                value={b64Error ? `Error: ${b64Error}` : b64Output}
                rows={8}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-indigo-600 dark:text-indigo-400 break-all"
              />
            </div>
          </div>
        </div>
      )}

      {/* 3. URL ENCODER & DECODER */}
      {toolSlug === 'url-encoder-decoder' && (
        <div className="space-y-6">
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-semibold w-fit">
            <button
              onClick={() => setUrlMode('encode')}
              className={`px-4 py-1.5 rounded-md transition-colors ${
                urlMode === 'encode' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Encode URL
            </button>
            <button
              onClick={() => setUrlMode('decode')}
              className={`px-4 py-1.5 rounded-md transition-colors ${
                urlMode === 'decode' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Decode URL
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Input
              </label>
              <textarea
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                rows={7}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-slate-900 dark:text-white"
              />
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Result
                </label>
                <button
                  onClick={() => copyToClipboard(urlOutput, 'url')}
                  className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400"
                >
                  {copiedKey === 'url' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  Copy
                </button>
              </div>
              <textarea
                readOnly
                value={urlOutput}
                rows={7}
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-indigo-600 dark:text-indigo-400 break-all"
              />
            </div>
          </div>
        </div>
      )}

      {/* 4. UUID GENERATOR */}
      {toolSlug === 'uuid-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-700 dark:text-slate-300">
              <div className="flex items-center gap-2">
                <span>Quantity:</span>
                <select
                  value={uuidCount}
                  onChange={(e) => setUuidCount(Number(e.target.value))}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                >
                  <option value={1}>1 UUID</option>
                  <option value={5}>5 UUIDs</option>
                  <option value={10}>10 UUIDs</option>
                  <option value={25}>25 UUIDs</option>
                  <option value={50}>50 UUIDs</option>
                </select>
              </div>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={uuidUppercase}
                  onChange={(e) => setUuidUppercase(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Uppercase
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={uuidHyphens}
                  onChange={(e) => setUuidHyphens(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Include Hyphens
              </label>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={generateUuids}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Regenerate
              </button>
              <button
                onClick={() => copyToClipboard(generatedUuids.join('\n'), 'all-uuids')}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {copiedKey === 'all-uuids' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                Copy All
              </button>
            </div>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto">
            {generatedUuids.map((id, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-slate-800 dark:text-slate-200 select-all"
              >
                <span>{id}</span>
                <button
                  onClick={() => copyToClipboard(id, `uuid-${idx}`)}
                  className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                  title="Copy this UUID"
                >
                  {copiedKey === `uuid-${idx}` ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. HASH GENERATOR */}
      {toolSlug === 'hash-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Input Text / Message
            </label>
            <input
              type="text"
              value={hashInput}
              onChange={(e) => setHashInput(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              placeholder="Type any text to compute cryptographic hashes..."
            />
          </div>

          <div className="space-y-4">
            {[
              { label: 'SHA-256 (Industry Standard)', value: hashes.sha256, key: 'sha256' },
              { label: 'SHA-1 (Legacy)', value: hashes.sha1, key: 'sha1' },
              { label: 'SHA-384', value: hashes.sha384, key: 'sha384' },
              { label: 'SHA-512 (High Security)', value: hashes.sha512, key: 'sha512' },
            ].map((item) => (
              <div key={item.key} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>{item.label}</span>
                  <button
                    onClick={() => copyToClipboard(item.value, item.key)}
                    className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400"
                  >
                    {copiedKey === item.key ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    Copy
                  </button>
                </div>
                <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-200 break-all select-all">
                  {item.value || '...'}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. TIMESTAMP CONVERTER */}
      {toolSlug === 'timestamp-converter' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 dark:bg-indigo-950/40 dark:border-indigo-900/60 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Current Unix Epoch Time
              </div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                {currentEpoch}
              </div>
            </div>
            <button
              onClick={() => {
                setTimestampInput(String(currentEpoch));
                copyToClipboard(String(currentEpoch), 'curr-epoch');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
            >
              <Copy className="h-3.5 w-3.5" />
              Use Current
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Timestamp to Human Date
              </label>
              <input
                type="text"
                value={timestampInput}
                onChange={(e) => setTimestampInput(e.target.value)}
                placeholder="e.g. 1770000000"
                className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />

              {convertedTimestamp && (
                <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2 text-xs">
                  <div>
                    <span className="text-slate-500">UTC:</span>{' '}
                    <span className="font-mono font-medium text-slate-900 dark:text-white">{convertedTimestamp.utc}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Local:</span>{' '}
                    <span className="font-mono font-medium text-slate-900 dark:text-white">{convertedTimestamp.local}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">ISO 8601:</span>{' '}
                    <span className="font-mono text-indigo-600 dark:text-indigo-400">{convertedTimestamp.iso}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Human Date to Timestamp
              </label>
              <input
                type="datetime-local"
                value={dateInput}
                onChange={(e) => setDateInput(e.target.value)}
                className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2 text-xs">
                <div>
                  <span className="text-slate-500">Unix Seconds:</span>{' '}
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {Math.floor(new Date(dateInput).getTime() / 1000)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">Milliseconds:</span>{' '}
                  <span className="font-mono text-indigo-600 dark:text-indigo-400">
                    {new Date(dateInput).getTime()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. COLOR CONVERTER */}
      {toolSlug === 'color-converter' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div
              className="h-28 w-28 sm:h-36 sm:w-36 rounded-2xl border-4 border-white dark:border-slate-800 shadow-lg shrink-0 flex items-center justify-center transition-all"
              style={{ backgroundColor: colorFormats ? colorFormats.hex : '#5B5BF7' }}
            >
              <input
                type="color"
                value={colorFormats ? colorFormats.hex : '#5B5BF7'}
                onChange={(e) => setHexColor(e.target.value)}
                className="opacity-0 w-full h-full cursor-pointer"
                title="Click to open color picker"
              />
            </div>

            <div className="flex-1 w-full space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  HEX Code
                </label>
                <input
                  type="text"
                  value={hexColor}
                  onChange={(e) => setHexColor(e.target.value)}
                  className="w-full px-3.5 py-2 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white uppercase"
                />
              </div>

              {colorFormats && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-700 dark:text-slate-300">{colorFormats.rgb}</span>
                    <button
                      onClick={() => copyToClipboard(colorFormats.rgb, 'rgb')}
                      className="text-indigo-600 dark:text-indigo-400 font-semibold"
                    >
                      Copy
                    </button>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-700 dark:text-slate-300">{colorFormats.hsl}</span>
                    <button
                      onClick={() => copyToClipboard(colorFormats.hsl, 'hsl')}
                      className="text-indigo-600 dark:text-indigo-400 font-semibold"
                    >
                      Copy
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 8. REGEX TESTER */}
      {toolSlug === 'regex-tester' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-9">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Regular Expression Pattern
              </label>
              <div className="flex items-center rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 overflow-hidden px-3">
                <span className="text-slate-400 font-mono text-sm mr-1">/</span>
                <input
                  type="text"
                  value={regexPattern}
                  onChange={(e) => setRegexPattern(e.target.value)}
                  className="w-full py-2 text-sm font-mono bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  placeholder="[0-9]+"
                />
                <span className="text-slate-400 font-mono text-sm ml-1">/</span>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Flags (g, i, m, s)
              </label>
              <input
                type="text"
                value={regexFlags}
                onChange={(e) => setRegexFlags(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                placeholder="g"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Test String
            </label>
            <textarea
              value={regexText}
              onChange={(e) => setRegexText(e.target.value)}
              rows={4}
              className="w-full p-3 rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 font-mono text-xs sm:text-sm text-slate-900 dark:text-white"
            />
          </div>

          {regexResult && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Matches Found:{' '}
                  <span className="font-mono text-indigo-600 dark:text-indigo-400">{regexResult.matchCount}</span>
                </span>
              </div>

              {regexResult.matches.length > 0 && (
                <div className="max-h-40 overflow-y-auto space-y-1.5 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs">
                  {regexResult.matches.map((m, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-indigo-600 dark:text-indigo-400 font-bold">#{idx + 1}:</span>
                      <span className="bg-indigo-100 dark:bg-indigo-900/60 text-slate-900 dark:text-white px-1.5 py-0.5 rounded">
                        {m.text}
                      </span>
                      <span className="text-slate-400 text-[11px]">(Index: {m.index})</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
