import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { DollarSign, Percent, TrendingUp, Calculator, RefreshCw, Check, Copy } from 'lucide-react';

interface FinanceToolsProps {
  toolSlug: string;
}

export const FinanceTools: React.FC<FinanceToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- 1. Loan & Mortgage State ---
  const [loanAmount, setLoanAmount] = useState<string>('300000');
  const [loanRate, setLoanRate] = useState<string>('6.5');
  const [loanTermYears, setLoanTermYears] = useState<string>('30');

  const mortgageResults = useMemo(() => {
    const P = parseFloat(loanAmount) || 0;
    const annualR = (parseFloat(loanRate) || 0) / 100;
    const r = annualR / 12;
    const n = (parseFloat(loanTermYears) || 0) * 12;

    if (P <= 0 || n <= 0) return { monthly: 0, totalPayment: 0, totalInterest: 0, schedule: [] };

    let monthly = 0;
    if (r === 0) {
      monthly = P / n;
    } else {
      monthly = (P * (r * Math.pow(1 + r, n))) / (Math.pow(1 + r, n) - 1);
    }
    const totalPayment = monthly * n;
    const totalInterest = totalPayment - P;

    // First 5 years amortization summary
    const schedule: Array<{ year: number; balance: number; interestPaidYear: number; principalPaidYear: number }> = [];
    let balance = P;
    for (let yr = 1; yr <= Math.min(5, Math.ceil(n / 12)); yr++) {
      let yrInterest = 0;
      let yrPrincipal = 0;
      for (let m = 1; m <= 12; m++) {
        if (balance <= 0) break;
        const interestMonth = balance * r;
        const principalMonth = Math.min(balance, monthly - interestMonth);
        yrInterest += interestMonth;
        yrPrincipal += principalMonth;
        balance -= principalMonth;
      }
      schedule.push({ year: yr, balance: Math.max(0, balance), interestPaidYear: yrInterest, principalPaidYear: yrPrincipal });
    }

    return { monthly, totalPayment, totalInterest, schedule };
  }, [loanAmount, loanRate, loanTermYears]);

  // --- 2. Sales Tax / VAT State ---
  const [taxAmountInput, setTaxAmountInput] = useState<string>('100');
  const [taxRatePercent, setTaxRatePercent] = useState<string>('8.5');
  const [taxMode, setTaxMode] = useState<'add' | 'extract'>('add');

  const taxResults = useMemo(() => {
    const amt = parseFloat(taxAmountInput) || 0;
    const rate = (parseFloat(taxRatePercent) || 0) / 100;
    if (taxMode === 'add') {
      const tax = amt * rate;
      const total = amt + tax;
      return { base: amt, tax, total };
    } else {
      const base = amt / (1 + rate);
      const tax = amt - base;
      return { base, tax, total: amt };
    }
  }, [taxAmountInput, taxRatePercent, taxMode]);

  // --- 3. ROI Calculator State ---
  const [roiInitial, setRoiInitial] = useState<string>('10000');
  const [roiFinal, setRoiFinal] = useState<string>('14500');
  const [roiYears, setRoiYears] = useState<string>('3');

  const roiResults = useMemo(() => {
    const init = parseFloat(roiInitial) || 0;
    const finalVal = parseFloat(roiFinal) || 0;
    const yrs = parseFloat(roiYears) || 1;
    if (init <= 0) return { netProfit: 0, totalRoi: 0, annualizedRoi: 0 };

    const netProfit = finalVal - init;
    const totalRoi = (netProfit / init) * 100;
    const annualizedRoi = yrs > 0 ? (Math.pow(finalVal / init, 1 / yrs) - 1) * 100 : totalRoi;
    return { netProfit, totalRoi, annualizedRoi };
  }, [roiInitial, roiFinal, roiYears]);

  // --- 4. Break-Even Calculator State ---
  const [fixedCosts, setFixedCosts] = useState<string>('50000');
  const [unitPrice, setUnitPrice] = useState<string>('120');
  const [varCostPerUnit, setVarCostPerUnit] = useState<string>('45');

  const breakEvenResults = useMemo(() => {
    const fc = parseFloat(fixedCosts) || 0;
    const p = parseFloat(unitPrice) || 0;
    const vc = parseFloat(varCostPerUnit) || 0;
    const cm = p - vc; // contribution margin
    if (cm <= 0) return { units: 0, revenue: 0, marginRatio: 0 };

    const units = Math.ceil(fc / cm);
    const revenue = units * p;
    const marginRatio = (cm / p) * 100;
    return { units, revenue, marginRatio };
  }, [fixedCosts, unitPrice, varCostPerUnit]);

  // --- 5. Salary to Hourly Calculator State ---
  const [salaryWage, setSalaryWage] = useState<string>('75000');
  const [wageType, setWageType] = useState<'annual' | 'hourly'>('annual');
  const [hoursPerWeek, setHoursPerWeek] = useState<string>('40');
  const [weeksPerYear, setWeeksPerYear] = useState<string>('52');

  const salaryResults = useMemo(() => {
    const val = parseFloat(salaryWage) || 0;
    const hpw = parseFloat(hoursPerWeek) || 40;
    const wpy = parseFloat(weeksPerYear) || 52;
    const totalHours = hpw * wpy;

    let annual = 0;
    let hourly = 0;
    if (wageType === 'annual') {
      annual = val;
      hourly = totalHours > 0 ? val / totalHours : 0;
    } else {
      hourly = val;
      annual = val * totalHours;
    }
    const monthly = annual / 12;
    const weekly = wpy > 0 ? annual / wpy : 0;
    const daily = hpw > 0 ? (weekly / 5) : 0;

    return { annual, monthly, weekly, daily, hourly };
  }, [salaryWage, wageType, hoursPerWeek, weeksPerYear]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast(`Copied ${text}`, 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. LOAN & MORTGAGE CALCULATOR */}
      {toolSlug === 'loan-mortgage-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Loan Inputs
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Total Principal Amount ($)</label>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Annual Interest Rate (%)</label>
              <input
                type="number"
                step="0.01"
                value={loanRate}
                onChange={(e) => setLoanRate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Loan Term (Years)</label>
              <div className="flex gap-2">
                {['15', '20', '30'].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setLoanTermYears(yr)}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border ${
                      loanTermYears === yr
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {yr} Yrs
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Estimated Monthly Payment</div>
              <div className="text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400 mt-1">
                ${mortgageResults.monthly.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <div className="text-[11px] text-slate-400 uppercase">Total Interest Paid</div>
                  <div className="text-lg font-bold font-mono text-slate-800 dark:text-slate-200">
                    ${mortgageResults.totalInterest.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400 uppercase">Total Repayment</div>
                  <div className="text-lg font-bold font-mono text-slate-800 dark:text-slate-200">
                    ${mortgageResults.totalPayment.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
            </div>

            {/* Amortization Snippet */}
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
                5-Year Balance Schedule
              </h4>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {mortgageResults.schedule.map((row) => (
                  <div key={row.year} className="py-2 flex items-center justify-between font-mono">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">Year {row.year}</span>
                    <span className="text-slate-500">Remaining Balance: ${row.balance.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. SALES TAX / VAT CALCULATOR */}
      {toolSlug === 'sales-tax-vat-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Calculation Mode
            </h3>
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setTaxMode('add')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  taxMode === 'add' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Add Tax (Net → Gross)
              </button>
              <button
                onClick={() => setTaxMode('extract')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  taxMode === 'extract' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Extract Tax (Gross → Net)
              </button>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {taxMode === 'add' ? 'Net Price ($)' : 'Gross Total ($)'}
              </label>
              <input
                type="number"
                value={taxAmountInput}
                onChange={(e) => setTaxAmountInput(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Tax / VAT Rate (%)</label>
              <input
                type="number"
                step="0.1"
                value={taxRatePercent}
                onChange={(e) => setTaxRatePercent(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>

            {/* Presets */}
            <div className="flex flex-wrap gap-2 pt-2">
              {[
                { name: 'US Avg (7%)', val: '7' },
                { name: 'UK VAT (20%)', val: '20' },
                { name: 'DE VAT (19%)', val: '19' },
                { name: 'AU GST (10%)', val: '10' },
              ].map((p) => (
                <button
                  key={p.name}
                  onClick={() => setTaxRatePercent(p.val)}
                  className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-medium hover:bg-slate-50"
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gross Total</span>
                <div className="text-4xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                  ${taxResults.total.toFixed(2)}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-sm font-mono">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Pre-Tax Amount:</span>
                  <span className="font-bold text-slate-900 dark:text-white">${taxResults.base.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Tax Amount ({taxRatePercent}%):</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">+${taxResults.tax.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. ROI CALCULATOR */}
      {toolSlug === 'roi-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Investment Inputs
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Initial Amount Invested ($)</label>
              <input
                type="number"
                value={roiInitial}
                onChange={(e) => setRoiInitial(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Final Return Value ($)</label>
              <input
                type="number"
                value={roiFinal}
                onChange={(e) => setRoiFinal(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Investment Duration (Years)</label>
              <input
                type="number"
                step="0.5"
                value={roiYears}
                onChange={(e) => setRoiYears(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total ROI</span>
                <div className={`text-4xl font-extrabold font-mono mt-1 ${roiResults.totalRoi >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                  {roiResults.totalRoi >= 0 ? '+' : ''}{roiResults.totalRoi.toFixed(2)}%
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-sm font-mono">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Net Profit:</span>
                  <span className={`font-bold ${roiResults.netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    ${roiResults.netProfit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Annualized Return (CAGR):</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">
                    {roiResults.annualizedRoi.toFixed(2)}% / yr
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. BREAK-EVEN CALCULATOR */}
      {toolSlug === 'break-even-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Cost & Pricing Inputs
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Total Fixed Costs ($)</label>
              <input
                type="number"
                value={fixedCosts}
                onChange={(e) => setFixedCosts(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Sale Price per Unit ($)</label>
              <input
                type="number"
                value={unitPrice}
                onChange={(e) => setUnitPrice(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Variable Cost per Unit ($)</label>
              <input
                type="number"
                value={varCostPerUnit}
                onChange={(e) => setVarCostPerUnit(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Break-Even Units</span>
                <div className="text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400 mt-1">
                  {breakEvenResults.units.toLocaleString()} Units
                </div>
              </div>
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-sm font-mono">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Break-Even Revenue:</span>
                  <span className="font-bold text-slate-900 dark:text-white">${breakEvenResults.revenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Contribution Margin Ratio:</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{breakEvenResults.marginRatio.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. SALARY TO HOURLY CALCULATOR */}
      {toolSlug === 'salary-hourly-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Wage Settings
            </h3>
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setWageType('annual')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  wageType === 'annual' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Annual Salary
              </button>
              <button
                onClick={() => setWageType('hourly')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  wageType === 'hourly' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Hourly Wage
              </button>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {wageType === 'annual' ? 'Annual Pay ($)' : 'Hourly Rate ($)'}
              </label>
              <input
                type="number"
                value={salaryWage}
                onChange={(e) => setSalaryWage(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Hours / Week</label>
                <input
                  type="number"
                  value={hoursPerWeek}
                  onChange={(e) => setHoursPerWeek(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Weeks / Year</label>
                <input
                  type="number"
                  value={weeksPerYear}
                  onChange={(e) => setWeeksPerYear(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Pay Breakdown
            </h4>
            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 flex justify-between items-center">
                <span className="text-slate-500 font-sans">Hourly Rate</span>
                <span className="text-base font-bold text-indigo-600 dark:text-indigo-400">
                  ${salaryResults.hourly.toFixed(2)} / hr
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 flex justify-between items-center">
                <span className="text-slate-500 font-sans">Daily (8 hrs)</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  ${salaryResults.daily.toFixed(2)}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 flex justify-between items-center">
                <span className="text-slate-500 font-sans">Weekly</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  ${salaryResults.weekly.toFixed(2)}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 flex justify-between items-center">
                <span className="text-slate-500 font-sans">Monthly</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  ${salaryResults.monthly.toFixed(2)}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 flex justify-between items-center">
                <span className="text-slate-500 font-sans">Annual Total</span>
                <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">
                  ${salaryResults.annual.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
