import React from 'react';
import { Bot, Copy, Check, RotateCcw } from 'lucide-react';
import { ChatMessage } from '../../types/ai';
import { MarkdownRenderer } from './MarkdownRenderer';

interface ChatMessageItemProps {
  message: ChatMessage;
  isLast: boolean;
  onCopy: (id: string, text: string) => void;
  onRegenerate: () => void;
  isCopied: boolean;
  navigate?: (path: string) => void;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = React.memo(
  ({ message, isLast, onCopy, onRegenerate, isCopied, navigate }) => {
    const isUser = message.role === 'user';

    // 1. User Message: compact rounded pill on the right
    if (isUser) {
      return (
        <div className="flex justify-end animate-in fade-in duration-100">
          <div className="max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm sm:text-[15px] leading-relaxed whitespace-pre-wrap">
            {message.content}
          </div>
        </div>
      );
    }

    // 2. AI Assistant Message
    return (
      <div className="flex items-start gap-3 sm:gap-4 animate-in fade-in duration-150">
        {/* Minimal AI Icon */}
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white shrink-0 mt-1 shadow-2xs">
          <Bot className="h-4 w-4" />
        </div>

        {/* Content Area */}
        <div className="flex-1 min-w-0">
          {message.error ? (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 text-sm">
              {message.content}
            </div>
          ) : message.isStreaming ? (
            /* STREAMING OPTIMIZATION:
               Lightweight raw text during streaming.
               Skips expensive regex parsing, tables, and syntax highlighters.
            */
            <div className="text-slate-800 dark:text-slate-200 text-sm sm:text-[15px] leading-7 whitespace-pre-wrap">
              {message.content ? (
                <>
                  <span>{message.content}</span>
                  <span className="inline-block w-2 h-4 ml-1 bg-indigo-500 animate-pulse align-middle" />
                </>
              ) : (
                <div className="flex items-center gap-2 py-1 text-slate-400 dark:text-slate-500 text-sm">
                  <span className="inline-block h-2 w-2 rounded-full bg-indigo-600 animate-ping" />
                  <span>Thinking...</span>
                </div>
              )}
            </div>
          ) : message.content ? (
            /* FINAL COMPLETED MESSAGE: Full rich Markdown parsing executed once */
            <div className="text-slate-800 dark:text-slate-200">
              <MarkdownRenderer content={message.content} navigate={navigate} />

              {/* Action buttons */}
              <div className="flex items-center gap-3 mt-3 pt-1 text-slate-400 dark:text-slate-500 text-xs">
                <button
                  type="button"
                  onClick={() => onCopy(message.id, message.content)}
                  className="flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                  title="Copy response"
                >
                  {isCopied ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-500" />
                      <span className="text-[11px] text-emerald-500">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span className="text-[11px]">Copy</span>
                    </>
                  )}
                </button>

                {isLast && (
                  <button
                    type="button"
                    onClick={onRegenerate}
                    className="flex items-center gap-1 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                    title="Regenerate"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span className="text-[11px]">Regenerate</span>
                  </button>
                )}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    );
  },
  // Custom memo comparator: only re-render if content, streaming state, or copy state changed
  (prev, next) =>
    prev.message.id === next.message.id &&
    prev.message.content === next.message.content &&
    prev.message.isStreaming === next.message.isStreaming &&
    prev.message.error === next.message.error &&
    prev.isCopied === next.isCopied &&
    prev.isLast === next.isLast
);
