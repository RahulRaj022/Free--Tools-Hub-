import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, RefreshCw, Check, Sparkles, Sliders, Palette, Eye, ArrowRightLeft } from 'lucide-react';

interface DesignToolsProps {
  toolSlug: string;
}

export const DesignTools: React.FC<DesignToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- 1. Color Palette Generator State ---
  const [paletteColors, setPaletteColors] = useState<string[]>([
    '#5B5BF7',
    '#7C3AED',
    '#06B6D4',
    '#10B981',
    '#F59E0B',
  ]);
  const [lockedIndices, setLockedIndices] = useState<number[]>([]);
  const [paletteMode, setPaletteMode] = useState<'random' | 'analogous' | 'monochromatic' | 'triadic'>('random');

  const randomHex = () => {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0').toUpperCase();
  };

  const generateNewPalette = () => {
    const base = paletteColors[0] || '#5B5BF7';
    // Helper to convert hex to HSL
    const hexToHsl = (hex: string) => {
      let c = hex.replace('#', '');
      if (c.length === 3) c = c.split('').map((x) => x + x).join('');
      const r = parseInt(c.substring(0, 2), 16) / 255;
      const g = parseInt(c.substring(2, 4), 16) / 255;
      const b = parseInt(c.substring(4, 6), 16) / 255;
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      let h = 0, s = 0, l = (max + min) / 2;
      if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
          case g: h = (b - r) / d + 2; break;
          case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
      }
      return [h * 360, s, l];
    };

    const hslToHex = (h: number, s: number, l: number) => {
      h = ((h % 360) + 360) % 360;
      const c = (1 - Math.abs(2 * l - 1)) * s;
      const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
      const m = l - c / 2;
      let r = 0, g = 0, b = 0;
      if (h < 60) [r, g, b] = [c, x, 0];
      else if (h < 120) [r, g, b] = [x, c, 0];
      else if (h < 180) [r, g, b] = [0, c, x];
      else if (h < 240) [r, g, b] = [0, x, c];
      else if (h < 300) [r, g, b] = [x, 0, c];
      else [r, g, b] = [c, 0, x];
      const toHex = (n: number) => Math.round((n + m) * 255).toString(16).padStart(2, '0');
      return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
    };

    const [h, s, l] = hexToHsl(base);
    const newColors = paletteColors.map((curr, idx) => {
      if (lockedIndices.includes(idx)) return curr;
      if (paletteMode === 'analogous') {
        return hslToHex(h + (idx - 2) * 28, Math.max(0.3, s), Math.max(0.2, Math.min(0.85, l + (idx - 2) * 0.08)));
      }
      if (paletteMode === 'monochromatic') {
        return hslToHex(h, s, 0.18 + idx * 0.16);
      }
      if (paletteMode === 'triadic') {
        const step = (idx % 3) * 120;
        return hslToHex(h + step, s, 0.35 + (idx % 2) * 0.25);
      }
      return randomHex();
    });

    setPaletteColors(newColors);
    showToast('Generated fresh palette', 'success');
  };

  const toggleLock = (idx: number) => {
    setLockedIndices((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  // --- 2. Contrast Checker State ---
  const [fgColor, setFgColor] = useState<string>('#0F172A');
  const [bgColor, setBgColor] = useState<string>('#FFFFFF');

  const getLuminance = (hex: string) => {
    let c = hex.replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const rgb = [0, 2, 4].map((idx) => {
      const val = parseInt(c.substring(idx, idx + 2), 16) / 255;
      return val <= 0.03928 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  };

  const contrastRatio = useMemo(() => {
    try {
      const l1 = getLuminance(fgColor);
      const l2 = getLuminance(bgColor);
      const brightest = Math.max(l1, l2);
      const darkest = Math.min(l1, l2);
      return (brightest + 0.05) / (darkest + 0.05);
    } catch {
      return 1;
    }
  }, [fgColor, bgColor]);

  // --- 3. Gradient Generator State ---
  const [gradType, setGradType] = useState<'linear' | 'radial'>('linear');
  const [gradAngle, setGradAngle] = useState<number>(135);
  const [gradColor1, setGradColor1] = useState<string>('#5B5BF7');
  const [gradColor2, setGradColor2] = useState<string>('#7C3AED');
  const [gradColor3, setGradColor3] = useState<string>('#06B6D4');
  const [useThirdColor, setUseThirdColor] = useState<boolean>(true);

  const gradientCss = useMemo(() => {
    if (gradType === 'linear') {
      return useThirdColor
        ? `linear-gradient(${gradAngle}deg, ${gradColor1} 0%, ${gradColor2} 50%, ${gradColor3} 100%)`
        : `linear-gradient(${gradAngle}deg, ${gradColor1} 0%, ${gradColor2} 100%)`;
    }
    return useThirdColor
      ? `radial-gradient(circle at center, ${gradColor1} 0%, ${gradColor2} 60%, ${gradColor3} 100%)`
      : `radial-gradient(circle at center, ${gradColor1} 0%, ${gradColor2} 100%)`;
  }, [gradType, gradAngle, gradColor1, gradColor2, gradColor3, useThirdColor]);

  // --- 4. Box Shadow Generator State ---
  const [bsX, setBsX] = useState<number>(0);
  const [bsY, setBsY] = useState<number>(10);
  const [bsBlur, setBsBlur] = useState<number>(25);
  const [bsSpread, setBsSpread] = useState<number>(-5);
  const [bsColor, setBsColor] = useState<string>('#000000');
  const [bsOpacity, setBsOpacity] = useState<number>(0.15);
  const [bsInset, setBsInset] = useState<boolean>(false);

  const boxShadowCss = useMemo(() => {
    // Hex to rgba
    let c = bsColor.replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const r = parseInt(c.substring(0, 2), 16) || 0;
    const g = parseInt(c.substring(2, 4), 16) || 0;
    const b = parseInt(c.substring(4, 6), 16) || 0;
    const rgba = `rgba(${r}, ${g}, ${b}, ${bsOpacity})`;
    return `${bsInset ? 'inset ' : ''}${bsX}px ${bsY}px ${bsBlur}px ${bsSpread}px ${rgba}`;
  }, [bsX, bsY, bsBlur, bsSpread, bsColor, bsOpacity, bsInset]);

  // --- 5. Color Shades Generator State ---
  const [baseHex, setBaseHex] = useState<string>('#5B5BF7');

  const generatedShades = useMemo(() => {
    let c = baseHex.replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const r = parseInt(c.substring(0, 2), 16) || 0;
    const g = parseInt(c.substring(2, 4), 16) || 0;
    const b = parseInt(c.substring(4, 6), 16) || 0;

    const shadeFactors = [
      { name: '50', factor: 0.94, tint: true },
      { name: '100', factor: 0.85, tint: true },
      { name: '200', factor: 0.70, tint: true },
      { name: '300', factor: 0.50, tint: true },
      { name: '400', factor: 0.25, tint: true },
      { name: '500', factor: 0, tint: false }, // Base
      { name: '600', factor: 0.15, tint: false },
      { name: '700', factor: 0.32, tint: false },
      { name: '800', factor: 0.50, tint: false },
      { name: '900', factor: 0.68, tint: false },
      { name: '950', factor: 0.82, tint: false },
    ];

    return shadeFactors.map((step) => {
      let red = r, green = g, blue = b;
      if (step.tint) {
        red = Math.round(r + (255 - r) * step.factor);
        green = Math.round(g + (255 - g) * step.factor);
        blue = Math.round(b + (255 - b) * step.factor);
      } else if (step.factor > 0) {
        red = Math.round(r * (1 - step.factor));
        green = Math.round(g * (1 - step.factor));
        blue = Math.round(b * (1 - step.factor));
      }
      const toHex = (n: number) => Math.min(255, Math.max(0, n)).toString(16).padStart(2, '0').toUpperCase();
      const hex = `#${toHex(red)}${toHex(green)}${toHex(blue)}`;
      return { step: step.name, hex };
    });
  }, [baseHex]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast(`Copied ${text}`, 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. COLOR PALETTE GENERATOR */}
      {toolSlug === 'color-palette-generator' && (
        <div className="space-y-6">
          {/* Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Harmony:</span>
              {(['random', 'analogous', 'monochromatic', 'triadic'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setPaletteMode(mode)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-colors ${
                    paletteMode === mode
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={generateNewPalette}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-xs"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Generate New</span>
              </button>
              <button
                onClick={() => copyToClipboard(JSON.stringify(paletteColors, null, 2), 'palette-json')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-50 transition-colors"
              >
                {copiedKey === 'palette-json' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Export JSON</span>
              </button>
            </div>
          </div>

          {/* Palette Canvas */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {paletteColors.map((color, idx) => {
              const isLocked = lockedIndices.includes(idx);
              return (
                <div
                  key={idx}
                  className="rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900 shadow-sm transition-all"
                >
                  <div
                    className="h-44 sm:h-56 w-full relative transition-colors duration-200 flex items-end p-3"
                    style={{ backgroundColor: color }}
                  >
                    <button
                      onClick={() => toggleLock(idx)}
                      className={`absolute top-3 right-3 p-1.5 rounded-lg text-xs font-bold backdrop-blur-md transition-colors ${
                        isLocked
                          ? 'bg-black/60 text-amber-300'
                          : 'bg-black/20 text-white/80 hover:bg-black/40'
                      }`}
                      title={isLocked ? 'Unlock color' : 'Lock color'}
                    >
                      {isLocked ? '🔒 Locked' : '🔓'}
                    </button>
                    <input
                      type="color"
                      value={color}
                      onChange={(e) => {
                        const newCols = [...paletteColors];
                        newCols[idx] = e.target.value.toUpperCase();
                        setPaletteColors(newCols);
                      }}
                      className="absolute top-3 left-3 h-8 w-8 rounded-lg cursor-pointer border-0 bg-transparent opacity-0"
                      title="Pick custom color"
                    />
                  </div>

                  <div className="p-3 text-center space-y-1">
                    <button
                      onClick={() => copyToClipboard(color, `pal-${idx}`)}
                      className="group flex items-center justify-center gap-1.5 w-full font-mono font-bold text-sm text-slate-900 dark:text-white hover:text-indigo-600 transition-colors"
                    >
                      <span>{color}</span>
                      {copiedKey === `pal-${idx}` ? (
                        <Check className="h-3 w-3 text-emerald-500" />
                      ) : (
                        <Copy className="h-3 w-3 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      )}
                    </button>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Color #{idx + 1}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. CONTRAST CHECKER */}
      {toolSlug === 'contrast-checker' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Color Inputs
            </h3>

            {/* Foreground */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Text Color (Foreground)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={fgColor}
                  onChange={(e) => setFgColor(e.target.value.toUpperCase())}
                  className="h-10 w-12 rounded-xl cursor-pointer border border-slate-200 dark:border-slate-700 p-1"
                />
                <input
                  type="text"
                  value={fgColor}
                  onChange={(e) => setFgColor(e.target.value.toUpperCase())}
                  className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
            </div>

            {/* Background */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Background Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={bgColor}
                  onChange={(e) => setBgColor(e.target.value.toUpperCase())}
                  className="h-10 w-12 rounded-xl cursor-pointer border border-slate-200 dark:border-slate-700 p-1"
                />
                <input
                  type="text"
                  value={bgColor}
                  onChange={(e) => setBgColor(e.target.value.toUpperCase())}
                  className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
            </div>

            {/* Swap button */}
            <button
              onClick={() => {
                const temp = fgColor;
                setFgColor(bgColor);
                setBgColor(temp);
              }}
              className="flex items-center justify-center gap-2 w-full py-2 rounded-xl border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-xs font-semibold transition-colors"
            >
              <ArrowRightLeft className="h-3.5 w-3.5" />
              <span>Swap Colors</span>
            </button>

            {/* Presets */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="text-xs font-semibold text-slate-500 mb-2">Popular Combinations:</div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => { setFgColor('#0F172A'); setBgColor('#FFFFFF'); }}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 text-left font-medium"
                >
                  Dark Slate on White
                </button>
                <button
                  onClick={() => { setFgColor('#5B5BF7'); setBgColor('#0F172A'); }}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 text-left font-medium"
                >
                  Indigo on Dark
                </button>
                <button
                  onClick={() => { setFgColor('#FFFFFF'); setBgColor('#1E293B'); }}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 text-left font-medium"
                >
                  White on Slate
                </button>
                <button
                  onClick={() => { setFgColor('#059669'); setBgColor('#ECFDF5'); }}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 text-left font-medium"
                >
                  Emerald on Mint
                </button>
              </div>
            </div>
          </div>

          {/* Results & Live Previews */}
          <div className="lg:col-span-7 space-y-4">
            {/* Scorecard */}
            <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Contrast Ratio
                </span>
                <div className="text-4xl font-extrabold font-mono text-slate-900 dark:text-white mt-1">
                  {contrastRatio.toFixed(2)} : 1
                </div>
              </div>

              {/* Badges */}
              <div className="grid grid-cols-2 gap-3 text-center w-full sm:w-auto">
                <div className={`p-2.5 rounded-xl border ${contrastRatio >= 4.5 ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300' : 'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/40 dark:border-rose-800 dark:text-rose-300'}`}>
                  <div className="text-sm font-bold">{contrastRatio >= 4.5 ? 'PASS' : 'FAIL'}</div>
                  <div className="text-[10px] font-medium">Normal Text (AA)</div>
                </div>
                <div className={`p-2.5 rounded-xl border ${contrastRatio >= 7.0 ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300' : 'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-950/40 dark:border-amber-800 dark:text-amber-300'}`}>
                  <div className="text-sm font-bold">{contrastRatio >= 7.0 ? 'PASS' : 'FAIL'}</div>
                  <div className="text-[10px] font-medium">Enhanced (AAA)</div>
                </div>
              </div>
            </div>

            {/* Live Interactive Sample Preview */}
            <div
              className="p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md transition-colors"
              style={{ backgroundColor: bgColor, color: fgColor }}
            >
              <h4 className="text-xl sm:text-2xl font-bold tracking-tight mb-2">
                Large Heading Sample (18pt+)
              </h4>
              <p className="text-sm leading-relaxed mb-4">
                This is standard body copy previewing your selected foreground and background colors.
                Good contrast ensures everyone, including users with visual impairments or reading under direct sunlight, can read your content effortlessly.
              </p>
              <button
                className="px-4 py-2 rounded-xl text-xs font-semibold border"
                style={{ borderColor: fgColor, color: fgColor }}
              >
                Sample Interactive Button
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. GRADIENT GENERATOR */}
      {toolSlug === 'gradient-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Gradient Controls
            </h3>

            {/* Type selector */}
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setGradType('linear')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  gradType === 'linear' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Linear
              </button>
              <button
                onClick={() => setGradType('radial')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  gradType === 'radial' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Radial
              </button>
            </div>

            {/* Angle slider */}
            {gradType === 'linear' && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>Angle</span>
                  <span className="font-mono">{gradAngle}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={gradAngle}
                  onChange={(e) => setGradAngle(parseInt(e.target.value))}
                  className="w-full accent-indigo-600"
                />
              </div>
            )}

            {/* Color stops */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Color Stops</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={gradColor1}
                  onChange={(e) => setGradColor1(e.target.value)}
                  className="h-9 w-10 rounded-lg cursor-pointer"
                />
                <input
                  type="text"
                  value={gradColor1}
                  onChange={(e) => setGradColor1(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-xs"
                />
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={gradColor2}
                  onChange={(e) => setGradColor2(e.target.value)}
                  className="h-9 w-10 rounded-lg cursor-pointer"
                />
                <input
                  type="text"
                  value={gradColor2}
                  onChange={(e) => setGradColor2(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-xs"
                />
              </div>
              {useThirdColor && (
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={gradColor3}
                    onChange={(e) => setGradColor3(e.target.value)}
                    className="h-9 w-10 rounded-lg cursor-pointer"
                  />
                  <input
                    type="text"
                    value={gradColor3}
                    onChange={(e) => setGradColor3(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-xs"
                  />
                </div>
              )}
              <button
                onClick={() => setUseThirdColor(!useThirdColor)}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
              >
                {useThirdColor ? '- Remove 3rd Color Stop' : '+ Add 3rd Color Stop'}
              </button>
            </div>
          </div>

          {/* Preview & Code */}
          <div className="lg:col-span-7 space-y-4">
            <div
              className="h-64 sm:h-72 w-full rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md transition-all flex items-center justify-center text-white font-bold drop-shadow-md"
              style={{ background: gradientCss }}
            >
              <span className="bg-black/30 backdrop-blur-md px-4 py-2 rounded-xl text-sm font-mono">
                Live Preview
              </span>
            </div>

            {/* CSS Export */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-900 text-slate-100 flex items-center justify-between gap-3 font-mono text-xs">
              <span className="truncate">background: {gradientCss};</span>
              <button
                onClick={() => copyToClipboard(`background: ${gradientCss};`, 'grad-css')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-colors shrink-0"
              >
                {copiedKey === 'grad-css' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy CSS</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. CSS BOX SHADOW GENERATOR */}
      {toolSlug === 'box-shadow-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Shadow Sliders
            </h3>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Horizontal Offset (X)</span>
                <span className="font-mono">{bsX}px</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={bsX}
                onChange={(e) => setBsX(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Vertical Offset (Y)</span>
                <span className="font-mono">{bsY}px</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                value={bsY}
                onChange={(e) => setBsY(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Blur Radius</span>
                <span className="font-mono">{bsBlur}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={bsBlur}
                onChange={(e) => setBsBlur(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Spread Radius</span>
                <span className="font-mono">{bsSpread}px</span>
              </div>
              <input
                type="range"
                min="-30"
                max="50"
                value={bsSpread}
                onChange={(e) => setBsSpread(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Opacity</span>
                <span className="font-mono">{Math.round(bsOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={bsOpacity}
                onChange={(e) => setBsOpacity(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Inset Shadow</label>
              <input
                type="checkbox"
                checked={bsInset}
                onChange={(e) => setBsInset(e.target.checked)}
                className="h-4 w-4 rounded accent-indigo-600 cursor-pointer"
              />
            </div>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <div className="h-64 sm:h-72 w-full rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-center p-8">
              <div
                className="h-32 w-52 sm:h-36 sm:w-64 rounded-2xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center font-bold text-sm text-slate-700 dark:text-slate-200"
                style={{ boxShadow: boxShadowCss }}
              >
                Box Shadow Preview
              </div>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-900 text-slate-100 flex items-center justify-between gap-3 font-mono text-xs">
              <span className="truncate">box-shadow: {boxShadowCss};</span>
              <button
                onClick={() => copyToClipboard(`box-shadow: ${boxShadowCss};`, 'bs-css')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-colors shrink-0"
              >
                {copiedKey === 'bs-css' ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy CSS</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. COLOR SHADES GENERATOR */}
      {toolSlug === 'color-shades-generator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Base Hex Color:</label>
              <input
                type="color"
                value={baseHex}
                onChange={(e) => setBaseHex(e.target.value.toUpperCase())}
                className="h-10 w-12 rounded-xl cursor-pointer border border-slate-200 dark:border-slate-700 p-1"
              />
              <input
                type="text"
                value={baseHex}
                onChange={(e) => setBaseHex(e.target.value.toUpperCase())}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono text-sm w-32"
              />
            </div>

            <button
              onClick={() => {
                const tailwindObj = generatedShades.reduce((acc, curr) => {
                  acc[curr.step] = curr.hex;
                  return acc;
                }, {} as Record<string, string>);
                copyToClipboard(JSON.stringify(tailwindObj, null, 2), 'shades-json');
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-xs"
            >
              {copiedKey === 'shades-json' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>Export Tailwind Palette</span>
            </button>
          </div>

          {/* Grid of shades */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {generatedShades.map((shade) => (
              <div
                key={shade.step}
                onClick={() => copyToClipboard(shade.hex, `shade-${shade.step}`)}
                className="group rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900 shadow-xs hover:scale-102 transition-all cursor-pointer"
              >
                <div
                  className="h-24 w-full flex items-end justify-between p-2.5 text-xs font-mono font-bold"
                  style={{ backgroundColor: shade.hex }}
                >
                  <span className="bg-black/30 backdrop-blur-xs px-2 py-0.5 rounded text-white text-[11px]">
                    {shade.step}
                  </span>
                </div>
                <div className="p-3 text-center">
                  <div className="font-mono text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 transition-colors">
                    {shade.hex}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {copiedKey === `shade-${shade.step}` ? 'Copied!' : 'Click to copy'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
