import React from 'react';
import { WebsiteScreenshotTool } from './web/WebsiteScreenshotTool';
import { WebsiteColorExtractorTool } from './web/WebsiteColorExtractorTool';
import { WebsiteFontDetectorTool } from './web/WebsiteFontDetectorTool';
import { WebsiteLinkCheckerTool } from './web/WebsiteLinkCheckerTool';
import { SitemapGeneratorTool } from './web/SitemapGeneratorTool';
import { RobotsGeneratorTool } from './web/RobotsGeneratorTool';
import { MetaTagGeneratorTool } from './web/MetaTagGeneratorTool';
import { OpenGraphPreviewTool } from './web/OpenGraphPreviewTool';
import { CanonicalUrlGeneratorTool } from './web/CanonicalUrlGeneratorTool';
import { HtmlLivePreviewTool } from './web/HtmlLivePreviewTool';
import { HttpStatusCheckerTool } from './web/HttpStatusCheckerTool';
import { RedirectCheckerTool } from './web/RedirectCheckerTool';
import { DnsLookupTool } from './web/DnsLookupTool';
import { SslCheckerTool } from './web/SslCheckerTool';
import { WebsiteTechnologyDetectorTool } from './web/WebsiteTechnologyDetectorTool';
import { WebsiteWordCounterTool } from './web/WebsiteWordCounterTool';
import { WebsiteAccessibilityCheckerTool } from './web/WebsiteAccessibilityCheckerTool';
import { WebsitePerformanceTool } from './web/WebsitePerformanceTool';
import { BrokenImageCheckerTool } from './web/BrokenImageCheckerTool';
import { LinkExtractorTool } from './web/LinkExtractorTool';

interface WebToolsProps {
  toolSlug: string;
}

export const WebTools: React.FC<WebToolsProps> = ({ toolSlug }) => {
  switch (toolSlug) {
    case 'website-screenshot':
      return <WebsiteScreenshotTool />;
    case 'website-color-extractor':
      return <WebsiteColorExtractorTool />;
    case 'website-font-detector':
      return <WebsiteFontDetectorTool />;
    case 'website-link-checker':
      return <WebsiteLinkCheckerTool />;
    case 'sitemap-generator':
    case 'xml-sitemap-generator':
      return <SitemapGeneratorTool />;
    case 'robots-generator':
    case 'robots-txt-generator':
      return <RobotsGeneratorTool />;
    case 'meta-tag-generator':
      return <MetaTagGeneratorTool />;
    case 'open-graph-preview':
      return <OpenGraphPreviewTool />;
    case 'canonical-url-generator':
      return <CanonicalUrlGeneratorTool />;
    case 'html-live-preview':
      return <HtmlLivePreviewTool />;
    case 'http-status-checker':
      return <HttpStatusCheckerTool />;
    case 'redirect-checker':
      return <RedirectCheckerTool />;
    case 'dns-lookup':
      return <DnsLookupTool />;
    case 'ssl-checker':
      return <SslCheckerTool />;
    case 'website-technology-detector':
      return <WebsiteTechnologyDetectorTool />;
    case 'website-word-counter':
      return <WebsiteWordCounterTool />;
    case 'website-accessibility-checker':
      return <WebsiteAccessibilityCheckerTool />;
    case 'website-performance':
      return <WebsitePerformanceTool />;
    case 'broken-image-checker':
      return <BrokenImageCheckerTool />;
    case 'link-extractor':
      return <LinkExtractorTool />;
    default:
      return (
        <div className="p-8 text-center text-slate-500">
          Select a Web & Website tool from the category list.
        </div>
      );
  }
};
