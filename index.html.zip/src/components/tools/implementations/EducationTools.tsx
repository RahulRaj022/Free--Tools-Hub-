import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, Volume2, Check, ArrowRightLeft, RefreshCw, Calculator, Binary } from 'lucide-react';

interface EducationToolsProps {
  toolSlug: string;
}

export const EducationTools: React.FC<EducationToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- 1. Roman Numeral Converter State ---
  const [romanInput, setRomanInput] = useState<string>('2026');
  const [romanMode, setRomanMode] = useState<'toRoman' | 'fromRoman'>('toRoman');

  const romanResult = useMemo(() => {
    if (!romanInput.trim()) return '';
    if (romanMode === 'toRoman') {
      const num = parseInt(romanInput);
      if (isNaN(num) || num < 1 || num > 3999999) return 'Enter a number between 1 and 3,999,999';
      const lookup: Array<[number, string]> = [
        [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'],
        [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'],
        [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I'],
      ];
      let n = num;
      let res = '';
      for (const [val, letter] of lookup) {
        while (n >= val) {
          res += letter;
          n -= val;
        }
      }
      return res;
    } else {
      const r = romanInput.toUpperCase().trim();
      const map: Record<string, number> = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
      let sum = 0;
      for (let i = 0; i < r.length; i++) {
        const cur = map[r[i]];
        const next = map[r[i + 1]];
        if (!cur) return 'Invalid Roman numeral character: ' + r[i];
        if (next && cur < next) {
          sum -= cur;
        } else {
          sum += cur;
        }
      }
      return sum.toString();
    }
  }, [romanInput, romanMode]);

  // --- 2. Morse Code Translator State ---
  const [morseInput, setMorseInput] = useState<string>('FREE TOOLS HUB');
  const [morseMode, setMorseMode] = useState<'toMorse' | 'fromMorse'>('toMorse');

  const MORSE_MAP: Record<string, string> = {
    A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.',
    G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..',
    M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.',
    S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-',
    Y: '-.--', Z: '--..', '0': '-----', '1': '.----', '2': '..---',
    '3': '...--', '4': '....-', '5': '.....', '6': '-....',
    '7': '--...', '8': '---..', '9': '----.', ' ': '/',
  };

  const morseResult = useMemo(() => {
    if (!morseInput.trim()) return '';
    if (morseMode === 'toMorse') {
      return morseInput
        .toUpperCase()
        .split('')
        .map((c) => MORSE_MAP[c] || c)
        .join(' ');
    } else {
      const invMorse: Record<string, string> = {};
      Object.entries(MORSE_MAP).forEach(([k, v]) => (invMorse[v] = k));
      return morseInput
        .trim()
        .split(' ')
        .map((code) => invMorse[code] || (code === '/' ? ' ' : code))
        .join('');
    }
  }, [morseInput, morseMode]);

  const playMorseAudio = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      let time = ctx.currentTime + 0.1;
      const dotLen = 0.08;

      const codeToPlay = morseMode === 'toMorse' ? morseResult : morseInput;
      for (let i = 0; i < codeToPlay.length; i++) {
        const char = codeToPlay[i];
        if (char === '.' || char === '-') {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.frequency.value = 650;
          osc.connect(gain);
          gain.connect(ctx.destination);
          const duration = char === '.' ? dotLen : dotLen * 3;
          osc.start(time);
          osc.stop(time + duration);
          time += duration + dotLen;
        } else if (char === ' ') {
          time += dotLen * 2;
        } else if (char === '/') {
          time += dotLen * 4;
        }
      }
      showToast('Playing Morse audio tone', 'info');
    } catch {
      showToast('Web Audio not supported on this browser', 'error');
    }
  };

  // --- 3. Binary & Text Converter State ---
  const [binaryText, setBinaryText] = useState<string>('Hello World');
  const [binaryMode, setBinaryMode] = useState<'toBinary' | 'fromBinary'>('toBinary');

  const binaryResult = useMemo(() => {
    if (!binaryText.trim()) return '';
    if (binaryMode === 'toBinary') {
      return binaryText
        .split('')
        .map((c) => c.charCodeAt(0).toString(2).padStart(8, '0'))
        .join(' ');
    } else {
      try {
        const clean = binaryText.trim().replace(/\s+/g, ' ');
        return clean
          .split(' ')
          .map((bin) => String.fromCharCode(parseInt(bin, 2)))
          .join('');
      } catch {
        return 'Invalid binary string';
      }
    }
  }, [binaryText, binaryMode]);

  // --- 4. Fraction Calculator State ---
  const [fracA_num, setFracA_num] = useState<string>('3');
  const [fracA_den, setFracA_den] = useState<string>('4');
  const [fracOp, setFracOp] = useState<'+' | '-' | '*' | '/'>('+');
  const [fracB_num, setFracB_num] = useState<string>('2');
  const [fracB_den, setFracB_den] = useState<string>('3');

  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));

  const fractionResult = useMemo(() => {
    const aNum = parseInt(fracA_num) || 0;
    const aDen = parseInt(fracA_den) || 1;
    const bNum = parseInt(fracB_num) || 0;
    const bDen = parseInt(fracB_den) || 1;

    if (aDen === 0 || bDen === 0) return { error: 'Denominator cannot be zero.' };

    let resNum = 0;
    let resDen = 1;

    if (fracOp === '+') {
      resNum = aNum * bDen + bNum * aDen;
      resDen = aDen * bDen;
    } else if (fracOp === '-') {
      resNum = aNum * bDen - bNum * aDen;
      resDen = aDen * bDen;
    } else if (fracOp === '*') {
      resNum = aNum * bNum;
      resDen = aDen * bDen;
    } else if (fracOp === '/') {
      if (bNum === 0) return { error: 'Division by zero is undefined.' };
      resNum = aNum * bDen;
      resDen = aDen * bNum;
    }

    if (resDen < 0) {
      resNum = -resNum;
      resDen = -resDen;
    }

    const divisor = Math.abs(gcd(resNum, resDen));
    const simpNum = resNum / divisor;
    const simpDen = resDen / divisor;

    const decimal = (simpNum / simpDen).toFixed(4);
    const whole = Math.floor(Math.abs(simpNum) / simpDen);
    const remainder = Math.abs(simpNum) % simpDen;
    const mixed =
      whole > 0 && remainder > 0
        ? `${simpNum < 0 ? '-' : ''}${whole} ${remainder}/${simpDen}`
        : null;

    return {
      simplified: `${simpNum}/${simpDen}`,
      decimal,
      mixed,
      simpNum,
      simpDen,
    };
  }, [fracA_num, fracA_den, fracOp, fracB_num, fracB_den]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. ROMAN NUMERAL CONVERTER */}
      {toolSlug === 'roman-numeral-converter' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Roman Converter
            </h3>
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => { setRomanMode('toRoman'); setRomanInput('2026'); }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  romanMode === 'toRoman' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Number → Roman
              </button>
              <button
                onClick={() => { setRomanMode('fromRoman'); setRomanInput('MMXXVI'); }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  romanMode === 'fromRoman' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs' : 'text-slate-500'
                }`}
              >
                Roman → Number
              </button>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {romanMode === 'toRoman' ? 'Enter Integer (1 to 3,999,999)' : 'Enter Roman Numeral'}
              </label>
              <input
                type={romanMode === 'toRoman' ? 'number' : 'text'}
                value={romanInput}
                onChange={(e) => setRomanInput(e.target.value)}
                className="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono font-bold uppercase"
              />
            </div>
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Result</span>
              <div className="text-4xl font-extrabold font-mono text-indigo-600 dark:text-indigo-400 mt-2 break-all">
                {romanResult}
              </div>
            </div>
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => copyToClipboard(romanResult, 'roman')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
              >
                {copiedKey === 'roman' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy Result</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. MORSE CODE TRANSLATOR */}
      {toolSlug === 'morse-code-translator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setMorseMode('toMorse')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg ${morseMode === 'toMorse' ? 'bg-white dark:bg-slate-900 shadow-2xs' : 'text-slate-500'}`}
              >
                Text → Morse Code
              </button>
              <button
                onClick={() => setMorseMode('fromMorse')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg ${morseMode === 'fromMorse' ? 'bg-white dark:bg-slate-900 shadow-2xs' : 'text-slate-500'}`}
              >
                Morse Code → Text
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={playMorseAudio}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 dark:border-slate-800 text-xs font-semibold"
              >
                <Volume2 className="h-3.5 w-3.5 text-indigo-600" />
                <span>Play Sound</span>
              </button>
              <button
                onClick={() => copyToClipboard(morseResult, 'morse')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
              >
                {copiedKey === 'morse' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                {morseMode === 'toMorse' ? 'Input Text' : 'Input Morse (Dots & Dashes)'}
              </label>
              <textarea
                value={morseInput}
                onChange={(e) => setMorseInput(e.target.value)}
                rows={6}
                className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm font-mono shadow-xs focus:outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Translation Output
              </label>
              <textarea
                readOnly
                value={morseResult}
                rows={6}
                className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs sm:text-sm font-mono text-indigo-600 dark:text-indigo-400 font-bold shadow-xs focus:outline-none"
              />
            </div>
          </div>
        </div>
      )}

      {/* 3. BINARY TEXT CONVERTER */}
      {toolSlug === 'binary-text-converter' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Binary Mode
            </h3>
            <div className="flex rounded-xl p-1 bg-slate-100 dark:bg-slate-800">
              <button
                onClick={() => setBinaryMode('toBinary')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg ${binaryMode === 'toBinary' ? 'bg-white dark:bg-slate-900 shadow-2xs' : 'text-slate-500'}`}
              >
                Text → Binary (8-bit)
              </button>
              <button
                onClick={() => setBinaryMode('fromBinary')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg ${binaryMode === 'fromBinary' ? 'bg-white dark:bg-slate-900 shadow-2xs' : 'text-slate-500'}`}
              >
                Binary → Text
              </button>
            </div>
            <textarea
              value={binaryText}
              onChange={(e) => setBinaryText(e.target.value)}
              rows={8}
              placeholder={binaryMode === 'toBinary' ? 'Enter regular text...' : 'Enter 01001000 01101001...'}
              className="w-full p-3 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
            />
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Converted Result</span>
                <button
                  onClick={() => copyToClipboard(binaryResult, 'binary')}
                  className="flex items-center gap-1 text-xs text-indigo-600 font-bold"
                >
                  {copiedKey === 'binary' ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                  <span>Copy</span>
                </button>
              </div>
              <textarea
                readOnly
                value={binaryResult}
                rows={8}
                className="w-full p-3 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-indigo-600 dark:text-indigo-400 font-bold"
              />
            </div>
          </div>
        </div>
      )}

      {/* 4. FRACTION CALCULATOR */}
      {toolSlug === 'fraction-calculator' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider text-center">
              Fraction Arithmetic
            </h3>

            {/* Arithmetic layout */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
              {/* Fraction A */}
              <div className="flex flex-col items-center gap-1 w-16">
                <input
                  type="number"
                  value={fracA_num}
                  onChange={(e) => setFracA_num(e.target.value)}
                  className="w-full text-center py-1.5 border border-slate-200 dark:border-slate-800 rounded-lg font-mono font-bold"
                />
                <div className="w-full h-0.5 bg-slate-800 dark:bg-slate-200" />
                <input
                  type="number"
                  value={fracA_den}
                  onChange={(e) => setFracA_den(e.target.value)}
                  className="w-full text-center py-1.5 border border-slate-200 dark:border-slate-800 rounded-lg font-mono font-bold"
                />
              </div>

              {/* Operator */}
              <div className="flex flex-col gap-1">
                {(['+', '-', '*', '/'] as const).map((op) => (
                  <button
                    key={op}
                    onClick={() => setFracOp(op)}
                    className={`h-7 w-7 rounded-lg text-sm font-bold transition-colors ${
                      fracOp === op ? 'bg-indigo-600 text-white' : 'border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {op === '*' ? '×' : op === '/' ? '÷' : op}
                  </button>
                ))}
              </div>

              {/* Fraction B */}
              <div className="flex flex-col items-center gap-1 w-16">
                <input
                  type="number"
                  value={fracB_num}
                  onChange={(e) => setFracB_num(e.target.value)}
                  className="w-full text-center py-1.5 border border-slate-200 dark:border-slate-800 rounded-lg font-mono font-bold"
                />
                <div className="w-full h-0.5 bg-slate-800 dark:bg-slate-200" />
                <input
                  type="number"
                  value={fracB_den}
                  onChange={(e) => setFracB_den(e.target.value)}
                  className="w-full text-center py-1.5 border border-slate-200 dark:border-slate-800 rounded-lg font-mono font-bold"
                />
              </div>

              <div className="text-2xl font-bold text-slate-400">=</div>

              {/* Result Fraction */}
              <div className="flex flex-col items-center gap-1 w-20">
                <div className="text-xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                  {(fractionResult as any).simpNum ?? '?'}
                </div>
                <div className="w-full h-0.5 bg-indigo-600 dark:bg-indigo-400" />
                <div className="text-xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                  {(fractionResult as any).simpDen ?? '?'}
                </div>
              </div>
            </div>

            {/* Breakdown stats */}
            {(fractionResult as any).decimal && (
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-around text-center text-xs font-mono">
                <div>
                  <div className="text-slate-400 text-[10px] uppercase">Decimal</div>
                  <div className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                    {(fractionResult as any).decimal}
                  </div>
                </div>
                {(fractionResult as any).mixed && (
                  <div>
                    <div className="text-slate-400 text-[10px] uppercase">Mixed Number</div>
                    <div className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                      {(fractionResult as any).mixed}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
