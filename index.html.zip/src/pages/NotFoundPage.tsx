import React, { useEffect } from 'react';
import { TOOLS_DATA } from '../data/toolsData';
import { ToolCard } from '../components/tools/ToolCard';
import { Search, Home, ArrowRight, HelpCircle } from 'lucide-react';
import { BackButton } from '../components/common/BackButton';

interface NotFoundPageProps {
  navigate: (path: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ navigate }) => {
  useEffect(() => {
    document.title = 'Page Not Found – Free Tools Hub';
  }, []);

  const popular = TOOLS_DATA.filter((t) => t.popular).slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-12">
      <div className="flex items-center">
        <BackButton navigate={navigate} fallbackPath="/" />
      </div>
      <div className="text-center max-w-xl mx-auto space-y-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 mx-auto">
          <HelpCircle className="h-8 w-8" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
          Oops! Tool Not Found
        </h1>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400">
          The page or tool you&apos;re looking for doesn&apos;t exist or might have been renamed.
        </p>

        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-semibold text-xs sm:text-sm hover:opacity-90 transition-opacity"
          >
            <Home className="h-4 w-4" />
            <span>Back Home</span>
          </button>
          <button
            onClick={() => navigate('/tools')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 font-semibold text-xs sm:text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <span>Explore All Tools</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="border-t border-slate-200/80 pt-10 dark:border-slate-800">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-6 text-center">
          Popular Tools You Might Need
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {popular.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              onSelect={(slug) => navigate(`/tools/${slug}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
