import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Sparkles, Copy, Check, RefreshCw, Sliders, Brain, FileText, ArrowRight } from 'lucide-react';

interface SmartToolsProps {
  toolSlug: string;
}

export const SmartTools: React.FC<SmartToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- 1. Headline Analyzer State ---
  const [headline, setHeadline] = useState<string>('How to Supercharge Your Daily Workflow with 10 Powerful Free Tools');

  const headlineScore = useMemo(() => {
    if (!headline.trim()) return { score: 0, wordCount: 0, charCount: 0, sentiment: 'Neutral', powerWords: [] };
    const words = headline.trim().split(/\s+/);
    const wordCount = words.length;
    const charCount = headline.length;

    const POWER_WORDS = ['supercharge', 'powerful', 'proven', 'secret', 'essential', 'ultimate', 'instant', 'free', 'effortless', 'master', 'guaranteed', 'guide', 'tricks', 'boost'];
    const detectedPower = words.filter((w) => POWER_WORDS.includes(w.toLowerCase().replace(/[^a-z]/g, '')));

    let score = 50;
    // Length optimal: 6 - 12 words
    if (wordCount >= 6 && wordCount <= 12) score += 20;
    else if (wordCount >= 4) score += 10;

    // Characters optimal: 50 - 70 chars
    if (charCount >= 45 && charCount <= 75) score += 15;

    // Has numbers?
    if (/\d+/.test(headline)) score += 10;

    // Has power words?
    score += Math.min(detectedPower.length * 5, 15);

    score = Math.min(100, Math.max(10, score));

    return {
      score,
      wordCount,
      charCount,
      sentiment: detectedPower.length > 0 ? 'Positive & Engaging' : 'Neutral',
      powerWords: detectedPower,
    };
  }, [headline]);

  // --- 2. AI Prompt Generator State ---
  const [promptRole, setPromptRole] = useState<string>('Senior Software Architect & TypeScript Expert');
  const [promptTask, setPromptTask] = useState<string>('Review and refactor an API authentication middleware');
  const [promptContext, setPromptContext] = useState<string>('Express.js application handling JWT tokens in an enterprise SaaS system');
  const [promptConstraints, setPromptConstraints] = useState<string>('Provide clean, well-commented TypeScript code. Use standard libraries only.');
  const [promptFormat, setPromptFormat] = useState<string>('Markdown document with step-by-step code snippets and security audit considerations');

  const compiledPrompt = useMemo(() => {
    return `### Role & Persona:
You are an expert ${promptRole}.

### Primary Objective / Task:
${promptTask}

### Relevant Context:
${promptContext}

### Key Constraints & Rules:
${promptConstraints}

### Expected Output Format:
${promptFormat}`;
  }, [promptRole, promptTask, promptContext, promptConstraints, promptFormat]);

  // --- 3. Text Summarizer State ---
  const [summarizeText, setSummarizeText] = useState<string>(
    `Online tools have revolutionized the way modern developers, designers, and students complete everyday computing tasks. Instead of downloading heavy desktop applications that consume storage and require constant updates, modern web applications run seamlessly inside the browser. WebAssembly and HTML5 Canvas enable complex image compression, PDF manipulation, and cryptographic hashing without sending a single byte of user data to external servers. This architecture provides unprecedented privacy and security, as sensitive financial documents and passwords never leave the user's local machine. As web standards continue to evolve, in-browser toolkits will replace bloated legacy software suites for millions of everyday users worldwide.`
  );
  const [summaryPercent, setSummaryPercent] = useState<number>(35);

  const summaryResult = useMemo(() => {
    if (!summarizeText.trim()) return '';
    // Extractive sentence scoring by word frequency
    const sentences = summarizeText
      .replace(/([.?!])\s*(?=[A-Z])/g, '$1|')
      .split('|')
      .map((s) => s.trim())
      .filter((s) => s.length > 10);

    if (sentences.length <= 1) return summarizeText;

    // Word frequency map
    const words = summarizeText.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter((w) => w.length > 3);
    const freq: Record<string, number> = {};
    words.forEach((w) => (freq[w] = (freq[w] || 0) + 1));

    // Score sentences
    const scored = sentences.map((sent, idx) => {
      const sWords = sent.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/);
      const score = sWords.reduce((acc, w) => acc + (freq[w] || 0), 0) / (sWords.length || 1);
      return { sent, score, idx };
    });

    const targetSentences = Math.max(1, Math.round(sentences.length * (summaryPercent / 100)));
    const topSentences = [...scored]
      .sort((a, b) => b.score - a.score)
      .slice(0, targetSentences)
      .sort((a, b) => a.idx - b.idx)
      .map((s) => s.sent);

    return topSentences.join(' ');
  }, [summarizeText, summaryPercent]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. HEADLINE ANALYZER */}
      {toolSlug === 'headline-analyzer' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Enter Headline or Title
            </label>
            <input
              type="text"
              value={headline}
              onChange={(e) => setHeadline(e.target.value)}
              className="w-full px-4 py-2.5 text-sm sm:text-base font-medium rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 focus:outline-none"
              placeholder="Type blog post or article title..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Scorecard */}
            <div className="md:col-span-4 p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs text-center flex flex-col justify-center items-center space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Headline Score</span>
              <div
                className={`text-6xl font-black font-mono ${
                  headlineScore.score >= 70 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-500'
                }`}
              >
                {headlineScore.score}
              </div>
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                {headlineScore.score >= 80 ? '🔥 Highly Engaging' : headlineScore.score >= 60 ? '✨ Good Headline' : 'Needs Optimization'}
              </span>
            </div>

            {/* Metrics Breakdown */}
            <div className="md:col-span-8 p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Readability & SEO Breakdown
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950">
                  <div className="text-slate-400">Word Count</div>
                  <div className="text-base font-bold text-slate-900 dark:text-white mt-1 font-mono">
                    {headlineScore.wordCount} words
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950">
                  <div className="text-slate-400">Character Length</div>
                  <div className="text-base font-bold text-slate-900 dark:text-white mt-1 font-mono">
                    {headlineScore.charCount} chars
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950">
                  <div className="text-slate-400">Sentiment</div>
                  <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                    {headlineScore.sentiment}
                  </div>
                </div>
              </div>

              {headlineScore.powerWords.length > 0 && (
                <div className="text-xs">
                  <span className="text-slate-500 font-semibold">Detected Power Words: </span>
                  <span className="text-indigo-600 font-mono font-bold">
                    {headlineScore.powerWords.join(', ')}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. AI PROMPT GENERATOR */}
      {toolSlug === 'ai-prompt-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Prompt Builder
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Role / Persona</label>
              <input
                type="text"
                value={promptRole}
                onChange={(e) => setPromptRole(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Task / Goal</label>
              <input
                type="text"
                value={promptTask}
                onChange={(e) => setPromptTask(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Context</label>
              <textarea
                value={promptContext}
                onChange={(e) => setPromptContext(e.target.value)}
                rows={2}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Constraints & Rules</label>
              <input
                type="text"
                value={promptConstraints}
                onChange={(e) => setPromptConstraints(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Output Format</label>
              <input
                type="text"
                value={promptFormat}
                onChange={(e) => setPromptFormat(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Compiled Structured Prompt
              </span>
              <button
                onClick={() => copyToClipboard(compiledPrompt, 'ai-prompt')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
              >
                {copiedKey === 'ai-prompt' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy Prompt</span>
              </button>
            </div>
            <textarea
              readOnly
              value={compiledPrompt}
              rows={14}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-200 focus:outline-none shadow-xs leading-relaxed"
            />
          </div>
        </div>
      )}

      {/* 3. TEXT SUMMARIZER */}
      {toolSlug === 'text-summarizer' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Summary Density:</span>
              <input
                type="range"
                min="10"
                max="60"
                value={summaryPercent}
                onChange={(e) => setSummaryPercent(parseInt(e.target.value))}
                className="w-40 accent-indigo-600"
              />
              <span className="text-xs font-mono font-bold text-indigo-600">{summaryPercent}% of original</span>
            </div>

            <button
              onClick={() => copyToClipboard(summaryResult, 'summary-text')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
            >
              {copiedKey === 'summary-text' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>Copy Summary</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Original Text ({summarizeText.split(/\s+/).filter(Boolean).length} words)
              </label>
              <textarea
                value={summarizeText}
                onChange={(e) => setSummarizeText(e.target.value)}
                rows={10}
                className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:outline-none shadow-xs leading-relaxed"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Summarized Output ({summaryResult.split(/\s+/).filter(Boolean).length} words)
              </label>
              <textarea
                readOnly
                value={summaryResult}
                rows={10}
                className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium focus:outline-none shadow-xs leading-relaxed"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
