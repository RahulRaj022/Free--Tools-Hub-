import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { ToastMessage } from '../types';

interface ToolsContextType {
  favorites: string[];
  toggleFavorite: (toolId: string) => void;
  isFavorite: (toolId: string) => boolean;
  recentTools: string[];
  addRecentTool: (toolId: string) => void;
  clearRecentTools: () => void;
  toasts: ToastMessage[];
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  removeToast: (id: string) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  openSearch: () => void;
  closeSearch: () => void;
}

const ToolsContext = createContext<ToolsContextType | undefined>(undefined);

export const ToolsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('fth_favorites');
      return saved ? JSON.parse(saved) : ['word-counter', 'qr-code-generator', 'image-compressor', 'percentage-calculator'];
    } catch {
      return ['word-counter', 'qr-code-generator', 'image-compressor', 'percentage-calculator'];
    }
  });

  const [recentTools, setRecentTools] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('fth_recent');
      return saved ? JSON.parse(saved) : ['pdf-compressor', 'word-counter', 'qr-code-generator'];
    } catch {
      return ['pdf-compressor', 'word-counter', 'qr-code-generator'];
    }
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);

  useEffect(() => {
    try {
      localStorage.setItem('fth_favorites', JSON.stringify(favorites));
    } catch {
      // ignore
    }
  }, [favorites]);

  useEffect(() => {
    try {
      localStorage.setItem('fth_recent', JSON.stringify(recentTools));
    } catch {
      // ignore
    }
  }, [recentTools]);

  const showToast = useCallback((text: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2800);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toggleFavorite = useCallback((toolId: string) => {
    setFavorites((prev) => {
      const exists = prev.includes(toolId);
      if (exists) {
        showToast('Removed from favorites', 'info');
        return prev.filter((id) => id !== toolId);
      } else {
        showToast('Added to favorites ★', 'success');
        return [toolId, ...prev];
      }
    });
  }, [showToast]);

  const isFavorite = useCallback((toolId: string) => {
    return favorites.includes(toolId);
  }, [favorites]);

  const addRecentTool = useCallback((toolId: string) => {
    setRecentTools((prev) => {
      const filtered = prev.filter((id) => id !== toolId);
      return [toolId, ...filtered].slice(0, 6);
    });
  }, []);

  const clearRecentTools = useCallback(() => {
    setRecentTools([]);
    showToast('Recent tools history cleared', 'info');
  }, [showToast]);

  const openSearch = useCallback(() => setIsSearchOpen(true), []);
  const closeSearch = useCallback(() => setIsSearchOpen(false), []);

  // Global keyboard shortcut for search (Cmd+K or Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <ToolsContext.Provider
      value={{
        favorites,
        toggleFavorite,
        isFavorite,
        recentTools,
        addRecentTool,
        clearRecentTools,
        toasts,
        showToast,
        removeToast,
        isSearchOpen,
        setIsSearchOpen,
        openSearch,
        closeSearch,
      }}
    >
      {children}
    </ToolsContext.Provider>
  );
};

export const useTools = () => {
  const ctx = useContext(ToolsContext);
  if (!ctx) throw new Error('useTools must be used within ToolsProvider');
  return ctx;
};
