import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Palette, Copy, Check, Download, AlertCircle, Loader2, RotateCcw } from 'lucide-react';

interface ExtractedColor {
  hex: string;
  rgb: string;
  hsl: string;
  count: number;
  category: 'primary' | 'accent' | 'background' | 'neutral';
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map((c) => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

function rgbToHsl(r: number, g: number, b: number): string {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
}

export const WebsiteColorExtractorTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [colors, setColors] = useState<ExtractedColor[]>([]);
  const [copiedColor, setCopiedColor] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scannedUrl, setScannedUrl] = useState<string | null>(null);

  const extractColors = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setColors([]);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch webpage.');
      }

      const html = data.html || '';
      const hexRegex = /#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b/g;
      const matches = html.match(hexRegex) || [];

      if (matches.length === 0) {
        setError('No inline CSS color codes could be extracted from this page.');
        return;
      }

      // Count occurrences
      const freqMap = new Map<string, number>();
      matches.forEach((m: string) => {
        let normalized = m.toUpperCase();
        if (normalized.length === 4) {
          normalized = '#' + normalized[1] + normalized[1] + normalized[2] + normalized[2] + normalized[3] + normalized[3];
        }
        freqMap.set(normalized, (freqMap.get(normalized) || 0) + 1);
      });

      // Filter and convert
      const sorted = Array.from(freqMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 16);

      const parsedColors: ExtractedColor[] = sorted.map(([hex, count], idx) => {
        const rgbObj = hexToRgb(hex);
        const rgbStr = `rgb(${rgbObj.r}, ${rgbObj.g}, ${rgbObj.b})`;
        const hslStr = rgbToHsl(rgbObj.r, rgbObj.g, rgbObj.b);

        // Simple categorization heuristic
        const brightness = (rgbObj.r * 299 + rgbObj.g * 587 + rgbObj.b * 114) / 1000;
        let category: ExtractedColor['category'] = 'neutral';
        if (idx === 0 || idx === 1) category = 'primary';
        else if (idx === 2 || idx === 3) category = 'accent';
        else if (brightness > 220 || brightness < 30) category = 'background';

        return {
          hex,
          rgb: rgbStr,
          hsl: hslStr,
          count,
          category,
        };
      });

      setColors(parsedColors);
      setScannedUrl(target);
      showToast(`Extracted ${parsedColors.length} unique colors!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error inspecting webpage colors.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedColor(text);
    showToast(`Copied ${label}!`, 'success');
    setTimeout(() => setCopiedColor(null), 2000);
  };

  const copyAllPaletteCss = () => {
    const cssVars = colors
      .map((c, i) => `  --color-${c.category}-${i + 1}: ${c.hex}; /* ${c.rgb} */`)
      .join('\n');
    const cssBlock = `:root {\n${cssVars}\n}`;
    copyToClipboard(cssBlock, 'CSS Variables block');
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify({ url: scannedUrl, colors }, null, 2)], {
      type: 'application/json',
    });
    const downloadLink = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = downloadLink;
    a.download = `palette_${scannedUrl?.replace(/[^a-z0-9]/gi, '_') || 'website'}.json`;
    a.click();
    URL.revokeObjectURL(downloadLink);
    showToast('Palette JSON downloaded!', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Search Input Box */}
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Website Address
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && extractColors()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
          <button
            type="button"
            onClick={extractColors}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Palette className="h-4 w-4" />}
            <span>{loading ? 'Analyzing...' : 'Extract Colors'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setColors([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Colors Grid Display */}
      {colors.length > 0 && (
        <div className="space-y-4 animate-in fade-in">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Detected Color Palette ({colors.length} Swatches)
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Click any swatch or code to copy to clipboard.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={copyAllPaletteCss}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>Copy CSS Variables</span>
              </button>
              <button
                type="button"
                onClick={downloadJson}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-2xs"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export JSON</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {colors.map((color) => {
              const isCopied = copiedColor === color.hex;
              return (
                <div
                  key={color.hex}
                  onClick={() => copyToClipboard(color.hex, color.hex)}
                  className="group rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 shadow-xs hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-600 transition-all cursor-pointer"
                >
                  <div
                    className="h-20 w-full rounded-xl shadow-inner relative flex items-end justify-end p-2 transition-transform group-hover:scale-[1.02]"
                    style={{ backgroundColor: color.hex }}
                  >
                    <span className="p-1 rounded-md bg-black/40 text-white backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      {isCopied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                        {color.hex}
                      </span>
                      <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        {color.category}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                      {color.rgb}
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 dark:text-slate-500 truncate">
                      {color.hsl}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
