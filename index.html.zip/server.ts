import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  getGenAIClient,
  buildCompactSystemInstruction,
  pruneConversationContext,
  checkRateLimit,
  FAST_MODEL,
  ThinkingLevel,
} from './server/aiService.js';
import { webToolsRouter } from './server/webToolsRouter.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function isValidPublicUrl(urlString: string): { valid: boolean; error?: string } {
  try {
    const parsed = new URL(urlString.trim());
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { valid: false, error: 'Only HTTP and HTTPS links are allowed.' };
    }
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '0.0.0.0' ||
      host === '::1' ||
      host.endsWith('.local') ||
      host.endsWith('.internal') ||
      /^10\./.test(host) ||
      /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) ||
      /^192\.168\./.test(host) ||
      /^169\.254\./.test(host)
    ) {
      return { valid: false, error: 'Internal and private network addresses are restricted.' };
    }
    return { valid: true };
  } catch {
    return { valid: false, error: 'Please enter a valid URL.' };
  }
}

function identifyPlatform(urlString: string): {
  id: 'youtube' | 'instagram' | 'facebook' | 'twitter' | 'tiktok' | 'vimeo' | 'direct-video' | 'direct-audio' | 'unknown';
  name: string;
  isPlatformPage: boolean;
} {
  try {
    const parsed = new URL(urlString.trim());
    const host = parsed.hostname.toLowerCase();
    const pathname = parsed.pathname.toLowerCase();

    if (host.includes('youtube.com') || host.includes('youtu.be')) {
      return { id: 'youtube', name: 'YouTube', isPlatformPage: true };
    }
    if (host.includes('instagram.com')) {
      return { id: 'instagram', name: 'Instagram', isPlatformPage: true };
    }
    if (host.includes('facebook.com') || host.includes('fb.watch')) {
      return { id: 'facebook', name: 'Facebook', isPlatformPage: true };
    }
    if (host.includes('twitter.com') || host.includes('x.com')) {
      return { id: 'twitter', name: 'X / Twitter', isPlatformPage: true };
    }
    if (host.includes('tiktok.com')) {
      return { id: 'tiktok', name: 'TikTok', isPlatformPage: true };
    }
    if (host.includes('vimeo.com')) {
      return { id: 'vimeo', name: 'Vimeo', isPlatformPage: true };
    }
    if (/\.(mp4|webm|mov|mkv|m4v)($|\?)/i.test(pathname)) {
      return { id: 'direct-video', name: 'Direct Video URL', isPlatformPage: false };
    }
    if (/\.(mp3|wav|ogg|m4a|flac|aac)($|\?)/i.test(pathname)) {
      return { id: 'direct-audio', name: 'Direct Audio URL', isPlatformPage: false };
    }
    return { id: 'unknown', name: 'Direct Media Link', isPlatformPage: false };
  } catch {
    return { id: 'unknown', name: 'Direct Media Link', isPlatformPage: false };
  }
}

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '5mb' }));

  // API 1: Validate & Inspect Public Media Link
  app.post('/api/fetch-media', async (req: Request, res: Response) => {
    const { url, mediaType = 'video' } = req.body || {};
    if (!url || typeof url !== 'string') {
      res.status(400).json({ error: 'Please enter a valid media URL.' });
      return;
    }

    const check = isValidPublicUrl(url);
    if (!check.valid) {
      res.status(400).json({ error: check.error });
      return;
    }

    const platform = identifyPlatform(url);

    // Case A: Platform social page URLs (YouTube, Vimeo, Instagram, TikTok, Facebook, Twitter)
    if (platform.isPlatformPage) {
      let title = '';
      let author = '';
      let thumbnail = '';
      let isAccessible = true;

      try {
        if (platform.id === 'youtube') {
          const oembedRes = await fetch(
            `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`,
            { signal: AbortSignal.timeout(4000) }
          );
          if (oembedRes.ok) {
            const data = (await oembedRes.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
            title = data.title || 'YouTube Public Video';
            author = data.author_name || '';
            thumbnail = data.thumbnail_url || '';
          } else {
            isAccessible = false;
          }
        } else if (platform.id === 'vimeo') {
          const vimeoRes = await fetch(
            `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`,
            { signal: AbortSignal.timeout(4000) }
          );
          if (vimeoRes.ok) {
            const data = (await vimeoRes.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
            title = data.title || 'Vimeo Public Video';
            author = data.author_name || '';
            thumbnail = data.thumbnail_url || '';
          } else {
            isAccessible = false;
          }
        }
      } catch {
        isAccessible = false;
      }

      res.json({
        success: false,
        platform: platform.id,
        platformName: platform.name,
        isPlatformPage: true,
        accessible: isAccessible,
        title: title || `${platform.name} Public Media`,
        author,
        thumbnail,
        canStreamDirectly: false,
        message: `This media cannot be accessed directly from this link due to platform security and access policies. Please upload the ${mediaType} file instead.`,
      });
      return;
    }

    // Case B: Direct media links
    try {
      const headRes = await fetch(url, {
        method: 'HEAD',
        signal: AbortSignal.timeout(6000),
      });

      if (!headRes.ok) {
        res.status(400).json({
          error: 'This media could not be accessed from the provided URL.',
          status: headRes.status,
        });
        return;
      }

      const contentType = headRes.headers.get('content-type') || '';
      const contentLengthStr = headRes.headers.get('content-length');
      const contentLength = contentLengthStr ? parseInt(contentLengthStr, 10) : 0;

      if (contentType.includes('text/html')) {
        res.status(400).json({
          error: 'This link does not appear to be a directly accessible media file. It returned an HTML webpage.',
        });
        return;
      }

      if (contentLength > 150 * 1024 * 1024) {
        res.status(400).json({
          error: 'This media file is too large for in-browser processing (max 150MB).',
        });
        return;
      }

      let filename = url.split('/').pop()?.split('?')[0] || `media_${Date.now()}`;
      if (!filename.includes('.')) {
        filename += mediaType === 'video' ? '.mp4' : '.mp3';
      }

      res.json({
        success: true,
        platform: platform.id,
        platformName: platform.name,
        isPlatformPage: false,
        proxyUrl: `/api/proxy-stream?url=${encodeURIComponent(url)}`,
        contentType,
        contentLength,
        filename,
      });
    } catch (err: unknown) {
      res.status(500).json({
        error: 'Unable to load the media. The server may be unreachable or restricting access.',
      });
    }
  });

  // API 2: Proxy Stream (Streams remote public media to the client with CORS headers)
  app.get('/api/proxy-stream', async (req: Request, res: Response) => {
    const rawUrl = req.query.url;
    if (!rawUrl || typeof rawUrl !== 'string') {
      res.status(400).send('Missing url parameter.');
      return;
    }

    const check = isValidPublicUrl(rawUrl);
    if (!check.valid) {
      res.status(400).send(check.error);
      return;
    }

    try {
      const response = await fetch(rawUrl, {
        signal: AbortSignal.timeout(30000),
      });

      if (!response.ok || !response.body) {
        res.status(response.status || 502).send('Remote media source failed.');
        return;
      }

      const contentType = response.headers.get('content-type') || 'application/octet-stream';
      const contentLength = response.headers.get('content-length');

      res.setHeader('Content-Type', contentType);
      if (contentLength) res.setHeader('Content-Length', contentLength);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=3600');

      // Convert ReadableStream to Node stream
      const reader = response.body.getReader();
      const stream = async () => {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(value);
        }
        res.end();
      };

      await stream();
    } catch {
      if (!res.headersSent) {
        res.status(500).send('Failed to stream media.');
      }
    }
  });

  // Web & Website Tools API (SSRF Protected)
  app.use('/api/web', webToolsRouter);

  // ==========================================
  // FREE TOOLS HUB AI ASSISTANT BACKEND
  // ==========================================

  // Check AI Service status
  app.get('/api/ai/status', (_req, res) => {
    const aiClient = getGenAIClient();
    res.json({
      available: !!aiClient,
      provider: 'Google Gemini',
      model: FAST_MODEL,
      status: aiClient ? 'connected' : 'unconfigured',
      message: aiClient
        ? 'Real AI service active and ready.'
        : 'AI Assistant requires GEMINI_API_KEY to be configured in server environment variables.',
    });
  });

  // AI Chat & Streaming Endpoint
  app.post('/api/ai/chat', async (req: Request, res: Response) => {
    const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.socket.remoteAddress || 'unknown';

    // 1. Rate Limiting Check
    const rateCheck = checkRateLimit(clientIp, 35, 60_000);
    if (!rateCheck.allowed) {
      res.status(429).json({
        error: 'Too many requests. Please wait a moment before sending another message.',
        rateLimited: true,
      });
      return;
    }

    // 2. Input Validation
    const { messages, toolContext, stream = true } = req.body || {};
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required.' });
      return;
    }

    const lastMessage = messages[messages.length - 1];
    if (!lastMessage || typeof lastMessage.content !== 'string' || !lastMessage.content.trim()) {
      res.status(400).json({ error: 'Message content cannot be empty.' });
      return;
    }

    if (lastMessage.content.length > 8000) {
      res.status(400).json({ error: 'Message is too long. Please limit prompts to 8,000 characters.' });
      return;
    }

    // 3. Smart context window: recent 12 messages with past message length bounding
    const formattedContents = pruneConversationContext(messages, 12);

    // 4. Check for Real AI Provider Client
    const aiClient = getGenAIClient();
    if (!aiClient) {
      res.status(503).json({
        error: 'AI Assistant requires GEMINI_API_KEY to be configured in the environment. Please add your Gemini API key to activate real AI responses.',
        configured: false,
      });
      return;
    }

    const systemInstruction = buildCompactSystemInstruction(toolContext);
    const startTime = Date.now();
    let ttftMs: number | null = null;
    let isAborted = false;

    res.on('close', () => {
      if (!res.writableEnded) {
        isAborted = true;
      }
    });

    try {
      if (stream) {
        // SSE Streaming Response
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache, no-transform');
        res.setHeader('Connection', 'keep-alive');
        res.setHeader('X-Accel-Buffering', 'no');
        res.flushHeaders?.();

        const responseStream = await aiClient.models.generateContentStream({
          model: FAST_MODEL,
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        for await (const chunk of responseStream) {
          if (isAborted) break;
          const chunkText = chunk.text;
          if (chunkText) {
            if (ttftMs === null) {
              ttftMs = Date.now() - startTime;
            }
            res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
          }
        }

        const totalMs = Date.now() - startTime;
        res.write(`\ndata: ${JSON.stringify({ done: true, stats: { ttftMs, totalMs, model: FAST_MODEL } })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
      } else {
        // Non-streaming JSON fallback
        const result = await aiClient.models.generateContent({
          model: FAST_MODEL,
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        const totalMs = Date.now() - startTime;
        res.json({
          response: result.text || '',
          configured: true,
          stats: { totalMs, model: FAST_MODEL },
        });
      }
    } catch (err: any) {
      console.error('Gemini AI API error:', err);
      if (!res.headersSent) {
        res.status(500).json({
          error: 'AI Assistant encountered an issue generating a response. Please try again.',
          details: err?.message,
        });
      } else {
        res.write(`data: ${JSON.stringify({ error: 'Stream interrupted. Please retry.' })}\n\n`);
        res.end();
      }
    }
  });

  // Vite Integration: Middleware mode in dev, static dist in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Free Tools Hub server ready at http://0.0.0.0:${PORT}`);
  });
}

startServer();
