import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Youtube, Copy, Download, Check, Hash, Share2, Smartphone, Plus, Trash2 } from 'lucide-react';

interface SocialToolsProps {
  toolSlug: string;
}

export const SocialTools: React.FC<SocialToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- 1. YouTube Thumbnail Grabber State ---
  const [ytUrl, setYtUrl] = useState<string>('https://www.youtube.com/watch?v=dQw4w9WgXcQ');

  const videoId = useMemo(() => {
    try {
      const match = ytUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }, [ytUrl]);

  // --- 2. Social Post Formatter State ---
  const [postText, setPostText] = useState<string>('Supercharge your productivity with Free Tools Hub! 🚀');

  const unicodeTransforms = useMemo(() => {
    const toBoldSans = (str: string) => {
      return str.split('').map((char) => {
        const code = char.charCodeAt(0);
        if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d5d4 + (code - 65));
        if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d5ee + (code - 97));
        if (code >= 48 && code <= 57) return String.fromCodePoint(0x1d7ec + (code - 48));
        return char;
      }).join('');
    };

    const toItalicSans = (str: string) => {
      return str.split('').map((char) => {
        const code = char.charCodeAt(0);
        if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d608 + (code - 65));
        if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d622 + (code - 97));
        return char;
      }).join('');
    };

    const toMonospace = (str: string) => {
      return str.split('').map((char) => {
        const code = char.charCodeAt(0);
        if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d670 + (code - 65));
        if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d68a + (code - 97));
        if (code >= 48 && code <= 57) return String.fromCodePoint(0x1d7f6 + (code - 48));
        return char;
      }).join('');
    };

    return [
      { name: 'Bold Sans', result: toBoldSans(postText) },
      { name: 'Italic Sans', result: toItalicSans(postText) },
      { name: 'Monospace Code', result: toMonospace(postText) },
    ];
  }, [postText]);

  // --- 3. Hashtag Generator State ---
  const [hashtagInput, setHashtagInput] = useState<string>('productivity, web tools, design, coding, tech');
  const [hashtagCase, setHashtagCase] = useState<'pascal' | 'lower'>('pascal');

  const generatedHashtags = useMemo(() => {
    return hashtagInput
      .split(/[,;\n]+/)
      .map((tag) => tag.trim())
      .filter(Boolean)
      .map((word) => {
        if (hashtagCase === 'pascal') {
          const capitalized = word.replace(/(?:^|\s)\S/g, (a) => a.toUpperCase()).replace(/\s+/g, '');
          return `#${capitalized}`;
        }
        return `#${word.toLowerCase().replace(/\s+/g, '')}`;
      })
      .join(' ');
  }, [hashtagInput, hashtagCase]);

  // --- 4. Bio Link Generator State ---
  const [bioName, setBioName] = useState<string>('Alex Morgan');
  const [bioTagline, setBioTagline] = useState<string>('Designer & Developer • Crafting digital products');
  const [bioLinks, setBioLinks] = useState([
    { id: '1', title: 'Visit My Portfolio', url: 'https://example.com' },
    { id: '2', title: 'Read My Blog', url: 'https://example.com/blog' },
    { id: '3', title: 'Free Design Resources', url: 'https://freetoolshub.com' },
  ]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. YOUTUBE THUMBNAIL GRABBER */}
      {toolSlug === 'youtube-thumbnail-grabber' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Paste YouTube Video URL or Short Link
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={ytUrl}
                onChange={(e) => setYtUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="flex-1 px-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
              />
            </div>
          </div>

          {videoId ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Maxres (1080p) */}
              <div className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs space-y-3 p-4">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>HD Quality (1080p / 720p)</span>
                  <a
                    href={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-600 hover:text-indigo-700 font-bold"
                  >
                    Direct Link
                  </a>
                </div>
                <img
                  src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                  alt="YouTube thumbnail 1080p"
                  className="rounded-xl w-full aspect-video object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                  }}
                />
              </div>

              {/* Standard HQ */}
              <div className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs space-y-3 p-4">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>Standard High Quality (480p)</span>
                  <a
                    href={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-600 hover:text-indigo-700 font-bold"
                  >
                    Direct Link
                  </a>
                </div>
                <img
                  src={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`}
                  alt="YouTube thumbnail standard"
                  className="rounded-xl w-full aspect-video object-cover"
                />
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-2xl">
              Enter a valid YouTube URL above to retrieve thumbnails.
            </div>
          )}
        </div>
      )}

      {/* 2. SOCIAL POST FORMATTER */}
      {toolSlug === 'social-post-formatter' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              <span>Standard Text Input</span>
              <span className="font-mono text-slate-400">{postText.length} characters</span>
            </div>
            <textarea
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
              rows={8}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm text-slate-800 dark:text-slate-200 focus:outline-none shadow-xs"
              placeholder="Type your caption or post text..."
            />
          </div>

          <div className="lg:col-span-6 space-y-4">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Unicode Styled Typography
            </h4>
            <div className="space-y-3">
              {unicodeTransforms.map((variant) => (
                <div
                  key={variant.name}
                  className="p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2"
                >
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
                    <span>{variant.name}</span>
                    <button
                      onClick={() => copyToClipboard(variant.result, variant.name)}
                      className="flex items-center gap-1 text-indigo-600 hover:text-indigo-700 font-bold"
                    >
                      {copiedKey === variant.name ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                      <span>{copiedKey === variant.name ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="text-sm font-medium text-slate-900 dark:text-white leading-relaxed">
                    {variant.result}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. HASHTAG GENERATOR */}
      {toolSlug === 'hashtag-generator' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Enter Keywords or Topics
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Casing:</span>
                <button
                  onClick={() => setHashtagCase('pascal')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold ${hashtagCase === 'pascal' ? 'bg-indigo-600 text-white' : 'border border-slate-200 dark:border-slate-800'}`}
                >
                  #PascalCase
                </button>
                <button
                  onClick={() => setHashtagCase('lower')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold ${hashtagCase === 'lower' ? 'bg-indigo-600 text-white' : 'border border-slate-200 dark:border-slate-800'}`}
                >
                  #lowercase
                </button>
              </div>
            </div>
            <textarea
              value={hashtagInput}
              onChange={(e) => setHashtagInput(e.target.value)}
              rows={3}
              className="w-full p-3 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
            />
          </div>

          <div className="p-6 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Generated Hashtags</span>
              <button
                onClick={() => copyToClipboard(generatedHashtags, 'all-hashtags')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
              >
                {copiedKey === 'all-hashtags' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                <span>Copy All Hashtags</span>
              </button>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 text-indigo-600 dark:text-indigo-400 font-medium text-sm leading-relaxed">
              {generatedHashtags || 'No hashtags generated yet.'}
            </div>
          </div>
        </div>
      )}

      {/* 4. BIO LINK GENERATOR */}
      {toolSlug === 'bio-link-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Profile & Links
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Name</label>
              <input
                type="text"
                value={bioName}
                onChange={(e) => setBioName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Bio Tagline</label>
              <input
                type="text"
                value={bioTagline}
                onChange={(e) => setBioTagline(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>

            <div className="space-y-2 pt-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Links</span>
                <button
                  onClick={() =>
                    setBioLinks([
                      ...bioLinks,
                      { id: Math.random().toString(), title: 'New Link', url: 'https://example.com' },
                    ])
                  }
                  className="text-indigo-600 hover:text-indigo-700 font-bold"
                >
                  + Add Link
                </button>
              </div>
              {bioLinks.map((link, idx) => (
                <div key={link.id} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={link.title}
                    onChange={(e) => {
                      const updated = [...bioLinks];
                      updated[idx].title = e.target.value;
                      setBioLinks(updated);
                    }}
                    placeholder="Link Title"
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
                  />
                  <input
                    type="url"
                    value={link.url}
                    onChange={(e) => {
                      const updated = [...bioLinks];
                      updated[idx].url = e.target.value;
                      setBioLinks(updated);
                    }}
                    placeholder="https://..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
                  />
                  <button
                    onClick={() => setBioLinks(bioLinks.filter((l) => l.id !== link.id))}
                    className="p-1.5 text-rose-500 hover:text-rose-600"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Smartphone Simulator Preview */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="w-72 rounded-3xl border-4 border-slate-800 bg-gradient-to-b from-slate-900 to-indigo-950 text-white p-6 shadow-xl space-y-4 text-center">
              <div className="h-16 w-16 mx-auto rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center font-bold text-xl shadow-md">
                {bioName.slice(0, 1) || 'A'}
              </div>
              <div>
                <h4 className="font-bold text-base">{bioName}</h4>
                <p className="text-[11px] text-slate-300 mt-1">{bioTagline}</p>
              </div>
              <div className="space-y-2 pt-2">
                {bioLinks.map((l) => (
                  <a
                    key={l.id}
                    href={l.url}
                    target="_blank"
                    rel="noreferrer"
                    className="block w-full py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-xs font-semibold text-white transition-all shadow-xs"
                  >
                    {l.title}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
