import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  navigate?: (path: string) => void;
  fallbackPath?: string;
  className?: string;
  label?: string;
}

export const BackButton: React.FC<BackButtonProps> = ({
  navigate,
  fallbackPath = '/',
  className = '',
  label = 'Back',
}) => {
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();

    // Check if there is internal session navigation history
    let navCount = 0;
    try {
      navCount = parseInt(sessionStorage.getItem('fth_internal_nav') || '0', 10);
    } catch {
      navCount = 0;
    }

    if (navCount > 0 && window.history.length > 1) {
      try {
        sessionStorage.setItem('fth_internal_nav', String(Math.max(0, navCount - 1)));
      } catch {
        // ignore
      }
      window.history.back();
    } else if (navigate) {
      navigate(fallbackPath);
    } else {
      window.location.href = fallbackPath;
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={`Go back${label !== 'Back' ? ` to ${label}` : ''}`}
      className={`group inline-flex items-center gap-2 rounded-xl border border-slate-200/90 bg-white px-3 py-1.5 text-xs sm:text-sm font-semibold text-slate-700 shadow-2xs hover:border-indigo-300 hover:bg-indigo-50/60 hover:text-indigo-600 dark:border-slate-800 dark:bg-slate-900/90 dark:text-slate-300 dark:hover:border-indigo-800 dark:hover:bg-indigo-950/40 dark:hover:text-indigo-400 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 cursor-pointer ${className}`}
    >
      <ArrowLeft className="h-4 w-4 text-slate-500 group-hover:text-indigo-600 dark:text-slate-400 dark:group-hover:text-indigo-400 transition-all group-hover:-translate-x-0.5 duration-150 shrink-0" />
      <span>{label}</span>
    </button>
  );
};
