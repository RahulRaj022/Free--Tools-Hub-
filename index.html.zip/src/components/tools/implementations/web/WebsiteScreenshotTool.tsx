import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Camera, Download, RotateCcw, Monitor, Smartphone, ExternalLink, AlertCircle, Loader2 } from 'lucide-react';

export const WebsiteScreenshotTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [viewport, setViewport] = useState<'desktop' | 'mobile'>('desktop');
  const [loading, setLoading] = useState(false);
  const [screenshotData, setScreenshotData] = useState<{
    imageUrl: string;
    downloadUrl: string;
    width: number;
    height: number;
    url: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleCapture = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a valid website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setScreenshotData(null);

    try {
      const res = await fetch(`/api/web/screenshot?url=${encodeURIComponent(target)}&viewport=${viewport}`);
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to capture website screenshot.');
      }

      setScreenshotData(data);
      showToast('Screenshot generated successfully!', 'success');
    } catch (err: any) {
      setError(err?.message || 'Failed to capture screenshot. Make sure the site is publicly accessible.');
      showToast('Capture failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setUrl('');
    setScreenshotData(null);
    setError(null);
  };

  return (
    <div className="space-y-6">
      {/* Control Card */}
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
              Public Website URL
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCapture()}
                placeholder="https://example.com"
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />

              {/* Viewport Selector */}
              <div className="flex rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 p-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setViewport('desktop')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    viewport === 'desktop'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Monitor className="h-3.5 w-3.5" />
                  <span>Desktop (1280px)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewport('mobile')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    viewport === 'mobile'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-2xs font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Smartphone className="h-3.5 w-3.5" />
                  <span>Mobile (390px)</span>
                </button>
              </div>

              {/* Action Buttons */}
              <button
                type="button"
                onClick={handleCapture}
                disabled={loading || !url.trim()}
                className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                <span>{loading ? 'Capturing...' : 'Capture Screenshot'}</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                title="Reset input"
              >
                <RotateCcw className="h-4 w-4" />
                <span className="hidden sm:inline">Reset</span>
              </button>
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Protected against internal SSRF. Only publicly reachable web domains are processed.
          </div>
        </div>
      </div>

      {/* Result Display */}
      {loading && (
        <div className="flex flex-col items-center justify-center p-12 rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-3">
          <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
          <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
            Launching headless browser and rendering webpage viewport...
          </p>
          <span className="text-xs text-slate-400">This usually takes 2 to 4 seconds.</span>
        </div>
      )}

      {screenshotData && !loading && (
        <div className="space-y-4 animate-in fade-in">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-md">
                  {screenshotData.url}
                </h4>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {viewport === 'desktop' ? 'Desktop Viewport (1280 × 800)' : 'Mobile Viewport (390 × 844)'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href={screenshotData.imageUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>Open Full Size</span>
              </a>

              <a
                href={screenshotData.downloadUrl}
                download
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors shadow-xs"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download PNG</span>
              </a>
            </div>
          </div>

          {/* Browser Window Mockup Frame */}
          <div
            className={`mx-auto rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-900 shadow-xl overflow-hidden ${
              viewport === 'mobile' ? 'max-w-sm' : 'max-w-4xl'
            }`}
          >
            {/* Browser Header Bar */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-800/90 border-b border-slate-700 text-slate-400 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              </div>
              <div className="flex-1 mx-3 px-3 py-1 rounded-md bg-slate-900 text-slate-300 text-[11px] font-mono truncate text-center">
                {screenshotData.url}
              </div>
            </div>

            {/* Image Preview */}
            <div className="relative bg-slate-950 flex items-center justify-center overflow-auto max-h-[600px]">
              <img
                src={screenshotData.imageUrl}
                alt={`Screenshot of ${screenshotData.url}`}
                className="w-full h-auto object-top object-contain block"
                loading="eager"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
