import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { CheckCircle, AlertTriangle, XCircle, Clock, ExternalLink, Download, Search, AlertCircle, Loader2, RotateCcw } from 'lucide-react';

interface LinkResult {
  url: string;
  statusCode: number;
  status: 'working' | 'redirect' | 'broken' | 'timeout' | 'blocked';
  responseTimeMs: number;
  isExternal: boolean;
}

export const WebsiteLinkCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [links, setLinks] = useState<LinkResult[]>([]);
  const [filter, setFilter] = useState<'all' | 'working' | 'redirect' | 'broken'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);

  const checkLinks = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setLinks([]);

    try {
      // 1. Fetch HTML to extract links
      const pageRes = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const pageData = await pageRes.json();

      if (!pageRes.ok || pageData.error) {
        throw new Error(pageData.error || 'Failed to fetch webpage.');
      }

      const html = pageData.html || '';
      const baseUrl = new URL(pageData.url || target);

      // Extract href attributes
      const linkRegex = /href=["']([^"']+)["']/gi;
      const foundUrls = new Set<string>();
      let match;

      while ((match = linkRegex.exec(html)) !== null) {
        let rawHref = match[1].trim();
        if (
          rawHref.startsWith('#') ||
          rawHref.startsWith('javascript:') ||
          rawHref.startsWith('mailto:') ||
          rawHref.startsWith('tel:')
        ) {
          continue;
        }

        try {
          const resolved = new URL(rawHref, baseUrl).toString();
          if (resolved.startsWith('http://') || resolved.startsWith('https://')) {
            foundUrls.add(resolved);
          }
        } catch {
          // ignore unparseable
        }
      }

      const urlList = Array.from(foundUrls).slice(0, 20); // capped for rate-limit protection
      if (urlList.length === 0) {
        setError('No valid web hyperlinks were found on this webpage.');
        return;
      }

      // 2. Check statuses in batch
      const checkRes = await fetch('/api/web/check-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urls: urlList }),
      });
      const checkData = await checkRes.json();

      if (!checkRes.ok || checkData.error) {
        throw new Error(checkData.error || 'Failed to check link statuses.');
      }

      const resultsWithExternal: LinkResult[] = (checkData.results || []).map((r: any) => {
        let isExt = false;
        try {
          isExt = new URL(r.url).hostname !== baseUrl.hostname;
        } catch {}
        return {
          ...r,
          isExternal: isExt,
        };
      });

      setLinks(resultsWithExternal);
      showToast(`Checked ${resultsWithExternal.length} links!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error executing link checker.');
    } finally {
      setLoading(false);
    }
  };

  const filteredLinks = links.filter((link) => {
    if (filter === 'working' && link.status !== 'working') return false;
    if (filter === 'redirect' && link.status !== 'redirect') return false;
    if (filter === 'broken' && link.status !== 'broken' && link.status !== 'timeout') return false;
    if (searchQuery && !link.url.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const exportCsv = () => {
    const header = 'URL,Status Code,Status,Response Time (ms),External\n';
    const rows = links
      .map((l) => `"${l.url}",${l.statusCode},${l.status},${l.responseTimeMs},${l.isExternal ? 'Yes' : 'No'}`)
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `link_audit_${url.replace(/[^a-z0-9]/gi, '_')}.csv`;
    a.click();
    URL.revokeObjectURL(u);
    showToast('Exported CSV report!', 'success');
  };

  const workingCount = links.filter((l) => l.status === 'working').length;
  const redirectCount = links.filter((l) => l.status === 'redirect').length;
  const brokenCount = links.filter((l) => l.status === 'broken' || l.status === 'timeout').length;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage to Audit
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && checkLinks()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
          <button
            type="button"
            onClick={checkLinks}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
            <span>{loading ? 'Auditing Links...' : 'Check Links'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setLinks([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {links.length > 0 && (
        <div className="space-y-4 animate-in fade-in">
          {/* Summary Stat Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div
              onClick={() => setFilter('all')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'all'
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="text-xs text-slate-500">Total Checked</div>
              <div className="text-xl font-bold text-slate-900 dark:text-white">{links.length}</div>
            </div>

            <div
              onClick={() => setFilter('working')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'working'
                  ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
                <CheckCircle className="h-3.5 w-3.5" />
                <span>Working</span>
              </div>
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{workingCount}</div>
            </div>

            <div
              onClick={() => setFilter('redirect')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'redirect'
                  ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400">
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>Redirects</span>
              </div>
              <div className="text-xl font-bold text-amber-600 dark:text-amber-400">{redirectCount}</div>
            </div>

            <div
              onClick={() => setFilter('broken')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'broken'
                  ? 'border-rose-500 bg-rose-50/50 dark:bg-rose-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400">
                <XCircle className="h-3.5 w-3.5" />
                <span>Broken</span>
              </div>
              <div className="text-xl font-bold text-rose-600 dark:text-rose-400">{brokenCount}</div>
            </div>
          </div>

          {/* Search and Export Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter by link URL..."
                className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="button"
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          {/* Table List */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500">
                  <tr>
                    <th className="px-4 py-3 font-semibold">Status</th>
                    <th className="px-4 py-3 font-semibold">Hyperlink Destination</th>
                    <th className="px-4 py-3 font-semibold">Code</th>
                    <th className="px-4 py-3 font-semibold">Latency</th>
                    <th className="px-4 py-3 font-semibold">Type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {filteredLinks.map((link, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3">
                        {link.status === 'working' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-sans font-semibold">
                            <CheckCircle className="h-3 w-3" /> OK
                          </span>
                        ) : link.status === 'redirect' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 font-sans font-semibold">
                            <AlertTriangle className="h-3 w-3" /> Redirect
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 font-sans font-semibold">
                            <XCircle className="h-3 w-3" /> Broken
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 max-w-md truncate font-sans text-slate-900 dark:text-slate-100">
                        <a
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:underline flex items-center gap-1"
                        >
                          <span className="truncate">{link.url}</span>
                          <ExternalLink className="h-3 w-3 shrink-0 opacity-40" />
                        </a>
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                        {link.statusCode || '—'}
                      </td>
                      <td className="px-4 py-3 text-slate-500">
                        {link.responseTimeMs ? `${link.responseTimeMs}ms` : '—'}
                      </td>
                      <td className="px-4 py-3 font-sans text-slate-500">
                        {link.isExternal ? 'External' : 'Internal'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
