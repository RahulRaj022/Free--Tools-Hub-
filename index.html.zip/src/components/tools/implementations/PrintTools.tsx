import React, { useState } from 'react';
import { useTools } from '../../../context/ToolsContext';
import {
  Printer,
  FileText,
  Calendar,
  Grid,
  Ruler,
  Sliders,
  Check,
  Download,
  RotateCw,
} from 'lucide-react';

interface PrintToolsProps {
  toolSlug: string;
}

export const PrintTools: React.FC<PrintToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // 1. A4 Page Generator
  const [a4Orientation, setA4Orientation] = useState<'portrait' | 'landscape'>('portrait');
  const [a4Title, setA4Title] = useState('Meeting Notes & Project Brief');
  const [a4Body, setA4Body] = useState(
    'Free Tools Hub - Printable A4 Document\n\n1. Project Scope & Architecture\n   - Clean client-side rendering\n   - Zero server uploads for maximum privacy\n\n2. Next Actions & Milestones\n   - Deliverables finalized by team\n   - Verification on mobile, tablet, and desktop'
  );
  const [a4Lined, setA4Lined] = useState(false);

  // 2. Ruler Generator
  const [rulerUnit, setRulerUnit] = useState<'cm' | 'inch'>('cm');

  // 3. Printable Grid Generator
  const [gridSpacing, setGridSpacing] = useState<number>(10); // mm
  const [gridLineStyle, setGridLineStyle] = useState<'solid' | 'dashed' | 'dotted'>('solid');

  // 4. Blank Calendar Generator
  const [calendarMonth, setCalendarMonth] = useState<number>(new Date().getMonth());
  const [calendarYear, setCalendarYear] = useState<number>(2026);
  const [startMonday, setStartMonday] = useState(false);

  // 5. Graph Paper Generator
  const [graphType, setGraphType] = useState<'square' | 'isometric'>('square');
  const [graphGridSize, setGraphGridSize] = useState<number>(5); // mm

  const triggerPrint = () => {
    window.print();
    showToast('Sent to browser print dialog!', 'success');
  };

  const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Calendar days calculation
  const calendarDays = () => {
    const firstDay = new Date(calendarYear, calendarMonth, 1).getDay();
    const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
    const offset = startMonday ? (firstDay === 0 ? 6 : firstDay - 1) : firstDay;

    const days: Array<number | null> = [];
    for (let i = 0; i < offset; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(i);
    return days;
  };

  return (
    <div className="space-y-6">
      {/* 1. Print Action Header */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200/60 dark:border-indigo-800/60 print:hidden">
        <div>
          <span className="text-xs font-bold text-indigo-900 dark:text-indigo-200 block">
            Print-Ready Vector Layout
          </span>
          <span className="text-[11px] text-indigo-700/80 dark:text-indigo-300/80">
            Click Print to send directly to your physical printer or save as a pixel-perfect PDF.
          </span>
        </div>
        <button
          onClick={triggerPrint}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 shadow-xs transition-colors shrink-0"
        >
          <Printer className="h-4 w-4" />
          <span>Print / Save as PDF</span>
        </button>
      </div>

      {/* 2. Interactive Tool Configurations & Live Sheets */}

      {/* A. A4 PAGE GENERATOR */}
      {toolSlug === 'a4-page-generator' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 print:hidden">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Orientation</label>
              <div className="flex gap-2 mt-1">
                <button
                  onClick={() => setA4Orientation('portrait')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold ${
                    a4Orientation === 'portrait' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  Portrait
                </button>
                <button
                  onClick={() => setA4Orientation('landscape')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold ${
                    a4Orientation === 'landscape' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  Landscape
                </button>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Document Title</label>
              <input
                type="text"
                value={a4Title}
                onChange={(e) => setA4Title(e.target.value)}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div className="flex items-end pb-1.5">
              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={a4Lined}
                  onChange={(e) => setA4Lined(e.target.checked)}
                  className="accent-indigo-600 rounded"
                />
                <span>Include Notebook Ruling Lines</span>
              </label>
            </div>
          </div>

          <div className="print:hidden">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Body Content:</label>
            <textarea
              value={a4Body}
              onChange={(e) => setA4Body(e.target.value)}
              rows={4}
              className="w-full mt-1 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
            />
          </div>

          {/* Printable A4 Canvas Card */}
          <div
            className={`mx-auto bg-white text-slate-900 border border-slate-300 shadow-xl p-12 transition-all print:border-none print:shadow-none print:p-0 ${
              a4Orientation === 'portrait' ? 'max-w-2xl min-h-[750px]' : 'max-w-4xl min-h-[500px]'
            }`}
          >
            <h1 className="text-2xl font-black border-b-2 border-slate-900 pb-3">{a4Title}</h1>
            <div
              className={`mt-6 text-sm leading-loose whitespace-pre-wrap ${
                a4Lined ? 'bg-[linear-gradient(#e2e8f0_1px,transparent_1px)] bg-[size:100%_28px]' : ''
              }`}
            >
              {a4Body}
            </div>
          </div>
        </div>
      )}

      {/* B. RULER GENERATOR */}
      {toolSlug === 'ruler-generator' && (
        <div className="space-y-6">
          <div className="flex gap-2 print:hidden">
            <button
              onClick={() => setRulerUnit('cm')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold ${
                rulerUnit === 'cm' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
              }`}
            >
              Metric (30 cm)
            </button>
            <button
              onClick={() => setRulerUnit('inch')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold ${
                rulerUnit === 'inch' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
              }`}
            >
              Imperial (12 inches)
            </button>
          </div>

          <div className="p-8 bg-white border border-slate-300 rounded-2xl overflow-x-auto shadow-md">
            {rulerUnit === 'cm' ? (
              <div className="flex border-t-2 border-b-2 border-black h-20 relative min-w-[750px]">
                {Array.from({ length: 31 }).map((_, cm) => (
                  <div key={cm} className="relative flex-1 border-l-2 border-black h-8 flex flex-col justify-end">
                    <span className="text-[10px] font-bold font-mono pl-1">{cm}</span>
                    {cm < 30 && (
                      <div className="absolute left-1/2 top-0 border-l border-black h-5" />
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex border-t-2 border-b-2 border-black h-24 relative min-w-[750px]">
                {Array.from({ length: 13 }).map((_, inch) => (
                  <div key={inch} className="relative flex-1 border-l-2 border-black h-10 flex flex-col justify-end">
                    <span className="text-xs font-bold font-mono pl-1">{inch}&quot;</span>
                    {inch < 12 && (
                      <>
                        <div className="absolute left-1/2 top-0 border-l-2 border-black h-7" />
                        <div className="absolute left-1/4 top-0 border-l border-black h-5" />
                        <div className="absolute left-3/4 top-0 border-l border-black h-5" />
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4 text-center text-xs text-slate-400 font-mono">
              Calibrated 1:1 Scale · Ensure &quot;Actual Size / 100%&quot; is selected in printer options
            </div>
          </div>
        </div>
      )}

      {/* C. PRINTABLE GRID GENERATOR */}
      {toolSlug === 'printable-grid-generator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap gap-4 items-center print:hidden">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Grid Spacing</label>
              <select
                value={gridSpacing}
                onChange={(e) => setGridSpacing(parseInt(e.target.value))}
                className="block mt-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
              >
                <option value={5}>5 mm (Fine Grid)</option>
                <option value={10}>10 mm (Standard 1cm)</option>
                <option value={15}>15 mm (Medium)</option>
                <option value={20}>20 mm (Large)</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Line Style</label>
              <select
                value={gridLineStyle}
                onChange={(e) => setGridLineStyle(e.target.value as any)}
                className="block mt-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
              >
                <option value="solid">Solid Lines</option>
                <option value="dashed">Dashed Lines</option>
                <option value="dotted">Dotted Grid</option>
              </select>
            </div>
          </div>

          <div
            className="w-full h-[650px] bg-white border border-slate-300 rounded-xl shadow-md p-4 print:border-none print:shadow-none"
            style={{
              backgroundImage:
                gridLineStyle === 'dotted'
                  ? `radial-gradient(#94a3b8 1.5px, transparent 1.5px)`
                  : `linear-gradient(to right, #cbd5e1 1px, transparent 1px), linear-gradient(to bottom, #cbd5e1 1px, transparent 1px)`,
              backgroundSize: `${gridSpacing * 3.78}px ${gridSpacing * 3.78}px`,
            }}
          />
        </div>
      )}

      {/* D. BLANK CALENDAR GENERATOR */}
      {toolSlug === 'blank-calendar-generator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap gap-4 items-center print:hidden">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Month</label>
              <select
                value={calendarMonth}
                onChange={(e) => setCalendarMonth(parseInt(e.target.value))}
                className="block mt-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
              >
                {MONTH_NAMES.map((m, idx) => (
                  <option key={idx} value={idx}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Year</label>
              <select
                value={calendarYear}
                onChange={(e) => setCalendarYear(parseInt(e.target.value))}
                className="block mt-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
              >
                {[2025, 2026, 2027, 2028].map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <div className="pt-4">
              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={startMonday}
                  onChange={(e) => setStartMonday(e.target.checked)}
                  className="accent-indigo-600 rounded"
                />
                <span>Start Week on Monday</span>
              </label>
            </div>
          </div>

          <div className="p-8 bg-white text-slate-900 rounded-2xl border border-slate-300 shadow-xl max-w-4xl mx-auto print:border-none print:shadow-none print:p-0">
            <div className="flex justify-between items-baseline border-b-2 border-slate-900 pb-4 mb-4">
              <h2 className="text-3xl font-black tracking-tight">
                {MONTH_NAMES[calendarMonth]} {calendarYear}
              </h2>
              <span className="text-xs uppercase font-mono text-slate-500 font-bold">Free Tools Hub Calendar</span>
            </div>

            <div className="grid grid-cols-7 border-t border-l border-slate-300">
              {(startMonday
                ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
              ).map((day) => (
                <div key={day} className="p-2 border-r border-b border-slate-300 font-bold text-center text-xs bg-slate-100">
                  {day}
                </div>
              ))}
              {calendarDays().map((dayNum, idx) => (
                <div key={idx} className="h-24 p-2 border-r border-b border-slate-300 relative text-left">
                  {dayNum && <span className="font-bold text-sm text-slate-800">{dayNum}</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* E. GRAPH PAPER GENERATOR */}
      {toolSlug === 'graph-paper-generator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap gap-4 items-center print:hidden">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Grid Type</label>
              <div className="flex gap-2 mt-1">
                <button
                  onClick={() => setGraphType('square')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    graphType === 'square' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  Cartesian Square Grid
                </button>
                <button
                  onClick={() => setGraphType('isometric')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    graphType === 'isometric' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  Isometric 3D Grid
                </button>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Grid Scale</label>
              <select
                value={graphGridSize}
                onChange={(e) => setGraphGridSize(parseInt(e.target.value))}
                className="block mt-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs"
              >
                <option value={5}>5 mm Standard</option>
                <option value={10}>10 mm Coarse</option>
                <option value={2}>2 mm Millimeter Paper</option>
              </select>
            </div>
          </div>

          <div
            className="w-full h-[650px] bg-white border border-slate-300 rounded-xl shadow-md p-4 print:border-none print:shadow-none"
            style={{
              backgroundImage:
                graphType === 'isometric'
                  ? `radial-gradient(#475569 1px, transparent 1px)`
                  : `linear-gradient(to right, #94a3b8 1px, transparent 1px), linear-gradient(to bottom, #94a3b8 1px, transparent 1px)`,
              backgroundSize: `${graphGridSize * 3.78}px ${graphGridSize * 3.78}px`,
            }}
          />
        </div>
      )}
    </div>
  );
};
