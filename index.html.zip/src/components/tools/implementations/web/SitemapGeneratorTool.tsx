import React, { useState, useMemo } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { FileCode, Copy, Check, Download, Info, RotateCcw } from 'lucide-react';

export const SitemapGeneratorTool: React.FC = () => {
  const { showToast } = useTools();
  const [urlsInput, setUrlsInput] = useState(
    'https://example.com/\nhttps://example.com/about\nhttps://example.com/pricing\nhttps://example.com/contact\nhttps://example.com/blog'
  );
  const [changefreq, setChangefreq] = useState('weekly');
  const [priority, setPriority] = useState('0.8');
  const [includeLastmod, setIncludeLastmod] = useState(true);
  const [copied, setCopied] = useState(false);

  const todayIso = new Date().toISOString().split('T')[0];

  const generatedXml = useMemo(() => {
    const urls = urlsInput
      .split('\n')
      .map((u) => u.trim())
      .filter((u) => u.startsWith('http://') || u.startsWith('https://'));

    if (urls.length === 0) {
      return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <!-- Add valid HTTP or HTTPS URLs above -->\n</urlset>`;
    }

    const items = urls
      .map((url, idx) => {
        const itemPriority = idx === 0 ? '1.0' : priority;
        return `  <url>\n    <loc>${url}</loc>${
          includeLastmod ? `\n    <lastmod>${todayIso}</lastmod>` : ''
        }\n    <changefreq>${changefreq}</changefreq>\n    <priority>${itemPriority}</priority>\n  </url>`;
      })
      .join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${items}\n</urlset>`;
  }, [urlsInput, changefreq, priority, includeLastmod, todayIso]);

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedXml);
    setCopied(true);
    showToast('Sitemap XML copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([generatedXml], { type: 'application/xml' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = 'sitemap.xml';
    a.click();
    URL.revokeObjectURL(u);
    showToast('sitemap.xml downloaded!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Configuration */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Page URLs (One per line)
              </label>
              <textarea
                rows={7}
                value={urlsInput}
                onChange={(e) => setUrlsInput(e.target.value)}
                placeholder="https://example.com/"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 p-3 text-xs font-mono text-slate-900 dark:text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Change Frequency
                </label>
                <select
                  value={changefreq}
                  onChange={(e) => setChangefreq(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                >
                  <option value="always">always</option>
                  <option value="hourly">hourly</option>
                  <option value="daily">daily</option>
                  <option value="weekly">weekly</option>
                  <option value="monthly">monthly</option>
                  <option value="yearly">yearly</option>
                  <option value="never">never</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subpage Priority
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                >
                  <option value="1.0">1.0 (Highest)</option>
                  <option value="0.9">0.9</option>
                  <option value="0.8">0.8 (Standard)</option>
                  <option value="0.7">0.7</option>
                  <option value="0.5">0.5 (Default)</option>
                  <option value="0.3">0.3 (Low)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="lastmod"
                checked={includeLastmod}
                onChange={(e) => setIncludeLastmod(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              <label htmlFor="lastmod" className="text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                Include automatic &lt;lastmod&gt; date ({todayIso})
              </label>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-800 dark:text-blue-300">
            <Info className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold mb-0.5">Where does sitemap.xml belong?</p>
              Upload this file directly to the root directory of your website domain so it is accessible at:{' '}
              <span className="font-mono font-bold">https://example.com/sitemap.xml</span>.
            </div>
          </div>
        </div>

        {/* Right Output: Live Preview & Actions */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Generated sitemap.xml
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Copy XML'}</span>
              </button>
              <button
                type="button"
                onClick={handleDownload}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download sitemap.xml</span>
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-100 p-4 font-mono text-xs overflow-x-auto max-h-[460px] scrollbar-thin">
            <pre>{generatedXml}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
