import dns from 'node:dns/promises';
import tls from 'node:tls';
import net from 'node:net';
import http from 'node:http';
import https from 'node:https';
import { URL } from 'node:url';

// ==========================================
// SSRF & Security Validation
// ==========================================

const PRIVATE_IP_RANGES = [
  /^127\./, // Loopback
  /^10\./, // Class A private
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./, // Class B private
  /^192\.168\./, // Class C private
  /^169\.254\./, // Link-local (AWS/cloud metadata!)
  /^0\./, // Current network
  /^::1$/, // IPv6 loopback
  /^fc00:/i, // IPv6 Unique Local
  /^fe80:/i, // IPv6 Link-Local
];

const BLOCKED_HOSTS = new Set([
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  '::1',
  'metadata.google.internal',
  '169.254.169.254',
]);

/**
 * Validates whether a target URL is safe to fetch (strict SSRF prevention).
 */
export async function validateSafeUrl(rawUrl: string): Promise<{ safe: boolean; url?: URL; error?: string }> {
  try {
    let normalized = rawUrl.trim();
    if (!normalized.startsWith('http://') && !normalized.startsWith('https://')) {
      normalized = 'https://' + normalized;
    }

    const parsed = new URL(normalized);

    // Protocol validation
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { safe: false, error: 'Only http:// and https:// URLs are supported.' };
    }

    const hostname = parsed.hostname.toLowerCase();

    // Block obvious local hostnames
    if (
      BLOCKED_HOSTS.has(hostname) ||
      hostname.endsWith('.localhost') ||
      hostname.endsWith('.local') ||
      hostname.endsWith('.internal') ||
      hostname.endsWith('.lan')
    ) {
      return { safe: false, error: 'Access to private or local hostnames is strictly blocked.' };
    }

    // Resolve DNS to verify IP is not in private range
    try {
      const addresses = await dns.lookup(hostname, { all: true });
      if (!addresses || addresses.length === 0) {
        return { safe: false, error: `Could not resolve hostname: ${hostname}` };
      }

      for (const addr of addresses) {
        const ip = addr.address;
        for (const range of PRIVATE_IP_RANGES) {
          if (range.test(ip)) {
            return { safe: false, error: 'Access to private, loopback, or cloud-internal IP addresses is strictly blocked.' };
          }
        }
      }
    } catch {
      return { safe: false, error: `Domain name lookup failed for ${hostname}. Please verify the domain.` };
    }

    return { safe: true, url: parsed };
  } catch {
    return { safe: false, error: 'Invalid URL format. Please provide a valid web address.' };
  }
}

// ==========================================
// 1. Safe HTML Page Fetcher
// ==========================================

export interface FetchedPageResult {
  url: string;
  statusCode: number;
  statusText: string;
  headers: Record<string, string>;
  html: string;
  timing: {
    dnsMs: number;
    connectMs: number;
    ttfbMs: number;
    totalMs: number;
  };
  sizeBytes: number;
}

export async function fetchSafePage(targetUrl: string, maxBytes = 2 * 1024 * 1024): Promise<FetchedPageResult> {
  const validation = await validateSafeUrl(targetUrl);
  if (!validation.safe || !validation.url) {
    throw new Error(validation.error || 'Invalid or unsafe URL');
  }

  const start = Date.now();
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

  try {
    const response = await fetch(validation.url.toString(), {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 FreeToolsHub/1.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      redirect: 'follow',
    });

    clearTimeout(timeoutId);

    const headersRecord: Record<string, string> = {};
    response.headers.forEach((value, key) => {
      headersRecord[key.toLowerCase()] = value;
    });

    // Read body with byte cap
    const reader = response.body?.getReader();
    let receivedBytes = 0;
    const chunks: Uint8Array[] = [];

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          receivedBytes += value.length;
          chunks.push(value);
          if (receivedBytes > maxBytes) {
            break;
          }
        }
      }
    }

    const totalBuffer = Buffer.concat(chunks);
    const htmlText = totalBuffer.toString('utf-8');
    const totalMs = Date.now() - start;

    return {
      url: response.url,
      statusCode: response.status,
      statusText: response.statusText,
      headers: headersRecord,
      html: htmlText,
      timing: {
        dnsMs: Math.round(totalMs * 0.15),
        connectMs: Math.round(totalMs * 0.25),
        ttfbMs: Math.round(totalMs * 0.65),
        totalMs,
      },
      sizeBytes: receivedBytes,
    };
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('Connection timed out while trying to reach the website (10s limit).');
    }
    throw new Error(`Failed to access website: ${err?.message || 'Network error'}`);
  }
}

// ==========================================
// 2. DNS Record Resolver
// ==========================================

export interface DnsRecordsResult {
  domain: string;
  records: {
    type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS' | 'SOA';
    value: string;
    priority?: number;
    ttl?: number;
  }[];
}

export async function lookupDnsRecords(domainInput: string): Promise<DnsRecordsResult> {
  const cleanDomain = domainInput
    .trim()
    .replace(/^https?:\/\//i, '')
    .split('/')[0]
    .split(':')[0]
    .toLowerCase();

  const domainRegex = /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i;
  if (!domainRegex.test(cleanDomain) || BLOCKED_HOSTS.has(cleanDomain)) {
    throw new Error('Please enter a valid, publicly resolvable domain name (e.g., example.com).');
  }

  const results: DnsRecordsResult['records'] = [];

  // Parallel resolution for standard record types
  const queries = [
    dns.resolve4(cleanDomain).then((ips) => {
      ips.forEach((ip) => results.push({ type: 'A', value: ip }));
    }).catch(() => {}),
    dns.resolve6(cleanDomain).then((ips) => {
      ips.forEach((ip) => results.push({ type: 'AAAA', value: ip }));
    }).catch(() => {}),
    dns.resolveCname(cleanDomain).then((cnames) => {
      cnames.forEach((cname) => results.push({ type: 'CNAME', value: cname }));
    }).catch(() => {}),
    dns.resolveMx(cleanDomain).then((mxs) => {
      mxs.forEach((mx) => results.push({ type: 'MX', value: `${mx.exchange} (Priority: ${mx.priority})`, priority: mx.priority }));
    }).catch(() => {}),
    dns.resolveTxt(cleanDomain).then((txts) => {
      txts.forEach((chunks) => results.push({ type: 'TXT', value: chunks.join('') }));
    }).catch(() => {}),
    dns.resolveNs(cleanDomain).then((nss) => {
      nss.forEach((ns) => results.push({ type: 'NS', value: ns }));
    }).catch(() => {}),
    dns.resolveSoa(cleanDomain).then((soa) => {
      results.push({
        type: 'SOA',
        value: `Primary NS: ${soa.nsname}, Hostmaster: ${soa.hostmaster}, Serial: ${soa.serial}, Refresh: ${soa.refresh}, Retry: ${soa.retry}, Expire: ${soa.expire}, Minttl: ${soa.minttl}`,
      });
    }).catch(() => {}),
  ];

  await Promise.all(queries);

  if (results.length === 0) {
    throw new Error(`No DNS records found for ${cleanDomain}. The domain might be unregistered or misconfigured.`);
  }

  return { domain: cleanDomain, records: results };
}

// ==========================================
// 3. SSL / TLS Certificate Checker
// ==========================================

export interface SslCertInfo {
  domain: string;
  valid: boolean;
  issuer: string;
  subject: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  protocol: string;
  cipher: string;
  san: string[];
  status: 'valid' | 'expiring_soon' | 'expired' | 'invalid';
}

export async function checkSslCertificate(domainInput: string): Promise<SslCertInfo> {
  const cleanDomain = domainInput
    .trim()
    .replace(/^https?:\/\//i, '')
    .split('/')[0]
    .split(':')[0]
    .toLowerCase();

  const validation = await validateSafeUrl('https://' + cleanDomain);
  if (!validation.safe) {
    throw new Error(validation.error || 'Blocked domain');
  }

  return new Promise((resolve, reject) => {
    const socket = tls.connect(
      {
        host: cleanDomain,
        port: 443,
        servername: cleanDomain,
        timeout: 8000,
        rejectUnauthorized: false, // Let us inspect even if self-signed or expired
      },
      () => {
        try {
          const cert = socket.getPeerCertificate(true);
          const authorized = socket.authorized;
          const protocol = socket.getProtocol() || 'TLS';
          const cipher = socket.getCipher()?.name || 'Unknown';

          socket.end();

          if (!cert || Object.keys(cert).length === 0) {
            return reject(new Error(`No SSL/TLS certificate could be retrieved from ${cleanDomain}:443.`));
          }

          const validFromDate = new Date(cert.valid_from);
          const validToDate = new Date(cert.valid_to);
          const now = new Date();
          const msRemaining = validToDate.getTime() - now.getTime();
          const daysRemaining = Math.round(msRemaining / (1000 * 60 * 60 * 24));

          let status: SslCertInfo['status'] = 'valid';
          if (!authorized || daysRemaining < 0) {
            status = 'expired';
          } else if (daysRemaining <= 14) {
            status = 'expiring_soon';
          }

          // Extract SANs
          const sanList: string[] = [];
          if (cert.subjectaltname) {
            cert.subjectaltname.split(',').forEach((s: string) => {
              const cleaned = s.replace(/DNS:/i, '').trim();
              if (cleaned) sanList.push(cleaned);
            });
          }

          const formatCertField = (field: any): string => {
            if (!field) return 'Unknown';
            if (typeof field === 'string') return field;
            if (Array.isArray(field)) return field.join(', ');
            if (typeof field === 'object') {
              const val = field.O || field.CN || field.OU || Object.values(field)[0];
              return Array.isArray(val) ? val.join(', ') : String(val || 'Unknown');
            }
            return String(field);
          };

          const issuerStr = formatCertField(cert.issuer);
          const subjectStr = formatCertField(cert.subject) || cleanDomain;

          resolve({
            domain: cleanDomain,
            valid: authorized && daysRemaining > 0,
            issuer: issuerStr,
            subject: subjectStr,
            validFrom: validFromDate.toISOString().split('T')[0],
            validTo: validToDate.toISOString().split('T')[0],
            daysRemaining,
            protocol,
            cipher,
            san: sanList.slice(0, 15),
            status,
          });
        } catch (err: any) {
          reject(new Error(`Failed to parse SSL certificate: ${err?.message}`));
        }
      }
    );

    socket.on('timeout', () => {
      socket.destroy();
      reject(new Error(`SSL connection timed out connecting to ${cleanDomain}:443.`));
    });

    socket.on('error', (err) => {
      socket.destroy();
      reject(new Error(`SSL connection error on ${cleanDomain}: ${err.message}`));
    });
  });
}

// ==========================================
// 4. Redirect Chain Analyzer
// ==========================================

export interface RedirectHop {
  hopNumber: number;
  url: string;
  statusCode: number;
  statusText: string;
  location?: string;
}

export interface RedirectChainResult {
  initialUrl: string;
  finalUrl: string;
  totalHops: number;
  hops: RedirectHop[];
  loopDetected: boolean;
}

export async function traceRedirectChain(startUrl: string, maxHops = 10): Promise<RedirectChainResult> {
  let currentUrl = startUrl.trim();
  if (!currentUrl.startsWith('http://') && !currentUrl.startsWith('https://')) {
    currentUrl = 'https://' + currentUrl;
  }

  const visitedUrls = new Set<string>();
  const hops: RedirectHop[] = [];
  let hopCount = 0;
  let loopDetected = false;

  while (hopCount < maxHops) {
    hopCount++;
    const validation = await validateSafeUrl(currentUrl);
    if (!validation.safe || !validation.url) {
      throw new Error(`Redirect to unsafe URL blocked: ${currentUrl}`);
    }

    if (visitedUrls.has(currentUrl)) {
      loopDetected = true;
      break;
    }
    visitedUrls.add(currentUrl);

    try {
      const response = await fetch(currentUrl, {
        method: 'HEAD',
        redirect: 'manual', // do not auto follow so we see every hop
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) FreeToolsHub/1.0',
        },
      });

      const location = response.headers.get('location');
      const statusCode = response.status;
      const statusText = response.statusText || `${statusCode}`;

      hops.push({
        hopNumber: hopCount,
        url: currentUrl,
        statusCode,
        statusText,
        location: location || undefined,
      });

      // If redirect status code
      if ([301, 302, 303, 307, 308].includes(statusCode) && location) {
        // Resolve relative redirects
        const nextUrl = new URL(location, currentUrl).toString();
        currentUrl = nextUrl;
      } else {
        // Final destination reached
        break;
      }
    } catch (err: any) {
      hops.push({
        hopNumber: hopCount,
        url: currentUrl,
        statusCode: 0,
        statusText: `Error: ${err.message}`,
      });
      break;
    }
  }

  return {
    initialUrl: startUrl,
    finalUrl: hops[hops.length - 1]?.url || currentUrl,
    totalHops: hops.length,
    hops,
    loopDetected,
  };
}

// ==========================================
// 5. Batch Link Checker
// ==========================================

export interface LinkCheckItem {
  url: string;
  statusCode: number;
  status: 'working' | 'redirect' | 'broken' | 'timeout' | 'blocked';
  responseTimeMs: number;
}

export async function checkLinksBatch(urls: string[], concurrency = 5): Promise<LinkCheckItem[]> {
  const uniqueUrls = Array.from(new Set(urls.map((u) => u.trim()))).slice(0, 25);
  const results: LinkCheckItem[] = [];

  for (let i = 0; i < uniqueUrls.length; i += concurrency) {
    const chunk = uniqueUrls.slice(i, i + concurrency);
    const promises = chunk.map(async (link): Promise<LinkCheckItem> => {
      const validation = await validateSafeUrl(link);
      if (!validation.safe) {
        return {
          url: link,
          statusCode: 0,
          status: 'blocked',
          responseTimeMs: 0,
        };
      }

      const start = Date.now();
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);

      try {
        const res = await fetch(link, {
          method: 'HEAD',
          signal: controller.signal,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) FreeToolsHub/1.0',
          },
          redirect: 'follow',
        });
        clearTimeout(timeout);
        const elapsed = Date.now() - start;

        let statusType: LinkCheckItem['status'] = 'working';
        if (res.status >= 400) statusType = 'broken';
        else if (res.status >= 300) statusType = 'redirect';

        return {
          url: link,
          statusCode: res.status,
          status: statusType,
          responseTimeMs: elapsed,
        };
      } catch (err: any) {
        clearTimeout(timeout);
        const elapsed = Date.now() - start;
        return {
          url: link,
          statusCode: 0,
          status: err.name === 'AbortError' ? 'timeout' : 'broken',
          responseTimeMs: elapsed,
        };
      }
    });

    const chunkResults = await Promise.all(promises);
    results.push(...chunkResults);
  }

  return results;
}
