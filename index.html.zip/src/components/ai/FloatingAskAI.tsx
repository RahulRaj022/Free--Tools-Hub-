import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  X,
  Bot,
  Send,
  Square,
  Copy,
  Check,
  ExternalLink,
  RotateCcw,
} from 'lucide-react';
import { ToolItem } from '../../types';
import { ChatMessage, ToolContext } from '../../types/ai';
import { streamAIChat } from '../../services/aiService';
import { MarkdownRenderer } from './MarkdownRenderer';

interface FloatingAskAIProps {
  tool: ToolItem;
  navigate: (path: string) => void;
}

export const FloatingAskAI: React.FC<FloatingAskAIProps> = ({ tool, navigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const toolContext: ToolContext = {
    name: tool.name,
    slug: tool.slug,
    path: `/tools/${tool.slug}`,
    category: tool.category,
    description: tool.shortDescription,
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  const handleSend = async (customPrompt?: string) => {
    const text = (customPrompt || input).trim();
    if (!text || isStreaming) return;

    const userMsg: ChatMessage = {
      id: `float_u_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const assistantId = `float_a_${Date.now()}`;
    const assistantPlaceholder: ChatMessage = {
      id: assistantId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    setMessages((prev) => [...prev, userMsg, assistantPlaceholder]);
    setInput('');
    setIsStreaming(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const history = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      await streamAIChat({
        messages: history,
        toolContext,
        signal: controller.signal,
        onBatchedText: (text) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantId ? { ...m, content: text } : m))
          );
        },
      });

      setMessages((prev) =>
        prev.map((m) => (m.id === assistantId ? { ...m, isStreaming: false } : m))
      );
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        const errMsg = err?.message || 'AI Assistant is currently unavailable. Please verify API key setup.';
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId ? { ...m, content: errMsg, error: true, isStreaming: false } : m
          )
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsStreaming(false);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickToolPrompts = [
    `How do I use ${tool.name}?`,
    `What are the best settings or tips for ${tool.name}?`,
    `Explain the technical concepts behind this tool.`,
  ];

  return (
    <>
      {/* Floating Trigger Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 text-white font-bold text-xs sm:text-sm shadow-xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer ring-4 ring-indigo-500/10 group"
          title="Ask Free Tools Hub AI about this tool"
        >
          <Sparkles className="h-4 w-4 transition-transform group-hover:rotate-12 duration-200" />
          <span>✨ Ask AI</span>
        </button>
      </div>

      {/* Slide-over Drawer Panel */}
      {isOpen && (
        <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[440px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-250">
          {/* Header */}
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/70 dark:bg-slate-800/40">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-2xs shrink-0">
                <Bot className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                  Free Tools Hub AI
                </h3>
                <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold truncate">
                  Context: {tool.name}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  navigate('/ai-assistant');
                }}
                className="p-1.5 text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer"
                title="Open full AI chat page"
              >
                <ExternalLink className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                title="Close"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs scrollbar-thin">
            {messages.length === 0 ? (
              <div className="py-6 space-y-5 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                  <Sparkles className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    Need help with {tool.name}?
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                    Ask questions, get instructions, or request quick tips right inside this tool.
                  </p>
                </div>

                {/* Quick Prompts */}
                <div className="space-y-2 text-left pt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block px-1">
                    Quick Questions
                  </span>
                  {quickToolPrompts.map((p, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleSend(p)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 hover:border-indigo-400 text-left text-xs text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m) => {
                const isUser = m.role === 'user';
                return (
                  <div
                    key={m.id}
                    className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[90%] rounded-2xl p-3 text-xs leading-relaxed ${
                        isUser
                          ? 'bg-indigo-600 text-white'
                          : m.error
                          ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      {isUser ? (
                        m.content
                      ) : m.content ? (
                        <div>
                          <MarkdownRenderer content={m.content} navigate={navigate} />
                          <div className="flex items-center justify-end gap-1.5 mt-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60 text-slate-400">
                            <button
                              type="button"
                              onClick={() => handleCopy(m.id, m.content)}
                              className="hover:text-indigo-600 transition-colors cursor-pointer"
                              title="Copy"
                            >
                              {copiedId === m.id ? (
                                <Check className="h-3 w-3 text-emerald-500" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 py-1 text-slate-500">
                          <Sparkles className="h-3.5 w-3.5 animate-spin text-indigo-500" />
                          <span>Thinking...</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Sticky Input */}
          <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSend();
                }}
                placeholder={`Ask about ${tool.name}...`}
                className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />

              {isStreaming ? (
                <button
                  type="button"
                  onClick={handleStop}
                  className="p-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 transition-colors cursor-pointer"
                  title="Stop"
                >
                  <Square className="h-4 w-4 fill-white" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleSend()}
                  disabled={!input.trim()}
                  className="p-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-40 transition-colors cursor-pointer"
                  title="Send"
                >
                  <Send className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
