import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export const Logo: React.FC<LogoProps> = ({ className = 'h-9 w-9', size }) => {
  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      style={size ? { width: size, height: size } : undefined}
      aria-label="Free Tools Hub Logo"
      role="img"
    >
      <defs>
        {/* Vibrant Cyan-Blue to Purple/Violet Gradient matching user reference */}
        <linearGradient id="fth-logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0088FF" />
          <stop offset="35%" stopColor="#2260FF" />
          <stop offset="70%" stopColor="#7018FF" />
          <stop offset="100%" stopColor="#9C24FF" />
        </linearGradient>
        {/* Top Glare subtle sheen */}
        <linearGradient id="fth-logo-sheen" x1="50%" y1="0%" x2="50%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Rounded-Square Icon Container ("Squircle") */}
      <rect width="120" height="120" rx="30" fill="url(#fth-logo-grad)" />
      <rect width="120" height="120" rx="30" fill="url(#fth-logo-sheen)" />
      <rect width="120" height="120" rx="30" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" />

      {/* Solid White Emblem: Open-end Wrench morphing into an Electric Lightning Bolt */}
      <path
        fill="#FFFFFF"
        fillRule="evenodd"
        clipRule="evenodd"
        d="
          M 69.5 24.5
          C 64.2 25.8 59.2 29.1 55.4 34.0
          C 51.5 39.0 49.8 45.2 50.8 51.4
          L 45.2 60.5
          C 44.5 61.6 43.4 62.4 42.1 62.8
          L 44.8 64.2
          L 34.8 79.5
          C 33.2 81.9 33.8 85.1 36.1 86.8
          C 38.0 88.2 40.6 88.0 42.2 86.4
          L 45.0 83.5
          L 39.5 101.5
          C 39.0 103.0 40.8 104.2 41.8 103.0
          L 73.8 70.2
          C 74.8 69.2 74.1 67.5 72.8 67.5
          L 59.2 67.5
          L 68.2 57.0
          L 73.8 58.2
          C 79.8 59.5 85.8 57.8 90.2 53.5
          C 94.8 49.0 96.8 42.8 95.8 36.5
          L 85.2 44.8
          C 81.8 47.5 76.8 47.0 74.1 43.5
          C 71.5 40.2 72.0 35.2 75.4 32.5
          L 83.5 26.2
          C 79.2 24.5 74.2 23.9 69.5 24.5
          Z
        "
      />
    </svg>
  );
};
