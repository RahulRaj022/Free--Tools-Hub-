import React, { useState, useRef, useEffect } from 'react';
import { useTools } from '../../../context/ToolsContext';
import {
  Users,
  RotateCw,
  Sparkles,
  CheckSquare,
  Calendar,
  Clock,
  ListFilter,
  Copy,
  Printer,
  Trash2,
  Plus,
  ArrowUpDown,
  Check,
} from 'lucide-react';

interface ProductivitySuiteToolsProps {
  toolSlug: string;
}

export const ProductivitySuiteTools: React.FC<ProductivitySuiteToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // 1. Random Team Generator
  const [namesInput, setNamesInput] = useState('Alex\nJordan\nTaylor\nMorgan\nRiley\nCasey\nAvery\nQuinn\nDakota\nSkyler');
  const [teamCount, setTeamCount] = useState<number>(2);
  const [generatedTeams, setGeneratedTeams] = useState<string[][]>([]);

  // 2. Decision Wheel
  const [wheelOptions, setWheelOptions] = useState<string[]>([
    'Pizza', 'Burgers', 'Sushi', 'Tacos', 'Salad', 'Pasta'
  ]);
  const [newOption, setNewOption] = useState('');
  const [spinning, setSpinning] = useState(false);
  const [wheelAngle, setWheelAngle] = useState(0);
  const [wheelWinner, setWheelWinner] = useState<string | null>(null);
  const wheelCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // 3. Random Picker
  const [pickerChoices, setPickerChoices] = useState('Option A\nOption B\nOption C\nOption D\nOption E');
  const [pickCount, setPickCount] = useState<number>(1);
  const [pickedWinners, setPickedWinners] = useState<string[]>([]);

  // 4. Habit Tracker
  const [habitDays, setHabitDays] = useState<number>(30);
  const [habitsList, setHabitsList] = useState<string[]>([
    'Morning Exercise (30m)', 'Read 15 Pages', 'Drink 2.5L Water', 'Meditation / Journaling'
  ]);
  const [newHabit, setNewHabit] = useState('');

  // 5. Checklist Generator
  const [checklistItems, setChecklistItems] = useState<Array<{ text: string; done: boolean }>>([
    { text: 'Review quarterly architecture plan', done: true },
    { text: 'Verify mobile responsive breakpoints', done: false },
    { text: 'Compile production client bundle', done: false },
  ]);
  const [newChecklistItem, setNewChecklistItem] = useState('');

  // 6. Meeting Agenda Generator
  const [agendaTitle, setAgendaTitle] = useState('Weekly Engineering Sync');
  const [agendaDate, setAgendaDate] = useState('2026-10-15');
  const [agendaAttendees, setAgendaAttendees] = useState('Engineering Team, Product Manager');
  const [agendaTopics, setAgendaTopics] = useState<Array<{ topic: string; mins: number; presenter: string }>>([
    { topic: 'Sprint Demo & Key Deliverables', mins: 15, presenter: 'Lead Dev' },
    { topic: 'Security & Client-Side Sandbox Review', mins: 20, presenter: 'Security Team' },
    { topic: 'Q&A and Next Milestones', mins: 10, presenter: 'All' },
  ]);

  // 7. Name List Formatter
  const [rawNameList, setRawNameList] = useState('john doe\nalice smith\nJOHN DOE\nbob johnson\ncharlie brown');
  const [nameSort, setNameSort] = useState<'az' | 'za' | 'none'>('az');
  const [nameTitleCase, setNameTitleCase] = useState(true);
  const [nameNumbering, setNameNumbering] = useState(true);
  const [nameDeduplicate, setNameDeduplicate] = useState(true);

  const copyText = (txt: string, msg = 'Copied to clipboard') => {
    navigator.clipboard.writeText(txt);
    showToast(msg, 'success');
  };

  // 1. Process: Random Teams
  const handleGenerateTeams = () => {
    const list = namesInput
      .split('\n')
      .map((n) => n.trim())
      .filter((n) => n.length > 0);

    if (list.length === 0) {
      showToast('Please enter at least one name', 'error');
      return;
    }

    // Shuffle
    const shuffled = [...list].sort(() => Math.random() - 0.5);
    const teams: string[][] = Array.from({ length: teamCount }, () => []);

    shuffled.forEach((person, index) => {
      teams[index % teamCount].push(person);
    });

    setGeneratedTeams(teams);
    showToast(`Generated ${teamCount} random teams!`, 'success');
  };

  // 2. Draw & Spin Decision Wheel
  const drawWheel = (angle: number) => {
    const canvas = wheelCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = 360);
    const height = (canvas.height = 360);
    const cx = width / 2;
    const cy = height / 2;
    const radius = width / 2 - 15;
    const arc = (2 * Math.PI) / wheelOptions.length;

    ctx.clearRect(0, 0, width, height);

    const colors = ['#6366F1', '#EC4899', '#10B981', '#F59E0B', '#06B6D4', '#8B5CF6', '#F43F5E', '#3B82F6'];

    wheelOptions.forEach((opt, idx) => {
      const start = angle + idx * arc;
      const end = start + arc;

      ctx.beginPath();
      ctx.fillStyle = colors[idx % colors.length];
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, start, end);
      ctx.closePath();
      ctx.fill();

      // Text label
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(start + arc / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText(opt, radius - 15, 4);
      ctx.restore();
    });

    // Center hub
    ctx.beginPath();
    ctx.arc(cx, cy, 22, 0, 2 * Math.PI);
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = 'rgba(0,0,0,0.2)';
    ctx.shadowBlur = 6;
    ctx.fill();

    // Top pointer needle
    ctx.beginPath();
    ctx.moveTo(cx - 10, 10);
    ctx.lineTo(cx + 10, 10);
    ctx.lineTo(cx, 26);
    ctx.closePath();
    ctx.fillStyle = '#DC2626';
    ctx.fill();
  };

  useEffect(() => {
    if (toolSlug === 'decision-wheel') {
      drawWheel(wheelAngle);
    }
  }, [toolSlug, wheelOptions, wheelAngle]);

  const spinTheWheel = () => {
    if (spinning || wheelOptions.length < 2) return;
    setSpinning(true);
    setWheelWinner(null);

    const extraSpins = 5 + Math.random() * 5;
    const targetAngle = wheelAngle + extraSpins * 2 * Math.PI + Math.random() * 2 * Math.PI;
    const durationMs = 3500;
    const startTimestamp = performance.now();
    const initialAngle = wheelAngle;

    const animateSpin = (now: number) => {
      const elapsed = now - startTimestamp;
      const progress = Math.min(1, elapsed / durationMs);
      // ease-out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = initialAngle + (targetAngle - initialAngle) * ease;
      setWheelAngle(current);
      drawWheel(current);

      if (progress < 1) {
        requestAnimationFrame(animateSpin);
      } else {
        setSpinning(false);
        const arc = (2 * Math.PI) / wheelOptions.length;
        const normalized = ((2 * Math.PI - (current % (2 * Math.PI)) - Math.PI / 2) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI);
        const winIdx = Math.floor(normalized / arc) % wheelOptions.length;
        const winner = wheelOptions[winIdx];
        setWheelWinner(winner);
        showToast(`Winner: ${winner}!`, 'success');
      }
    };

    requestAnimationFrame(animateSpin);
  };

  // 3. Process: Random Picker
  const handleRandomPick = () => {
    const list = pickerChoices
      .split('\n')
      .map((c) => c.trim())
      .filter((c) => c.length > 0);

    if (list.length === 0) {
      showToast('Enter options to pick from', 'error');
      return;
    }

    const shuffled = [...list].sort(() => Math.random() - 0.5);
    const count = Math.min(list.length, pickCount);
    setPickedWinners(shuffled.slice(0, count));
    showToast(`Picked ${count} choice(s)!`, 'success');
  };

  // 7. Formatted Name List calculation
  const formattedNames = () => {
    let list = rawNameList
      .split('\n')
      .map((n) => n.trim())
      .filter((n) => n.length > 0);

    if (nameTitleCase) {
      list = list.map((n) =>
        n.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.substring(1).toLowerCase())
      );
    }

    if (nameDeduplicate) {
      list = Array.from(new Set(list));
    }

    if (nameSort === 'az') {
      list.sort((a, b) => a.localeCompare(b));
    } else if (nameSort === 'za') {
      list.sort((a, b) => b.localeCompare(a));
    }

    if (nameNumbering) {
      return list.map((n, i) => `${i + 1}. ${n}`).join('\n');
    }

    return list.join('\n');
  };

  return (
    <div className="space-y-6">
      {/* 1. RANDOM TEAM GENERATOR */}
      {toolSlug === 'random-team-generator' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-indigo-600" />
              <span>Random Team Divider</span>
            </div>
            <button
              onClick={handleGenerateTeams}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 shadow-xs"
            >
              <RotateCw className="h-3.5 w-3.5" />
              <span>Generate Random Teams</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Number of Teams: {teamCount}
              </label>
              <input
                type="range"
                min="2"
                max="8"
                value={teamCount}
                onChange={(e) => setTeamCount(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block pt-2">
                List of Participants (one per line):
              </label>
              <textarea
                value={namesInput}
                onChange={(e) => setNamesInput(e.target.value)}
                rows={8}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
              />
            </div>

            <div className="md:col-span-2">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-2">
                Balanced Teams:
              </span>
              {generatedTeams.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {generatedTeams.map((team, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 space-y-2"
                    >
                      <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-1.5">
                        <span className="font-bold text-xs text-indigo-600">Team {idx + 1}</span>
                        <span className="text-[11px] text-slate-400">{team.length} members</span>
                      </div>
                      <ul className="text-xs space-y-1 text-slate-800 dark:text-slate-200">
                        {team.map((member, mIdx) => (
                          <li key={mIdx}>• {member}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-16 text-center text-xs text-slate-400 border border-dashed rounded-xl">
                  Click Generate to randomize your participants into balanced squads.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. DECISION WHEEL */}
      {toolSlug === 'decision-wheel' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
            <div className="flex items-center gap-2">
              <RotateCw className="h-4 w-4 text-indigo-600" />
              <span>Interactive Decision Wheel</span>
            </div>
            {wheelWinner && (
              <span className="px-3 py-1 rounded-full bg-emerald-500 text-white font-black text-xs animate-bounce">
                🎉 Selected: {wheelWinner}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="flex flex-col items-center">
              <canvas ref={wheelCanvasRef} className="rounded-full shadow-xl" />
              <button
                onClick={spinTheWheel}
                disabled={spinning}
                className="mt-6 px-8 py-3 rounded-2xl bg-indigo-600 text-white font-black text-sm hover:bg-indigo-700 disabled:opacity-50 shadow-md hover:scale-105 transition-all"
              >
                {spinning ? 'Spinning...' : 'SPIN WHEEL'}
              </button>
            </div>

            <div className="space-y-4">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 block">
                Wheel Slices ({wheelOptions.length}):
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newOption}
                  onChange={(e) => setNewOption(e.target.value)}
                  placeholder="Add choice..."
                  className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
                />
                <button
                  onClick={() => {
                    if (newOption.trim()) {
                      setWheelOptions([...wheelOptions, newOption.trim()]);
                      setNewOption('');
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold"
                >
                  Add
                </button>
              </div>

              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
                {wheelOptions.map((opt, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300"
                  >
                    <span>{opt}</span>
                    <button
                      onClick={() => setWheelOptions(wheelOptions.filter((_, i) => i !== idx))}
                      className="text-slate-400 hover:text-rose-500"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. RANDOM PICKER */}
      {toolSlug === 'random-picker' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              <span>Random Choice Picker</span>
            </div>
            <button
              onClick={handleRandomPick}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 shadow-xs"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Pick Random Winner</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                Enter choices (one per line):
              </label>
              <textarea
                value={pickerChoices}
                onChange={(e) => setPickerChoices(e.target.value)}
                rows={6}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-2">
                Winner Outcome:
              </label>
              {pickedWinners.length > 0 ? (
                <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center space-y-2">
                  <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider block">
                    Selected Result
                  </span>
                  <div className="text-2xl font-black text-emerald-600">
                    {pickedWinners.join(', ')}
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center text-xs text-slate-400 border border-dashed rounded-xl">
                  Click Pick to draw a random item.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. HABIT TRACKER GENERATOR */}
      {toolSlug === 'habit-tracker-generator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 print:hidden">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Days Tracker:</span>
              {[7, 14, 21, 30].map((d) => (
                <button
                  key={d}
                  onClick={() => setHabitDays(d)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    habitDays === d ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-800 text-slate-600'
                  }`}
                >
                  {d} Days
                </button>
              ))}
            </div>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs shadow-xs"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print Sheet</span>
            </button>
          </div>

          <div className="p-8 bg-white text-slate-900 rounded-2xl border border-slate-300 shadow-lg print:border-none print:shadow-none print:p-0">
            <h2 className="text-2xl font-black border-b-2 border-slate-900 pb-2 mb-4">
              Monthly Habit & Routine Tracker
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-slate-300 text-xs">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-300 p-2 text-left w-48">Habit / Goal</th>
                    {Array.from({ length: habitDays }).map((_, i) => (
                      <th key={i} className="border border-slate-300 p-1 w-6 text-center font-mono">
                        {i + 1}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {habitsList.map((habit, idx) => (
                    <tr key={idx}>
                      <td className="border border-slate-300 p-2.5 font-bold">{habit}</td>
                      {Array.from({ length: habitDays }).map((_, i) => (
                        <td key={i} className="border border-slate-300 p-1 text-center">
                          <div className="w-3.5 h-3.5 rounded-full border border-slate-400 mx-auto" />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5. CHECKLIST GENERATOR */}
      {toolSlug === 'checklist-generator' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
            <div className="flex items-center gap-2">
              <CheckSquare className="h-4 w-4 text-indigo-600" />
              <span>Interactive Checklist Builder</span>
            </div>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold hover:bg-slate-50"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print Checklist</span>
            </button>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={newChecklistItem}
              onChange={(e) => setNewChecklistItem(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newChecklistItem.trim()) {
                  setChecklistItems([...checklistItems, { text: newChecklistItem.trim(), done: false }]);
                  setNewChecklistItem('');
                }
              }}
              placeholder="Add checklist task..."
              className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
            />
            <button
              onClick={() => {
                if (newChecklistItem.trim()) {
                  setChecklistItems([...checklistItems, { text: newChecklistItem.trim(), done: false }]);
                  setNewChecklistItem('');
                }
              }}
              className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs"
            >
              Add Task
            </button>
          </div>

          <div className="space-y-2">
            {checklistItems.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/40 text-xs"
              >
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={item.done}
                    onChange={() => {
                      const updated = [...checklistItems];
                      updated[idx].done = !updated[idx].done;
                      setChecklistItems(updated);
                    }}
                    className="accent-indigo-600 rounded"
                  />
                  <span className={item.done ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200 font-medium'}>
                    {item.text}
                  </span>
                </label>
                <button
                  onClick={() => setChecklistItems(checklistItems.filter((_, i) => i !== idx))}
                  className="text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. MEETING AGENDA GENERATOR */}
      {toolSlug === 'meeting-agenda-generator' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 print:hidden">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Meeting Title</label>
              <input
                type="text"
                value={agendaTitle}
                onChange={(e) => setAgendaTitle(e.target.value)}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Date</label>
              <input
                type="date"
                value={agendaDate}
                onChange={(e) => setAgendaDate(e.target.value)}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Attendees</label>
              <input
                type="text"
                value={agendaAttendees}
                onChange={(e) => setAgendaAttendees(e.target.value)}
                className="w-full mt-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
          </div>

          <div className="p-8 bg-white text-slate-900 rounded-2xl border border-slate-300 shadow-xl max-w-3xl mx-auto print:border-none print:shadow-none print:p-0">
            <div className="border-b-2 border-slate-900 pb-3 mb-4">
              <h2 className="text-2xl font-black">{agendaTitle}</h2>
              <div className="text-xs text-slate-500 font-mono mt-1">
                Date: {agendaDate} · Attendees: {agendaAttendees}
              </div>
            </div>

            <div className="space-y-4">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-400 block">
                Agenda Topics:
              </span>
              <div className="divide-y divide-slate-200">
                {agendaTopics.map((top, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold mr-2">{idx + 1}.</span>
                      <span className="font-semibold">{top.topic}</span>
                      <span className="text-slate-400 ml-2">({top.presenter})</span>
                    </div>
                    <span className="font-mono font-bold bg-slate-100 px-2 py-0.5 rounded">
                      {top.mins} min
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. NAME LIST FORMATTER */}
      {toolSlug === 'name-list-formatter' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white">
            <div className="flex items-center gap-2">
              <ListFilter className="h-4 w-4 text-indigo-600" />
              <span>Name List Formatter & Deduplicator</span>
            </div>
            <button
              onClick={() => copyText(formattedNames(), 'Formatted names copied!')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 shadow-xs"
            >
              <Copy className="h-3.5 w-3.5" />
              <span>Copy Formatted List</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-4 text-xs font-semibold">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={nameTitleCase}
                onChange={(e) => setNameTitleCase(e.target.checked)}
                className="accent-indigo-600 rounded"
              />
              <span>Capitalize Names (Title Case)</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={nameDeduplicate}
                onChange={(e) => setNameDeduplicate(e.target.checked)}
                className="accent-indigo-600 rounded"
              />
              <span>Remove Duplicates</span>
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={nameNumbering}
                onChange={(e) => setNameNumbering(e.target.checked)}
                className="accent-indigo-600 rounded"
              />
              <span>Add Sequential Numbering</span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">Raw Names Input:</label>
              <textarea
                value={rawNameList}
                onChange={(e) => setRawNameList(e.target.value)}
                rows={8}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 block mb-1">Clean Formatted Output:</label>
              <textarea
                readOnly
                value={formattedNames()}
                rows={8}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 font-mono text-xs text-indigo-600"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
