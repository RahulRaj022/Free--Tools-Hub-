import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { useTools } from '../../context/ToolsContext';
import { Logo } from '../common/Logo';
import {
  Search,
  Moon,
  Sun,
  Menu,
  X,
  Star,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, navigate }) => {
  const { theme, toggleTheme } = useTheme();
  const { favorites, openSearch } = useTools();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'All Tools', path: '/tools' },
    { label: 'Video', path: '/video-tools' },
    { label: 'Audio', path: '/audio-tools' },
    { label: 'PDF', path: '/pdf-tools' },
    { label: 'Images', path: '/image-tools' },
    { label: 'Design', path: '/design-tools' },
    { label: 'Text', path: '/text-tools' },
    { label: 'Calculators', path: '/calculators' },
    { label: 'Developer', path: '/developer-tools' },
    { label: '✨ AI Assistant', path: '/ai-assistant' },
  ];

  const handleNav = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800/80 dark:bg-slate-900/90 transition-colors">
      <div className="mx-auto flex h-16 w-full max-w-7xl 2xl:max-w-[1600px] items-center justify-between px-3 sm:px-4 lg:px-6 xl:px-8">
        
        {/* Zone 1: Brand Logo & Name (Always ONE single horizontal line, never wrapped) */}
        <div className="flex items-center shrink-0 mr-2 sm:mr-3 lg:mr-4">
          <button
            onClick={() => handleNav('/')}
            className="group flex items-center gap-2.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-lg p-1 shrink-0 cursor-pointer"
            title="Free Tools Hub Home"
          >
            <Logo className="h-8 w-8 sm:h-9 sm:w-9 rounded-xl shadow-xs shadow-indigo-500/25 group-hover:scale-105 transition-transform shrink-0" />
            <span className="font-bold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white whitespace-nowrap select-none">
              Free Tools Hub
            </span>
          </button>
        </div>

        {/* Zone 2: Main Direct Navigation Links (Desktop/Laptop - No dropdown, all direct links) */}
        <nav className="hidden lg:flex items-center gap-0.5 xl:gap-1 2xl:gap-1.5 shrink-0">
          {navLinks.map((link) => {
            const isActive = currentPath === link.path;
            const isAi = link.path === '/ai-assistant';
            return (
              <button
                key={link.path}
                onClick={() => handleNav(link.path)}
                className={`px-1.5 xl:px-2 2xl:px-2.5 py-1 xl:py-1.5 text-xs xl:text-[13px] 2xl:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50/80 dark:bg-indigo-950/50 font-semibold'
                    : isAi
                    ? 'text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/30 font-semibold'
                    : 'text-slate-600 hover:text-slate-950 dark:text-slate-300 dark:hover:text-white hover:bg-slate-100/70 dark:hover:bg-slate-800/50'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Header Controls (Search, Favorites, Theme Toggle, Mobile Hamburger) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 ml-2">
          {/* Quick Search trigger */}
          <button
            onClick={openSearch}
            className="flex items-center gap-1.5 sm:gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2 sm:px-2.5 py-1.5 text-xs text-slate-500 hover:border-slate-300 hover:bg-white hover:text-slate-800 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400 dark:hover:border-slate-700 dark:hover:text-slate-200 transition-all shadow-2xs cursor-pointer"
            title="Search tools (Ctrl+K or Cmd+K)"
          >
            <Search className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Search...</span>
            <kbd className="hidden md:inline-block rounded border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] font-mono text-slate-400 dark:border-slate-800 dark:bg-slate-900">
              ⌘K
            </kbd>
          </button>

          {/* Favorites link */}
          <button
            onClick={() => handleNav('/favorites')}
            className={`relative flex h-8.5 w-8.5 sm:h-9 sm:w-9 items-center justify-center rounded-lg border transition-colors cursor-pointer ${
              currentPath === '/favorites'
                ? 'border-indigo-200 bg-indigo-50 text-indigo-600 dark:border-indigo-900/60 dark:bg-indigo-950/50 dark:text-indigo-400'
                : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400 dark:hover:border-slate-700'
            }`}
            title="View favorite tools"
          >
            <Star className={`h-4 w-4 ${favorites.length > 0 ? 'text-amber-500 fill-amber-500' : ''}`} />
            {favorites.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-bold text-white shadow-2xs">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Dark / Light mode toggle */}
          <button
            onClick={toggleTheme}
            className="flex h-8.5 w-8.5 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-slate-700 transition-colors cursor-pointer"
            title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-slate-600" />}
          </button>

          {/* Mobile/Tablet hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-8.5 w-8.5 sm:h-9 sm:w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 lg:hidden dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile / Tablet Drawer */}
      {mobileMenuOpen && (
        <div className="border-b border-slate-200 bg-white px-4 pt-2 pb-6 lg:hidden dark:border-slate-800 dark:bg-slate-900 shadow-xl max-h-[85vh] overflow-y-auto animate-in slide-in-from-top duration-150">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleNav(link.path)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 font-semibold'
                      : 'text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <span>{link.label}</span>
                </button>
              );
            })}

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 mt-2 flex flex-col gap-1">
              <button
                onClick={() => handleNav('/favorites')}
                className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-medium text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800/60 cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                  My Favorites
                </span>
                <span className="text-xs font-mono font-medium text-slate-500">
                  {favorites.length} saved
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
