import React, { useState } from 'react';
import { PDFDocument } from 'pdf-lib';
import { useTools } from '../../../context/ToolsContext';
import { UploadCloud, Download, Files, Scissors, FileImage, FileArchive, Trash2, ArrowUp, ArrowDown, Check } from 'lucide-react';

interface PdfToolsProps {
  toolSlug: string;
}

export const PdfTools: React.FC<PdfToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // Merger states
  const [mergeFiles, setMergeFiles] = useState<Array<{ id: string; file: File; name: string; size: number; pageCount?: number }>>([]);
  const [isMerging, setIsMerging] = useState<boolean>(false);

  // Splitter states
  const [splitFile, setSplitFile] = useState<{ file: File; name: string; size: number; totalPages: number } | null>(null);
  const [splitRange, setSplitRange] = useState<string>('1-2');
  const [isSplitting, setIsSplitting] = useState<boolean>(false);

  // Images to PDF states
  const [imgFiles, setImgFiles] = useState<Array<{ id: string; file: File; name: string; size: number; preview: string }>>([]);
  const [isConvertingImg, setIsConvertingImg] = useState<boolean>(false);

  // Compressor states
  const [compressFile, setCompressFile] = useState<{ file: File; name: string; size: number } | null>(null);
  const [isCompressing, setIsCompressing] = useState<boolean>(false);
  const [compressedResult, setCompressedResult] = useState<{ url: string; size: number } | null>(null);

  // PDF to JPG states
  const [pdfToJpgFile, setPdfToJpgFile] = useState<{ file: File; name: string; size: number; totalPages: number } | null>(null);
  const [selectedPageNum, setSelectedPageNum] = useState<number>(1);
  const [isConvertingPdfToJpg, setIsConvertingPdfToJpg] = useState<boolean>(false);
  const [renderedJpgResult, setRenderedJpgResult] = useState<string | null>(null);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // 1. PDF MERGER HANDLERS
  const handleMergeFilesAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const newItems: Array<{ id: string; file: File; name: string; size: number; pageCount?: number }> = [];
    for (const f of files) {
      if (f.type !== 'application/pdf' && !f.name.endsWith('.pdf')) {
        showToast(`Skipped ${f.name} (not a PDF)`, 'error');
        continue;
      }
      try {
        const arrayBuf = await f.arrayBuffer();
        const doc = await PDFDocument.load(arrayBuf, { ignoreEncryption: true });
        newItems.push({
          id: Math.random().toString(36).substring(2, 9),
          file: f,
          name: f.name,
          size: f.size,
          pageCount: doc.getPageCount(),
        });
      } catch {
        newItems.push({
          id: Math.random().toString(36).substring(2, 9),
          file: f,
          name: f.name,
          size: f.size,
        });
      }
    }
    setMergeFiles((prev) => [...prev, ...newItems]);
    showToast(`Added ${newItems.length} PDF file(s)`, 'success');
  };

  const handleExecuteMerge = async () => {
    if (mergeFiles.length < 2) {
      showToast('Please add at least 2 PDF files to merge', 'error');
      return;
    }
    setIsMerging(true);
    try {
      const mergedPdf = await PDFDocument.create();

      for (const item of mergeFiles) {
        const bytes = await item.file.arrayBuffer();
        const doc = await PDFDocument.load(bytes);
        const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }

      const mergedBytes = await mergedPdf.save();
      const blob = new Blob([mergedBytes as any], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `merged_${Date.now()}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Merged PDFs successfully!', 'success');
    } catch (err: any) {
      console.error(err);
      showToast('Failed to merge PDFs. Please verify files are not password-protected.', 'error');
    } finally {
      setIsMerging(false);
    }
  };

  // 2. PDF SPLITTER HANDLERS
  const handleSplitFileAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
      showToast('Please select a valid PDF file', 'error');
      return;
    }

    try {
      const arrayBuf = await file.arrayBuffer();
      const doc = await PDFDocument.load(arrayBuf, { ignoreEncryption: true });
      const total = doc.getPageCount();
      setSplitFile({
        file,
        name: file.name,
        size: file.size,
        totalPages: total,
      });
      setSplitRange(`1-${Math.min(total, 2)}`);
      showToast(`Loaded PDF with ${total} pages`, 'success');
    } catch {
      showToast('Could not read PDF. It may be encrypted.', 'error');
    }
  };

  const handleExecuteSplit = async () => {
    if (!splitFile) return;
    setIsSplitting(true);

    try {
      const arrayBuf = await splitFile.file.arrayBuffer();
      const srcDoc = await PDFDocument.load(arrayBuf);
      const total = srcDoc.getPageCount();

      // Parse range: e.g. "1-3, 5"
      const pagesToExtract = new Set<number>();
      const parts = splitRange.split(',');
      for (const part of parts) {
        const trimmed = part.trim();
        if (trimmed.includes('-')) {
          const [startStr, endStr] = trimmed.split('-');
          const start = parseInt(startStr);
          const end = parseInt(endStr);
          if (!isNaN(start) && !isNaN(end)) {
            for (let i = Math.max(1, start); i <= Math.min(total, end); i++) {
              pagesToExtract.add(i - 1); // 0-indexed
            }
          }
        } else {
          const p = parseInt(trimmed);
          if (!isNaN(p) && p >= 1 && p <= total) {
            pagesToExtract.add(p - 1);
          }
        }
      }

      if (pagesToExtract.size === 0) {
        showToast('Invalid page range specified', 'error');
        setIsSplitting(false);
        return;
      }

      const outDoc = await PDFDocument.create();
      const indices = Array.from(pagesToExtract).sort((a, b) => a - b);
      const copiedPages = await outDoc.copyPages(srcDoc, indices);
      copiedPages.forEach((page) => outDoc.addPage(page));

      const outBytes = await outDoc.save();
      const blob = new Blob([outBytes as any], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `extracted_pages_${splitFile.name}`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Extracted ${indices.length} page(s) successfully!`, 'success');
    } catch (err) {
      console.error(err);
      showToast('Error splitting PDF', 'error');
    } finally {
      setIsSplitting(false);
    }
  };

  // 3. JPG / PNG TO PDF HANDLERS
  const handleImgFilesAdd = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const items = files
      .filter((f) => f.type.startsWith('image/'))
      .map((f) => ({
        id: Math.random().toString(36).substring(2, 9),
        file: f,
        name: f.name,
        size: f.size,
        preview: URL.createObjectURL(f),
      }));

    setImgFiles((prev) => [...prev, ...items]);
    showToast(`Added ${items.length} image(s)`, 'success');
  };

  const handleExecuteImgToPdf = async () => {
    if (imgFiles.length === 0) {
      showToast('Add at least one image', 'error');
      return;
    }
    setIsConvertingImg(true);

    try {
      const pdfDoc = await PDFDocument.create();

      for (const item of imgFiles) {
        const bytes = await item.file.arrayBuffer();
        let pdfImage;
        if (item.file.type === 'image/png') {
          pdfImage = await pdfDoc.embedPng(bytes);
        } else {
          pdfImage = await pdfDoc.embedJpg(bytes);
        }

        const page = pdfDoc.addPage([pdfImage.width, pdfImage.height]);
        page.drawImage(pdfImage, {
          x: 0,
          y: 0,
          width: pdfImage.width,
          height: pdfImage.height,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes as any], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `converted_images_${Date.now()}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Converted images to PDF!', 'success');
    } catch (err) {
      console.error(err);
      showToast('Error converting images to PDF. Try JPG or PNG files.', 'error');
    } finally {
      setIsConvertingImg(false);
    }
  };

  // 4. PDF COMPRESSOR HANDLER
  const handleCompressFileAdd = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
      showToast('Please select a PDF file', 'error');
      return;
    }
    setCompressFile({
      file,
      name: file.name,
      size: file.size,
    });
    setCompressedResult(null);
  };

  const handleExecuteCompress = async () => {
    if (!compressFile) return;
    setIsCompressing(true);

    try {
      const arrayBuf = await compressFile.file.arrayBuffer();
      // Load and re-save with stream compression enabled
      const doc = await PDFDocument.load(arrayBuf);
      const savedBytes = await doc.save({ useObjectStreams: true });
      const blob = new Blob([savedBytes as any], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setCompressedResult({
        url,
        size: blob.size,
      });
      showToast('PDF optimized and compressed!', 'success');
    } catch (err) {
      console.error(err);
      showToast('Failed to optimize PDF', 'error');
    } finally {
      setIsCompressing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. PDF MERGER */}
      {toolSlug === 'pdf-merger' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="relative rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 p-8 text-center hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept=".pdf,application/pdf"
              multiple
              onChange={handleMergeFilesAdd}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <div className="flex flex-col items-center pointer-events-none">
              <Files className="h-10 w-10 text-indigo-600 dark:text-indigo-400 mb-2" />
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                Click or drag & drop PDF files to combine
              </p>
              <p className="text-xs text-slate-500 mt-1">Select multiple files</p>
            </div>
          </div>

          {mergeFiles.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Documents to merge ({mergeFiles.length} files):</span>
                <button
                  onClick={() => setMergeFiles([])}
                  className="text-rose-500 hover:text-rose-600"
                >
                  Clear All
                </button>
              </div>

              <div className="space-y-2 max-h-80 overflow-y-auto">
                {mergeFiles.map((item, idx) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950 text-xs"
                  >
                    <div className="flex items-center gap-3 truncate">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-indigo-100 dark:bg-indigo-950 font-mono font-bold text-indigo-600 dark:text-indigo-400 text-[11px]">
                        {idx + 1}
                      </span>
                      <div className="truncate">
                        <span className="font-semibold text-slate-900 dark:text-white block truncate">
                          {item.name}
                        </span>
                        <span className="text-slate-500">
                          {formatFileSize(item.size)} {item.pageCount ? `· ${item.pageCount} pages` : ''}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      {idx > 0 && (
                        <button
                          onClick={() => {
                            const next = [...mergeFiles];
                            const temp = next[idx];
                            next[idx] = next[idx - 1];
                            next[idx - 1] = temp;
                            setMergeFiles(next);
                          }}
                          className="p-1 hover:text-indigo-600 text-slate-400"
                          title="Move Up"
                        >
                          <ArrowUp className="h-4 w-4" />
                        </button>
                      )}
                      {idx < mergeFiles.length - 1 && (
                        <button
                          onClick={() => {
                            const next = [...mergeFiles];
                            const temp = next[idx];
                            next[idx] = next[idx + 1];
                            next[idx + 1] = temp;
                            setMergeFiles(next);
                          }}
                          className="p-1 hover:text-indigo-600 text-slate-400"
                          title="Move Down"
                        >
                          <ArrowDown className="h-4 w-4" />
                        </button>
                      )}
                      <button
                        onClick={() => setMergeFiles(mergeFiles.filter((f) => f.id !== item.id))}
                        className="p-1 text-slate-400 hover:text-rose-500"
                        title="Remove"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <button
                disabled={isMerging}
                onClick={handleExecuteMerge}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs disabled:opacity-50"
              >
                <Files className="h-4 w-4" />
                <span>{isMerging ? 'Merging PDF Documents...' : `Merge ${mergeFiles.length} PDFs`}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* 2. PDF SPLITTER */}
      {toolSlug === 'pdf-splitter' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="relative rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 p-8 text-center hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept=".pdf,application/pdf"
              onChange={handleSplitFileAdd}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <div className="flex flex-col items-center pointer-events-none">
              <Scissors className="h-10 w-10 text-indigo-600 dark:text-indigo-400 mb-2" />
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                {splitFile ? splitFile.name : 'Select or drop a PDF to extract pages'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                {splitFile ? `${splitFile.totalPages} total pages · ${formatFileSize(splitFile.size)}` : 'Client-side page splitter'}
              </p>
            </div>
          </div>

          {splitFile && (
            <div className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Page Range to Extract (1 to {splitFile.totalPages})
                </label>
                <input
                  type="text"
                  value={splitRange}
                  onChange={(e) => setSplitRange(e.target.value)}
                  placeholder="e.g. 1-3, 5, 7-10"
                  className="w-full px-3.5 py-2.5 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Example: <code className="text-indigo-600 font-mono">1-3</code> extracts pages 1 through 3. <code className="text-indigo-600 font-mono">1, 4, 6</code> extracts individual pages.
                </p>
              </div>

              <button
                disabled={isSplitting}
                onClick={handleExecuteSplit}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                <span>{isSplitting ? 'Extracting Pages...' : 'Split & Download Pages'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. JPG / PNG TO PDF */}
      {toolSlug === 'jpg-to-pdf' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="relative rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 p-8 text-center hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept="image/jpeg,image/png"
              multiple
              onChange={handleImgFilesAdd}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <div className="flex flex-col items-center pointer-events-none">
              <FileImage className="h-10 w-10 text-indigo-600 dark:text-indigo-400 mb-2" />
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                Upload JPG or PNG photos to create PDF
              </p>
              <p className="text-xs text-slate-500 mt-1">Each image becomes a clean PDF page</p>
            </div>
          </div>

          {imgFiles.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Selected Images ({imgFiles.length}):</span>
                <button
                  onClick={() => setImgFiles([])}
                  className="text-rose-500 hover:text-rose-600"
                >
                  Clear
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-h-60 overflow-y-auto">
                {imgFiles.map((item, idx) => (
                  <div key={item.id} className="relative rounded-xl border border-slate-200 dark:border-slate-800 p-2 bg-slate-50 dark:bg-slate-950">
                    <img src={item.preview} alt={item.name} className="h-24 w-full object-cover rounded-lg" />
                    <span className="block text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate mt-1">
                      {idx + 1}. {item.name}
                    </span>
                    <button
                      onClick={() => setImgFiles(imgFiles.filter((f) => f.id !== item.id))}
                      className="absolute top-3 right-3 p-1 rounded-full bg-slate-900/70 text-white hover:bg-rose-600"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>

              <button
                disabled={isConvertingImg}
                onClick={handleExecuteImgToPdf}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs disabled:opacity-50"
              >
                <Download className="h-4 w-4" />
                <span>{isConvertingImg ? 'Generating PDF...' : `Convert ${imgFiles.length} Images to PDF`}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* 4. PDF COMPRESSOR */}
      {toolSlug === 'pdf-compressor' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="relative rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 p-8 text-center hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept=".pdf,application/pdf"
              onChange={handleCompressFileAdd}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <div className="flex flex-col items-center pointer-events-none">
              <FileArchive className="h-10 w-10 text-indigo-600 dark:text-indigo-400 mb-2" />
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                {compressFile ? compressFile.name : 'Select or drop a PDF to optimize & compress'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                {compressFile ? `Original size: ${formatFileSize(compressFile.size)}` : 'Client-side stream optimizer'}
              </p>
            </div>
          </div>

          {compressFile && (
            <div className="space-y-4">
              <button
                disabled={isCompressing}
                onClick={handleExecuteCompress}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs disabled:opacity-50"
              >
                <FileArchive className="h-4 w-4" />
                <span>{isCompressing ? 'Optimizing PDF Stream...' : 'Compress PDF'}</span>
              </button>

              {compressedResult && (
                <div className="p-5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider block">
                      Compression Complete
                    </span>
                    <div className="text-sm text-slate-700 dark:text-slate-300 mt-1">
                      Original: <strong className="font-mono">{formatFileSize(compressFile.size)}</strong> → Optimized: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{formatFileSize(compressedResult.size)}</strong>
                    </div>
                  </div>

                  <a
                    href={compressedResult.url}
                    download={`compressed_${compressFile.name}`}
                    className="flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    Download PDF
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 5. PDF TO JPG */}
      {toolSlug === 'pdf-to-jpg' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="relative rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 p-8 text-center hover:border-indigo-500 transition-colors">
            <input
              type="file"
              accept=".pdf,application/pdf"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
                  showToast('Please select a valid PDF file', 'error');
                  return;
                }
                try {
                  const arrayBuf = await file.arrayBuffer();
                  const doc = await PDFDocument.load(arrayBuf, { ignoreEncryption: true });
                  const total = doc.getPageCount();
                  setPdfToJpgFile({ file, name: file.name, size: file.size, totalPages: total });
                  setSelectedPageNum(1);
                  setRenderedJpgResult(null);
                  showToast(`Loaded PDF with ${total} pages`, 'success');
                } catch {
                  showToast('Could not load PDF document', 'error');
                }
              }}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <div className="flex flex-col items-center pointer-events-none">
              <FileImage className="h-10 w-10 text-indigo-600 dark:text-indigo-400 mb-2" />
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                {pdfToJpgFile ? pdfToJpgFile.name : 'Select or drop a PDF to convert pages to JPG'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                {pdfToJpgFile ? `${pdfToJpgFile.totalPages} total pages · ${formatFileSize(pdfToJpgFile.size)}` : 'Client-side high-DPI rasterizer'}
              </p>
            </div>
          </div>

          {pdfToJpgFile && (
            <div className="space-y-4 pt-2">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Select Page to Convert (1 to {pdfToJpgFile.totalPages})
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      max={pdfToJpgFile.totalPages}
                      value={selectedPageNum}
                      onChange={(e) => setSelectedPageNum(Math.max(1, Math.min(pdfToJpgFile.totalPages, parseInt(e.target.value) || 1)))}
                      className="w-24 px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                    <span className="text-xs text-slate-500">of {pdfToJpgFile.totalPages} pages</span>
                  </div>
                </div>

                <button
                  disabled={isConvertingPdfToJpg}
                  onClick={async () => {
                    if (!pdfToJpgFile) return;
                    setIsConvertingPdfToJpg(true);
                    try {
                      const pdfjs = await import('pdfjs-dist');
                      if (!pdfjs.GlobalWorkerOptions.workerSrc) {
                        pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;
                      }
                      const arrayBuf = await pdfToJpgFile.file.arrayBuffer();
                      const loadingTask = pdfjs.getDocument({ data: arrayBuf });
                      const pdfDoc = await loadingTask.promise;
                      const page = await pdfDoc.getPage(selectedPageNum);
                      const viewport = page.getViewport({ scale: 2.0 });

                      const canvas = document.createElement('canvas');
                      canvas.width = viewport.width;
                      canvas.height = viewport.height;
                      const ctx = canvas.getContext('2d');
                      if (!ctx) throw new Error('Canvas context not available');

                      ctx.fillStyle = '#FFFFFF';
                      ctx.fillRect(0, 0, canvas.width, canvas.height);

                      await page.render({ canvasContext: ctx, viewport } as any).promise;

                      canvas.toBlob((blob) => {
                        if (blob) {
                          const url = URL.createObjectURL(blob);
                          setRenderedJpgResult(url);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `page_${selectedPageNum}_${pdfToJpgFile.name.replace(/\.pdf$/i, '')}.jpg`;
                          a.click();
                          showToast(`Downloaded Page ${selectedPageNum} as JPG!`, 'success');
                        }
                        setIsConvertingPdfToJpg(false);
                      }, 'image/jpeg', 0.95);
                    } catch (err) {
                      console.error(err);
                      showToast('Error rendering PDF page', 'error');
                      setIsConvertingPdfToJpg(false);
                    }
                  }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs sm:text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-xs disabled:opacity-50"
                >
                  <Download className="h-4 w-4" />
                  <span>{isConvertingPdfToJpg ? 'Rendering Page...' : `Render & Download Page ${selectedPageNum} JPG`}</span>
                </button>
              </div>

              {renderedJpgResult && (
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col items-center">
                  <span className="text-xs font-semibold text-slate-500 mb-2">Rendered JPG Preview</span>
                  <img src={renderedJpgResult} alt="Rendered page" className="max-h-80 rounded-lg shadow-sm border border-slate-200 dark:border-slate-800" />
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
