import React, { useState, useEffect, useRef, useCallback, useTransition, useMemo } from 'react';
import {
  Menu,
  Plus,
  ArrowDown,
  Zap,
  ChevronUp,
} from 'lucide-react';
import { ChatMessage, ToolContext } from '../types/ai';
import {
  checkAIStatus,
  streamAIChat,
  loadConversationsMeta,
  saveConversationsMeta,
  loadConversationMessages,
  saveConversationMessages,
  deleteConversationData,
  clearAllConversationsData,
  getActiveConversationId,
  setActiveConversationId,
  createNewConversationMeta,
  generateTitleFromPrompt,
  ConversationMeta,
  StreamStats,
} from '../services/aiService';
import { ChatInput } from '../components/ai/ChatInput';
import { WelcomeScreen } from '../components/ai/WelcomeScreen';
import { ChatHistorySidebar } from '../components/ai/ChatHistorySidebar';
import { ChatMessageItem } from '../components/ai/ChatMessageItem';
import { PerformanceDebugModal } from '../components/ai/PerformanceDebugModal';

const DEFAULT_PAGE_SIZE = 25;

interface AiAssistantPageProps {
  navigate: (path: string) => void;
  initialToolContext?: ToolContext;
}

export const AiAssistantPage: React.FC<AiAssistantPageProps> = ({
  navigate,
  initialToolContext,
}) => {
  // 1. Instant Startup: Load lightweight metadata first (O(1))
  const [conversationsMeta, setConversationsMeta] = useState<ConversationMeta[]>(() =>
    loadConversationsMeta()
  );
  const [activeConvId, setActiveConvId] = useState<string | null>(() => getActiveConversationId());

  // 2. Lazy-loaded active conversation messages
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const id = getActiveConversationId();
    return id ? loadConversationMessages(id) : [];
  });

  // 3. Memory Optimization: Windowed message rendering for long conversations
  const [visibleCount, setVisibleCount] = useState<number>(DEFAULT_PAGE_SIZE);

  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userScrolledUp, setUserScrolledUp] = useState(false);
  const [perfStats, setPerfStats] = useState<StreamStats | null>(null);
  const [showDebugModal, setShowDebugModal] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [, startTransition] = useTransition();

  // Instant SEO meta
  useEffect(() => {
    document.title = 'Free AI Assistant – Ask Questions & Get Help | Free Tools Hub';
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute(
        'content',
        'Use the Free Tools Hub AI Assistant to ask questions, write, learn, code, summarize and get everyday help.'
      );
    }
  }, []);

  // Background non-blocking health check
  useEffect(() => {
    checkAIStatus();
  }, []);

  // Save metadata changes
  useEffect(() => {
    saveConversationsMeta(conversationsMeta);
  }, [conversationsMeta]);

  // Save active conversation messages
  useEffect(() => {
    if (activeConvId) {
      saveConversationMessages(activeConvId, messages);
    }
  }, [activeConvId, messages]);

  // Sync active conversation ID
  useEffect(() => {
    setActiveConversationId(activeConvId);
  }, [activeConvId]);

  // Keyboard shortcut: Ctrl/Cmd + Shift + O for new chat, Ctrl + Shift + D for performance debug
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        handleNewChat();
      }
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        setShowDebugModal((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [initialToolContext]);

  // Auto-scroll handler: only scroll if user is near bottom
  const scrollToBottom = useCallback((smooth = true) => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth ? 'smooth' : 'auto',
    });
    setUserScrolledUp(false);
  }, []);

  const handleScroll = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceToBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setUserScrolledUp(distanceToBottom > 140);
  }, []);

  // Scroll down during streaming only when user is near bottom
  useEffect(() => {
    if (!userScrolledUp) {
      scrollToBottom(false);
    }
  }, [messages, userScrolledUp, scrollToBottom]);

  // 1. New Chat (Instant UI transition)
  const handleNewChat = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    const newMeta = createNewConversationMeta(initialToolContext);
    setConversationsMeta((prev) => [newMeta, ...prev]);
    setActiveConvId(newMeta.id);
    setMessages([]);
    setVisibleCount(DEFAULT_PAGE_SIZE);
    setUserScrolledUp(false);
    setPerfStats(null);
  }, [initialToolContext]);

  // 2. Select Conversation (Lazy-loaded, fast memory switch)
  const handleSelectConversation = useCallback((id: string) => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setActiveConvId(id);
    startTransition(() => {
      const loaded = loadConversationMessages(id);
      setMessages(loaded);
      setVisibleCount(DEFAULT_PAGE_SIZE);
      setUserScrolledUp(false);
    });
  }, []);

  // 3. Delete Conversation
  const handleDeleteConversation = useCallback((id: string) => {
    deleteConversationData(id);
    setConversationsMeta((prev) => prev.filter((c) => c.id !== id));
    if (activeConvId === id) {
      const remaining = conversationsMeta.filter((c) => c.id !== id);
      if (remaining.length > 0) {
        handleSelectConversation(remaining[0].id);
      } else {
        setActiveConvId(null);
        setMessages([]);
      }
    }
  }, [activeConvId, conversationsMeta, handleSelectConversation]);

  // 4. Rename Conversation
  const handleRenameConversation = useCallback((id: string, newTitle: string) => {
    setConversationsMeta((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  }, []);

  // 5. Clear All Conversations
  const handleClearAllConversations = useCallback(() => {
    clearAllConversationsData(conversationsMeta);
    setConversationsMeta([]);
    setActiveConvId(null);
    setMessages([]);
  }, [conversationsMeta]);

  // Copy Message Helper
  const handleCopyMessage = useCallback((id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 2000);
  }, []);

  // Stop Generation (Immediate cancellation)
  const handleStopGenerating = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
  }, []);

  // Send Message with Optimistic UI & Batched Streaming
  const handleSendMessage = useCallback(async (promptText: string) => {
    const cleanPrompt = promptText.trim();
    if (!cleanPrompt || isStreaming) return;

    // Abort any lingering connection first
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // 1. Ensure Active Conversation exists
    let currId = activeConvId;
    if (!currId) {
      const newMeta = createNewConversationMeta(initialToolContext);
      setConversationsMeta((prev) => [newMeta, ...prev]);
      setActiveConvId(newMeta.id);
      currId = newMeta.id;
    }

    // 2. OPTIMISTIC UI: Display User Message immediately without delay
    const userMsg: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: cleanPrompt,
      timestamp: Date.now(),
    };

    const assistantPlaceholderId = `msg_a_${Date.now()}`;
    const assistantMsg: ChatMessage = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    // Update conversation title if first message
    const isFirst = messages.length === 0;
    if (isFirst) {
      const title = generateTitleFromPrompt(cleanPrompt);
      setConversationsMeta((prev) =>
        prev.map((c) => (c.id === currId ? { ...c, title, updatedAt: Date.now() } : c))
      );
    }

    // Update state immediately
    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setIsStreaming(true);
    setUserScrolledUp(false);
    scrollToBottom(false);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Send only recent bounded context for minimal network payload
      const historyContext = [...messages, userMsg].slice(-12).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      await streamAIChat({
        messages: historyContext,
        toolContext: initialToolContext,
        signal: controller.signal,
        onBatchedText: (batchedContent) => {
          // BATCHED UI UPDATE: Only updates the single generating assistant message
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantPlaceholderId
                ? { ...m, content: batchedContent, isStreaming: true }
                : m
            )
          );
        },
        onStats: (stats) => {
          setPerfStats(stats);
        },
      });

      // Stream Finished: Switch from raw text to rich final Markdown render
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantPlaceholderId ? { ...m, isStreaming: false } : m
        )
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User clicked Stop
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantPlaceholderId ? { ...m, isStreaming: false } : m
          )
        );
      } else {
        const errorText = err?.message || 'Something went wrong. Please try again.';
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantPlaceholderId
              ? { ...m, content: errorText, error: true, isStreaming: false }
              : m
          )
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  }, [isStreaming, activeConvId, initialToolContext, messages, scrollToBottom]);

  // Regenerate last response
  const handleRegenerate = useCallback(async () => {
    if (isStreaming || messages.length < 2) return;
    const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user');
    if (!lastUserMsg) return;

    // Remove the last assistant message
    setMessages((prev) => prev.slice(0, prev.length - 1));
    handleSendMessage(lastUserMsg.content);
  }, [isStreaming, messages, handleSendMessage]);

  // Windowed Visible Messages (Memory optimization for long chats)
  const visibleMessages = useMemo(() => {
    if (messages.length <= visibleCount) return messages;
    return messages.slice(-visibleCount);
  }, [messages, visibleCount]);

  const hiddenCount = messages.length - visibleMessages.length;

  return (
    <div className="flex h-full w-full overflow-hidden bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* 1. Left Sidebar: 260px fixed width, lazy loaded metadata */}
      <ChatHistorySidebar
        conversations={conversationsMeta}
        activeId={activeConvId}
        onSelect={handleSelectConversation}
        onNewChat={handleNewChat}
        onDelete={handleDeleteConversation}
        onRename={handleRenameConversation}
        onClearAll={handleClearAllConversations}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* 2. Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full relative">
        {/* Minimal Header */}
        <header className="h-12 border-b border-slate-200/70 dark:border-slate-800/80 px-4 flex items-center justify-between gap-3 shrink-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm z-10">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              title="Open chats sidebar"
            >
              <Menu className="h-4.5 w-4.5" />
            </button>

            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              Free Tools Hub AI
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Dev Performance Badge (Click to open debug panel) */}
            {import.meta.env.DEV && perfStats && (
              <button
                type="button"
                onClick={() => setShowDebugModal(true)}
                className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-[10px] font-mono text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors cursor-pointer"
                title="View Performance Telemetry"
              >
                <Zap className="h-3 w-3 text-emerald-600" />
                <span>
                  TTFT: {perfStats.ttftMs ?? 0}ms · Total: {((perfStats.totalMs || 0) / 1000).toFixed(2)}s
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={handleNewChat}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
              title="Start a new chat (Ctrl+Shift+O)"
            >
              <Plus className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">New Chat</span>
            </button>
          </div>
        </header>

        {/* 3. Messages Stream Container */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 scrollbar-thin relative"
        >
          {messages.length === 0 ? (
            <WelcomeScreen
              onSelectPrompt={(p) => handleSendMessage(p)}
              toolContext={initialToolContext}
            />
          ) : (
            <div className="max-w-3xl mx-auto space-y-6 sm:space-y-8 w-full">
              {/* Pagination control for large conversations */}
              {hiddenCount > 0 && (
                <div className="flex justify-center pt-2 pb-1">
                  <button
                    type="button"
                    onClick={() => setVisibleCount((prev) => prev + DEFAULT_PAGE_SIZE)}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-medium transition-colors cursor-pointer"
                  >
                    <ChevronUp className="h-3.5 w-3.5" />
                    <span>Load earlier messages ({hiddenCount} more)</span>
                  </button>
                </div>
              )}

              {visibleMessages.map((msg, idx) => (
                <ChatMessageItem
                  key={msg.id}
                  message={msg}
                  isLast={idx === visibleMessages.length - 1}
                  onCopy={handleCopyMessage}
                  onRegenerate={handleRegenerate}
                  isCopied={copiedMessageId === msg.id}
                  navigate={navigate}
                />
              ))}
            </div>
          )}

          {/* Floating '↓ New response' button when user has scrolled up */}
          {userScrolledUp && isStreaming && (
            <div className="sticky bottom-4 flex justify-center z-20 pointer-events-none">
              <button
                type="button"
                onClick={() => scrollToBottom(true)}
                className="pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-md text-xs font-medium hover:scale-105 active:scale-95 transition-all cursor-pointer animate-in fade-in"
              >
                <ArrowDown className="h-3.5 w-3.5" />
                <span>New response</span>
              </button>
            </div>
          )}
        </div>

        {/* 4. Bottom Centered Input Area (Uncoupled typing state) */}
        <div className="p-3 sm:p-4 bg-gradient-to-t from-white via-white dark:from-slate-950 dark:via-slate-950 to-transparent shrink-0">
          <div className="max-w-3xl mx-auto w-full">
            <ChatInput
              onSend={handleSendMessage}
              isStreaming={isStreaming}
              onStop={handleStopGenerating}
              placeholder="Ask anything..."
            />
          </div>
        </div>
      </div>

      {/* Dev Mode Performance Telemetry Modal */}
      {import.meta.env.DEV && (
        <PerformanceDebugModal
          stats={perfStats}
          messageCount={messages.length}
          isOpen={showDebugModal}
          onClose={() => setShowDebugModal(false)}
        />
      )}
    </div>
  );
};
