import React, { useState } from 'react';
import { TOOLS_DATA, CATEGORIES } from '../data/toolsData';
import { ToolCard } from '../components/tools/ToolCard';
import { ToolAppIcon } from '../components/common/ToolAppIcon';
import { useTools } from '../context/ToolsContext';
import {
  Search,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Lock,
  ChevronDown,
  ChevronUp,
  History,
  Trash2,
  Bot,
} from 'lucide-react';

interface HomePageProps {
  navigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ navigate }) => {
  const { recentTools, clearRecentTools, openSearch } = useTools();
  const [heroSearch, setHeroSearch] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Popular tools (12 tools)
  const popularTools = TOOLS_DATA.filter((t) => t.popular).slice(0, 12);

  // Recently used tools items
  const recentToolItems = TOOLS_DATA.filter((t) => recentTools.includes(t.id));

  // Quick live filtered tools for hero search
  const searchResults = heroSearch.trim()
    ? TOOLS_DATA.filter(
        (t) =>
          t.name.toLowerCase().includes(heroSearch.toLowerCase()) ||
          t.keywords.some((k) => k.toLowerCase().includes(heroSearch.toLowerCase()))
      ).slice(0, 5)
    : [];

  const handleHeroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchResults.length > 0) {
      navigate(`/tools/${searchResults[0].slug}`);
    } else {
      openSearch();
    }
  };

  const faqs = [
    {
      q: 'Are all tools on Free Tools Hub completely free?',
      a: 'Yes, 100% of our core tools are free with no hidden fees, paywalls, or feature locking. You can compress PDFs, resize images, generate passwords, and run calculations without any payment.',
    },
    {
      q: 'Do I need to sign up or create an account?',
      a: 'No account, email, or login is required. You can start using any tool immediately the moment you open the website.',
    },
    {
      q: 'Are my files and documents uploaded to remote servers?',
      a: 'No. Free Tools Hub utilizes modern WebAssembly, Web Cryptography, and HTML5 Canvas APIs to process your files, PDFs, images, and text directly inside your web browser. Your private files never leave your computer.',
    },
    {
      q: 'Can I use Free Tools Hub on mobile phones and tablets?',
      a: 'Yes. Every tool interface is fully responsive, optimized for touchscreens, and tested across modern iOS Safari, Android Chrome, and desktop browsers.',
    },
    {
      q: 'Can I use these tools for school, work, or commercial projects?',
      a: 'Absolutely. You are welcome to use all generated QR codes, resized images, merged documents, and formatted code for both personal and commercial assignments.',
    },
  ];

  return (
    <div className="space-y-20 pb-16">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-12 sm:pt-16 pb-12 sm:pb-20 border-b border-slate-200/70 dark:border-slate-800/80 bg-gradient-to-b from-indigo-50/40 via-white to-transparent dark:from-slate-900/40 dark:via-slate-950 dark:to-slate-950">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6 lg:px-8">
          
          {/* Subtle quiet badge conforming to zero-pill discipline */}
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 mb-4 tracking-wide uppercase">
            <Sparkles className="h-3.5 w-3.5" />
            <span>100% Free Online Tools · No Signup Required</span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-tight sm:leading-none">
            Powerful Tools for Everyday Tasks
          </h1>

          {/* Subheading */}
          <p className="mt-4 sm:mt-5 text-base sm:text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Convert, compress, calculate, generate and edit files online — quickly, securely and completely free in your browser.
          </p>

          {/* Hero Search Bar */}
          <div className="relative mt-8 max-w-2xl mx-auto text-left">
            <form onSubmit={handleHeroSubmit} className="relative flex items-center">
              <div className="relative w-full">
                <Search className="absolute left-4 top-3.5 sm:top-4 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  value={heroSearch}
                  onChange={(e) => setHeroSearch(e.target.value)}
                  placeholder="Search for a tool (e.g. PDF Compressor, QR Generator, Word Counter)..."
                  className="w-full rounded-2xl border border-slate-300/80 bg-white py-3.5 sm:py-4 pl-12 pr-28 text-sm sm:text-base text-slate-900 placeholder-slate-400 shadow-lg shadow-indigo-500/5 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                />
              </div>
              <button
                type="submit"
                className="absolute right-2 sm:right-2.5 rounded-xl bg-indigo-600 px-4 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-white shadow-xs hover:bg-indigo-700 transition-colors"
              >
                Search
              </button>
            </form>

            {/* Quick Hero Results Dropdown */}
            {heroSearch.trim() && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 z-30 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-800 dark:bg-slate-900 animate-in fade-in duration-100">
                {searchResults.map((tool) => (
                  <button
                    key={tool.id}
                    onClick={() => navigate(`/tools/${tool.slug}`)}
                    className="flex w-full items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-left transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <ToolAppIcon
                        slug={tool.slug}
                        category={tool.category}
                        size="sm"
                        alt={tool.name}
                        interactive={false}
                      />
                      <div>
                        <div className="text-sm font-semibold text-slate-900 dark:text-white">
                          {tool.name}
                        </div>
                        <div className="text-xs text-slate-400 truncate max-w-sm">
                          {tool.shortDescription}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </button>
                ))}
              </div>
            )}

            {/* Popular search quick suggestions */}
            <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-medium text-slate-600 dark:text-slate-300">Popular:</span>
              {[
                { label: 'PDF Compressor', slug: 'pdf-compressor' },
                { label: 'QR Generator', slug: 'qr-code-generator' },
                { label: 'Image Compressor', slug: 'image-compressor' },
                { label: 'Word Counter', slug: 'word-counter' },
                { label: 'Percentage Calculator', slug: 'percentage-calculator' },
                { label: 'Password Generator', slug: 'password-generator' },
              ].map((item) => (
                <button
                  key={item.slug}
                  onClick={() => navigate(`/tools/${item.slug}`)}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 underline decoration-slate-300 dark:decoration-slate-700 underline-offset-2 transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => navigate('/tools')}
              className="flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white shadow-xs hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 transition-all hover:scale-102"
            >
              <span>Explore All Tools</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={() => {
                const el = document.getElementById('popular-tools-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-xs hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              Popular Tools
            </button>
          </div>

          {/* AI Assistant Featured Hero Card */}
          <div className="mt-10 max-w-3xl mx-auto rounded-3xl p-5 sm:p-6 border border-indigo-200/90 dark:border-indigo-900/80 bg-gradient-to-r from-indigo-50/90 via-purple-50/70 to-pink-50/40 dark:from-indigo-950/40 dark:via-purple-950/30 dark:to-slate-900 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-5 text-left">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/20 shrink-0">
                <Bot className="h-6 w-6 sm:h-7 sm:w-7" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <span>🤖 AI Assistant</span>
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-600 text-white shadow-2xs">
                    New
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  Ask questions, explain concepts, write, summarize and get help.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => navigate('/ai-assistant')}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-indigo-600 text-white font-bold text-xs sm:text-sm shadow-md hover:bg-indigo-700 hover:shadow-lg transition-all shrink-0 cursor-pointer"
            >
              <span>Open AI Assistant</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          {/* Value Props Row */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-200/80 dark:border-slate-800/80 pt-8 text-left">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 dark:text-white">100% In-Browser Privacy</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Files and documents are processed locally on your device.</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 dark:text-white">Lightning Fast</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Zero network lag or server queues for immediate exports.</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-600 dark:bg-violet-950/60 dark:text-violet-400">
                <Lock className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 dark:text-white">No Signup or Limits</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Unlimited usage without credit cards, subscriptions, or emails.</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 2. RECENTLY USED SECTION (IF ANY) */}
      {recentToolItems.length > 0 && (
        <section id="recently-used-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 scroll-mt-24">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <History className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
              <span>Recently Used Tools</span>
            </div>
            <button
              onClick={clearRecentTools}
              className="flex items-center gap-1 text-xs text-slate-400 hover:text-rose-500 transition-colors"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Clear History</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
            {recentToolItems.map((tool) => (
              <button
                key={tool.id}
                onClick={() => navigate(`/tools/${tool.slug}`)}
                className="flex items-center gap-2.5 p-3 rounded-xl border border-slate-200 bg-white text-left hover:border-indigo-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500/50 transition-all shadow-2xs group"
              >
                <ToolAppIcon
                  slug={tool.slug}
                  category={tool.category}
                  size="sm"
                  alt={tool.name}
                  interactive={false}
                />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 truncate">
                  {tool.name}
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* 3. TOOL CATEGORIES GRID */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            Explore by Category
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Find the exact utility you need organized across our specialized productivity suites.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => {
            const count = TOOLS_DATA.filter((t) => t.category === cat.id).length;
            return (
              <div
                key={cat.id}
                onClick={() => navigate(`/${cat.slug}`)}
                className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs hover:-translate-y-1 hover:border-indigo-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 dark:hover:border-indigo-500/50 transition-all cursor-pointer"
              >
                <div>
                  <div className="mb-4">
                    <ToolAppIcon
                      category={cat.id}
                      size="lg"
                      alt={cat.name}
                      interactive={true}
                    />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-indigo-600 dark:text-white dark:group-hover:text-indigo-400 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                  <span>{count} free tools</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. POPULAR TOOLS SECTION */}
      <section id="popular-tools-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 scroll-mt-20">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Popular Tools
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              The most frequented tools for PDF, images, text and math calculations.
            </p>
          </div>
          <button
            onClick={() => navigate('/tools')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 transition-colors self-start sm:self-auto"
          >
            <span>View All Tools</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {popularTools.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              onSelect={(slug) => navigate(`/tools/${slug}`)}
            />
          ))}
        </div>
      </section>

      {/* 5. HOMEPAGE SEO INFORMATIONAL CONTENT */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-slate-200/90 bg-white p-8 sm:p-12 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="max-w-3xl">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              Free Online Tools for Everyone
            </h2>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Free Tools Hub is an all-in-one suite of browser-based utilities designed to solve everyday digital tasks without hurdles, subscriptions, or watermarks. Whether you need to compress a PDF document before sending an email, generate a secure random password for a new account, format and validate JSON for a developer project, or convert photo formats, everything executes client-side directly on your hardware.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                Privacy-First Architecture
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Your data is never transmitted to third-party databases. PDF merging, image transformations, and password entropy calculations happen purely within local JavaScript memory.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                Zero Friction Workflow
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Skip registration forms and email confirmations. Launch any tool in one click, perform your operation, and download results instantly.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5">
                Modern Responsive Engine
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Engineered for desktop power users and mobile touch devices alike, featuring full dark mode support and keyboard command navigation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. FAQ SECTION */}
      <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Everything you need to know about Free Tools Hub and how our browser tools work.
          </p>
        </div>

        <div className="divide-y divide-slate-200/80 rounded-2xl border border-slate-200/90 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div key={idx} className="p-5 sm:p-6">
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="flex w-full items-center justify-between text-left gap-4"
                >
                  <span className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white">
                    {faq.q}
                  </span>
                  {isOpen ? (
                    <ChevronUp className="h-5 w-5 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-slate-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <p className="mt-3 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed pr-8">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
