import React, { useState, useEffect, useRef } from 'react';
import { useTools } from '../../context/ToolsContext';
import { TOOLS_DATA } from '../../data/toolsData';
import { ToolItem } from '../../types';
import { ToolAppIcon } from '../common/ToolAppIcon';
import { Search, X, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  onSelectTool: (slug: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ onSelectTool }) => {
  const { isSearchOpen, closeSearch } = useTools();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const filteredTools = TOOLS_DATA.filter((tool) => {
    const matchesCategory = selectedCategory === 'all' || tool.category === selectedCategory;
    if (!matchesCategory) return false;

    if (!query.trim()) return true;

    const q = query.toLowerCase().trim();
    const inName = tool.name.toLowerCase().includes(q);
    const inDesc = tool.shortDescription.toLowerCase().includes(q) || tool.description.toLowerCase().includes(q);
    const inKeywords = tool.keywords.some((kw) => kw.toLowerCase().includes(q));

    return inName || inDesc || inKeywords;
  });

  const handleSelect = (slug: string) => {
    closeSearch();
    onSelectTool(slug);
  };

  const highlightMatch = (text: string, term: string) => {
    if (!term.trim()) return text;
    const parts = text.split(new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return (
      <>
        {parts.map((part, i) =>
          part.toLowerCase() === term.toLowerCase() ? (
            <mark key={i} className="bg-indigo-100 text-indigo-900 dark:bg-indigo-950 dark:text-indigo-200 font-semibold px-0.5 rounded">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:p-6 md:p-20 overflow-y-auto bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      {/* Backdrop click to close */}
      <div className="fixed inset-0" onClick={closeSearch} aria-hidden="true" />

      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 overflow-hidden z-10 animate-in zoom-in-95 duration-150">
        
        {/* Search Input Bar */}
        <div className="flex items-center border-b border-slate-200 px-4 dark:border-slate-800">
          <Search className="h-5 w-5 text-slate-400 shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for a tool (e.g. PDF Compressor, QR Generator, Image Resizer)..."
            className="h-14 w-full bg-transparent text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none dark:text-white"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
              title="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <button
            onClick={closeSearch}
            className="ml-2 text-xs font-medium text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 px-2 py-1 rounded border border-slate-200 dark:border-slate-800"
          >
            ESC
          </button>
        </div>

        {/* Category Filter Pills (Functional Buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto px-4 py-2.5 border-b border-slate-100 bg-slate-50/70 dark:border-slate-800/80 dark:bg-slate-950/40 text-xs">
          {[
            { id: 'all', label: 'All' },
            { id: 'video', label: 'Video' },
            { id: 'audio', label: 'Audio' },
            { id: 'pdf', label: 'PDF' },
            { id: 'image', label: 'Images' },
            { id: 'text', label: 'Text' },
            { id: 'calculator', label: 'Calculators' },
            { id: 'developer', label: 'Developer' },
            { id: 'student', label: 'Students' },
            { id: 'security', label: 'Security' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-slate-100 dark:divide-slate-800/60">
          {filteredTools.length > 0 ? (
            filteredTools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => handleSelect(tool.slug)}
                className="group flex w-full items-center justify-between gap-4 p-3 rounded-xl text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <ToolAppIcon
                    slug={tool.slug}
                    category={tool.category}
                    size="md"
                    alt={tool.name}
                    interactive={false}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-slate-900 group-hover:text-indigo-600 dark:text-white dark:group-hover:text-indigo-400 truncate">
                        {highlightMatch(tool.name, query)}
                      </span>
                      <span className="text-[11px] font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wider shrink-0">
                        {tool.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {highlightMatch(tool.shortDescription, query)}
                    </p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>
            ))
          ) : (
            <div className="py-12 text-center">
              <Search className="h-8 w-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-900 dark:text-white">No tools found</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                No matching tools for &ldquo;{query}&rdquo;. Try another keyword or browse all categories.
              </p>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 dark:bg-slate-950/60 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>{filteredTools.length} tools available</span>
          <span>Press Enter to select · Esc to close</span>
        </div>
      </div>
    </div>
  );
};
