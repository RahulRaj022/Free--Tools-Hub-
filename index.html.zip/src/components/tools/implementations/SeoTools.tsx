import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, Download, Check, Globe, Eye, FileCode, Search, RefreshCw } from 'lucide-react';

interface SeoToolsProps {
  toolSlug: string;
}

export const SeoTools: React.FC<SeoToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // --- Meta Tag Generator State ---
  const [metaTitle, setMetaTitle] = useState<string>('Free Tools Hub – 100% Free Online Toolkit');
  const [metaDesc, setMetaDesc] = useState<string>('Powerful browser-based tools for PDF, images, text, calculators, developers, and everyday tasks. No sign up required.');
  const [metaKeywords, setMetaKeywords] = useState<string>('free online tools, pdf tools, image compressor, calculators, developer utilities');
  const [metaAuthor, setMetaAuthor] = useState<string>('Free Tools Hub');
  const [metaUrl, setMetaUrl] = useState<string>('https://freetoolshub.com');
  const [metaOgImage, setMetaOgImage] = useState<string>('https://freetoolshub.com/og-image.png');
  const [metaTwitterHandle, setMetaTwitterHandle] = useState<string>('@freetoolshub');
  const [metaRobots, setMetaRobots] = useState<string>('index, follow');

  const generatedMetaHtml = useMemo(() => {
    return `<!-- Primary Meta Tags -->
<title>${metaTitle}</title>
<meta name="title" content="${metaTitle}">
<meta name="description" content="${metaDesc}">
<meta name="keywords" content="${metaKeywords}">
<meta name="author" content="${metaAuthor}">
<meta name="robots" content="${metaRobots}">
<link rel="canonical" href="${metaUrl}">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="${metaUrl}">
<meta property="og:title" content="${metaTitle}">
<meta property="og:description" content="${metaDesc}">
<meta property="og:image" content="${metaOgImage}">

<!-- Twitter / X -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="${metaUrl}">
<meta property="twitter:title" content="${metaTitle}">
<meta property="twitter:description" content="${metaDesc}">
<meta property="twitter:image" content="${metaOgImage}">
<meta property="twitter:site" content="${metaTwitterHandle}">`;
  }, [metaTitle, metaDesc, metaKeywords, metaAuthor, metaUrl, metaOgImage, metaTwitterHandle, metaRobots]);

  // --- Robots.txt State ---
  const [robotsAgent, setRobotsAgent] = useState<string>('*');
  const [robotsAllow, setRobotsAllow] = useState<string>('/');
  const [robotsDisallow, setRobotsDisallow] = useState<string>('/admin/\n/api/\n/private/');
  const [robotsSitemap, setRobotsSitemap] = useState<string>('https://freetoolshub.com/sitemap.xml');
  const [robotsCrawlDelay, setRobotsCrawlDelay] = useState<string>('');

  const generatedRobotsTxt = useMemo(() => {
    const disallowRules = robotsDisallow
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((p) => `Disallow: ${p}`)
      .join('\n');
    return `User-agent: ${robotsAgent}\n${robotsAllow ? `Allow: ${robotsAllow}\n` : ''}${disallowRules}\n${
      robotsCrawlDelay ? `Crawl-delay: ${robotsCrawlDelay}\n` : ''
    }\nSitemap: ${robotsSitemap}`;
  }, [robotsAgent, robotsAllow, robotsDisallow, robotsSitemap, robotsCrawlDelay]);

  // --- XML Sitemap State ---
  const [sitemapUrls, setSitemapUrls] = useState<string>(
    `https://freetoolshub.com\nhttps://freetoolshub.com/tools\nhttps://freetoolshub.com/pdf-tools\nhttps://freetoolshub.com/image-tools\nhttps://freetoolshub.com/calculators`
  );
  const [sitemapFreq, setSitemapFreq] = useState<string>('weekly');
  const [sitemapPriority, setSitemapPriority] = useState<string>('0.8');

  const generatedSitemapXml = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const urls = sitemapUrls
      .split('\n')
      .map((u) => u.trim())
      .filter(Boolean);
    const entries = urls
      .map(
        (url) => `  <url>
    <loc>${url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${sitemapFreq}</changefreq>
    <priority>${sitemapPriority}</priority>
  </url>`
      )
      .join('\n');
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries}\n</urlset>`;
  }, [sitemapUrls, sitemapFreq, sitemapPriority]);

  // --- Keyword Density State ---
  const [keywordText, setKeywordText] = useState<string>(
    `Free Tools Hub provides fast online utilities. The online tools operate inside your browser. No sign up is needed to use our tools. Every tool is private and responsive. Fast online tools make everyday tasks seamless.`
  );

  const keywordStats = useMemo(() => {
    const words = keywordText
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .split(/\s+/)
      .filter((w) => w.length > 2);
    const totalWords = words.length;
    if (totalWords === 0) return { totalWords: 0, singleWords: [], twoWords: [] };

    // 1-word frequency
    const freq: Record<string, number> = {};
    words.forEach((w) => (freq[w] = (freq[w] || 0) + 1));
    const singleWords = Object.entries(freq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([word, count]) => ({
        word,
        count,
        density: ((count / totalWords) * 100).toFixed(1),
      }));

    // 2-word frequency
    const biFreq: Record<string, number> = {};
    for (let i = 0; i < words.length - 1; i++) {
      const phrase = `${words[i]} ${words[i + 1]}`;
      biFreq[phrase] = (biFreq[phrase] || 0) + 1;
    }
    const twoWords = Object.entries(biFreq)
      .filter(([_, count]) => count > 1)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([phrase, count]) => ({
        phrase,
        count,
        density: ((count / (totalWords - 1)) * 100).toFixed(1),
      }));

    return { totalWords, singleWords, twoWords };
  }, [keywordText]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${filename}`, 'success');
  };

  return (
    <div className="space-y-6">
      {/* 1. META TAG GENERATOR & OPEN GRAPH PREVIEWER */}
      {(toolSlug === 'meta-tag-generator' || toolSlug === 'open-graph-previewer') && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Inputs */}
          <div className="lg:col-span-6 space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Website Information
            </h3>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Page Title ({metaTitle.length} chars)</span>
                <span className={metaTitle.length > 60 ? 'text-amber-500 font-bold' : 'text-slate-400'}>
                  Target: 50-60
                </span>
              </div>
              <input
                type="text"
                value={metaTitle}
                onChange={(e) => setMetaTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Meta Description ({metaDesc.length} chars)</span>
                <span className={metaDesc.length > 160 ? 'text-amber-500 font-bold' : 'text-slate-400'}>
                  Target: 140-160
                </span>
              </div>
              <textarea
                value={metaDesc}
                onChange={(e) => setMetaDesc(e.target.value)}
                rows={3}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Canonical URL</label>
                <input
                  type="url"
                  value={metaUrl}
                  onChange={(e) => setMetaUrl(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Twitter Handle</label>
                <input
                  type="text"
                  value={metaTwitterHandle}
                  onChange={(e) => setMetaTwitterHandle(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">OG Image URL (1200x630px recommended)</label>
              <input
                type="url"
                value={metaOgImage}
                onChange={(e) => setMetaOgImage(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950"
              />
            </div>
          </div>

          {/* Previews */}
          <div className="lg:col-span-6 space-y-4">
            {/* Google Search Result Preview */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-1.5">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                Google Search Snippet Preview
              </div>
              <div className="text-xs text-slate-700 dark:text-slate-300 truncate">{metaUrl}</div>
              <div className="text-base text-blue-600 dark:text-blue-400 font-medium hover:underline cursor-pointer truncate">
                {metaTitle}
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                {metaDesc}
              </div>
            </div>

            {/* Social Card Preview */}
            <div className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs">
              <div className="p-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                Facebook / X Social Card Preview
              </div>
              <div className="h-36 sm:h-44 bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 text-xs font-mono">
                {metaOgImage ? (
                  <img
                    src={metaOgImage}
                    alt="Social preview"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <span>1200 × 630 Preview Image</span>
                )}
              </div>
              <div className="p-3 space-y-1 bg-slate-50 dark:bg-slate-950">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-mono truncate">
                  {new URL(metaUrl || 'https://freetoolshub.com').hostname}
                </div>
                <div className="font-bold text-xs text-slate-900 dark:text-white truncate">
                  {metaTitle}
                </div>
                <div className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  {metaDesc}
                </div>
              </div>
            </div>

            {/* HTML Code Output */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-slate-900 text-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400">HTML &lt;meta&gt; Tags</span>
                <button
                  onClick={() => copyToClipboard(generatedMetaHtml, 'meta-code')}
                  className="flex items-center gap-1 px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
                >
                  {copiedKey === 'meta-code' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>Copy Code</span>
                </button>
              </div>
              <pre className="max-h-40 overflow-y-auto text-[11px] font-mono text-slate-300 leading-relaxed whitespace-pre">
                {generatedMetaHtml}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* 2. ROBOTS.TXT GENERATOR */}
      {toolSlug === 'robots-txt-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Robots Configuration
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">User Agent</label>
              <input
                type="text"
                value={robotsAgent}
                onChange={(e) => setRobotsAgent(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Allow Path</label>
              <input
                type="text"
                value={robotsAllow}
                onChange={(e) => setRobotsAllow(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Disallow Paths (one per line)</label>
              <textarea
                value={robotsDisallow}
                onChange={(e) => setRobotsDisallow(e.target.value)}
                rows={4}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Sitemap XML URL</label>
              <input
                type="url"
                value={robotsSitemap}
                onChange={(e) => setRobotsSitemap(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Generated robots.txt
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(generatedRobotsTxt, 'robots-txt')}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 text-xs font-semibold"
                >
                  {copiedKey === 'robots-txt' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>Copy</span>
                </button>
                <button
                  onClick={() => downloadFile(generatedRobotsTxt, 'robots.txt', 'text/plain')}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download robots.txt</span>
                </button>
              </div>
            </div>
            <textarea
              readOnly
              value={generatedRobotsTxt}
              rows={14}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900 text-emerald-400 font-mono text-xs focus:outline-none shadow-xs"
            />
          </div>
        </div>
      )}

      {/* 3. XML SITEMAP GENERATOR */}
      {toolSlug === 'xml-sitemap-generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Sitemap URLs
            </h3>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Website URLs (one per line)
              </label>
              <textarea
                value={sitemapUrls}
                onChange={(e) => setSitemapUrls(e.target.value)}
                rows={8}
                className="w-full p-3 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Change Frequency</label>
                <select
                  value={sitemapFreq}
                  onChange={(e) => setSitemapFreq(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
                >
                  <option value="always">always</option>
                  <option value="hourly">hourly</option>
                  <option value="daily">daily</option>
                  <option value="weekly">weekly</option>
                  <option value="monthly">monthly</option>
                  <option value="yearly">yearly</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Priority</label>
                <select
                  value={sitemapPriority}
                  onChange={(e) => setSitemapPriority(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
                >
                  <option value="1.0">1.0 (Highest)</option>
                  <option value="0.8">0.8 (High)</option>
                  <option value="0.5">0.5 (Normal)</option>
                  <option value="0.3">0.3 (Low)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Generated sitemap.xml
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(generatedSitemapXml, 'sitemap-xml')}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 text-xs font-semibold"
                >
                  {copiedKey === 'sitemap-xml' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>Copy</span>
                </button>
                <button
                  onClick={() => downloadFile(generatedSitemapXml, 'sitemap.xml', 'application/xml')}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download XML</span>
                </button>
              </div>
            </div>
            <textarea
              readOnly
              value={generatedSitemapXml}
              rows={15}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-900 text-sky-400 font-mono text-xs focus:outline-none shadow-xs"
            />
          </div>
        </div>
      )}

      {/* 4. KEYWORD DENSITY CHECKER */}
      {toolSlug === 'keyword-density-checker' && (
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Paste Content / Article Text
              </label>
              <span className="text-xs text-slate-500 font-mono">
                {keywordStats.totalWords} Words analyzed
              </span>
            </div>
            <textarea
              value={keywordText}
              onChange={(e) => setKeywordText(e.target.value)}
              rows={6}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200 focus:outline-none shadow-xs"
              placeholder="Paste article text here..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 1-Word Density Table */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Top Keywords (1-Word)
              </h4>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {keywordStats.singleWords.map((item, idx) => (
                  <div key={idx} className="py-2 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{item.word}</span>
                    <div className="flex items-center gap-3 font-mono">
                      <span className="text-slate-400">{item.count}x</span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">{item.density}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 2-Word Phrase Density Table */}
            <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Top 2-Word Phrases
              </h4>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {keywordStats.twoWords.length === 0 ? (
                  <div className="text-xs text-slate-400 py-4">No repeated 2-word phrases detected.</div>
                ) : (
                  keywordStats.twoWords.map((item, idx) => (
                    <div key={idx} className="py-2 flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{item.phrase}</span>
                      <div className="flex items-center gap-3 font-mono">
                        <span className="text-slate-400">{item.count}x</span>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">{item.density}%</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
