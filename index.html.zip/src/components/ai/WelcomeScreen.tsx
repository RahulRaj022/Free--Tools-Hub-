import React from 'react';
import {
  Sparkles,
  BookOpen,
  PenTool,
  Code,
  FileText,
  Calculator,
  Lightbulb,
} from 'lucide-react';
import { ToolContext } from '../../types/ai';

interface WelcomeScreenProps {
  onSelectPrompt: (prompt: string) => void;
  toolContext?: ToolContext;
}

const SUGGESTIONS = [
  {
    title: 'Explain something',
    prompt: 'Explain what RAM is in simple terms, how it works, and why computers need it.',
    icon: BookOpen,
  },
  {
    title: 'Help me write',
    prompt: 'Help me write a concise, professional message requesting a project update.',
    icon: PenTool,
  },
  {
    title: 'Help with coding',
    prompt: 'Write a clean TypeScript helper function to format file sizes into KB, MB, and GB.',
    icon: Code,
  },
  {
    title: 'Summarize text',
    prompt: 'Summarize the key differences between client-side and server-side processing in 3 points.',
    icon: FileText,
  },
  {
    title: 'Solve a problem',
    prompt: 'Calculate the monthly savings needed to accumulate $15,000 in 3 years with 5% annual interest.',
    icon: Calculator,
  },
  {
    title: 'Generate ideas',
    prompt: 'Give me 5 practical, high-value ideas for browser-based productivity utilities.',
    icon: Lightbulb,
  },
];

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectPrompt,
  toolContext,
}) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 max-w-2xl mx-auto w-full text-center">
      {/* Title & Subtitle */}
      <div className="mb-6 space-y-1.5">
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          Free Tools Hub AI
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          How can I help you today?
        </p>
        {toolContext && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 mt-2">
            <Sparkles className="h-3.5 w-3.5 text-indigo-500" />
            <span>Active context: {toolContext.name}</span>
          </div>
        )}
      </div>

      {/* Small Compact Suggestion Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-2.5 w-full text-left">
        {SUGGESTIONS.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.title}
              type="button"
              onClick={() => onSelectPrompt(item.prompt)}
              className="p-3 rounded-xl border border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900/60 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2">
                <Icon className="h-3.5 w-3.5 text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors shrink-0" />
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white transition-colors truncate">
                  {item.title}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
