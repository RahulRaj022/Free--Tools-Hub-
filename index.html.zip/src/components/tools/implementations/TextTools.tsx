import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, Trash2, Check, ArrowRightLeft, FileUp, Sparkles } from 'lucide-react';

interface TextToolProps {
  toolSlug: string;
}

export const TextTools: React.FC<TextToolProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [text, setText] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  // States for specific tools
  const [loremCount, setLoremCount] = useState<number>(3);
  const [loremType, setLoremType] = useState<'paragraphs' | 'sentences' | 'words'>('paragraphs');
  const [startWithLorem, setStartWithLorem] = useState<boolean>(true);

  const [slugSeparator, setSlugSeparator] = useState<'-' | '_'>('-');

  const handleCopy = (contentToCopy?: string) => {
    const val = contentToCopy !== undefined ? contentToCopy : text;
    if (!val) {
      showToast('Nothing to copy', 'info');
      return;
    }
    navigator.clipboard.writeText(val);
    setCopied(true);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClear = () => {
    setText('');
    showToast('Cleared text', 'info');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showToast('File is too large (max 5MB)', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      setText(event.target?.result as string || '');
      showToast('Text loaded from file', 'success');
    };
    reader.readAsText(file);
  };

  // Text statistics calculation
  const stats = useMemo(() => {
    const trimmed = text.trim();
    const words = trimmed ? trimmed.split(/\s+/).filter(Boolean).length : 0;
    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s+/g, '').length;
    const sentences = trimmed ? trimmed.split(/[.!?]+/).filter((s) => s.trim().length > 0).length : 0;
    const paragraphs = trimmed ? text.split(/\n+/).filter((p) => p.trim().length > 0).length : 0;
    const readingTimeMinutes = Math.ceil(words / 200);
    const speakingTimeMinutes = Math.ceil(words / 130);

    return {
      words,
      characters,
      charactersNoSpaces,
      sentences,
      paragraphs,
      readingTime: `${readingTimeMinutes} min`,
      speakingTime: `${speakingTimeMinutes} min`,
    };
  }, [text]);

  // Casing functions
  const transformCase = (mode: string) => {
    if (!text) return;
    let result = text;
    switch (mode) {
      case 'uppercase':
        result = text.toUpperCase();
        break;
      case 'lowercase':
        result = text.toLowerCase();
        break;
      case 'title':
        result = text.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
        break;
      case 'sentence':
        result = text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase());
        break;
      case 'camel':
        result = text
          .toLowerCase()
          .replace(/[^a-zA-Z0-9]+(.)/g, (_, chr) => chr.toUpperCase())
          .replace(/^[A-Z]/, (c) => c.toLowerCase());
        break;
      case 'kebab':
        result = text
          .trim()
          .toLowerCase()
          .replace(/[^a-zA-Z0-9]+/g, '-')
          .replace(/^-+|-+$/g, '');
        break;
      case 'snake':
        result = text
          .trim()
          .toLowerCase()
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_+|_+$/g, '');
        break;
      case 'constant':
        result = text
          .trim()
          .toUpperCase()
          .replace(/[^a-zA-Z0-9]+/g, '_')
          .replace(/^_+|_+$/g, '');
        break;
      case 'alternating':
        result = text
          .split('')
          .map((char, index) => (index % 2 === 0 ? char.toLowerCase() : char.toUpperCase()))
          .join('');
        break;
      default:
        break;
    }
    setText(result);
    showToast(`Converted to ${mode} case`, 'success');
  };

  // Remove spaces
  const cleanSpaces = (type: 'all' | 'multiple' | 'lines' | 'trim') => {
    if (!text) return;
    let res = text;
    if (type === 'multiple') {
      res = text.replace(/[ \t]+/g, ' ');
    } else if (type === 'lines') {
      res = text
        .split('\n')
        .filter((line) => line.trim().length > 0)
        .join('\n');
    } else if (type === 'trim') {
      res = text
        .split('\n')
        .map((line) => line.trim())
        .join('\n');
    } else if (type === 'all') {
      res = text
        .split('\n')
        .map((line) => line.trim().replace(/[ \t]+/g, ' '))
        .filter((line) => line.length > 0)
        .join('\n');
    }
    setText(res);
    showToast('Cleaned whitespace', 'success');
  };

  // Reversal
  const reverseText = (mode: 'chars' | 'words' | 'lines') => {
    if (!text) return;
    let res = '';
    if (mode === 'chars') {
      res = text.split('').reverse().join('');
    } else if (mode === 'words') {
      res = text
        .split('\n')
        .map((line) => line.split(' ').reverse().join(' '))
        .join('\n');
    } else if (mode === 'lines') {
      res = text.split('\n').reverse().join('\n');
    }
    setText(res);
    showToast('Reversed text', 'success');
  };

  // Sorter
  const sortLines = (order: 'az' | 'za' | 'lengthAsc' | 'lengthDesc' | 'random') => {
    if (!text) return;
    const lines = text.split('\n');
    if (order === 'az') {
      lines.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    } else if (order === 'za') {
      lines.sort((a, b) => b.localeCompare(a, undefined, { numeric: true, sensitivity: 'base' }));
    } else if (order === 'lengthAsc') {
      lines.sort((a, b) => a.length - b.length);
    } else if (order === 'lengthDesc') {
      lines.sort((a, b) => b.length - a.length);
    } else if (order === 'random') {
      for (let i = lines.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [lines[i], lines[j]] = [lines[j], lines[i]];
      }
    }
    setText(lines.join('\n'));
    showToast(`Sorted lines (${order})`, 'success');
  };

  // Deduplicate lines
  const deduplicateLines = (caseSensitive = false, trim = true) => {
    if (!text) return;
    const lines = text.split('\n');
    const seen = new Set<string>();
    const result: string[] = [];
    let dupCount = 0;

    for (const line of lines) {
      const key = trim ? (caseSensitive ? line.trim() : line.trim().toLowerCase()) : (caseSensitive ? line : line.toLowerCase());
      if (seen.has(key)) {
        dupCount++;
      } else {
        seen.add(key);
        result.push(trim ? line.trim() : line);
      }
    }

    setText(result.join('\n'));
    showToast(`Removed ${dupCount} duplicate line(s)`, 'success');
  };

  // Slug generator
  const generatedSlug = useMemo(() => {
    if (!text) return '';
    return text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, slugSeparator)
      .replace(new RegExp(`^${slugSeparator}+|${slugSeparator}+$`, 'g'), '');
  }, [text, slugSeparator]);

  // Lorem generator
  const generateLorem = () => {
    const sentencesPool = [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
      'Curabitur pretium tincidunt lacus nulla gravida orci a odio.',
      'Nullam varius, turpis et commodo pharetra, est eros bibendum elit, nec luctus magna felis sollicitudin mauris.',
      'Integer in mauris eu nibh euismod gravida.',
      'Duis ac tellus et risus vulputate vehicula.',
      'Donec lobortis risus a elit ullamcorper feugiat.',
    ];

    let result = '';
    if (loremType === 'paragraphs') {
      const paras: string[] = [];
      for (let i = 0; i < loremCount; i++) {
        const pSentences = [];
        const count = 4 + (i % 3);
        for (let j = 0; j < count; j++) {
          pSentences.push(sentencesPool[(i * 3 + j) % sentencesPool.length]);
        }
        paras.push(pSentences.join(' '));
      }
      result = paras.join('\n\n');
    } else if (loremType === 'sentences') {
      const sArr: string[] = [];
      for (let i = 0; i < loremCount; i++) {
        sArr.push(sentencesPool[i % sentencesPool.length]);
      }
      result = sArr.join(' ');
    } else {
      const wordsPool = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation'.split(' ');
      const wordsArr: string[] = [];
      for (let i = 0; i < loremCount; i++) {
        wordsArr.push(wordsPool[i % wordsPool.length]);
      }
      result = wordsArr.join(' ');
    }

    if (!startWithLorem && result.toLowerCase().startsWith('lorem ipsum')) {
      result = result.substring(12).trim();
      result = result.charAt(0).toUpperCase() + result.slice(1);
    }

    setText(result);
    showToast('Generated placeholder text', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Specific top actions / controls depending on tool */}
      {toolSlug === 'slug-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Separator:</span>
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                <button
                  onClick={() => setSlugSeparator('-')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    slugSeparator === '-' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Hyphen (-)
                </button>
                <button
                  onClick={() => setSlugSeparator('_')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    slugSeparator === '_' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Underscore (_)
                </button>
              </div>
            </div>
            {generatedSlug && (
              <button
                onClick={() => handleCopy(generatedSlug)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Copy className="h-3.5 w-3.5" />
                Copy Slug
              </button>
            )}
          </div>
          {generatedSlug && (
            <div className="mt-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-950 font-mono text-xs sm:text-sm text-indigo-600 dark:text-indigo-400 break-all select-all">
              /{generatedSlug}
            </div>
          )}
        </div>
      )}

      {toolSlug === 'lorem-ipsum-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Generate:</label>
              <input
                type="number"
                min="1"
                max="50"
                value={loremCount}
                onChange={(e) => setLoremCount(Math.max(1, Math.min(50, parseInt(e.target.value) || 1)))}
                className="w-16 px-2 py-1 text-xs border border-slate-300 dark:border-slate-700 rounded-lg dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs">
              {(['paragraphs', 'sentences', 'words'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setLoremType(t)}
                  className={`px-3 py-1 rounded-md font-medium capitalize transition-colors ${
                    loremType === t ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs font-semibold' : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={startWithLorem}
                onChange={(e) => setStartWithLorem(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              Start with &quot;Lorem ipsum&quot;
            </label>
            <button
              onClick={generateLorem}
              className="ml-auto flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Generate Lorem
            </button>
          </div>
        </div>
      )}

      {toolSlug === 'text-sorter' && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Sort Lines:</span>
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <button
                onClick={() => sortLines('az')}
                className="px-3 py-1.5 font-semibold rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900 transition-colors"
              >
                A → Z Alphabetical
              </button>
              <button
                onClick={() => sortLines('za')}
                className="px-3 py-1.5 font-semibold rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-900 transition-colors"
              >
                Z → A Reverse
              </button>
              <button
                onClick={() => sortLines('lengthAsc')}
                className="px-3 py-1.5 font-medium rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Shortest → Longest
              </button>
              <button
                onClick={() => sortLines('lengthDesc')}
                className="px-3 py-1.5 font-medium rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Longest → Shortest
              </button>
              <button
                onClick={() => sortLines('random')}
                className="px-3 py-1.5 font-medium rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Random Shuffle
              </button>
            </div>
          </div>
        </div>
      )}

      {toolSlug === 'duplicate-line-remover' && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Deduplicate:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => deduplicateLines(false, true)}
                className="px-4 py-2 font-semibold text-xs rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 transition-colors shadow-xs"
              >
                Remove Duplicates (Standard)
              </button>
              <button
                onClick={() => deduplicateLines(true, true)}
                className="px-3 py-2 font-medium text-xs rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                Case-Sensitive Deduplicate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Textarea Container */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900 overflow-hidden">
        
        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-2.5 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-950/40">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {toolSlug === 'slug-generator' ? 'Input Title / Headline' : 'Editor'}
            </span>
            <label className="flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 cursor-pointer">
              <FileUp className="h-3.5 w-3.5" />
              <span>Load file</span>
              <input type="file" accept=".txt,.md,.json,.csv" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopy()}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg text-slate-700 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
              title="Copy to clipboard"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={handleClear}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40 transition-colors"
              title="Clear all text"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Text Area */}
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={
            toolSlug === 'slug-generator'
              ? 'Type or paste a title (e.g. "10 Best Free Online Utilities for 2026")...'
              : 'Type or paste your text here to analyze, transform or count...'
          }
          rows={10}
          className="w-full resize-y p-4 text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none dark:bg-slate-900 dark:text-slate-100 font-sans"
        />

        {/* Footer Statistics Row */}
        <div className="border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/30 px-4 py-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-center">
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.words.toLocaleString()}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Words</div>
            </div>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.characters.toLocaleString()}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Characters</div>
            </div>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.charactersNoSpaces.toLocaleString()}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">No Spaces</div>
            </div>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.sentences.toLocaleString()}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Sentences</div>
            </div>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {stats.paragraphs.toLocaleString()}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Paragraphs</div>
            </div>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800">
              <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                {stats.readingTime}
              </div>
              <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Reading Time</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tool Action Buttons (Casing, Spaces, Reversals) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Case Conversions */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2.5">
          <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
            Case Conversions
          </h4>
          <div className="grid grid-cols-2 gap-1.5 text-xs">
            <button
              onClick={() => transformCase('uppercase')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              UPPERCASE
            </button>
            <button
              onClick={() => transformCase('lowercase')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              lowercase
            </button>
            <button
              onClick={() => transformCase('title')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Title Case
            </button>
            <button
              onClick={() => transformCase('sentence')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Sentence case
            </button>
            <button
              onClick={() => transformCase('camel')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300 font-mono text-[11px]"
            >
              camelCase
            </button>
            <button
              onClick={() => transformCase('kebab')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300 font-mono text-[11px]"
            >
              kebab-case
            </button>
            <button
              onClick={() => transformCase('snake')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300 font-mono text-[11px]"
            >
              snake_case
            </button>
            <button
              onClick={() => transformCase('constant')}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300 font-mono text-[11px]"
            >
              CONSTANT_CASE
            </button>
          </div>
        </div>

        {/* Space & Line Cleaning */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2.5">
          <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
            Space & Line Cleaner
          </h4>
          <div className="flex flex-col gap-1.5 text-xs">
            <button
              onClick={() => cleanSpaces('multiple')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Collapse multiple spaces
            </button>
            <button
              onClick={() => cleanSpaces('trim')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Trim leading & trailing spaces
            </button>
            <button
              onClick={() => cleanSpaces('lines')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Remove blank lines
            </button>
            <button
              onClick={() => cleanSpaces('all')}
              className="px-3 py-2 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300 font-semibold text-left transition-colors"
            >
              Deep clean all whitespace
            </button>
          </div>
        </div>

        {/* Text Reversal & Transform */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2.5">
          <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
            Text Reversal
          </h4>
          <div className="flex flex-col gap-1.5 text-xs">
            <button
              onClick={() => reverseText('chars')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Reverse characters (olleh → hello)
            </button>
            <button
              onClick={() => reverseText('words')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Reverse word sequence
            </button>
            <button
              onClick={() => reverseText('lines')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              Reverse line order
            </button>
            <button
              onClick={() => transformCase('alternating')}
              className="px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 text-left font-medium text-slate-700 dark:text-slate-300"
            >
              aLtErNaTiNg cAsE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
