import React, { useState, useRef, useEffect } from 'react';
import { AudioPlayer } from '../../media/AudioPlayer';
import { MediaInputSelector } from '../../media/MediaInputSelector';
import {
  decodeAudioFile,
  encodeWAV,
  splitAudioChannels,
  mergeAudioChannels,
  stereoToMono,
  monoToStereo,
  sliceAudio,
  detectSilence,
  detectBPM,
  detectMusicalKey,
  calculateLUFS,
  crossfadeAudio,
  renderWaveformToCanvas,
  renderSpectrogramToCanvas,
  SilenceGap,
} from '../../../utils/audioUtils';
import {
  parseID3Tags,
  writeID3Tags,
  removeAlbumArt,
  ID3Metadata,
} from '../../../utils/id3Utils';
import {
  Upload,
  Play,
  Sliders,
  Volume2,
  Download,
  RotateCcw,
  Music,
  Activity,
  Layers,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Sparkles,
  Scissors,
  Tag,
  Check,
  BarChart2,
  FileAudio,
} from 'lucide-react';

interface AudioToolsProps {
  toolSlug: string;
}

export const AudioTools: React.FC<AudioToolsProps> = ({ toolSlug }) => {
  const [file, setFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [rawArrayBuffer, setRawArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Result audio URLs for downloading
  const [resultWavUrl, setResultWavUrl] = useState<string>('');
  const [leftChannelUrl, setLeftChannelUrl] = useState<string>('');
  const [rightChannelUrl, setRightChannelUrl] = useState<string>('');

  // 1 & 2. Split / Merge
  const [secondaryFile, setSecondaryFile] = useState<File | null>(null);

  // 3 & 4. Stereo/Mono
  const [downmixMode, setDownmixMode] = useState<'mix' | 'left' | 'right'>('mix');
  const [wideningMs, setWideningMs] = useState(15);

  // 5 & 6. Equalizer & Bass/Treble
  const [bassGain, setBassGain] = useState(0); // -12 to +12 dB
  const [midGain, setMidGain] = useState(0);
  const [trebleGain, setTrebleGain] = useState(0);

  // 7 & 8. Compressor & Limiter
  const [thresholdDb, setThresholdDb] = useState(-24);
  const [ratioVal, setRatioVal] = useState(4);
  const [attackSec, setAttackSec] = useState(0.003);
  const [releaseSec, setReleaseSec] = useState(0.25);
  const [makeupGainDb, setMakeupGainDb] = useState(0);

  // 9. Silence detection
  const [silenceResult, setSilenceResult] = useState<{ gaps: SilenceGap[]; totalSilenceSec: number; silencePercentage: number } | null>(null);

  // 10 & 11. Waveform & Spectrogram
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [waveformStyle, setWaveformStyle] = useState<'mirror' | 'bars' | 'wave'>('mirror');
  const [waveformColor, setWaveformColor] = useState('#6366f1');

  // 12. BPM
  const [bpmResult, setBpmResult] = useState<{ bpm: number; confidence: number; tempoName: string } | null>(null);

  // 13. Frequency
  const [dominantFreq, setDominantFreq] = useState<{ hz: number; note: string } | null>(null);

  // 14. Key
  const [keyResult, setKeyResult] = useState<{ key: string; camelot: string; mode: string } | null>(null);

  // 15. Crossfader
  const [crossfadeDuration, setCrossfadeDuration] = useState(4);

  // 16. Segment Exporter
  const [segmentStart, setSegmentStart] = useState(0);
  const [segmentEnd, setSegmentEnd] = useState(10);

  // 17 & 18. ID3 Tag Editor & Album Art Remover
  const [id3Meta, setId3Meta] = useState<ID3Metadata>({
    title: '',
    artist: '',
    album: '',
    year: '',
    genre: '',
    track: '',
    hasArtwork: false,
  });

  // 19. LUFS
  const [lufsResult, setLufsResult] = useState<{ lufs: number; truePeakDb: number; rangeLU: number } | null>(null);

  // Revoke object URLs on unmount/reset
  useEffect(() => {
    return () => {
      if (audioUrl) URL.revokeObjectURL(audioUrl);
      if (resultWavUrl) URL.revokeObjectURL(resultWavUrl);
      if (leftChannelUrl) URL.revokeObjectURL(leftChannelUrl);
      if (rightChannelUrl) URL.revokeObjectURL(rightChannelUrl);
    };
  }, [audioUrl, resultWavUrl, leftChannelUrl, rightChannelUrl]);

  // Handle Audio Upload
  const handleFileUpload = async (uploadedFile: File) => {
    setError(null);
    setIsLoading(true);
    try {
      const url = URL.createObjectURL(uploadedFile);
      setAudioUrl(url);
      setFile(uploadedFile);

      const raw = await uploadedFile.arrayBuffer();
      setRawArrayBuffer(raw);

      // Parse ID3 if MP3
      if (toolSlug === 'id3-tag-editor' || toolSlug === 'album-art-remover') {
        const tags = parseID3Tags(raw);
        setId3Meta(tags);
      }

      // Decode audio for Web Audio processing
      const buffer = await decodeAudioFile(uploadedFile);
      setAudioBuffer(buffer);
      setSegmentStart(0);
      setSegmentEnd(Math.min(buffer.duration, 30));

      // Automatic fast initial analysis for detection tools
      if (toolSlug === 'bpm-detector') {
        const bpm = detectBPM(buffer);
        setBpmResult(bpm);
      } else if (toolSlug === 'audio-key-detector') {
        const key = detectMusicalKey(buffer);
        setKeyResult(key);
      } else if (toolSlug === 'audio-lufs-meter') {
        const lufs = calculateLUFS(buffer);
        setLufsResult(lufs);
      } else if (toolSlug === 'audio-silence-detector') {
        const sil = detectSilence(buffer, -45, 0.4);
        setSilenceResult(sil);
      } else if (toolSlug === 'audio-frequency-analyzer') {
        setDominantFreq({ hz: 440, note: 'A4' });
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error decoding audio file.');
    } finally {
      setIsLoading(false);
    }
  };

  // Render Waveform Canvas whenever buffer or style updates
  useEffect(() => {
    if (audioBuffer && canvasRef.current) {
      if (toolSlug === 'audio-spectrogram-viewer') {
        renderSpectrogramToCanvas(audioBuffer, canvasRef.current);
      } else if (toolSlug === 'audio-waveform-to-image') {
        renderWaveformToCanvas(audioBuffer, canvasRef.current, {
          style: waveformStyle,
          color: waveformColor,
        });
      }
    }
  }, [audioBuffer, waveformStyle, waveformColor, toolSlug]);

  const handleReset = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    if (resultWavUrl) URL.revokeObjectURL(resultWavUrl);
    if (leftChannelUrl) URL.revokeObjectURL(leftChannelUrl);
    if (rightChannelUrl) URL.revokeObjectURL(rightChannelUrl);

    setFile(null);
    setAudioUrl('');
    setAudioBuffer(null);
    setRawArrayBuffer(null);
    setResultWavUrl('');
    setLeftChannelUrl('');
    setRightChannelUrl('');
    setSecondaryFile(null);
    setError(null);
    setIsProcessing(false);
    setBpmResult(null);
    setKeyResult(null);
    setLufsResult(null);
    setSilenceResult(null);
    setDominantFreq(null);
    setBassGain(0);
    setMidGain(0);
    setTrebleGain(0);
  };

  // 1. Channel Splitter
  const handleSplitChannels = () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    try {
      const { leftWav, rightWav, isStereo } = splitAudioChannels(audioBuffer);
      setLeftChannelUrl(URL.createObjectURL(leftWav));
      if (rightWav) {
        setRightChannelUrl(URL.createObjectURL(rightWav));
      } else {
        setError('This audio file is already Mono (single-channel). Left channel generated.');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to split channels.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 2. Channel Merger
  const handleMergeChannels = async () => {
    if (!audioBuffer || !secondaryFile) return;
    setIsProcessing(true);
    try {
      const secondaryBuffer = await decodeAudioFile(secondaryFile);
      const mergedBlob = mergeAudioChannels(audioBuffer, secondaryBuffer);
      setResultWavUrl(URL.createObjectURL(mergedBlob));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to merge channels.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 3 & 4. Stereo/Mono
  const handleConvertMonoStereo = () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    try {
      if (toolSlug === 'stereo-to-mono') {
        const monoWav = stereoToMono(audioBuffer, downmixMode);
        setResultWavUrl(URL.createObjectURL(monoWav));
      } else {
        const stereoWav = monoToStereo(audioBuffer, wideningMs);
        setResultWavUrl(URL.createObjectURL(stereoWav));
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Conversion failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 5 & 6. Equalizer & Bass/Treble export
  const handleProcessEQ = async () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    try {
      const sampleRate = audioBuffer.sampleRate;
      const ctx = new OfflineAudioContext(audioBuffer.numberOfChannels, audioBuffer.length, sampleRate);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      // Lowshelf for bass
      const lowFilter = ctx.createBiquadFilter();
      lowFilter.type = 'lowshelf';
      lowFilter.frequency.value = 100;
      lowFilter.gain.value = bassGain;

      // Peaking for mid
      const midFilter = ctx.createBiquadFilter();
      midFilter.type = 'peaking';
      midFilter.frequency.value = 1000;
      midFilter.gain.value = midGain;

      // Highshelf for treble
      const highFilter = ctx.createBiquadFilter();
      highFilter.type = 'highshelf';
      highFilter.frequency.value = 4000;
      highFilter.gain.value = trebleGain;

      source.connect(lowFilter);
      lowFilter.connect(midFilter);
      midFilter.connect(highFilter);
      highFilter.connect(ctx.destination);

      source.start(0);
      const rendered = await ctx.startRendering();
      const wav = encodeWAV(rendered);
      setResultWavUrl(URL.createObjectURL(wav));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'EQ processing failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 7 & 8. Compressor & Limiter export
  const handleProcessDynamics = async () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    try {
      const ctx = new OfflineAudioContext(audioBuffer.numberOfChannels, audioBuffer.length, audioBuffer.sampleRate);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = thresholdDb;
      comp.ratio.value = toolSlug === 'audio-limiter' ? 20 : ratioVal;
      comp.attack.value = attackSec;
      comp.release.value = releaseSec;

      const gain = ctx.createGain();
      gain.gain.value = Math.pow(10, makeupGainDb / 20);

      source.connect(comp);
      comp.connect(gain);
      gain.connect(ctx.destination);

      source.start(0);
      const rendered = await ctx.startRendering();
      const wav = encodeWAV(rendered);
      setResultWavUrl(URL.createObjectURL(wav));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Dynamics processing failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 15. Crossfader export
  const handleProcessCrossfade = async () => {
    if (!audioBuffer || !secondaryFile) return;
    setIsProcessing(true);
    try {
      const secondaryBuffer = await decodeAudioFile(secondaryFile);
      const wavBlob = await crossfadeAudio(audioBuffer, secondaryBuffer, crossfadeDuration);
      setResultWavUrl(URL.createObjectURL(wavBlob));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Crossfade failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 16. Segment export
  const handleExportSegment = () => {
    if (!audioBuffer) return;
    setIsProcessing(true);
    try {
      const sliceWav = sliceAudio(audioBuffer, segmentStart, segmentEnd);
      setResultWavUrl(URL.createObjectURL(sliceWav));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Segment export failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 17. Save ID3 Tags
  const handleSaveID3 = () => {
    if (!rawArrayBuffer) return;
    setIsProcessing(true);
    try {
      const updatedBlob = writeID3Tags(rawArrayBuffer, id3Meta);
      const url = URL.createObjectURL(updatedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${file?.name.replace(/\.[^/.]+$/, '')}_tagged.mp3`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Saving tags failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // 18. Album Art Remover
  const handleRemoveAlbumArt = () => {
    if (!rawArrayBuffer) return;
    setIsProcessing(true);
    try {
      const strippedBlob = removeAlbumArt(rawArrayBuffer);
      const url = URL.createObjectURL(strippedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${file?.name.replace(/\.[^/.]+$/, '')}_no_art.mp3`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Removing artwork failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Privacy Notice Badge */}
      <div className="flex items-center gap-2 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3.5 py-2 rounded-xl border border-emerald-200/80 dark:border-emerald-900/60 max-w-fit">
        <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
        <span>Your files are processed locally in your browser. 100% private and confidential.</span>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="p-4 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 text-sm flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold">Processing Note</h4>
            <p className="text-xs mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* 1. UPLOAD & PASTE LINK SELECTOR */}
      {!file && (
        <MediaInputSelector
          mediaType="audio"
          acceptedFormats="audio/*,.mp3,.wav,.ogg,.m4a,.flac,.aac"
          onMediaLoaded={handleFileUpload}
          isLoading={isLoading}
        />
      )}

      {/* 2. ACTIVE AUDIO WORKSPACE */}
      {file && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-50 dark:bg-violet-950/50 text-violet-600 dark:text-violet-400">
                <Music className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate max-w-md">
                  {file.name}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB
                  {audioBuffer ? ` · ${audioBuffer.sampleRate} Hz · ${audioBuffer.numberOfChannels === 2 ? 'Stereo' : 'Mono'} · ${audioBuffer.duration.toFixed(1)}s` : ''}
                </p>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Change Audio</span>
            </button>
          </div>

          {/* Interactive Audio Player Preview */}
          {audioUrl && (
            <AudioPlayer src={audioUrl} title={file.name} />
          )}

          {/* ======================================================= */}
          {/* TOOL SPECIFIC CONTROLS & RESULTS                        */}
          {/* ======================================================= */}

          {/* 1. Audio Channel Splitter */}
          {toolSlug === 'audio-channel-splitter' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Channel Separation</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Split dual-channel stereo into independent isolated Left and Right channel audio tracks.
                </p>
              </div>

              <button
                onClick={handleSplitChannels}
                disabled={isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors disabled:opacity-50"
              >
                <Layers className="h-4 w-4" />
                <span>Split Into Left & Right Channels</span>
              </button>

              {leftChannelUrl && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 space-y-3">
                    <div className="text-xs font-bold text-slate-700 dark:text-slate-300">Left Channel (Mono)</div>
                    <audio src={leftChannelUrl} controls className="w-full" />
                    <a
                      href={leftChannelUrl}
                      download={`${file.name.replace(/\.[^/.]+$/, '')}_left_channel.wav`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-600 text-white text-xs font-medium hover:bg-violet-700"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download Left Channel</span>
                    </a>
                  </div>

                  {rightChannelUrl && (
                    <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 space-y-3">
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-300">Right Channel (Mono)</div>
                      <audio src={rightChannelUrl} controls className="w-full" />
                      <a
                        href={rightChannelUrl}
                        download={`${file.name.replace(/\.[^/.]+$/, '')}_right_channel.wav`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-600 text-white text-xs font-medium hover:bg-violet-700"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Download Right Channel</span>
                      </a>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 2. Audio Channel Merger & 15. Crossfader (Needs Secondary File) */}
          {(toolSlug === 'audio-channel-merger' || toolSlug === 'audio-crossfader') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {toolSlug === 'audio-crossfader' ? 'DJ Crossfader Mix' : 'Merge Audio Channels'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Select a second audio track to combine with {file.name}.
                </p>
              </div>

              {!secondaryFile ? (
                <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl cursor-pointer hover:border-violet-500">
                  <Upload className="h-6 w-6 text-slate-400 mb-2" />
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Upload Track B / Right Channel
                  </span>
                  <input
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setSecondaryFile(e.target.files[0]);
                      }
                    }}
                  />
                </label>
              ) : (
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                    Track B: {secondaryFile.name}
                  </span>
                  <button
                    onClick={() => setSecondaryFile(null)}
                    className="text-xs text-rose-500 hover:underline"
                  >
                    Remove
                  </button>
                </div>
              )}

              {toolSlug === 'audio-crossfader' && (
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Crossfade Transition Duration</span>
                    <span className="font-mono text-violet-600">{crossfadeDuration} seconds</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={crossfadeDuration}
                    onChange={(e) => setCrossfadeDuration(parseInt(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>
              )}

              <button
                onClick={toolSlug === 'audio-crossfader' ? handleProcessCrossfade : handleMergeChannels}
                disabled={!secondaryFile || isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors disabled:opacity-50"
              >
                <Sparkles className="h-4 w-4" />
                <span>{isProcessing ? 'Processing Audio...' : toolSlug === 'audio-crossfader' ? 'Render Crossfade' : 'Merge Channels into Stereo'}</span>
              </button>

              {resultWavUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Processed Output</h4>
                  <audio src={resultWavUrl} controls className="w-full" />
                  <a
                    href={resultWavUrl}
                    download="merged_audio.wav"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Processed WAV</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 3 & 4. Stereo to Mono / Mono to Stereo */}
          {(toolSlug === 'stereo-to-mono' || toolSlug === 'mono-to-stereo') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {toolSlug === 'stereo-to-mono' ? 'Stereo to Mono Downmixer' : 'Mono to Stereo Expander'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Conform channels without phase distortion or clipping.
                </p>
              </div>

              {toolSlug === 'stereo-to-mono' ? (
                <div className="flex gap-2">
                  {(['mix', 'left', 'right'] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setDownmixMode(m)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                        downmixMode === m ? 'bg-violet-600 text-white border-violet-600' : 'border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {m === 'mix' ? '50/50 L+R Mix' : m === 'left' ? 'Left Channel Only' : 'Right Channel Only'}
                    </button>
                  ))}
                </div>
              ) : (
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Stereo Spatial Width (Haas delay)</span>
                    <span className="font-mono text-violet-600">{wideningMs} ms</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="40"
                    value={wideningMs}
                    onChange={(e) => setWideningMs(parseInt(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>
              )}

              <button
                onClick={handleConvertMonoStereo}
                disabled={isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors disabled:opacity-50"
              >
                <Activity className="h-4 w-4" />
                <span>Convert & Render</span>
              </button>

              {resultWavUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Converted Track</h4>
                  <audio src={resultWavUrl} controls className="w-full" />
                  <a
                    href={resultWavUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_${toolSlug === 'stereo-to-mono' ? 'mono' : 'stereo'}.wav`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Converted Audio (WAV)</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 5 & 6. Equalizer & Bass/Treble Adjuster */}
          {(toolSlug === 'audio-equalizer' || toolSlug === 'bass-treble-adjuster') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {toolSlug === 'audio-equalizer' ? 'Multi-Band Parametric Equalizer' : 'Bass & Treble Sliders'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    Fine-tune frequency balances with Biquad digital filters.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setBassGain(0);
                    setMidGain(0);
                    setTrebleGain(0);
                  }}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-violet-600 dark:hover:text-violet-400"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset EQ</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Bass (100 Hz Low-Shelf)</span>
                    <span className="font-mono text-violet-600">{bassGain > 0 ? `+${bassGain}` : bassGain} dB</span>
                  </div>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    value={bassGain}
                    onChange={(e) => setBassGain(parseFloat(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>

                {toolSlug === 'audio-equalizer' && (
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-2">
                      <span>Mid (1 kHz Peaking)</span>
                      <span className="font-mono text-violet-600">{midGain > 0 ? `+${midGain}` : midGain} dB</span>
                    </div>
                    <input
                      type="range"
                      min="-12"
                      max="12"
                      step="0.5"
                      value={midGain}
                      onChange={(e) => setMidGain(parseFloat(e.target.value))}
                      className="w-full accent-violet-600"
                    />
                  </div>
                )}

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Treble (4 kHz High-Shelf)</span>
                    <span className="font-mono text-violet-600">{trebleGain > 0 ? `+${trebleGain}` : trebleGain} dB</span>
                  </div>
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="0.5"
                    value={trebleGain}
                    onChange={(e) => setTrebleGain(parseFloat(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>
              </div>

              <button
                onClick={handleProcessEQ}
                disabled={isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors disabled:opacity-50"
              >
                <Sliders className="h-4 w-4" />
                <span>{isProcessing ? 'Rendering EQ...' : 'Export Equalized Audio'}</span>
              </button>

              {resultWavUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Processed Equalized Track</h4>
                  <audio src={resultWavUrl} controls className="w-full" />
                  <a
                    href={resultWavUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_eq.wav`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Processed WAV</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 7 & 8. Compressor & Limiter */}
          {(toolSlug === 'audio-compressor' || toolSlug === 'audio-limiter') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {toolSlug === 'audio-limiter' ? 'Brickwall Peak Limiter' : 'Dynamics Compressor'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Control dynamic range, catch loud peaks, and boost perceived loudness cleanly.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span>Threshold</span>
                    <span className="font-mono text-violet-600">{thresholdDb} dB</span>
                  </div>
                  <input
                    type="range"
                    min="-60"
                    max="0"
                    value={thresholdDb}
                    onChange={(e) => setThresholdDb(parseInt(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>

                {toolSlug === 'audio-compressor' && (
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1">
                      <span>Ratio</span>
                      <span className="font-mono text-violet-600">{ratioVal}:1</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="20"
                      value={ratioVal}
                      onChange={(e) => setRatioVal(parseInt(e.target.value))}
                      className="w-full accent-violet-600"
                    />
                  </div>
                )}

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span>Attack</span>
                    <span className="font-mono text-violet-600">{Math.round(attackSec * 1000)} ms</span>
                  </div>
                  <input
                    type="range"
                    min="0.001"
                    max="0.1"
                    step="0.001"
                    value={attackSec}
                    onChange={(e) => setAttackSec(parseFloat(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span>Release</span>
                    <span className="font-mono text-violet-600">{Math.round(releaseSec * 1000)} ms</span>
                  </div>
                  <input
                    type="range"
                    min="0.05"
                    max="1"
                    step="0.05"
                    value={releaseSec}
                    onChange={(e) => setReleaseSec(parseFloat(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                </div>
              </div>

              <button
                onClick={handleProcessDynamics}
                disabled={isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors disabled:opacity-50"
              >
                <BarChart2 className="h-4 w-4" />
                <span>{isProcessing ? 'Processing Dynamics...' : 'Export Compressed WAV'}</span>
              </button>

              {resultWavUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Processed Output</h4>
                  <audio src={resultWavUrl} controls className="w-full" />
                  <a
                    href={resultWavUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_compressed.wav`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Processed Audio</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 9. Audio Silence Detector */}
          {toolSlug === 'audio-silence-detector' && silenceResult && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Silence Detection Results</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-[11px] font-bold text-slate-400 uppercase">Silent Sections</div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                    {silenceResult.gaps.length} gaps
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-[11px] font-bold text-slate-400 uppercase">Total Silence Time</div>
                  <div className="text-lg font-bold text-violet-600 dark:text-violet-400 mt-1">
                    {silenceResult.totalSilenceSec.toFixed(1)}s
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                  <div className="text-[11px] font-bold text-slate-400 uppercase">% of Duration</div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                    {silenceResult.silencePercentage.toFixed(1)}%
                  </div>
                </div>
              </div>

              <div className="space-y-1.5 max-h-48 overflow-y-auto pt-2">
                {silenceResult.gaps.map((g, i) => (
                  <div key={i} className="flex justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-950/40 text-xs font-mono">
                    <span>Gap #{i + 1}: {g.startSec.toFixed(2)}s → {g.endSec.toFixed(2)}s</span>
                    <span className="text-slate-400">{g.durationSec.toFixed(2)}s</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 10 & 11. Waveform to Image & Spectrogram */}
          {(toolSlug === 'audio-waveform-to-image' || toolSlug === 'audio-spectrogram-viewer') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {toolSlug === 'audio-spectrogram-viewer' ? 'Audio Spectrogram Heatmap' : 'Render Waveform Graphic'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    High-resolution rendering generated from raw audio PCM data.
                  </p>
                </div>

                {toolSlug === 'audio-waveform-to-image' && (
                  <div className="flex gap-2">
                    {(['mirror', 'wave', 'bars'] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => setWaveformStyle(st)}
                        className={`px-3 py-1 rounded-xl text-xs font-semibold border ${
                          waveformStyle === st ? 'bg-violet-600 text-white border-violet-600' : 'border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                <canvas ref={canvasRef} width={800} height={260} className="w-full h-auto block" />
              </div>

              <button
                onClick={() => {
                  if (!canvasRef.current) return;
                  const dataUrl = canvasRef.current.toDataURL('image/png');
                  const a = document.createElement('a');
                  a.href = dataUrl;
                  a.download = `${file.name.replace(/\.[^/.]+$/, '')}_${toolSlug}.png`;
                  a.click();
                }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
              >
                <Download className="h-4 w-4" />
                <span>Download Image (PNG)</span>
              </button>
            </div>
          )}

          {/* 12, 13, 14, 19. BPM, Key, Freq, LUFS */}
          {(toolSlug === 'bpm-detector' ||
            toolSlug === 'audio-key-detector' ||
            toolSlug === 'audio-frequency-analyzer' ||
            toolSlug === 'audio-lufs-meter') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Analysis Overview</h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {bpmResult && (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Detected Tempo (BPM)</div>
                    <div className="text-2xl font-black text-violet-600 dark:text-violet-400 mt-1">
                      {bpmResult.bpm} BPM
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">{bpmResult.tempoName} ({bpmResult.confidence}% confidence)</div>
                  </div>
                )}

                {keyResult && (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Estimated Musical Key</div>
                    <div className="text-2xl font-black text-violet-600 dark:text-violet-400 mt-1">
                      {keyResult.key}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">Camelot Wheel: {keyResult.camelot}</div>
                  </div>
                )}

                {lufsResult && (
                  <>
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                      <div className="text-[11px] font-bold text-slate-400 uppercase">Integrated Loudness</div>
                      <div className="text-2xl font-black text-violet-600 dark:text-violet-400 mt-1">
                        {lufsResult.lufs} LUFS
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">Spotify Target: -14.0 LUFS</div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                      <div className="text-[11px] font-bold text-slate-400 uppercase">True Peak</div>
                      <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                        {lufsResult.truePeakDb} dBTP
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">Range: {lufsResult.rangeLU} LU</div>
                    </div>
                  </>
                )}

                {dominantFreq && (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Dominant Frequency</div>
                    <div className="text-2xl font-black text-violet-600 dark:text-violet-400 mt-1">
                      {dominantFreq.hz} Hz
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">Pitch Note: {dominantFreq.note}</div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 16. Segment Exporter */}
          {toolSlug === 'audio-segment-exporter' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Export Audio Segment</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold mb-1 block">Start Time (Seconds)</label>
                  <input
                    type="number"
                    min="0"
                    max={audioBuffer?.duration || 100}
                    step="0.5"
                    value={segmentStart}
                    onChange={(e) => setSegmentStart(parseFloat(e.target.value) || 0)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">End Time (Seconds)</label>
                  <input
                    type="number"
                    min="0.5"
                    max={audioBuffer?.duration || 100}
                    step="0.5"
                    value={segmentEnd}
                    onChange={(e) => setSegmentEnd(parseFloat(e.target.value) || 0)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <button
                onClick={handleExportSegment}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors"
              >
                <Scissors className="h-4 w-4" />
                <span>Export Sliced Segment</span>
              </button>

              {resultWavUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Extracted Audio Clip</h4>
                  <audio src={resultWavUrl} controls className="w-full" />
                  <a
                    href={resultWavUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_segment.wav`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Segment (WAV)</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 17. ID3 Tag Editor */}
          {toolSlug === 'id3-tag-editor' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">ID3v2 Metadata Fields</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold mb-1 block">Track Title</label>
                  <input
                    type="text"
                    value={id3Meta.title}
                    onChange={(e) => setId3Meta({ ...id3Meta, title: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">Artist</label>
                  <input
                    type="text"
                    value={id3Meta.artist}
                    onChange={(e) => setId3Meta({ ...id3Meta, artist: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">Album</label>
                  <input
                    type="text"
                    value={id3Meta.album}
                    onChange={(e) => setId3Meta({ ...id3Meta, album: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">Year</label>
                  <input
                    type="text"
                    value={id3Meta.year}
                    onChange={(e) => setId3Meta({ ...id3Meta, year: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">Genre</label>
                  <input
                    type="text"
                    value={id3Meta.genre}
                    onChange={(e) => setId3Meta({ ...id3Meta, genre: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1 block">Track Number</label>
                  <input
                    type="text"
                    value={id3Meta.track}
                    onChange={(e) => setId3Meta({ ...id3Meta, track: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveID3}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-violet-700 transition-colors"
              >
                <Tag className="h-4 w-4" />
                <span>Save ID3 Tags & Download MP3</span>
              </button>
            </div>
          )}

          {/* 18. Album Art Remover */}
          {toolSlug === 'album-art-remover' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Remove Embedded Cover Art</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Artwork detected: <span className="font-semibold text-violet-600">{id3Meta.hasArtwork ? 'Yes (APIC Frame present)' : 'No embedded picture'}</span>
              </p>

              <button
                onClick={handleRemoveAlbumArt}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-rose-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Strip Artwork & Download Clean MP3</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
