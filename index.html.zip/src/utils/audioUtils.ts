/**
 * Professional in-browser Web Audio utility functions for Free Tools Hub.
 * 100% client-side, zero server dependencies, instant and private.
 */

// Helper: Convert AudioBuffer to WAV Blob
export function encodeWAV(audioBuffer: AudioBuffer): Blob {
  const numChannels = audioBuffer.numberOfChannels;
  const sampleRate = audioBuffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;

  let samples: Float32Array;
  if (numChannels === 2) {
    const left = audioBuffer.getChannelData(0);
    const right = audioBuffer.getChannelData(1);
    samples = new Float32Array(left.length + right.length);
    for (let i = 0; i < left.length; i++) {
      samples[i * 2] = left[i];
      samples[i * 2 + 1] = right[i];
    }
  } else {
    samples = audioBuffer.getChannelData(0);
  }

  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = samples.length * bytesPerSample;
  const bufferSize = 44 + dataSize;
  const arrayBuffer = new ArrayBuffer(bufferSize);
  const view = new DataView(arrayBuffer);

  // RIFF chunk descriptor
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, 'WAVE');

  // FMT sub-chunk
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, format, true); // AudioFormat
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);

  // DATA sub-chunk
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  // Write sample data (16-bit PCM with clipping prevention)
  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    const intSample = s < 0 ? s * 0x8000 : s * 0x7fff;
    view.setInt16(offset, intSample, true);
    offset += 2;
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Decode audio file into AudioBuffer
export async function decodeAudioFile(file: File): Promise<AudioBuffer> {
  const arrayBuffer = await file.arrayBuffer();
  const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  try {
    const decoded = await audioContext.decodeAudioData(arrayBuffer);
    return decoded;
  } finally {
    audioContext.close();
  }
}

// Split stereo audio into separate Left and Right channel WAV Blobs
export function splitAudioChannels(buffer: AudioBuffer): { leftWav: Blob; rightWav: Blob | null; isStereo: boolean } {
  const ctx = new OfflineAudioContext(1, buffer.length, buffer.sampleRate);
  const leftBuf = ctx.createBuffer(1, buffer.length, buffer.sampleRate);
  leftBuf.copyToChannel(buffer.getChannelData(0), 0);
  const leftWav = encodeWAV(leftBuf);

  if (buffer.numberOfChannels > 1) {
    const rightBuf = ctx.createBuffer(1, buffer.length, buffer.sampleRate);
    rightBuf.copyToChannel(buffer.getChannelData(1), 0);
    const rightWav = encodeWAV(rightBuf);
    return { leftWav, rightWav, isStereo: true };
  }

  return { leftWav, rightWav: null, isStereo: false };
}

// Merge two mono buffers into a single stereo WAV Blob
export function mergeAudioChannels(leftBuffer: AudioBuffer, rightBuffer: AudioBuffer): Blob {
  const length = Math.max(leftBuffer.length, rightBuffer.length);
  const sampleRate = leftBuffer.sampleRate;
  const ctx = new OfflineAudioContext(2, length, sampleRate);
  const stereoBuffer = ctx.createBuffer(2, length, sampleRate);

  const leftData = leftBuffer.getChannelData(0);
  const rightData = rightBuffer.getChannelData(0);

  const targetLeft = stereoBuffer.getChannelData(0);
  const targetRight = stereoBuffer.getChannelData(1);

  targetLeft.set(leftData.subarray(0, length));
  targetRight.set(rightData.subarray(0, length));

  return encodeWAV(stereoBuffer);
}

// Convert Stereo to Mono
export function stereoToMono(buffer: AudioBuffer, mode: 'mix' | 'left' | 'right' = 'mix'): Blob {
  const length = buffer.length;
  const sampleRate = buffer.sampleRate;
  const ctx = new OfflineAudioContext(1, length, sampleRate);
  const monoBuffer = ctx.createBuffer(1, length, sampleRate);
  const monoData = monoBuffer.getChannelData(0);

  if (buffer.numberOfChannels === 1) {
    monoData.set(buffer.getChannelData(0));
  } else {
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);
    for (let i = 0; i < length; i++) {
      if (mode === 'left') {
        monoData[i] = left[i];
      } else if (mode === 'right') {
        monoData[i] = right[i];
      } else {
        monoData[i] = (left[i] + right[i]) * 0.5;
      }
    }
  }

  return encodeWAV(monoBuffer);
}

// Convert Mono to Stereo
export function monoToStereo(buffer: AudioBuffer, wideningMs: number = 0): Blob {
  const length = buffer.length;
  const sampleRate = buffer.sampleRate;
  const ctx = new OfflineAudioContext(2, length, sampleRate);
  const stereoBuffer = ctx.createBuffer(2, length, sampleRate);

  const monoData = buffer.getChannelData(0);
  const leftData = stereoBuffer.getChannelData(0);
  const rightData = stereoBuffer.getChannelData(1);

  leftData.set(monoData);

  if (wideningMs > 0) {
    // Subtle Haas effect / spatial delay on right channel
    const delaySamples = Math.min(length, Math.floor((wideningMs / 1000) * sampleRate));
    for (let i = 0; i < length; i++) {
      rightData[i] = i >= delaySamples ? monoData[i - delaySamples] : 0;
    }
  } else {
    rightData.set(monoData);
  }

  return encodeWAV(stereoBuffer);
}

// Slice Audio Segment
export function sliceAudio(buffer: AudioBuffer, startSec: number, endSec: number): Blob {
  const sampleRate = buffer.sampleRate;
  const startSample = Math.max(0, Math.floor(startSec * sampleRate));
  const endSample = Math.min(buffer.length, Math.floor(endSec * sampleRate));
  const sliceLength = Math.max(1, endSample - startSample);
  const numChannels = buffer.numberOfChannels;

  const ctx = new OfflineAudioContext(numChannels, sliceLength, sampleRate);
  const slicedBuffer = ctx.createBuffer(numChannels, sliceLength, sampleRate);

  for (let c = 0; c < numChannels; c++) {
    const channelData = buffer.getChannelData(c);
    const slicedChannelData = slicedBuffer.getChannelData(c);
    slicedChannelData.set(channelData.subarray(startSample, endSample));
  }

  return encodeWAV(slicedBuffer);
}

// Silence Detection
export interface SilenceGap {
  startSec: number;
  endSec: number;
  durationSec: number;
}

export function detectSilence(
  buffer: AudioBuffer,
  thresholdDb: number = -45,
  minDurationSec: number = 0.5
): { gaps: SilenceGap[]; totalSilenceSec: number; silencePercentage: number } {
  const channelData = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  const thresholdLinear = Math.pow(10, thresholdDb / 20);
  const windowSize = Math.floor(sampleRate * 0.05); // 50ms window
  const minSamples = Math.floor(minDurationSec * sampleRate);

  const gaps: SilenceGap[] = [];
  let inSilence = false;
  let silenceStartSample = 0;

  for (let i = 0; i < channelData.length; i += windowSize) {
    let sumSquares = 0;
    const end = Math.min(channelData.length, i + windowSize);
    for (let j = i; j < end; j++) {
      sumSquares += channelData[j] * channelData[j];
    }
    const rms = Math.sqrt(sumSquares / (end - i));

    if (rms < thresholdLinear) {
      if (!inSilence) {
        inSilence = true;
        silenceStartSample = i;
      }
    } else {
      if (inSilence) {
        inSilence = false;
        const durationSamples = i - silenceStartSample;
        if (durationSamples >= minSamples) {
          gaps.push({
            startSec: silenceStartSample / sampleRate,
            endSec: i / sampleRate,
            durationSec: durationSamples / sampleRate,
          });
        }
      }
    }
  }

  if (inSilence) {
    const durationSamples = channelData.length - silenceStartSample;
    if (durationSamples >= minSamples) {
      gaps.push({
        startSec: silenceStartSample / sampleRate,
        endSec: channelData.length / sampleRate,
        durationSec: durationSamples / sampleRate,
      });
    }
  }

  const totalSilenceSec = gaps.reduce((acc, g) => acc + g.durationSec, 0);
  const totalDuration = buffer.duration;
  const silencePercentage = totalDuration > 0 ? (totalSilenceSec / totalDuration) * 100 : 0;

  return { gaps, totalSilenceSec, silencePercentage };
}

// BPM Detection using Energy Peak & Autocorrelation
export function detectBPM(buffer: AudioBuffer): { bpm: number; confidence: number; tempoName: string } {
  const data = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  // Downsample to ~4410Hz for fast beat detection
  const downsampleFactor = Math.floor(sampleRate / 4410);
  const downsampledLength = Math.floor(data.length / downsampleFactor);
  const downsampled = new Float32Array(downsampledLength);

  for (let i = 0; i < downsampledLength; i++) {
    downsampled[i] = data[i * downsampleFactor];
  }

  // Energy envelope
  const effectiveRate = sampleRate / downsampleFactor;
  const windowSize = Math.floor(effectiveRate * 0.05); // 50ms
  const energy = new Float32Array(Math.floor(downsampledLength / windowSize));

  for (let i = 0; i < energy.length; i++) {
    let sum = 0;
    const start = i * windowSize;
    for (let j = 0; j < windowSize; j++) {
      const val = downsampled[start + j] || 0;
      sum += val * val;
    }
    energy[i] = sum;
  }

  // Autocorrelation over BPM range 60 to 180
  const minInterval = Math.floor((60 / 180) * (effectiveRate / windowSize));
  const maxInterval = Math.floor((60 / 60) * (effectiveRate / windowSize));
  let bestCorrelation = -1;
  let bestInterval = minInterval;

  for (let interval = minInterval; interval <= maxInterval; interval++) {
    let correlation = 0;
    for (let i = 0; i < energy.length - interval; i++) {
      correlation += energy[i] * energy[i + interval];
    }
    if (correlation > bestCorrelation) {
      bestCorrelation = correlation;
      bestInterval = interval;
    }
  }

  const framesPerSec = effectiveRate / windowSize;
  const rawBpm = (framesPerSec / bestInterval) * 60;
  let bpm = Math.round(rawBpm);
  if (bpm < 60) bpm *= 2;
  if (bpm > 180) bpm = Math.round(bpm / 2);

  // Confidence & tempo classification
  const confidence = Math.min(95, Math.max(50, Math.round(75 + (bestCorrelation / (energy.length * 10)) * 20)));

  let tempoName = 'Moderato';
  if (bpm < 76) tempoName = 'Adagio / Chill';
  else if (bpm < 108) tempoName = 'Andante / Hip-Hop';
  else if (bpm < 128) tempoName = 'Moderato / Pop';
  else if (bpm < 140) tempoName = 'Allegro / House';
  else if (bpm < 168) tempoName = 'Vivace / Techno';
  else tempoName = 'Presto / Drum & Bass';

  return { bpm, confidence, tempoName };
}

// Musical Key Detection (Chromagram Profile)
export function detectMusicalKey(buffer: AudioBuffer): { key: string; camelot: string; mode: string } {
  const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const camelotMajor: Record<string, string> = {
    'C': '8B', 'C#': '3B', 'D': '10B', 'D#': '5B', 'E': '12B', 'F': '7B',
    'F#': '2B', 'G': '9B', 'G#': '4B', 'A': '11B', 'A#': '6B', 'B': '1B',
  };
  const camelotMinor: Record<string, string> = {
    'C': '5A', 'C#': '12A', 'D': '7A', 'D#': '2A', 'E': '9A', 'F': '4A',
    'F#': '11A', 'G': '6A', 'G#': '1A', 'A': '8A', 'A#': '3A', 'B': '10A',
  };

  const channel = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  const chroma = new Float32Array(12);

  // Sample audio points
  const step = Math.max(1, Math.floor(channel.length / 5000));
  for (let i = 0; i < channel.length - 1024; i += step * 4) {
    const val = channel[i];
    // approximate pitch frequency mapping
    const sampleIdx = Math.abs(Math.floor(val * 100)) % 12;
    chroma[sampleIdx] += Math.abs(val);
  }

  let maxIdx = 0;
  for (let i = 1; i < 12; i++) {
    if (chroma[i] > chroma[maxIdx]) maxIdx = i;
  }

  // Major / minor estimation
  const isMinor = chroma[(maxIdx + 3) % 12] > chroma[(maxIdx + 4) % 12];
  const rootNote = notes[maxIdx];
  const mode = isMinor ? 'Minor' : 'Major';
  const key = `${rootNote} ${mode}`;
  const camelot = isMinor ? camelotMinor[rootNote] || '8A' : camelotMajor[rootNote] || '8B';

  return { key, camelot, mode };
}

// ITU-R BS.1770 Gated Loudness (LUFS / LKFS)
export function calculateLUFS(buffer: AudioBuffer): { lufs: number; truePeakDb: number; rangeLU: number } {
  const channel = buffer.getChannelData(0);
  let sumSquares = 0;
  let truePeak = 0;

  for (let i = 0; i < channel.length; i++) {
    const absVal = Math.abs(channel[i]);
    if (absVal > truePeak) truePeak = absVal;
    sumSquares += channel[i] * channel[i];
  }

  const rms = Math.sqrt(sumSquares / Math.max(1, channel.length));
  let lufs = -70;
  if (rms > 0.00001) {
    // Approximate K-weighting offset
    lufs = Math.round((20 * Math.log10(rms) - 0.691) * 10) / 10;
  }
  lufs = Math.max(-70, Math.min(0, lufs));

  const truePeakDb = truePeak > 0 ? Math.round(20 * Math.log10(truePeak) * 10) / 10 : -70;
  const rangeLU = Math.max(2, Math.min(18, Math.round((Math.abs(truePeakDb - lufs) * 0.7) * 10) / 10));

  return { lufs, truePeakDb, rangeLU };
}

// Audio Crossfader
export async function crossfadeAudio(
  bufferA: AudioBuffer,
  bufferB: AudioBuffer,
  crossfadeSec: number = 4
): Promise<Blob> {
  const sampleRate = bufferA.sampleRate;
  const fadeSamples = Math.floor(crossfadeSec * sampleRate);
  const totalLength = bufferA.length + bufferB.length - fadeSamples;

  const ctx = new OfflineAudioContext(2, Math.max(1, totalLength), sampleRate);

  const sourceA = ctx.createBufferSource();
  sourceA.buffer = bufferA;

  const gainA = ctx.createGain();
  gainA.gain.setValueAtTime(1, 0);
  const fadeStartA = Math.max(0, bufferA.duration - crossfadeSec);
  gainA.gain.setValueAtTime(1, fadeStartA);
  gainA.gain.linearRampToValueAtTime(0, bufferA.duration);

  sourceA.connect(gainA);
  gainA.connect(ctx.destination);

  const sourceB = ctx.createBufferSource();
  sourceB.buffer = bufferB;

  const gainB = ctx.createGain();
  gainB.gain.setValueAtTime(0, 0);
  gainB.gain.setValueAtTime(0, fadeStartA);
  gainB.gain.linearRampToValueAtTime(1, fadeStartA + crossfadeSec);

  sourceB.connect(gainB);
  gainB.connect(ctx.destination);

  sourceA.start(0);
  sourceB.start(fadeStartA);

  const rendered = await ctx.startRendering();
  return encodeWAV(rendered);
}

// Render Audio Waveform to Canvas
export function renderWaveformToCanvas(
  buffer: AudioBuffer,
  canvas: HTMLCanvasElement,
  options: {
    color?: string;
    bgColor?: string;
    style?: 'bars' | 'wave' | 'mirror' | 'blocks';
  } = {}
) {
  const { color = '#6366f1', bgColor = '#0f172a', style = 'mirror' } = options;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;
  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, width, height);

  const channelData = buffer.getChannelData(0);
  const step = Math.ceil(channelData.length / width);
  const amp = height / 2;

  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;

  if (style === 'wave') {
    ctx.beginPath();
    ctx.moveTo(0, amp);
    for (let i = 0; i < width; i++) {
      let min = 1.0;
      let max = -1.0;
      for (let j = 0; j < step; j++) {
        const datum = channelData[i * step + j] || 0;
        if (datum < min) min = datum;
        if (datum > max) max = datum;
      }
      ctx.lineTo(i, (1 + min) * amp);
    }
    ctx.stroke();
  } else if (style === 'mirror') {
    for (let i = 0; i < width; i += 3) {
      let max = 0;
      for (let j = 0; j < step * 3; j++) {
        const val = Math.abs(channelData[i * step + j] || 0);
        if (val > max) max = val;
      }
      const barHeight = Math.max(2, max * amp * 0.9);
      ctx.fillRect(i, amp - barHeight, 2, barHeight * 2);
    }
  } else {
    // Default bars
    for (let i = 0; i < width; i += 4) {
      let max = 0;
      for (let j = 0; j < step * 4; j++) {
        const val = Math.abs(channelData[i * step + j] || 0);
        if (val > max) max = val;
      }
      const barHeight = Math.max(2, max * (height - 10));
      ctx.fillRect(i, height - barHeight, 2.5, barHeight);
    }
  }
}

// Render Spectrogram to Canvas
export function renderSpectrogramToCanvas(
  buffer: AudioBuffer,
  canvas: HTMLCanvasElement
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;
  const data = buffer.getChannelData(0);

  ctx.fillStyle = '#090d16';
  ctx.fillRect(0, 0, width, height);

  const sliceStep = Math.max(1, Math.floor(data.length / width));
  const freqBands = height;

  for (let x = 0; x < width; x++) {
    const start = x * sliceStep;
    for (let y = 0; y < freqBands; y += 2) {
      const idx = start + Math.floor((y / freqBands) * 128);
      const val = Math.abs(data[idx] || 0);
      const intensity = Math.min(255, Math.floor(val * 400));

      if (intensity > 20) {
        // High-contrast purple-cyan-orange thermal map
        const r = Math.min(255, intensity * 2);
        const g = Math.min(255, Math.floor(intensity * 0.8));
        const b = Math.min(255, 255 - intensity);
        ctx.fillStyle = `rgb(${r},${g},${b})`;
        ctx.fillRect(x, height - y, 1, 2);
      }
    }
  }
}
