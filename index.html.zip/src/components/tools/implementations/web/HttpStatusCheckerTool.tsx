import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Activity, Clock, ArrowRight, AlertCircle, Loader2, RotateCcw, CheckCircle, HelpCircle } from 'lucide-react';

const HTTP_DEFINITIONS: Record<number, { title: string; meaning: string; type: 'success' | 'redirect' | 'client_error' | 'server_error' }> = {
  200: { title: '200 OK', meaning: 'The request succeeded and the server returned the requested resource.', type: 'success' },
  301: { title: '301 Moved Permanently', meaning: 'The requested resource has been permanently moved to a new URL. Search engines transfer ranking signals.', type: 'redirect' },
  302: { title: '302 Found (Temporary Redirect)', meaning: 'The resource temporarily resides at a different location. SEO signals are not transferred.', type: 'redirect' },
  304: { title: '304 Not Modified', meaning: 'Client cache is still fresh and does not need to re-download the resource.', type: 'redirect' },
  400: { title: '400 Bad Request', meaning: 'The server could not understand the request due to invalid syntax or parameters.', type: 'client_error' },
  401: { title: '401 Unauthorized', meaning: 'Authentication credentials are required to view this webpage.', type: 'client_error' },
  403: { title: '403 Forbidden', meaning: 'The server understood the request but refuses to authorize access.', type: 'client_error' },
  404: { title: '404 Not Found', meaning: 'The server could not find the requested webpage or resource.', type: 'client_error' },
  408: { title: '408 Request Timeout', meaning: 'The server timed out waiting for the client to complete sending the request.', type: 'client_error' },
  429: { title: '429 Too Many Requests', meaning: 'Rate limit exceeded. The user has sent too many requests in a given amount of time.', type: 'client_error' },
  500: { title: '500 Internal Server Error', meaning: 'The server encountered an unexpected condition that prevented it from fulfilling the request.', type: 'server_error' },
  502: { title: '502 Bad Gateway', meaning: 'The server was acting as a gateway or proxy and received an invalid response from upstream.', type: 'server_error' },
  503: { title: '503 Service Unavailable', meaning: 'The server is currently unable to handle the request due to maintenance or overload.', type: 'server_error' },
  504: { title: '504 Gateway Timeout', meaning: 'The gateway or reverse-proxy did not receive a timely response from the backend application.', type: 'server_error' },
};

export const HttpStatusCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    url: string;
    statusCode: number;
    statusText: string;
    responseTimeMs: number;
    headers: Record<string, string>;
    location: string | null;
    isRedirect: boolean;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const checkStatus = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a target URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch('/api/web/http-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to check HTTP status.');
      }

      setResult(data);
      showToast(`HTTP ${data.statusCode} ${data.statusText}`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Could not connect to the specified URL.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (code: number) => {
    if (code >= 200 && code < 300) return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800';
    if (code >= 300 && code < 400) return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800';
    if (code >= 400 && code < 500) return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800';
    return 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900';
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage or Endpoint URL
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && checkStatus()}
            placeholder="https://example.com/api/health"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={checkStatus}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Activity className="h-4 w-4" />}
            <span>{loading ? 'Testing...' : 'Check Status'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setResult(null);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {result && (
        <div className="space-y-6 animate-in fade-in">
          {/* Status Display Card */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className={`px-4 py-2 rounded-xl text-xl font-mono font-bold border ${getStatusColor(result.statusCode)}`}>
                  {result.statusCode}
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {result.statusText}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono break-all">{result.url}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
                <Clock className="h-3.5 w-3.5 text-indigo-500" />
                <span>Response Time: {result.responseTimeMs} ms</span>
              </div>
            </div>

            {/* Explanation */}
            {HTTP_DEFINITIONS[result.statusCode] && (
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                <span className="font-semibold text-slate-900 dark:text-white">
                  Meaning of {result.statusCode}:
                </span>
                <p className="text-slate-600 dark:text-slate-300">
                  {HTTP_DEFINITIONS[result.statusCode].meaning}
                </p>
              </div>
            )}

            {result.location && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-300">
                <ArrowRight className="h-4 w-4 shrink-0 text-blue-500" />
                <span>Redirect Location: </span>
                <a href={result.location} target="_blank" rel="noopener noreferrer" className="font-mono underline truncate">
                  {result.location}
                </a>
              </div>
            )}

            {/* Response Headers */}
            <div className="pt-2">
              <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Response Headers ({Object.keys(result.headers).length})
              </span>
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-200 p-3 text-xs font-mono max-h-48 overflow-y-auto space-y-1 scrollbar-thin">
                {Object.entries(result.headers).map(([key, value]) => (
                  <div key={key} className="flex gap-2">
                    <span className="text-indigo-400 select-none">{key}:</span>
                    <span className="text-slate-300 truncate">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Dictionary of Common HTTP Codes */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <HelpCircle className="h-3.5 w-3.5" />
              Common HTTP Status Codes Quick Guide
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
              {[200, 301, 302, 401, 403, 404, 429, 500, 502, 503].map((code) => {
                const def = HTTP_DEFINITIONS[code];
                return (
                  <div key={code} className="p-2.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30">
                    <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{code}</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{def.title.replace(`${code} `, '')}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">{def.meaning}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
