import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { ToolsProvider } from './context/ToolsContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { ToastContainer } from './components/common/ToastContainer';
import { SearchModal } from './components/tools/SearchModal';
import { ToolLayout } from './components/tools/ToolLayout';

import { HomePage } from './pages/HomePage';
import { AllToolsPage } from './pages/AllToolsPage';
import { CategoryPage } from './pages/CategoryPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { VideoToolsPage } from './pages/VideoToolsPage';
import { AiAssistantPage } from './pages/AiAssistantPage';

import { TOOLS_DATA, CATEGORIES } from './data/toolsData';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  // Handle browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    if (path === currentPath) return;
    try {
      const currentCount = parseInt(sessionStorage.getItem('fth_internal_nav') || '0', 10);
      sessionStorage.setItem('fth_internal_nav', String(currentCount + 1));
    } catch {
      // ignore
    }
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Route Resolution
  const renderCurrentView = () => {
    const cleanPath = currentPath.replace(/\/$/, '') || '/';

    // Home
    if (cleanPath === '/') {
      return <HomePage navigate={navigate} />;
    }

    // All tools directory
    if (cleanPath === '/tools') {
      return <AllToolsPage navigate={navigate} />;
    }

    // AI Assistant
    if (cleanPath === '/ai-assistant') {
      return <AiAssistantPage navigate={navigate} />;
    }

    // Favorites
    if (cleanPath === '/favorites') {
      return <FavoritesPage navigate={navigate} />;
    }

    // Informational pages
    if (cleanPath === '/about') {
      return <AboutPage navigate={navigate} />;
    }
    if (cleanPath === '/contact') {
      return <ContactPage navigate={navigate} />;
    }
    if (cleanPath === '/privacy') {
      return <PrivacyPage navigate={navigate} />;
    }
    if (cleanPath === '/terms') {
      return <TermsPage navigate={navigate} />;
    }

    // Dedicated Upgraded Video Tools Platform
    if (cleanPath === '/video-tools') {
      return <VideoToolsPage navigate={navigate} />;
    }

    // Category landing pages: /pdf-tools, /image-tools, /web-tools, etc.
    if (cleanPath === '/web-website-tools' || cleanPath === '/web') {
      return <CategoryPage categorySlug="web-tools" navigate={navigate} />;
    }
    const matchingCategory = CATEGORIES.find((c) => `/${c.slug}` === cleanPath);
    if (matchingCategory) {
      return <CategoryPage categorySlug={matchingCategory.slug} navigate={navigate} />;
    }

    // Individual tool pages: /tools/:slug or /calculators/:slug
    if (cleanPath.startsWith('/tools/')) {
      const slug = cleanPath.replace('/tools/', '');
      const tool = TOOLS_DATA.find((t) => t.slug === slug);
      if (tool) {
        return <ToolLayout tool={tool} navigate={navigate} />;
      }
    }

    // Fallback for direct calculator links (e.g. /calculators/percentage-calculator)
    if (cleanPath.startsWith('/calculators/')) {
      const slug = cleanPath.replace('/calculators/', '');
      const tool = TOOLS_DATA.find((t) => t.slug === slug);
      if (tool) {
        return <ToolLayout tool={tool} navigate={navigate} />;
      }
    }

    // Direct slug link fallback (e.g. /percentage-calculator)
    const directSlug = cleanPath.replace('/', '');
    const directTool = TOOLS_DATA.find((t) => t.slug === directSlug);
    if (directTool) {
      return <ToolLayout tool={directTool} navigate={navigate} />;
    }

    // 404 Not Found
    return <NotFoundPage navigate={navigate} />;
  };

  const isAiAssistant = currentPath === '/ai-assistant';

  return (
    <ThemeProvider>
      <ToolsProvider>
        <div className={`flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors ${isAiAssistant ? 'h-screen overflow-hidden' : 'min-h-screen'}`}>
          {/* Top Bar Navigation */}
          <Navbar currentPath={currentPath} navigate={navigate} />

          {/* Main View Area */}
          <main className={`flex-1 ${isAiAssistant ? 'h-[calc(100vh-4rem)] overflow-hidden' : ''}`}>
            {renderCurrentView()}
          </main>

          {/* Site Footer */}
          {!isAiAssistant && <Footer navigate={navigate} />}

          {/* Global Search Modal */}
          <SearchModal onSelectTool={(slug) => navigate(`/tools/${slug}`)} />

          {/* Global Toast System */}
          <ToastContainer />
        </div>
      </ToolsProvider>
    </ThemeProvider>
  );
}
