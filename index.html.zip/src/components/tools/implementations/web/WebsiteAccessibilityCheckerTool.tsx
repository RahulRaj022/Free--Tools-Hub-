import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { CheckCircle, AlertTriangle, XCircle, Info, AlertCircle, Loader2, RotateCcw } from 'lucide-react';

interface AuditItem {
  id: string;
  category: string;
  title: string;
  status: 'pass' | 'warning' | 'fail';
  description: string;
  remediation: string;
}

export const WebsiteAccessibilityCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [audits, setAudits] = useState<AuditItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'fail' | 'warning' | 'pass'>('all');
  const [error, setError] = useState<string | null>(null);

  const runAudit = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setAudits([]);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to inspect webpage.');
      }

      const html = data.html || '';
      const items: AuditItem[] = [];

      // 1. Check HTML lang attribute
      const langMatch = html.match(/<html[^>]*\blang=["']([^"']+)["']/i);
      if (langMatch) {
        items.push({
          id: 'lang',
          category: 'Document Language',
          title: 'HTML <html> element has a valid "lang" attribute',
          status: 'pass',
          description: `Found lang="${langMatch[1]}". This enables screen readers to pronounce words correctly.`,
          remediation: 'No action needed.',
        });
      } else {
        items.push({
          id: 'lang',
          category: 'Document Language',
          title: 'Missing "lang" attribute on <html> element',
          status: 'fail',
          description: 'The root <html> element lacks a language identifier.',
          remediation: 'Add lang="en" (or your language code) to the opening <html lang="en"> tag.',
        });
      }

      // 2. Check Page <title>
      const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
      if (titleMatch && titleMatch[1].trim()) {
        items.push({
          id: 'title',
          category: 'Document Structure',
          title: 'Document has a descriptive <title>',
          status: 'pass',
          description: `Found title: "${titleMatch[1].trim().slice(0, 50)}...".`,
          remediation: 'No action needed.',
        });
      } else {
        items.push({
          id: 'title',
          category: 'Document Structure',
          title: 'Missing or empty <title> tag',
          status: 'fail',
          description: 'A webpage title is essential for orientation and browser history.',
          remediation: 'Add a descriptive <title> tag inside the <head> element.',
        });
      }

      // 3. Check H1 Heading presence
      const h1Matches = html.match(/<h1\b[^>]*>/gi) || [];
      if (h1Matches.length === 1) {
        items.push({
          id: 'h1',
          category: 'Headings & Outline',
          title: 'Page contains exactly one main <h1> heading',
          status: 'pass',
          description: 'A single H1 creates a clear, unambiguous document outline.',
          remediation: 'No action needed.',
        });
      } else if (h1Matches.length === 0) {
        items.push({
          id: 'h1',
          category: 'Headings & Outline',
          title: 'Missing top-level <h1> heading',
          status: 'warning',
          description: 'Screen reader users rely on H1 headings to jump to the primary content.',
          remediation: 'Ensure each page has a single semantic <h1> describing its topic.',
        });
      } else {
        items.push({
          id: 'h1',
          category: 'Headings & Outline',
          title: `Multiple <h1> headings found (${h1Matches.length})`,
          status: 'warning',
          description: 'Multiple H1 tags can confuse navigation hierarchies in assistive tech.',
          remediation: 'Consider using subheadings (<h2>, <h3>) for secondary sections.',
        });
      }

      // 4. Check Image Alt Attributes
      const imgMatches = html.match(/<img\b[^>]*>/gi) || [];
      let missingAltCount = 0;
      imgMatches.forEach((imgTag: string) => {
        if (!/\balt\s*=/i.test(imgTag)) {
          missingAltCount++;
        }
      });

      if (imgMatches.length === 0) {
        items.push({
          id: 'alt',
          category: 'Images & Media',
          title: 'No <img> elements found on page',
          status: 'pass',
          description: 'No image elements to audit.',
          remediation: 'No action needed.',
        });
      } else if (missingAltCount === 0) {
        items.push({
          id: 'alt',
          category: 'Images & Media',
          title: `All ${imgMatches.length} images have "alt" attributes`,
          status: 'pass',
          description: 'Images provide alternative text for visually impaired visitors.',
          remediation: 'No action needed.',
        });
      } else {
        items.push({
          id: 'alt',
          category: 'Images & Media',
          title: `${missingAltCount} out of ${imgMatches.length} images are missing "alt" attributes`,
          status: 'fail',
          description: 'Screen readers cannot describe images without alt text.',
          remediation: 'Add descriptive alt="Description of image" or alt="" for decorative graphics.',
        });
      }

      // 5. Check Viewport Zoom Disabling
      const viewportMatch = html.match(/<meta[^>]*name=["']viewport["'][^>]*content=["']([^"']*)["']/i);
      const vpContent = viewportMatch ? viewportMatch[1] : '';
      if (vpContent.includes('user-scalable=no') || vpContent.includes('maximum-scale=1')) {
        items.push({
          id: 'viewport_zoom',
          category: 'Mobile & Zoom',
          title: 'Viewport disables user pinch-to-zoom',
          status: 'fail',
          description: 'Disabling zoom prevents low-vision users from magnifying text on mobile devices.',
          remediation: 'Remove "user-scalable=no" and "maximum-scale=1" from your viewport meta tag.',
        });
      } else {
        items.push({
          id: 'viewport_zoom',
          category: 'Mobile & Zoom',
          title: 'User zoom is enabled on mobile viewports',
          status: 'pass',
          description: 'Allows users with visual impairments to zoom and scale interface text.',
          remediation: 'No action needed.',
        });
      }

      // 6. Check generic link text ("click here", "read more")
      const genericLinkRegex = /<a\b[^>]*>(?:click here|read more|more|learn more)<\/a>/gi;
      const genericLinks = html.match(genericLinkRegex) || [];
      if (genericLinks.length > 0) {
        items.push({
          id: 'generic_links',
          category: 'Links & Navigation',
          title: `Found ${genericLinks.length} non-descriptive links ("click here", "read more")`,
          status: 'warning',
          description: 'Screen readers frequently browse lists of links out of context.',
          remediation: 'Use descriptive anchor text like "Read our privacy policy" rather than "click here".',
        });
      } else {
        items.push({
          id: 'generic_links',
          category: 'Links & Navigation',
          title: 'Link text appears descriptive and contextual',
          status: 'pass',
          description: 'Links convey meaningful purpose when read by assistive devices.',
          remediation: 'No action needed.',
        });
      }

      setAudits(items);
      showToast('Automated accessibility scan completed!', 'success');
    } catch (err: any) {
      setError(err?.message || 'Error executing accessibility audit.');
    } finally {
      setLoading(false);
    }
  };

  const passCount = audits.filter((a) => a.status === 'pass').length;
  const warnCount = audits.filter((a) => a.status === 'warning').length;
  const failCount = audits.filter((a) => a.status === 'fail').length;

  const filtered = audits.filter((a) => {
    if (filter === 'pass') return a.status === 'pass';
    if (filter === 'warning') return a.status === 'warning';
    if (filter === 'fail') return a.status === 'fail';
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage Address for Baseline A11y Audit
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && runAudit()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={runAudit}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle className="h-4 w-4" />}
            <span>{loading ? 'Auditing A11y...' : 'Audit Accessibility'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setAudits([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {audits.length > 0 && (
        <div className="space-y-6 animate-in fade-in">
          {/* Summary Pills */}
          <div className="grid grid-cols-3 gap-3">
            <div
              onClick={() => setFilter('pass')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                filter === 'pass'
                  ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/40 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                <CheckCircle className="h-4 w-4" />
                <span>Passed</span>
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                {passCount}
              </div>
            </div>

            <div
              onClick={() => setFilter('warning')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                filter === 'warning'
                  ? 'border-amber-500 bg-amber-50/60 dark:bg-amber-950/40 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold">
                <AlertTriangle className="h-4 w-4" />
                <span>Warnings</span>
              </div>
              <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-1">
                {warnCount}
              </div>
            </div>

            <div
              onClick={() => setFilter('fail')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                filter === 'fail'
                  ? 'border-rose-500 bg-rose-50/60 dark:bg-rose-950/40 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 font-semibold">
                <XCircle className="h-4 w-4" />
                <span>Needs Attention</span>
              </div>
              <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-1">
                {failCount}
              </div>
            </div>
          </div>

          {/* Audit Results List */}
          <div className="space-y-3">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {item.status === 'pass' && <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />}
                    {item.status === 'warning' && <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />}
                    {item.status === 'fail' && <XCircle className="h-4 w-4 text-rose-500 shrink-0" />}
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">{item.title}</h4>
                  </div>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500">
                    {item.category}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 pl-6.5">{item.description}</p>

                {item.remediation && item.status !== 'pass' && (
                  <div className="ml-6.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs text-slate-700 dark:text-slate-300 font-mono">
                    <span className="font-bold text-indigo-600 dark:text-indigo-400">Remediation: </span>
                    {item.remediation}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 space-y-1">
            <div className="font-semibold text-slate-700 dark:text-slate-300">
              Automated Baseline Check Notice:
            </div>
            <p>
              This tool provides an automated preliminary scan for common structural issues (alt text, headings, lang attributes). Full WCAG 2.1 AA compliance requires comprehensive manual auditing, keyboard accessibility testing, and screen reader verification.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
