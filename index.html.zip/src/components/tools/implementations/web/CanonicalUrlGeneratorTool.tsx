import React, { useState, useMemo } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Link as LinkIcon, Copy, Check, Info } from 'lucide-react';

export const CanonicalUrlGeneratorTool: React.FC = () => {
  const { showToast } = useTools();
  const [inputUrl, setInputUrl] = useState(
    'https://example.com/products/headphones?utm_source=newsletter&utm_medium=email&ref=campaign123'
  );
  const [stripParams, setStripParams] = useState(true);
  const [forceHttps, setForceHttps] = useState(true);
  const [lowercaseHost, setLowercaseHost] = useState(true);
  const [trailingSlash, setTrailingSlash] = useState<'keep' | 'add' | 'remove'>('keep');
  const [copied, setCopied] = useState(false);

  const normalizedResult = useMemo(() => {
    let raw = inputUrl.trim();
    if (!raw) return { url: '', tag: '', removedParams: [] };

    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      raw = (forceHttps ? 'https://' : 'http://') + raw;
    }

    try {
      const parsed = new URL(raw);

      if (forceHttps) {
        parsed.protocol = 'https:';
      }

      if (lowercaseHost) {
        parsed.hostname = parsed.hostname.toLowerCase();
      }

      const removed: string[] = [];
      if (stripParams) {
        const trackingKeys = [
          'utm_source',
          'utm_medium',
          'utm_campaign',
          'utm_term',
          'utm_content',
          'ref',
          'fbclid',
          'gclid',
          '_ga',
          'mc_cid',
          'mc_eid',
        ];

        trackingKeys.forEach((key) => {
          if (parsed.searchParams.has(key)) {
            removed.push(`${key}=${parsed.searchParams.get(key)}`);
            parsed.searchParams.delete(key);
          }
        });
      }

      let pathname = parsed.pathname;
      if (trailingSlash === 'add' && !pathname.endsWith('/') && !pathname.includes('.')) {
        pathname += '/';
      } else if (trailingSlash === 'remove' && pathname.endsWith('/') && pathname !== '/') {
        pathname = pathname.slice(0, -1);
      }
      parsed.pathname = pathname;

      const finalUrl = parsed.toString();
      const tag = `<link rel="canonical" href="${finalUrl}" />`;

      return {
        url: finalUrl,
        tag,
        removedParams: removed,
      };
    } catch {
      return { url: '', tag: '<!-- Invalid URL format -->', removedParams: [] };
    }
  }, [inputUrl, stripParams, forceHttps, lowercaseHost, trailingSlash]);

  const handleCopy = () => {
    if (!normalizedResult.tag) return;
    navigator.clipboard.writeText(normalizedResult.tag);
    setCopied(true);
    showToast('Canonical link tag copied!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Input & Options */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                Target Webpage URL
              </label>
              <input
                type="text"
                value={inputUrl}
                onChange={(e) => setInputUrl(e.target.value)}
                placeholder="https://example.com/page?utm_source=facebook"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-mono focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Normalization Rules
              </span>

              <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={stripParams}
                  onChange={(e) => setStripParams(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Strip UTM, social, and ad tracking query parameters</span>
              </label>

              <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={forceHttps}
                  onChange={(e) => setForceHttps(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Enforce secure HTTPS protocol</span>
              </label>

              <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={lowercaseHost}
                  onChange={(e) => setLowercaseHost(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Lowercase domain hostname</span>
              </label>

              <div className="pt-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Trailing Slash Behavior
                </label>
                <select
                  value={trailingSlash}
                  onChange={(e: any) => setTrailingSlash(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-2 text-xs text-slate-900 dark:text-white"
                >
                  <option value="keep">Keep as provided</option>
                  <option value="add">Force trailing slash (/)</option>
                  <option value="remove">Remove trailing slash</option>
                </select>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 text-xs text-indigo-900 dark:text-indigo-300">
            <Info className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold mb-0.5">Why are Canonical URLs critical for SEO?</p>
              When the same page is accessed with different parameters (e.g. ?utm_source=twitter vs ?ref=email), search engines can consider them duplicates. A canonical tag signals the authoritative master page.
            </div>
          </div>
        </div>

        {/* Right Output */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Generated Canonical Tag
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Copy HTML Tag'}</span>
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs overflow-x-auto">
              <code>{normalizedResult.tag}</code>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="font-semibold text-slate-700 dark:text-slate-300">
                Normalized Master URL:
              </div>
              <div className="font-mono text-indigo-600 dark:text-indigo-400 break-all">
                {normalizedResult.url || '—'}
              </div>
            </div>

            {normalizedResult.removedParams.length > 0 && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className="font-semibold text-slate-600 dark:text-slate-400">
                  Cleaned Tracking Parameters ({normalizedResult.removedParams.length}):
                </span>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {normalizedResult.removedParams.map((p, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-[10px] font-mono text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-900"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
