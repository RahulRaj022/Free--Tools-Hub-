import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { FileText, Copy, Check, Download, AlertCircle, Loader2, RotateCcw, Clock, Mic } from 'lucide-react';

export const WebsiteWordCounterTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<{
    words: number;
    characters: number;
    charactersNoSpaces: number;
    sentences: number;
    paragraphs: number;
    readingTimeMin: number;
    speakingTimeMin: number;
    topKeywords: { word: string; count: number }[];
    extractedText: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeWordCount = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a target URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setStats(null);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch webpage.');
      }

      const rawHtml = data.html || '';

      // Strip <script>, <style>, <nav>, <header>, <footer>
      const cleanHtml = rawHtml
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
        .replace(/<nav\b[^<]*(?:(?!<\/nav>)<[^<]*)*<\/nav>/gi, ' ')
        .replace(/<header\b[^<]*(?:(?!<\/header>)<[^<]*)*<\/header>/gi, ' ')
        .replace(/<footer\b[^<]*(?:(?!<\/footer>)<[^<]*)*<\/footer>/gi, ' ')
        .replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, ' ');

      // Strip all tags and decode common entities
      const text = cleanHtml
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/gi, ' ')
        .replace(/&amp;/gi, '&')
        .replace(/&lt;/gi, '<')
        .replace(/&gt;/gi, '>')
        .replace(/\s+/g, ' ')
        .trim();

      const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
      const characters = text.length;
      const charactersNoSpaces = text.replace(/\s/g, '').length;
      const sentences = text.split(/[.!?]+/).filter((s: string) => s.trim().length > 0).length;
      const paragraphs = text.split(/\n+/).filter((p: string) => p.trim().length > 0).length || 1;

      // Calculate keywords
      const stopWords = new Set([
        'the', 'and', 'for', 'with', 'this', 'that', 'from', 'your', 'have', 'more',
        'are', 'was', 'were', 'which', 'will', 'about', 'they', 'what', 'when', 'make',
      ]);
      const wordList = text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .split(/\s+/)
        .filter((w: string) => w.length > 3 && !stopWords.has(w));

      const freq: Record<string, number> = {};
      wordList.forEach((w: string) => (freq[w] = (freq[w] || 0) + 1));
      const topKeywords = Object.entries(freq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([word, count]) => ({ word, count }));

      setStats({
        words,
        characters,
        charactersNoSpaces,
        sentences,
        paragraphs,
        readingTimeMin: Math.max(1, Math.round(words / 200)),
        speakingTimeMin: Math.max(1, Math.round(words / 130)),
        topKeywords,
        extractedText: text.slice(0, 3000), // capped preview
      });

      showToast(`Analyzed ${words} words!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error analyzing word count.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = () => {
    if (!stats) return;
    navigator.clipboard.writeText(stats.extractedText);
    setCopied(true);
    showToast('Copied extracted text!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadText = () => {
    if (!stats) return;
    const blob = new Blob([stats.extractedText], { type: 'text/plain' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `text_${url.replace(/[^a-z0-9]/gi, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(u);
    showToast('Downloaded text.txt!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage Address to Count Words
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && analyzeWordCount()}
            placeholder="https://example.com/article"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={analyzeWordCount}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
            <span>{loading ? 'Extracting...' : 'Count Words'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setStats(null);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {stats && (
        <div className="space-y-6 animate-in fade-in">
          {/* Main Stat Counters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
              <span className="text-xs text-slate-500">Total Words</span>
              <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5">
                {stats.words.toLocaleString()}
              </div>
            </div>

            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
              <span className="text-xs text-slate-500">Characters (all)</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                {stats.characters.toLocaleString()}
              </div>
              <span className="text-[10px] text-slate-400">
                {stats.charactersNoSpaces.toLocaleString()} no spaces
              </span>
            </div>

            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
              <span className="text-xs text-slate-500">Reading Time</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5 flex items-center gap-1.5">
                <Clock className="h-5 w-5 text-emerald-500" />
                <span>~{stats.readingTimeMin} min</span>
              </div>
              <span className="text-[10px] text-slate-400">at 200 wpm</span>
            </div>

            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
              <span className="text-xs text-slate-500">Speaking Time</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5 flex items-center gap-1.5">
                <Mic className="h-5 w-5 text-amber-500" />
                <span>~{stats.speakingTimeMin} min</span>
              </div>
              <span className="text-[10px] text-slate-400">at 130 wpm</span>
            </div>
          </div>

          {/* Top Keywords */}
          {stats.topKeywords.length > 0 && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Top Keywords Found
              </h4>
              <div className="flex flex-wrap gap-2">
                {stats.topKeywords.map((k) => (
                  <span
                    key={k.word}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200"
                  >
                    <span>{k.word}</span>
                    <span className="font-mono text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 font-bold">
                      {k.count}
                    </span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Extracted Text Preview */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Clean Extracted Text Preview
              </h4>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyText}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Text'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownloadText}
                  className="flex items-center gap-1.5 px-3.5 py-1 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download .txt</span>
                </button>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans max-h-64 overflow-y-auto scrollbar-thin">
              {stats.extractedText}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
