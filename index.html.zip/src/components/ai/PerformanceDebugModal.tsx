import React from 'react';
import { X, Zap, Cpu, Clock, Layers, MessageSquare, Gauge } from 'lucide-react';
import { StreamStats } from '../../services/aiService';

interface PerformanceDebugModalProps {
  stats: StreamStats | null;
  messageCount: number;
  isOpen: boolean;
  onClose: () => void;
}

export const PerformanceDebugModal: React.FC<PerformanceDebugModalProps> = ({
  stats,
  messageCount,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const ttft = stats?.ttftMs ?? null;
  const total = stats?.totalMs ?? null;
  const chars = stats?.charCount ?? 0;
  // Approximation: ~4 chars per token
  const estTokens = Math.round(chars / 4);
  const genDurationSec = total && ttft ? Math.max((total - ttft) / 1000, 0.05) : null;
  const tokensPerSec = genDurationSec && estTokens ? (estTokens / genDurationSec).toFixed(1) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-md rounded-2xl border border-slate-700/80 bg-slate-900 text-slate-100 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-800/60">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-emerald-400" />
            <h3 className="text-xs font-bold tracking-wide uppercase text-slate-200">
              AI Performance Telemetry (Dev Mode)
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Metrics Grid */}
        <div className="p-4 space-y-3.5 text-xs font-mono">
          <div className="grid grid-cols-2 gap-2.5">
            {/* TTFT */}
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Clock className="h-3.5 w-3.5 text-indigo-400" />
                <span>TTFT (First Token)</span>
              </div>
              <div className="text-base font-bold text-white">
                {ttft !== null ? `${ttft} ms` : '—'}
              </div>
            </div>

            {/* Total Duration */}
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Clock className="h-3.5 w-3.5 text-emerald-400" />
                <span>Total Response Time</span>
              </div>
              <div className="text-base font-bold text-white">
                {total !== null ? `${(total / 1000).toFixed(2)} s` : '—'}
              </div>
            </div>

            {/* Tokens Per Second */}
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Gauge className="h-3.5 w-3.5 text-amber-400" />
                <span>Tokens / Sec (Est.)</span>
              </div>
              <div className="text-base font-bold text-white">
                {tokensPerSec ? `${tokensPerSec} tps` : '—'}
              </div>
            </div>

            {/* Active Model */}
            <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px] mb-1">
                <Cpu className="h-3.5 w-3.5 text-purple-400" />
                <span>Model Engine</span>
              </div>
              <div className="text-xs font-bold text-slate-200 truncate">
                {stats?.model || 'gemini-3.8-flash'}
              </div>
            </div>
          </div>

          {/* Context & Batching Stats */}
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 space-y-2 text-[11px]">
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5 text-slate-400">
                <MessageSquare className="h-3.5 w-3.5" />
                <span>Context Messages</span>
              </span>
              <span className="font-semibold text-white">{messageCount} in conversation</span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5 text-slate-400">
                <Layers className="h-3.5 w-3.5" />
                <span>Streaming Batch Interval</span>
              </span>
              <span className="font-semibold text-emerald-400">40ms UI throttling</span>
            </div>

            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5 text-slate-400">
                <Zap className="h-3.5 w-3.5" />
                <span>Reasoning Overhead</span>
              </span>
              <span className="font-semibold text-indigo-400">ThinkingLevel.LOW</span>
            </div>
          </div>

          <div className="text-[10px] text-slate-500 text-center pt-1 font-sans">
            Only visible in local development. Never exposed in production.
          </div>
        </div>
      </div>
    </div>
  );
};
