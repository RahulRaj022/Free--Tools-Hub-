import React, { useState, useRef, useEffect } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { UploadCloud, Download, RefreshCw, RotateCw, FlipHorizontal, FlipVertical, Sliders, Check, Image as ImageIcon } from 'lucide-react';

interface ImageToolsProps {
  toolSlug: string;
}

export const ImageTools: React.FC<ImageToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // Shared file state
  const [selectedImage, setSelectedImage] = useState<{
    file: File;
    name: string;
    originalSize: number;
    url: string;
    width: number;
    height: number;
  } | null>(null);

  // Compression state
  const [quality, setQuality] = useState<number>(0.8);
  const [compressedResult, setCompressedResult] = useState<{
    url: string;
    size: number;
    width: number;
    height: number;
  } | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Resizer state
  const [targetWidth, setTargetWidth] = useState<number>(800);
  const [targetHeight, setTargetHeight] = useState<number>(600);
  const [lockAspectRatio, setLockAspectRatio] = useState<boolean>(true);
  const [aspectRatio, setAspectRatio] = useState<number>(1);
  const [exportFormat, setExportFormat] = useState<'image/jpeg' | 'image/png' | 'image/webp'>('image/jpeg');

  // Convert state
  const [jpgBgColor, setJpgBgColor] = useState<string>('#FFFFFF');

  // Effects / Rotator state
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [flipH, setFlipH] = useState<boolean>(false);
  const [flipV, setFlipV] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState<'none' | 'grayscale' | 'sepia' | 'invert'>('none');

  // Cropper state
  const [cropPreset, setCropPreset] = useState<'free' | '1:1' | '16:9' | '4:3'>('1:1');
  const [cropW, setCropW] = useState<number>(400);
  const [cropH, setCropH] = useState<number>(400);
  const [cropX, setCropX] = useState<number>(0);
  const [cropY, setCropY] = useState<number>(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // File handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (JPG, PNG, WebP)', 'error');
      return;
    }

    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      setSelectedImage({
        file,
        name: file.name,
        originalSize: file.size,
        url,
        width: img.width,
        height: img.height,
      });
      setTargetWidth(img.width);
      setTargetHeight(img.height);
      setAspectRatio(img.width / img.height);
      setRotationAngle(0);
      setFlipH(false);
      setFlipV(false);
      setActiveFilter('none');
      showToast('Image loaded successfully', 'success');
    };
    img.src = url;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        setSelectedImage({
          file,
          name: file.name,
          originalSize: file.size,
          url,
          width: img.width,
          height: img.height,
        });
        setTargetWidth(img.width);
        setTargetHeight(img.height);
        setAspectRatio(img.width / img.height);
        showToast('Image loaded', 'success');
      };
      img.src = url;
    }
  };

  // 1. COMPRESS IMAGE EFFECT
  useEffect(() => {
    if (!selectedImage) return;

    const processImage = () => {
      setIsProcessing(true);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // If target format is JPEG or converting from PNG to JPEG, fill background
        if (toolSlug === 'png-to-jpg' || (toolSlug === 'image-compressor' && selectedImage.file.type === 'image/jpeg')) {
          ctx.fillStyle = jpgBgColor;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        ctx.drawImage(img, 0, 0);

        let mimeType = selectedImage.file.type;
        if (toolSlug === 'jpg-to-png') mimeType = 'image/png';
        else if (toolSlug === 'png-to-jpg') mimeType = 'image/jpeg';
        else if (toolSlug === 'webp-converter') mimeType = 'image/webp';
        else if (toolSlug === 'image-compressor') {
          mimeType = selectedImage.file.type === 'image/png' ? 'image/webp' : 'image/jpeg';
        }

        canvas.toBlob(
          (blob) => {
            if (blob) {
              const resUrl = URL.createObjectURL(blob);
              setCompressedResult({
                url: resUrl,
                size: blob.size,
                width: img.width,
                height: img.height,
              });
            }
            setIsProcessing(false);
          },
          mimeType,
          quality
        );
      };
      img.src = selectedImage.url;
    };

    processImage();
  }, [selectedImage, quality, toolSlug, jpgBgColor]);

  // 2. RESIZE HANDLERS
  const handleWidthChange = (val: number) => {
    setTargetWidth(val);
    if (lockAspectRatio && aspectRatio > 0) {
      setTargetHeight(Math.round(val / aspectRatio));
    }
  };

  const handleHeightChange = (val: number) => {
    setTargetHeight(val);
    if (lockAspectRatio && aspectRatio > 0) {
      setTargetWidth(Math.round(val * aspectRatio));
    }
  };

  // 3. EXECUTE RESIZE & DOWNLOAD
  const handleExecuteResize = () => {
    if (!selectedImage) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Fill background if JPEG
      if (exportFormat === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
      }

      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const ext = exportFormat === 'image/png' ? 'png' : exportFormat === 'image/webp' ? 'webp' : 'jpg';
            a.href = url;
            a.download = `resized_${targetWidth}x${targetHeight}_${selectedImage.name.replace(/\.[^/.]+$/, '')}.${ext}`;
            a.click();
            URL.revokeObjectURL(url);
            showToast('Downloaded resized image!', 'success');
          }
        },
        exportFormat,
        0.92
      );
    };
    img.src = selectedImage.url;
  };

  // 4. EXECUTE EFFECTS & ROTATION DOWNLOAD
  const handleExecuteEffects = () => {
    if (!selectedImage) return;

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const isRotated90or270 = rotationAngle === 90 || rotationAngle === 270;
      canvas.width = isRotated90or270 ? img.height : img.width;
      canvas.height = isRotated90or270 ? img.width : img.height;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotationAngle * Math.PI) / 180);
      ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);

      // Apply filter
      if (activeFilter === 'grayscale') ctx.filter = 'grayscale(100%)';
      else if (activeFilter === 'sepia') ctx.filter = 'sepia(100%)';
      else if (activeFilter === 'invert') ctx.filter = 'invert(100%)';
      else ctx.filter = 'none';

      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      ctx.restore();

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `edited_${selectedImage.name}`;
          a.click();
          URL.revokeObjectURL(url);
          showToast('Downloaded edited image!', 'success');
        }
      }, 'image/png');
    };
    img.src = selectedImage.url;
  };

  const applyCropPreset = (preset: 'free' | '1:1' | '16:9' | '4:3') => {
    setCropPreset(preset);
    if (!selectedImage) return;
    const { width, height } = selectedImage;
    if (preset === '1:1') {
      const size = Math.min(width, height);
      setCropW(size);
      setCropH(size);
      setCropX(Math.round((width - size) / 2));
      setCropY(Math.round((height - size) / 2));
    } else if (preset === '16:9') {
      let w = width;
      let h = Math.round(width * (9 / 16));
      if (h > height) {
        h = height;
        w = Math.round(height * (16 / 9));
      }
      setCropW(w);
      setCropH(h);
      setCropX(Math.round((width - w) / 2));
      setCropY(Math.round((height - h) / 2));
    } else if (preset === '4:3') {
      let w = width;
      let h = Math.round(width * (3 / 4));
      if (h > height) {
        h = height;
        w = Math.round(height * (4 / 3));
      }
      setCropW(w);
      setCropH(h);
      setCropX(Math.round((width - w) / 2));
      setCropY(Math.round((height - h) / 2));
    } else {
      setCropW(Math.round(width * 0.8));
      setCropH(Math.round(height * 0.8));
      setCropX(Math.round(width * 0.1));
      setCropY(Math.round(height * 0.1));
    }
  };

  const handleExecuteCrop = () => {
    if (!selectedImage) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const w = Math.min(cropW, img.width - cropX);
      const h = Math.min(cropH, img.height - cropY);
      canvas.width = Math.max(1, w);
      canvas.height = Math.max(1, h);
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, cropX, cropY, w, h, 0, 0, w, h);
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `cropped_${selectedImage.name}`;
          a.click();
          URL.revokeObjectURL(url);
          showToast('Downloaded cropped image!', 'success');
        }
      }, selectedImage.file.type || 'image/png');
    };
    img.src = selectedImage.url;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Upload Dropzone if no image or to replace */}
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        className={`relative rounded-2xl border-2 border-dashed p-6 sm:p-10 text-center transition-colors ${
          selectedImage
            ? 'border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50'
            : 'border-indigo-300 dark:border-indigo-800 bg-indigo-50/20 dark:bg-indigo-950/20 hover:border-indigo-500'
        }`}
      >
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleFileChange}
          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
        />
        <div className="flex flex-col items-center justify-center pointer-events-none">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 mb-3">
            <UploadCloud className="h-6 w-6" />
          </div>
          <p className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white">
            {selectedImage ? 'Click or drop another file to change image' : 'Drag & Drop your image here'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Supports JPG, JPEG, PNG, and WebP (up to 25MB)
          </p>
        </div>
      </div>

      {selectedImage && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Column */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* File Info */}
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-900 dark:text-white truncate block max-w-xs">
                  {selectedImage.name}
                </span>
                <span className="text-slate-500">
                  {selectedImage.width} × {selectedImage.height} px · {formatFileSize(selectedImage.originalSize)}
                </span>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="text-xs text-slate-400 hover:text-rose-500"
              >
                Remove
              </button>
            </div>

            {/* A. COMPRESSOR SETTINGS */}
            {toolSlug === 'image-compressor' && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-900 dark:text-white">
                  <span>Compression Quality</span>
                  <span className="font-mono text-indigo-600 dark:text-indigo-400">
                    {Math.round(quality * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1.0"
                  step="0.05"
                  value={quality}
                  onChange={(e) => setQuality(parseFloat(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>Smaller Size (More compressed)</span>
                  <span>Higher Quality</span>
                </div>
              </div>
            )}

            {/* B. RESIZER SETTINGS */}
            {toolSlug === 'image-resizer' && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Width (px)
                    </label>
                    <input
                      type="number"
                      value={targetWidth}
                      onChange={(e) => handleWidthChange(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Height (px)
                    </label>
                    <input
                      type="number"
                      value={targetHeight}
                      onChange={(e) => handleHeightChange(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full px-3 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lockAspectRatio}
                      onChange={(e) => setLockAspectRatio(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600"
                    />
                    Lock Aspect Ratio
                  </label>

                  <div className="flex items-center gap-1 text-[11px]">
                    <span className="text-slate-400">Scale:</span>
                    <button
                      onClick={() => {
                        handleWidthChange(Math.round(selectedImage.width * 0.5));
                      }}
                      className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                    >
                      50%
                    </button>
                    <button
                      onClick={() => {
                        handleWidthChange(Math.round(selectedImage.width * 0.75));
                      }}
                      className="px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                    >
                      75%
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Output Format
                  </label>
                  <select
                    value={exportFormat}
                    onChange={(e) => setExportFormat(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="image/jpeg">JPG / JPEG (Standard)</option>
                    <option value="image/png">PNG (Lossless)</option>
                    <option value="image/webp">WebP (Modern Web)</option>
                  </select>
                </div>

                <button
                  onClick={handleExecuteResize}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
                >
                  <Download className="h-4 w-4" />
                  Resize & Download Image
                </button>
              </div>
            )}

            {/* C. FORMAT CONVERTERS (PNG TO JPG, JPG TO PNG, WEBP) */}
            {(toolSlug === 'png-to-jpg' || toolSlug === 'jpg-to-png' || toolSlug === 'webp-converter') && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
                {toolSlug === 'png-to-jpg' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Background Fill for Transparent Pixels
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={jpgBgColor}
                        onChange={(e) => setJpgBgColor(e.target.value)}
                        className="h-8 w-12 rounded cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent p-0.5"
                      />
                      <span className="font-mono text-xs text-slate-600 dark:text-slate-400 uppercase">{jpgBgColor}</span>
                    </div>
                  </div>
                )}

                <div className="text-xs text-slate-600 dark:text-slate-400">
                  Target conversion format:{' '}
                  <strong className="text-slate-900 dark:text-white uppercase font-mono">
                    {toolSlug === 'jpg-to-png' ? 'PNG' : toolSlug === 'png-to-jpg' ? 'JPG' : 'WebP'}
                  </strong>
                </div>

                {compressedResult && (
                  <a
                    href={compressedResult.url}
                    download={`converted_${selectedImage.name.replace(/\.[^/.]+$/, '')}.${
                      toolSlug === 'jpg-to-png' ? 'png' : toolSlug === 'png-to-jpg' ? 'jpg' : 'webp'
                    }`}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
                  >
                    <Download className="h-4 w-4" />
                    Download Converted Image ({formatFileSize(compressedResult.size)})
                  </a>
                )}
              </div>
            )}

            {/* D. IMAGE EDITOR & ROTATOR */}
            {toolSlug === 'image-effects' && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Rotation & Orientation
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setRotationAngle((prev) => (prev + 90) % 360)}
                      className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <RotateCw className="h-3.5 w-3.5" />
                      Rotate 90° ({rotationAngle}°)
                    </button>
                    <button
                      onClick={() => setFlipH(!flipH)}
                      className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                        flipH
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60'
                          : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <FlipHorizontal className="h-3.5 w-3.5" />
                      Flip H
                    </button>
                    <button
                      onClick={() => setFlipV(!flipV)}
                      className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                        flipV
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60'
                          : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <FlipVertical className="h-3.5 w-3.5" />
                      Flip V
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Filter Presets
                  </label>
                  <div className="grid grid-cols-4 gap-2 text-xs">
                    {(['none', 'grayscale', 'sepia', 'invert'] as const).map((filter) => (
                      <button
                        key={filter}
                        onClick={() => setActiveFilter(filter)}
                        className={`py-2 px-2 rounded-lg font-semibold capitalize border transition-colors ${
                          activeFilter === filter
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400'
                            : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleExecuteEffects}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
                >
                  <Download className="h-4 w-4" />
                  Save & Download Image
                </button>
              </div>
            )}

            {/* E. IMAGE CROPPER */}
            {toolSlug === 'image-cropper' && (
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                    Aspect Ratio Preset
                  </label>
                  <div className="grid grid-cols-4 gap-2 text-xs">
                    {[
                      { id: '1:1', label: '1:1 Square' },
                      { id: '16:9', label: '16:9 Wide' },
                      { id: '4:3', label: '4:3 Standard' },
                      { id: 'free', label: 'Custom' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() => applyCropPreset(p.id as any)}
                        className={`py-2 px-2 rounded-lg font-semibold border transition-colors ${
                          cropPreset === p.id
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400'
                            : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Crop Width ({cropW}px)
                    </label>
                    <input
                      type="range"
                      min="50"
                      max={selectedImage.width}
                      value={cropW}
                      onChange={(e) => setCropW(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Crop Height ({cropH}px)
                    </label>
                    <input
                      type="range"
                      min="50"
                      max={selectedImage.height}
                      value={cropH}
                      onChange={(e) => setCropH(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Offset X ({cropX}px)
                    </label>
                    <input
                      type="range"
                      min="0"
                      max={Math.max(0, selectedImage.width - cropW)}
                      value={cropX}
                      onChange={(e) => setCropX(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Offset Y ({cropY}px)
                    </label>
                    <input
                      type="range"
                      min="0"
                      max={Math.max(0, selectedImage.height - cropH)}
                      value={cropY}
                      onChange={(e) => setCropY(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                </div>

                <button
                  onClick={handleExecuteCrop}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
                >
                  <Download className="h-4 w-4" />
                  Crop & Download Photo ({cropW}×{cropH})
                </button>
              </div>
            )}

          </div>

          {/* Preview Column */}
          <div className="lg:col-span-6 space-y-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-sm flex flex-col items-center">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
                Image Preview
              </span>

              <div className="relative max-h-80 w-full flex items-center justify-center overflow-hidden rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-950/50 p-2">
                <img
                  src={selectedImage.url}
                  alt="Preview"
                  style={{
                    transform: `rotate(${rotationAngle}deg) scale(${flipH ? -1 : 1}, ${flipV ? -1 : 1})`,
                    filter: activeFilter === 'grayscale' ? 'grayscale(100%)' : activeFilter === 'sepia' ? 'sepia(100%)' : activeFilter === 'invert' ? 'invert(100%)' : 'none',
                  }}
                  className="max-h-72 max-w-full object-contain rounded transition-all duration-200"
                />
              </div>

              {/* Comparison for compression */}
              {toolSlug === 'image-compressor' && compressedResult && (
                <div className="mt-4 w-full space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-center p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <div>
                      <div className="text-[11px] text-slate-400">Original Size</div>
                      <div className="text-sm font-bold font-mono text-slate-700 dark:text-slate-300">
                        {formatFileSize(selectedImage.originalSize)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400">Compressed Size</div>
                      <div className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400">
                        {formatFileSize(compressedResult.size)}
                        {compressedResult.size < selectedImage.originalSize && (
                          <span className="ml-1 text-[11px] font-normal text-emerald-500">
                            (-{Math.round(((selectedImage.originalSize - compressedResult.size) / selectedImage.originalSize) * 100)}%)
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <a
                    href={compressedResult.url}
                    download={`compressed_${selectedImage.name}`}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
                  >
                    <Download className="h-4 w-4" />
                    Download Compressed Image
                  </a>
                </div>
              )}
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
