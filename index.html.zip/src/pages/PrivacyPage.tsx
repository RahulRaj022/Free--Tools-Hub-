import React, { useEffect } from 'react';
import { Breadcrumbs } from '../components/layout/Breadcrumbs';
import { BackButton } from '../components/common/BackButton';
import { ShieldCheck, Lock, HardDrive } from 'lucide-react';

interface PrivacyPageProps {
  navigate: (path: string) => void;
}

export const PrivacyPage: React.FC<PrivacyPageProps> = ({ navigate }) => {
  useEffect(() => {
    document.title = 'Privacy Policy – Free Tools Hub';
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <BackButton navigate={navigate} fallbackPath="/" />
        <Breadcrumbs items={[{ label: 'Privacy Policy' }]} navigate={navigate} />
      </div>

      <div className="border-b border-slate-200/80 pb-6 dark:border-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Privacy Policy
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Last updated: October 2026
        </p>
      </div>

      <div className="prose prose-slate dark:prose-invert max-w-none space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-500" />
            1. Client-Side Data & File Processing
          </h2>
          <p>
            At Free Tools Hub, user privacy is our foundational architecture. The tools on this website (such as the PDF Compressor, Image Resizer, Password Generator, and Word Counter) execute entirely inside your local web browser via HTML5 Canvas, Web Cryptography, and WebAssembly APIs.
          </p>
          <p>
            Your uploaded files, images, documents, and inputs are never transmitted, uploaded, or saved to any remote servers. When you close the browser tab, any temporary memory allocations are instantly destroyed.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <HardDrive className="h-5 w-5 text-indigo-500" />
            2. Local Storage Usage
          </h2>
          <p>
            We use your browser&apos;s native <code className="font-mono text-xs">localStorage</code> mechanism strictly to enhance your local user experience:
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>Theme Preference:</strong> Remembers your Dark or Light mode choice (<code className="font-mono text-xs">fth_theme</code>).</li>
            <li><strong>Saved Favorites:</strong> Stores the IDs of tools you have starred for quick retrieval (<code className="font-mono text-xs">fth_favorites</code>).</li>
            <li><strong>Recently Used:</strong> Stores the last 6 tools you opened (<code className="font-mono text-xs">fth_recent</code>).</li>
          </ul>
          <p>
            This data never leaves your device and can be cleared at any time via the &quot;Clear History&quot; button or by clearing your browser cache.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Lock className="h-5 w-5 text-violet-500" />
            3. Passwords and Cryptographic Secrets
          </h2>
          <p>
            Passwords generated with our Password Generator or tokens produced by our Secret Key utility use <code className="font-mono text-xs">window.crypto.getRandomValues</code> directly in client memory. Free Tools Hub does not log, inspect, or retain any generated credentials.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            4. Third-Party Services & Analytics
          </h2>
          <p>
            The website is structured to be compatible with privacy-friendly analytics if configured in the future. We do not use intrusive surveillance tracking, advertising pixels, or cross-site fingerprinting scripts.
          </p>
        </section>
      </div>
    </div>
  );
};
