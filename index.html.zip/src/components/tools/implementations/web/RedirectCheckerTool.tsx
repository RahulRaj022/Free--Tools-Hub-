import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { ArrowRight, CornerDownRight, Download, AlertTriangle, AlertCircle, Loader2, RotateCcw, CheckCircle } from 'lucide-react';

interface RedirectHop {
  hopNumber: number;
  url: string;
  statusCode: number;
  statusText: string;
  location?: string;
}

export const RedirectCheckerTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('http://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    initialUrl: string;
    finalUrl: string;
    totalHops: number;
    hops: RedirectHop[];
    loopDetected: boolean;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const traceRedirects = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'http://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch('/api/web/redirect-chain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to trace redirect chain.');
      }

      setResult(data);
      showToast(`Traced ${data.hops.length} redirect hop(s)!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error tracing redirect chain.');
    } finally {
      setLoading(false);
    }
  };

  const exportCsv = () => {
    if (!result) return;
    const header = 'Hop,Source URL,Status Code,Status Text,Redirect Target\n';
    const rows = result.hops
      .map((h) => `${h.hopNumber},"${h.url}",${h.statusCode},"${h.statusText}","${h.location || ''}"`)
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `redirect_chain_${result.initialUrl.replace(/[^a-z0-9]/gi, '_')}.csv`;
    a.click();
    URL.revokeObjectURL(u);
    showToast('Exported redirect chain CSV!', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Starting URL to Trace
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && traceRedirects()}
            placeholder="http://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={traceRedirects}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
            <span>{loading ? 'Tracing Hops...' : 'Trace Redirects'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setResult(null);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {result && (
        <div className="space-y-6 animate-in fade-in">
          {/* Summary Banner */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div>
              <div className="text-xs text-slate-500">Redirect Summary</div>
              <div className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mt-0.5">
                <span>{result.hops.length} Total Hop(s)</span>
                {result.hops.length === 1 && (
                  <span className="text-xs font-normal text-emerald-600 dark:text-emerald-400">
                    (Direct, no redirects)
                  </span>
                )}
                {result.loopDetected && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 text-xs font-bold">
                    <AlertTriangle className="h-3 w-3" /> Redirect Loop Detected!
                  </span>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shadow-xs"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          {/* Visual Hop Chain */}
          <div className="space-y-3">
            {result.hops.map((hop, idx) => {
              const isLast = idx === result.hops.length - 1;
              const isRedirect = [301, 302, 307, 308].includes(hop.statusCode);
              return (
                <div key={idx} className="relative">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">
                          {hop.hopNumber}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-md text-xs font-mono font-bold ${
                            isRedirect
                              ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                              : hop.statusCode === 200
                              ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                              : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300'
                          }`}
                        >
                          {hop.statusCode} {hop.statusText}
                        </span>
                      </div>
                      <span className="text-xs font-medium text-slate-400">
                        {isLast ? 'Final Destination' : 'Intermediary Hop'}
                      </span>
                    </div>

                    <div className="font-mono text-xs text-slate-900 dark:text-slate-100 break-all pl-8">
                      {hop.url}
                    </div>

                    {hop.location && (
                      <div className="flex items-center gap-1.5 pl-8 text-xs text-slate-500 font-mono">
                        <CornerDownRight className="h-3.5 w-3.5 text-amber-500 shrink-0" />
                        <span>Redirects to: </span>
                        <span className="text-indigo-600 dark:text-indigo-400 font-semibold truncate">
                          {hop.location}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Flow Arrow to next hop */}
                  {!isLast && (
                    <div className="flex justify-center my-1 text-slate-400">
                      <ArrowRight className="h-4 w-4 rotate-90" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
