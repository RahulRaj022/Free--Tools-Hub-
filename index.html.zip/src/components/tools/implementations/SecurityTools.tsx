import React, { useState, useEffect, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Key, Copy, Check, RefreshCw, ShieldCheck, ShieldAlert, Eye, EyeOff, Lock } from 'lucide-react';

interface SecurityToolsProps {
  toolSlug: string;
}

export const SecurityTools: React.FC<SecurityToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // Password Generator states
  const [length, setLength] = useState<number>(18);
  const [incUpper, setIncUpper] = useState<boolean>(true);
  const [incLower, setIncLower] = useState<boolean>(true);
  const [incNumbers, setIncNumbers] = useState<boolean>(true);
  const [incSymbols, setIncSymbols] = useState<boolean>(true);
  const [excludeAmbiguous, setExcludeAmbiguous] = useState<boolean>(false);
  const [password, setPassword] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  // Password Strength Checker states
  const [testPassword, setTestPassword] = useState<string>('Tr0ub4dor&3#Strong!');
  const [showTestPassword, setShowTestPassword] = useState<boolean>(false);

  // Random String Generator states
  const [secretType, setSecretType] = useState<'alphaNum' | 'hex' | 'alpha' | 'numeric'>('alphaNum');
  const [secretLength, setSecretLength] = useState<number>(32);
  const [secretCount, setSecretCount] = useState<number>(5);
  const [generatedSecrets, setGeneratedSecrets] = useState<string[]>([]);

  // 1. Password Generation Logic using Web Crypto
  const generatePassword = () => {
    let upperChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let lowerChars = 'abcdefghijklmnopqrstuvwxyz';
    let numberChars = '0123456789';
    let symbolChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (excludeAmbiguous) {
      upperChars = upperChars.replace(/[OI]/g, '');
      lowerChars = lowerChars.replace(/[l]/g, '');
      numberChars = numberChars.replace(/[01]/g, '');
    }

    let charPool = '';
    if (incUpper) charPool += upperChars;
    if (incLower) charPool += lowerChars;
    if (incNumbers) charPool += numberChars;
    if (incSymbols) charPool += symbolChars;

    if (!charPool) {
      showToast('Select at least one character type', 'error');
      return;
    }

    const array = new Uint32Array(length);
    crypto.getRandomValues(array);

    let res = '';
    for (let i = 0; i < length; i++) {
      res += charPool[array[i] % charPool.length];
    }

    setPassword(res);
  };

  useEffect(() => {
    generatePassword();
  }, [length, incUpper, incLower, incNumbers, incSymbols, excludeAmbiguous]);

  // Entropy and Strength metric
  const strengthInfo = useMemo(() => {
    const pw = toolSlug === 'password-strength-checker' ? testPassword : password;
    if (!pw) {
      return { score: 0, label: 'Empty', color: 'text-slate-400', bar: 0, entropy: 0, crackTime: '0 seconds' };
    }

    let poolSize = 0;
    if (/[a-z]/.test(pw)) poolSize += 26;
    if (/[A-Z]/.test(pw)) poolSize += 26;
    if (/[0-9]/.test(pw)) poolSize += 10;
    if (/[^a-zA-Z0-9]/.test(pw)) poolSize += 32;

    const entropy = Math.round(pw.length * Math.log2(poolSize || 1));

    let score = 1;
    let label = 'Very Weak';
    let color = 'text-rose-500';
    let bar = 15;
    let crackTime = 'Instant';

    if (entropy >= 80) {
      score = 5;
      label = 'Very Strong';
      color = 'text-emerald-500';
      bar = 100;
      crackTime = 'Centuries (10,000+ years)';
    } else if (entropy >= 60) {
      score = 4;
      label = 'Strong';
      color = 'text-teal-500';
      bar = 80;
      crackTime = 'Several decades';
    } else if (entropy >= 45) {
      score = 3;
      label = 'Moderate';
      color = 'text-amber-500';
      bar = 55;
      crackTime = 'A few months';
    } else if (entropy >= 30) {
      score = 2;
      label = 'Weak';
      color = 'text-orange-500';
      bar = 35;
      crackTime = 'A few hours';
    }

    return { score, label, color, bar, entropy, crackTime };
  }, [password, testPassword, toolSlug]);

  const handleCopy = (txt: string) => {
    if (!txt) return;
    navigator.clipboard.writeText(txt);
    setCopied(true);
    showToast('Password copied to clipboard! (Never stored)', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  // 2. Random Secret Token Generator
  const generateSecrets = () => {
    let pool = '';
    if (secretType === 'alphaNum') pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    else if (secretType === 'hex') pool = '0123456789abcdef';
    else if (secretType === 'alpha') pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    else pool = '0123456789';

    const list: string[] = [];
    for (let c = 0; c < secretCount; c++) {
      const arr = new Uint32Array(secretLength);
      crypto.getRandomValues(arr);
      let s = '';
      for (let i = 0; i < secretLength; i++) {
        s += pool[arr[i] % pool.length];
      }
      list.push(s);
    }
    setGeneratedSecrets(list);
  };

  useEffect(() => {
    generateSecrets();
  }, [secretType, secretLength, secretCount]);

  return (
    <div className="space-y-6">
      {/* 1. PASSWORD GENERATOR */}
      {toolSlug === 'password-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          
          {/* Display & Action */}
          <div className="flex items-center justify-between gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
            <span className="font-mono text-lg sm:text-2xl font-bold text-slate-900 dark:text-white tracking-wider break-all select-all">
              {password}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={generatePassword}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-indigo-600 transition-colors"
                title="Regenerate"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
              <button
                onClick={() => handleCopy(password)}
                className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Strength Meter */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-slate-600 dark:text-slate-400">Password Strength:</span>
              <span className={strengthInfo.color}>{strengthInfo.label} ({strengthInfo.entropy} bits)</span>
            </div>
            <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  strengthInfo.score >= 4 ? 'bg-emerald-500' : strengthInfo.score === 3 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${strengthInfo.bar}%` }}
              />
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              Estimated brute-force crack time: <span className="font-semibold text-slate-700 dark:text-slate-300">{strengthInfo.crackTime}</span>
            </div>
          </div>

          {/* Sliders & Checkboxes */}
          <div className="space-y-4 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex justify-between text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                <span>Password Length</span>
                <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{length} characters</span>
              </div>
              <input
                type="range"
                min="6"
                max="64"
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                <input
                  type="checkbox"
                  checked={incUpper}
                  onChange={(e) => setIncUpper(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Uppercase (A-Z)
              </label>
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                <input
                  type="checkbox"
                  checked={incLower}
                  onChange={(e) => setIncLower(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Lowercase (a-z)
              </label>
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                <input
                  type="checkbox"
                  checked={incNumbers}
                  onChange={(e) => setIncNumbers(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Numbers (0-9)
              </label>
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                <input
                  type="checkbox"
                  checked={incSymbols}
                  onChange={(e) => setIncSymbols(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Symbols (!@#$)
              </label>
            </div>

            <div className="pt-2">
              <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={excludeAmbiguous}
                  onChange={(e) => setExcludeAmbiguous(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Exclude ambiguous characters (O, 0, l, 1, I)
              </label>
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-800 dark:text-emerald-300">
            <ShieldCheck className="h-4 w-4 shrink-0" />
            <span>Zero Server Transmission: Passwords generated here are calculated in browser memory and never leave your computer.</span>
          </div>
        </div>
      )}

      {/* 2. PASSWORD STRENGTH CHECKER */}
      {toolSlug === 'password-strength-checker' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Enter Password to Test
            </label>
            <div className="relative">
              <input
                type={showTestPassword ? 'text' : 'password'}
                value={testPassword}
                onChange={(e) => setTestPassword(e.target.value)}
                placeholder="Enter password..."
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white pr-10 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={() => setShowTestPassword(!showTestPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                {showTestPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-500">Strength Evaluation</div>
                <div className={`text-2xl font-bold font-mono ${strengthInfo.color}`}>
                  {strengthInfo.label}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">Information Entropy</div>
                <div className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                  {strengthInfo.entropy} bits
                </div>
              </div>
            </div>

            <div className="h-2.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  strengthInfo.score >= 4 ? 'bg-emerald-500' : strengthInfo.score === 3 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${strengthInfo.bar}%` }}
              />
            </div>

            <div className="text-xs text-slate-600 dark:text-slate-400">
              Estimated offline brute-force crack time:{' '}
              <span className="font-semibold text-slate-900 dark:text-white">{strengthInfo.crackTime}</span>
            </div>
          </div>

          {/* Checklist */}
          <div className="space-y-2 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Security Checklist:
            </span>
            {[
              { label: 'At least 12 characters (16+ recommended)', pass: testPassword.length >= 12 },
              { label: 'Contains uppercase letter (A-Z)', pass: /[A-Z]/.test(testPassword) },
              { label: 'Contains lowercase letter (a-z)', pass: /[a-z]/.test(testPassword) },
              { label: 'Contains number (0-9)', pass: /[0-9]/.test(testPassword) },
              { label: 'Contains special symbol (!@#$%)', pass: /[^a-zA-Z0-9]/.test(testPassword) },
            ].map((rule, idx) => (
              <div key={idx} className="flex items-center gap-2">
                {rule.pass ? (
                  <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                ) : (
                  <ShieldAlert className="h-4 w-4 text-slate-300 dark:text-slate-600 shrink-0" />
                )}
                <span className={rule.pass ? 'text-slate-900 dark:text-white' : 'text-slate-400'}>
                  {rule.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. RANDOM STRING GENERATOR */}
      {toolSlug === 'random-string-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Format
              </label>
              <select
                value={secretType}
                onChange={(e) => setSecretType(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                <option value="alphaNum">Alphanumeric (a-Z, 0-9)</option>
                <option value="hex">Hexadecimal (0-9, a-f)</option>
                <option value="alpha">Letters Only (a-Z)</option>
                <option value="numeric">Numbers Only (0-9)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Length: {secretLength}
              </label>
              <input
                type="number"
                min="8"
                max="128"
                value={secretLength}
                onChange={(e) => setSecretLength(Math.max(8, Math.min(128, Number(e.target.value))))}
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Quantity: {secretCount}
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={secretCount}
                onChange={(e) => setSecretCount(Math.max(1, Math.min(50, Number(e.target.value))))}
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={generateSecrets}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Generate Secrets
            </button>
            <button
              onClick={() => handleCopy(generatedSecrets.join('\n'))}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400"
            >
              Copy All Secrets
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto">
            {generatedSecrets.map((sec, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-200 select-all"
              >
                <span className="truncate mr-2">{sec}</span>
                <button
                  onClick={() => handleCopy(sec)}
                  className="text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                  title="Copy secret"
                >
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
