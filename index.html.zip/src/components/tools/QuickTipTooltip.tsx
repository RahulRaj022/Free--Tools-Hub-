import React, { useState, useRef, useEffect } from 'react';
import { Lightbulb, Keyboard, Sparkles, X, Check, Command } from 'lucide-react';

export interface QuickTipInfo {
  tip: string;
  bestPractice?: string;
  shortcuts?: Array<{ keys: string[]; description: string }>;
}

export const TOOL_QUICK_TIPS: Record<string, QuickTipInfo> = {
  // PDF Tools
  'pdf-compressor': {
    tip: 'Compress PDFs locally without losing document sharpness.',
    bestPractice: 'For text-heavy contracts and invoices, standard optimization preserves razor-sharp vector typography while stripping bloated metadata and stream duplication.',
    shortcuts: [
      { keys: ['Drag & Drop'], description: 'Drop PDF file directly onto the upload zone' },
      { keys: ['Ctrl', 'K'], description: 'Open search to switch to PDF Merger or Splitter' },
    ],
  },
  'pdf-merger': {
    tip: 'Arrange documents before merging into a unified PDF.',
    bestPractice: 'Use the Up/Down arrow controls to order your files sequentially. Merging processes entirely in your browser RAM without uploading sensitive files.',
    shortcuts: [
      { keys: ['↑ / ↓'], description: 'Reorder uploaded PDF documents' },
      { keys: ['Delete'], description: 'Remove unwanted document from queue' },
    ],
  },
  'pdf-splitter': {
    tip: 'Extract targeted pages with flexible range syntax.',
    bestPractice: 'Use commas and hyphens like "1-3, 5, 8-10" to selectively extract specific pages or chapters into a standalone PDF.',
    shortcuts: [
      { keys: ['Tab'], description: 'Jump between page range input and action button' },
      { keys: ['Enter'], description: 'Trigger PDF split immediately' },
    ],
  },
  'pdf-to-jpg': {
    tip: 'Render high-resolution raster images of individual PDF pages.',
    bestPractice: 'Ideal for embedding PDF pages into presentations, keynote slides, or portfolio graphics with crisp 300-DPI visual fidelity.',
    shortcuts: [
      { keys: ['1-N'], description: 'Select specific page number to extract' },
      { keys: ['Ctrl', 'S'], description: 'Save the exported JPEG snapshot' },
    ],
  },
  'jpg-to-pdf': {
    tip: 'Combine photo albums and scanned receipts into a clean PDF.',
    bestPractice: 'Select multiple images at once. Each image automatically scales to fit standard page bounds without resolution loss.',
    shortcuts: [
      { keys: ['Drag & Drop'], description: 'Add multiple photos at once' },
      { keys: ['↑ / ↓'], description: 'Adjust page sequence before exporting' },
    ],
  },

  // Image Tools
  'image-compressor': {
    tip: 'Balance small file size with sharp visual clarity.',
    bestPractice: 'Set quality slider between 75%–85%. This yields 60%–80% bandwidth savings with virtually indistinguishable visual difference from original.',
    shortcuts: [
      { keys: ['Drag & Drop'], description: 'Drop image from desktop' },
      { keys: ['← / →'], description: 'Fine-tune compression percentage slider' },
    ],
  },
  'image-resizer': {
    tip: 'Preserve proportions to prevent image distortion.',
    bestPractice: 'Keep "Maintain Aspect Ratio" locked. Use the 50% or 25% presets for fast responsive web asset preparation.',
    shortcuts: [
      { keys: ['Tab'], description: 'Switch between width and height inputs' },
      { keys: ['Presets'], description: 'One-click sizing for Social, HD, and Thumbnails' },
    ],
  },
  'image-cropper': {
    tip: 'Crop photos to exact aspect ratios in seconds.',
    bestPractice: 'Choose 1:1 for profile pictures & avatars, or 16:9 for YouTube thumbnails, blog banners, and presentation slides.',
    shortcuts: [
      { keys: ['1:1'], description: 'Square avatar aspect ratio lock' },
      { keys: ['16:9'], description: 'Widescreen landscape aspect ratio lock' },
    ],
  },
  'jpg-to-png': {
    tip: 'Convert compressed JPEG photos into lossless PNG format.',
    bestPractice: 'Use PNG when you plan to add graphic text overlays or transparent watermarks to eliminate repeated JPEG compression artifacts.',
    shortcuts: [
      { keys: ['Drag & Drop'], description: 'Drop JPG file for instantaneous conversion' },
    ],
  },
  'png-to-jpg': {
    tip: 'Shrink transparent PNG graphics to compact JPEG files.',
    bestPractice: 'Specify your background fill color (white by default) so transparent PNG pixels blend seamlessly into the new JPEG.',
    shortcuts: [
      { keys: ['Color Picker'], description: 'Choose background fill for transparent areas' },
    ],
  },
  'webp-converter': {
    tip: 'Modern next-gen WebP format reduces web bandwidth drastically.',
    bestPractice: 'WebP files are typically 25%–35% smaller than equivalent JPEGs and PNGs while supporting full alpha channel transparency.',
    shortcuts: [
      { keys: ['Quality Slider'], description: 'Tune compression balance before export' },
    ],
  },
  'image-effects': {
    tip: 'Rotate, mirror, and filter images without leaving the browser.',
    bestPractice: 'Use Grayscale to prep printed documents, or Flip Horizontal for correcting mirrored selfie camera shots.',
    shortcuts: [
      { keys: ['90° Button'], description: 'Rotate image clockwise in 90° increments' },
      { keys: ['Flip H / V'], description: 'Mirror image along horizontal or vertical axis' },
    ],
  },

  // QR Code Tool
  'qr-code-generator': {
    tip: 'Configure error correction according to your deployment medium.',
    bestPractice: 'Select "High" (H) error correction if printing on outdoor signage, stickers, or packaging where wear, moisture, or partial obstruction may occur.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste target URL or Wi-Fi configuration' },
      { keys: ['Download'], description: 'Export crisp PNG or scalable vector SVG' },
    ],
  },

  // Text Tools
  'word-counter': {
    tip: 'Real-time text analytics with reading and speaking metrics.',
    bestPractice: 'Average human reading speed is ~200 words per minute, and speaking speed is ~130 words per minute. Use these to time presentations accurately.',
    shortcuts: [
      { keys: ['Ctrl', 'A'], description: 'Select all text in editor' },
      { keys: ['Ctrl', 'C'], description: 'Copy text / statistics' },
      { keys: ['Ctrl', 'V'], description: 'Paste text from clipboard' },
    ],
  },
  'character-counter': {
    tip: 'Monitor strict character limits for social media and SEO.',
    bestPractice: 'Keep Google Search meta descriptions under 160 characters and title tags under 60 characters to prevent truncation in search engine results.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste snippet to test length instantly' },
    ],
  },
  'case-converter': {
    tip: 'Transform naming conventions for writing and coding.',
    bestPractice: 'Use Title Case for blog and video titles, UPPERCASE for acronyms, camelCase for JavaScript variables, and kebab-case for CSS classes.',
    shortcuts: [
      { keys: ['One-Click'], description: 'Toggle between UPPER, lower, Title, and camelCase' },
    ],
  },
  'remove-extra-spaces': {
    tip: 'Purge accidental double spaces, tabs, and excess line breaks.',
    bestPractice: 'Click "Deep clean all whitespace" to normalize copy-pasted text from PDFs, emails, or spreadsheets into clean single-spaced prose.',
    shortcuts: [
      { keys: ['Clean All'], description: 'Removes trailing spaces and empty blank lines' },
    ],
  },
  'text-reverser': {
    tip: 'Reverse character sequences, word orders, or entire line blocks.',
    bestPractice: 'Use "Reverse line order" to flip chronological changelogs or reverse-order lists of data entries.',
    shortcuts: [
      { keys: ['Reverse Chars'], description: 'Flips letter by letter (hello → olleh)' },
      { keys: ['Reverse Words'], description: 'Flips sentence order while keeping words intact' },
    ],
  },
  'slug-generator': {
    tip: 'Generate URL-friendly slugs for web publishing.',
    bestPractice: 'Generates clean lowercase strings with diacritic accents stripped (e.g., "café" → "cafe") and hyphens replacing special punctuation.',
    shortcuts: [
      { keys: ['Copy Slug'], description: 'Copy formatted URL slug to clipboard' },
    ],
  },
  'lorem-ipsum-generator': {
    tip: 'Generate placeholder text for design mockups and wireframes.',
    bestPractice: 'Pick paragraph mode for article wireframes, or sentence mode for hero headline and card caption mocks.',
    shortcuts: [
      { keys: ['1-10 Count'], description: 'Choose number of dummy paragraphs to produce' },
    ],
  },
  'text-sorter': {
    tip: 'Alphabetize or reorder lists and data lines.',
    bestPractice: 'Use A–Z sorting for customer directories, or "Random Shuffle" when conducting fair prize giveaways or team assignments.',
    shortcuts: [
      { keys: ['A → Z'], description: 'Alphabetical ascending sort' },
      { keys: ['Z → A'], description: 'Alphabetical descending sort' },
      { keys: ['Short → Long'], description: 'Sort by character length' },
    ],
  },
  'duplicate-line-remover': {
    tip: 'Clean messy mailing lists and data sets.',
    bestPractice: 'Toggle case-insensitive deduplication to merge entries like "john@example.com" and "John@example.com" into a single unique record.',
    shortcuts: [
      { keys: ['Deduplicate'], description: 'Instantly identifies and eliminates duplicate lines' },
    ],
  },

  // Calculators
  'percentage-calculator': {
    tip: 'Instant real-time math without form submissions or reload.',
    bestPractice: 'Switch tabs between "What is X% of Y", "X is what % of Y", and "Percentage Increase/Decrease" to handle financial and discount calculations.',
    shortcuts: [
      { keys: ['Tab'], description: 'Cycle between number inputs' },
      { keys: ['Auto-Calc'], description: 'Calculates in real time as digits are typed' },
    ],
  },
  'age-calculator': {
    tip: 'Calculates exact chronological age down to the day.',
    bestPractice: 'Accounts for leap years and month length variances. Also displays countdown days until the upcoming birthday milestone.',
    shortcuts: [
      { keys: ['Date Picker'], description: 'Choose birth date or custom target reference' },
    ],
  },
  'discount-calculator': {
    tip: 'Calculate checkout savings, sales tax, and final amount.',
    bestPractice: 'Enter your local sales tax rate along with the discount percentage to know the exact out-of-pocket register price before paying.',
    shortcuts: [
      { keys: ['Tab'], description: 'Jump between original price and discount percent' },
    ],
  },
  'bmi-calculator': {
    tip: 'Measure Body Mass Index against WHO health classifications.',
    bestPractice: 'Toggle between Metric (cm/kg) and Imperial (ft/in/lbs). Keep in mind BMI does not differentiate between dense muscle mass and adipose tissue.',
    shortcuts: [
      { keys: ['Metric / Imperial'], description: 'Toggle measurement units instantly' },
    ],
  },
  'tip-calculator': {
    tip: 'Split restaurant bills and tips evenly among party members.',
    bestPractice: 'Use standard quick tip buttons (15%, 18%, 20%) and enter headcount to calculate the exact per-person contribution.',
    shortcuts: [
      { keys: ['15%', '18%', '20%'], description: 'Quick-select customary tip percentages' },
    ],
  },
  'average-calculator': {
    tip: 'Computes Mean, Median, Mode, Range, and Total Sum.',
    bestPractice: 'Paste numbers separated by commas, spaces, or newlines. Median is especially valuable when your dataset contains extreme outliers.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste raw number series directly into input' },
    ],
  },
  'gpa-calculator': {
    tip: 'Determine semester and cumulative Grade Point Average.',
    bestPractice: 'Enter course credit weights alongside letter grades. Higher credit classes exert proportional leverage on your overall GPA.',
    shortcuts: [
      { keys: ['+ Add Course'], description: 'Add additional class rows to computation' },
    ],
  },
  'unit-converter': {
    tip: 'Instant conversions across Metric and Imperial measurements.',
    bestPractice: 'Select from Length, Weight, Temperature, Area, Volume, and Speed. Values recalculate continuously as you type.',
    shortcuts: [
      { keys: ['Swap'], description: 'Reverse "From" and "To" measurement units' },
    ],
  },
  'ratio-calculator': {
    tip: 'Solve proportional equations (A:B = C:D) and aspect ratios.',
    bestPractice: 'Leave any single variable blank to solve for it automatically. Great for video canvas scaling (e.g. 1920:1080 = 1280:?).',
    shortcuts: [
      { keys: ['Tab'], description: 'Move between ratio input slots' },
    ],
  },
  'simple-interest-calculator': {
    tip: 'Calculate linear loan interest: Interest = Principal × Rate × Time.',
    bestPractice: 'Enter time in fractional years (e.g. 2.5 for 2 years and 6 months) to determine total interest accrued and final payment balance.',
    shortcuts: [
      { keys: ['Tab'], description: 'Switch between principal, rate, and duration' },
    ],
  },
  'compound-interest-calculator': {
    tip: 'Visualize exponential interest compounding over time.',
    bestPractice: 'Monthly compounding generates significantly greater returns over long time horizons (10+ years) compared to simple annual compounding.',
    shortcuts: [
      { keys: ['Frequency'], description: 'Toggle Annual, Semi-annual, Quarterly, or Monthly' },
    ],
  },

  // Developer Tools
  'json-formatter': {
    tip: 'Format, validate, and beautify messy JSON payloads.',
    bestPractice: 'Invalid syntax highlights the exact problematic line and token. Choose 2-space or 4-space indentation for clean code documentation.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste raw JSON string' },
      { keys: ['Format'], description: 'Beautify with standardized 2-space indentation' },
      { keys: ['Minify'], description: 'Strip all formatting whitespace for production payloads' },
    ],
  },
  'base64-encoder': {
    tip: 'Encode and decode Base64 strings with full UTF-8 Unicode support.',
    bestPractice: 'Includes full multi-byte UTF-8 support for emoji and international text characters without corruption.',
    shortcuts: [
      { keys: ['Encode / Decode'], description: 'Toggle mode tab' },
      { keys: ['Copy Result'], description: 'Grab transformed payload to clipboard' },
    ],
  },
  'url-encoder-decoder': {
    tip: 'Safely encode URI components and query string parameters.',
    bestPractice: 'Use encodeURIComponent for query string values like search terms and tokens to ensure special characters like "&", "=", and "?" are escaped.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste URL or query parameter' },
    ],
  },
  'uuid-generator': {
    tip: 'Generate cryptographically unique RFC4122 Version 4 UUIDs.',
    bestPractice: 'Uses window.crypto.getRandomValues() for 122 bits of true entropy. Collision probability is virtually zero (1 in 10^37).',
    shortcuts: [
      { keys: ['Generate'], description: 'Batch generate 1 to 50 UUIDs at once' },
      { keys: ['Hyphens / Caps'], description: 'Toggle formatting styles' },
    ],
  },
  'hash-generator': {
    tip: 'Compute cryptographic checksums in your browser.',
    bestPractice: 'SHA-256 is the modern standard for cryptographic verification and digital signatures. MD5 is suitable for non-cryptographic checksum matches.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Type or paste input string' },
      { keys: ['Copy Hash'], description: 'Copy generated hex digest' },
    ],
  },
  'timestamp-converter': {
    tip: 'Convert Unix timestamps to readable human dates and back.',
    bestPractice: 'Inspect timestamps in both Seconds (10 digits) and Milliseconds (13 digits). Shows UTC time and your current local timezone.',
    shortcuts: [
      { keys: ['Current Time'], description: 'Insert active real-time epoch timestamp' },
    ],
  },
  'color-converter': {
    tip: 'Convert between HEX, RGB, HSL, and HSV color models.',
    bestPractice: 'HSL is easiest for designers to tweak lightness and saturation, while HEX and RGB are standard for CSS stylesheets.',
    shortcuts: [
      { keys: ['Color Picker'], description: 'Visual interactive palette selection' },
      { keys: ['Copy CSS'], description: 'Copy ready-to-paste CSS color rule' },
    ],
  },
  'regex-tester': {
    tip: 'Test regular expressions with live syntax highlighting.',
    bestPractice: 'Toggle flags (g for global, i for case-insensitive, m for multiline) to verify capture groups and regex replacements in real time.',
    shortcuts: [
      { keys: ['Tab'], description: 'Switch between regex pattern and test string' },
    ],
  },

  // Security Tools
  'password-generator': {
    tip: 'Generate uncrackable, cryptographically secure passwords.',
    bestPractice: 'Use 16 or more characters including uppercase, lowercase, numbers, and symbols. 16-character passwords resist brute force for millions of years.',
    shortcuts: [
      { keys: ['Regenerate'], description: 'Create a new secure random password' },
      { keys: ['Copy'], description: 'Copy generated password to clipboard' },
    ],
  },
  'password-strength-checker': {
    tip: 'Test password entropy and estimated brute-force time.',
    bestPractice: 'Avoid common dictionary words, keyboard walks (like "qwerty"), and predictable numeric substitutions (like "P@ssw0rd").',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste password to assess vulnerability' },
    ],
  },
  'random-string-generator': {
    tip: 'Generate API secret tokens, alphanumeric keys, or hex strings.',
    bestPractice: 'Select "Hexadecimal" mode for cryptographic seed keys and secrets, or "Alphanumeric" for temporary verification tokens.',
    shortcuts: [
      { keys: ['Generate'], description: 'Instantly produce new random string' },
    ],
  },

  // Student Tools
  'pomodoro-timer': {
    tip: 'Boost focus with the 25/5 interval productivity technique.',
    bestPractice: 'Focus deeply for 25 minutes, then take a full 5-minute break away from screens. After 4 sessions, reward yourself with a 15-minute long rest.',
    shortcuts: [
      { keys: ['Spacebar'], description: 'Start / Pause active timer' },
      { keys: ['R'], description: 'Reset timer back to default duration' },
    ],
  },
  'random-number-generator': {
    tip: 'Generate random numbers within custom minimum and maximum bounds.',
    bestPractice: 'Use "Exclude Duplicates" mode when generating lottery picks, bingo numbers, or fair raffle contest drawings.',
    shortcuts: [
      { keys: ['Space / Enter'], description: 'Roll numbers again' },
      { keys: ['Dice Presets'], description: 'Instant roll for 1d6, 1d20, 1d100' },
    ],
  },
  // Advanced PDF Tools
  'pdf-to-word': {
    tip: 'Extract structured text and formatting from PDF into an editable Word document.',
    bestPractice: 'Exported .doc files preserve paragraphs, lists, and headings so you can edit in Microsoft Word or Google Docs immediately.',
    shortcuts: [
      { keys: ['Drag & Drop'], description: 'Drop PDF to extract text' },
      { keys: ['Download'], description: 'Save as .doc file' },
    ],
  },
  'word-to-pdf': {
    tip: 'Type or paste rich copy and compile directly into a standardized PDF.',
    bestPractice: 'Client-side typesetting ensures line wraps, title headers, and page margins are rendered cleanly without cloud rendering dependencies.',
    shortcuts: [
      { keys: ['Ctrl', 'Enter'], description: 'Compile and download PDF' },
    ],
  },
  'pdf-page-rotator': {
    tip: 'Permanently orient scanned sideways or upside-down pages.',
    bestPractice: 'Rotates standard PDF viewport coordinate matrices so orientation is universally recognized across Adobe Acrobat, Chrome, and iOS previewers.',
    shortcuts: [
      { keys: ['90° / 180° / 270°'], description: 'Choose rotation degrees' },
    ],
  },
  'pdf-page-numberer': {
    tip: 'Stamp crisp sequential page numbering along header or footer margins.',
    bestPractice: 'Choose "Page X of Y" for legal, academic, and business documentation to prevent missing page discrepancies.',
    shortcuts: [
      { keys: ['Position'], description: 'Select bottom center, bottom right, or top right' },
    ],
  },
  'pdf-watermark': {
    tip: 'Protect confidential drafts and proprietary IP with angled vector watermarks.',
    bestPractice: 'Set opacity to 15%–25% so the watermark remains legible while the underlying body text remains readable.',
    shortcuts: [
      { keys: ['Text Input'], description: 'Type custom watermark text (e.g. DRAFT, CONFIDENTIAL)' },
    ],
  },

  // Design Tools
  'color-palette-generator': {
    tip: 'Generate harmonic color palettes based on color theory formulas.',
    bestPractice: 'Analogous harmonies provide serene branding, while Complementary and Triadic modes maximize visual punch and button CTA pop.',
    shortcuts: [
      { keys: ['Spacebar'], description: 'Generate fresh harmonic palette' },
      { keys: ['Click Hex'], description: 'Copy color code to clipboard' },
    ],
  },
  'contrast-checker': {
    tip: 'Verify WCAG 2.1 compliance for text readability and accessibility.',
    bestPractice: 'Aim for at least 4.5:1 for standard body text (AA) and 7:1 for AAA certification to guarantee readability in sunlight.',
    shortcuts: [
      { keys: ['Swap'], description: 'Invert foreground and background colors' },
    ],
  },
  'gradient-generator': {
    tip: 'Craft multi-stop linear and radial CSS gradients with one-click CSS copy.',
    bestPractice: 'Keep color stops within adjacent hues or subtle saturation shifts to prevent muddy grey bands in the gradient midpoint.',
    shortcuts: [
      { keys: ['Angle'], description: 'Rotate direction angle wheel' },
      { keys: ['Copy CSS'], description: 'Copy production-ready CSS snippet' },
    ],
  },
  'box-shadow-generator': {
    tip: 'Layer smooth multi-level drop shadows for realistic depth.',
    bestPractice: 'Use large blur (20px+) with low opacity (8%–15%) for modern elevation cards instead of harsh, dark retro shadows.',
    shortcuts: [
      { keys: ['Inset Toggle'], description: 'Switch between outer elevation and inner pressed deboss' },
    ],
  },
  'color-shades-generator': {
    tip: 'Compute a complete 11-step Tailwind/Material design shade ramp (50 to 950).',
    bestPractice: 'Use shade 500 as the primary button background, 50 for subtle hover tints, and 900 for dark mode typography.',
    shortcuts: [
      { keys: ['Paste Hex'], description: 'Enter any brand hex color' },
      { keys: ['Click Swatch'], description: 'Copy individual shade hex value' },
    ],
  },

  // Data Tools
  'csv-to-json': {
    tip: 'Transform spreadsheet CSV rows into structured JSON arrays or objects.',
    bestPractice: 'Toggle "Auto-detect Data Types" so numbers and booleans are parsed as true primitives rather than string literals.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste raw CSV text' },
      { keys: ['Download'], description: 'Export .json data file' },
    ],
  },
  'json-to-csv': {
    tip: 'Flatten nested or tabular JSON arrays into comma-separated spreadsheet data.',
    bestPractice: 'Ensure all JSON objects share consistent keys for clean column mapping in Excel and Google Sheets.',
    shortcuts: [
      { keys: ['Download'], description: 'Export .csv spreadsheet file' },
    ],
  },
  'csv-viewer-filter': {
    tip: 'Inspect large CSV datasets in an interactive paginated table with column search.',
    bestPractice: 'Filter columns dynamically to locate outlier records without needing desktop spreadsheet software.',
    shortcuts: [
      { keys: ['Filter'], description: 'Type in column search inputs' },
    ],
  },
  'xml-to-json': {
    tip: 'Parse hierarchical XML trees and RSS feeds into modern JSON trees.',
    bestPractice: 'Attributes and text nodes are cleanly normalized into inspectable JSON dictionaries.',
    shortcuts: [
      { keys: ['Format'], description: 'Prettify resulting JSON' },
    ],
  },
  'json-to-xml': {
    tip: 'Convert JSON payloads into valid XML with custom root and item tags.',
    bestPractice: 'Specify your root element name to conform to legacy SOAP or enterprise XML schemas.',
    shortcuts: [
      { keys: ['Copy XML'], description: 'Copy compliant XML document' },
    ],
  },
  'yaml-json-converter': {
    tip: 'Bidirectional converter between YAML configuration and JSON data.',
    bestPractice: 'Essential for Docker Compose, Kubernetes manifests, GitHub Actions workflows, and OpenAPI schemas.',
    shortcuts: [
      { keys: ['Switch Mode'], description: 'Toggle between YAML→JSON and JSON→YAML' },
    ],
  },

  // SEO Tools
  'meta-tag-generator': {
    tip: 'Generate search and social meta tags with real-time Google & Twitter SERP previews.',
    bestPractice: 'Keep titles under 60 characters and descriptions between 140–160 characters to prevent truncation in search result snippets.',
    shortcuts: [
      { keys: ['Live Preview'], description: 'Preview cards in Google, Facebook, and Twitter cards' },
    ],
  },
  'robots-txt-generator': {
    tip: 'Formulate search engine crawler permissions with fine-grained path rules.',
    bestPractice: 'Always link your XML sitemap URL at the bottom of robots.txt to speed up bot discovery.',
    shortcuts: [
      { keys: ['Disallow'], description: 'Add directories to restrict from crawlers' },
    ],
  },
  'xml-sitemap-generator': {
    tip: 'Assemble standard sitemap.xml files with change frequencies and priorities.',
    bestPractice: 'Give your homepage a priority of 1.0 and main category pages 0.8 for optimized search crawl budget allocation.',
    shortcuts: [
      { keys: ['Download'], description: 'Save as valid sitemap.xml' },
    ],
  },
  'open-graph-previewer': {
    tip: 'Preview how your web links appear when shared across social networks.',
    bestPractice: 'Use 1200x630 pixel images with centered visual motifs to avoid awkward automatic mobile crops.',
    shortcuts: [
      { keys: ['Platform Tabs'], description: 'Switch between Facebook, Twitter/X, and LinkedIn' },
    ],
  },
  'keyword-density-checker': {
    tip: 'Analyze single, 2-word, and 3-word phrase frequency in articles and copy.',
    bestPractice: 'Aim for a primary keyword density of 1%–2.5%. Avoid keyword stuffing to protect SEO quality scores.',
    shortcuts: [
      { keys: ['Analyze'], description: 'Compute lexical frequency rankings' },
    ],
  },

  // Finance Tools
  'loan-mortgage-calculator': {
    tip: 'Calculate monthly loan EMI payments and total interest costs over time.',
    bestPractice: 'View the interactive amortization chart to see how extra principal payments dramatically reduce overall interest.',
    shortcuts: [
      { keys: ['Inputs'], description: 'Adjust loan amount, interest rate, and term' },
    ],
  },
  'sales-tax-vat-calculator': {
    tip: 'Quickly compute gross or net amounts with sales tax or VAT included/excluded.',
    bestPractice: 'Use preset buttons for common rates (5%, 8.25%, 10%, 20%) to speed up billing computations.',
    shortcuts: [
      { keys: ['Add / Remove'], description: 'Toggle tax forward calculation or reverse extraction' },
    ],
  },
  'roi-calculator': {
    tip: 'Determine return on investment percentages and annualized gains.',
    bestPractice: 'A positive annualized ROI above your cost of capital indicates profitable capital deployment.',
    shortcuts: [
      { keys: ['Calculate'], description: 'Update net profit and percentage yield' },
    ],
  },
  'break-even-calculator': {
    tip: 'Find the exact sales volume and revenue required to cover fixed and variable costs.',
    bestPractice: 'Identify your contribution margin per unit to gauge how discounts affect your business safety margin.',
    shortcuts: [
      { keys: ['Units / Revenue'], description: 'Instant calculation of break-even threshold' },
    ],
  },
  'salary-hourly-calculator': {
    tip: 'Convert between annual salary, monthly pay, weekly income, and hourly rates.',
    bestPractice: 'Standard calculations assume 40 hours per week across 52 weeks (2,080 working hours per year).',
    shortcuts: [
      { keys: ['Any Field'], description: 'Change any wage tier to synchronize all others' },
    ],
  },

  // Productivity Tools
  'world-clock-converter': {
    tip: 'Synchronize timezones across global teams and clients in real time.',
    bestPractice: 'Use the slider to drag meeting hours and check local business hours across London, New York, Tokyo, and Sydney.',
    shortcuts: [
      { keys: ['Time Slider'], description: 'Slide forward or backward to inspect cross-zone hours' },
    ],
  },
  'stopwatch-timer': {
    tip: 'High-precision millisecond stopwatch with split lap tracking.',
    bestPractice: 'Export lap history directly into a clipboard or text file for athletic training or workflow audits.',
    shortcuts: [
      { keys: ['Spacebar'], description: 'Start / Stop stopwatch' },
      { keys: ['L'], description: 'Record current split lap time' },
      { keys: ['R'], description: 'Reset stopwatch to zero' },
    ],
  },
  'event-countdown-timer': {
    tip: 'Track remaining days, hours, minutes, and seconds until upcoming milestones.',
    bestPractice: 'Add product launches, deadlines, or exams to track progress visually with live second-by-second updates.',
    shortcuts: [
      { keys: ['Date Picker'], description: 'Select target milestone timestamp' },
    ],
  },
  'work-hours-calculator': {
    tip: 'Sum weekly timesheet shifts, deduct lunch breaks, and tally gross earnings.',
    bestPractice: 'Log start, end, and break times per weekday to automate contractor billing and payroll compliance.',
    shortcuts: [
      { keys: ['Add Day'], description: 'Append additional shift entries' },
    ],
  },

  // Social Tools
  'youtube-thumbnail-grabber': {
    tip: 'Extract maximum-resolution (1080p HD) cover graphics from any YouTube URL.',
    bestPractice: 'Works with youtube.com/watch, youtu.be short links, and YouTube Shorts URLs alike.',
    shortcuts: [
      { keys: ['Ctrl', 'V'], description: 'Paste YouTube video link' },
      { keys: ['Download'], description: 'Save max-res thumbnail image' },
    ],
  },
  'social-post-formatter': {
    tip: 'Convert ordinary text into bold, italic, monospace, and bubble Unicode typography.',
    bestPractice: 'Use bold or serif accents on key words in LinkedIn and Instagram captions to grab attention in crowded feeds.',
    shortcuts: [
      { keys: ['Style Tabs'], description: 'Click any style variant to instantly copy' },
    ],
  },
  'hashtag-generator': {
    tip: 'Generate categorized tags for Instagram, TikTok, LinkedIn, and YouTube.',
    bestPractice: 'Combine high-volume trending tags with niche specific tags for optimal organic discoverability without shadowbanning.',
    shortcuts: [
      { keys: ['One-Click'], description: 'Copy all tags pre-formatted with #' },
    ],
  },
  'bio-link-generator': {
    tip: 'Design a sleek mobile bio landing page with custom links and themes.',
    bestPractice: 'Place your highest-value link at the top and test the live mobile mock preview before sharing.',
    shortcuts: [
      { keys: ['Add Link'], description: 'Add new social or web destination' },
      { keys: ['Theme Selector'], description: 'Switch color gradients and aesthetics' },
    ],
  },

  // Education Tools
  'roman-numeral-converter': {
    tip: 'Convert between standard Arabic numbers and classical Roman numerals.',
    bestPractice: 'Supports values from 1 to 3,999 (I to MMMCMXCIX) with complete breakdown explanations of subtractive notation rules.',
    shortcuts: [
      { keys: ['Enter'], description: 'Swap conversion direction' },
    ],
  },
  'morse-code-translator': {
    tip: 'Translate text to Morse code with built-in Web Audio oscillator beeps.',
    bestPractice: 'Click "Play Sound" to listen to authentic dit and dah acoustic audio playback directly from browser synthesis.',
    shortcuts: [
      { keys: ['Play'], description: 'Hear audio acoustic playback' },
      { keys: ['Copy'], description: 'Copy dots and dashes' },
    ],
  },
  'binary-text-converter': {
    tip: 'Translate ASCII and Unicode text into 8-bit binary and vice-versa.',
    bestPractice: 'Inspect individual byte encodings to learn how computers represent strings and characters in memory.',
    shortcuts: [
      { keys: ['Toggle'], description: 'Switch between Text→Binary and Binary→Text' },
    ],
  },
  'fraction-calculator': {
    tip: 'Add, subtract, multiply, and divide fractions with automated reduction.',
    bestPractice: 'Returns both the simplified fraction and its exact decimal and mixed number equivalents with step-by-step math.',
    shortcuts: [
      { keys: ['Operation'], description: 'Select +, -, ×, or ÷' },
    ],
  },

  // AI & Smart Tools
  'headline-analyzer': {
    tip: 'Score headlines on sentiment, emotional resonance, power words, and readability.',
    bestPractice: 'Headlines between 6–10 words that include emotional triggers and numbers achieve significantly higher CTR in search and social feeds.',
    shortcuts: [
      { keys: ['Enter'], description: 'Re-analyze headline metrics' },
    ],
  },
  'ai-prompt-generator': {
    tip: 'Structure detailed prompts using Role, Goal, Context, and Output constraints.',
    bestPractice: 'Specifying the persona and explicit constraints prevents AI hallucinations and dramatically improves output quality.',
    shortcuts: [
      { keys: ['Template Presets'], description: 'Quick-load Coding, Writing, Marketing, or Summarizing archetypes' },
      { keys: ['Copy Prompt'], description: 'Copy ready-to-use prompt' },
    ],
  },
  'text-summarizer': {
    tip: 'Extract the most salient key sentences and main topics using sentence scoring.',
    bestPractice: 'Adjust the summary length slider between 20%–50% to obtain concise executive briefings of long essays, articles, or reports.',
    shortcuts: [
      { keys: ['Length Slider'], description: 'Tune compression ratio' },
    ],
  },
};

interface QuickTipTooltipProps {
  toolSlug: string;
  fallbackTip?: string;
}

export const QuickTipTooltip: React.FC<QuickTipTooltipProps> = ({
  toolSlug,
  fallbackTip,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const info: QuickTipInfo = TOOL_QUICK_TIPS[toolSlug] || {
    tip: fallbackTip || 'All calculations and file processing run 100% locally in your browser memory for maximum speed and privacy.',
    bestPractice: 'No data leaves your device, guaranteeing total confidentiality with no upload limits or signup barriers.',
    shortcuts: [
      { keys: ['Ctrl', 'K'], description: 'Open search anytime to find any other tool' },
      { keys: ['Ctrl', 'V'], description: 'Paste input data directly into active fields' },
    ],
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Handle escape key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const copyTipText = () => {
    const textToCopy = `${info.tip} ${info.bestPractice ? `Best Practice: ${info.bestPractice}` : ''}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="relative inline-block" ref={containerRef}>
      {/* Quick Tip Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        onMouseEnter={() => setIsOpen(true)}
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        className={`group flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-150 border ${
          isOpen
            ? 'bg-amber-500/10 text-amber-600 border-amber-300 dark:border-amber-700/60 dark:text-amber-400 shadow-xs'
            : 'bg-white hover:bg-amber-50/60 text-slate-700 hover:text-amber-700 border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-amber-400'
        }`}
        title="View Quick Tips & Keyboard Shortcuts"
      >
        <span className="flex h-4 w-4 items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-950/80 dark:text-amber-400 group-hover:scale-110 transition-transform">
          <Lightbulb className="h-2.5 w-2.5 fill-amber-500" />
        </span>
        <span className="font-medium">Quick Tip</span>
        <span className="hidden sm:inline-flex items-center text-[10px] font-mono text-slate-400 dark:text-slate-500">
          <Keyboard className="h-3 w-3 mr-0.5 opacity-70" />
          Shortcuts
        </span>
      </button>

      {/* Floating Tooltip / Popover Card */}
      {isOpen && (
        <div
          role="dialog"
          aria-label="Quick Tip and Shortcuts"
          className="absolute right-0 top-full mt-2 w-80 sm:w-96 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xl z-50 text-left animate-in fade-in zoom-in-95 duration-150 ring-1 ring-black/5 dark:ring-white/5"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2.5 mb-3">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-400">
                <Sparkles className="h-3.5 w-3.5" />
              </div>
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Pro Tip & Best Practices
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={copyTipText}
                className="text-[11px] font-medium text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 px-1.5 py-0.5 rounded transition-colors"
                title="Copy tip text"
              >
                {copiedKey ? <Check className="h-3.5 w-3.5 text-emerald-500 inline" /> : 'Copy'}
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1 rounded-md transition-colors"
                aria-label="Close tooltip"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Tip Content */}
          <div className="space-y-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <div className="bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 rounded-xl p-3 text-amber-900 dark:text-amber-200">
              <p className="font-semibold text-amber-950 dark:text-amber-100 mb-1 flex items-center gap-1.5">
                <Lightbulb className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                {info.tip}
              </p>
              {info.bestPractice && (
                <p className="text-[11px] text-amber-800/90 dark:text-amber-300/80 mt-1">
                  {info.bestPractice}
                </p>
              )}
            </div>

            {/* Keyboard Shortcuts Section */}
            {info.shortcuts && info.shortcuts.length > 0 && (
              <div>
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
                  <Command className="h-3 w-3" />
                  <span>Efficient Shortcuts</span>
                </div>
                <div className="space-y-1.5 bg-slate-50 dark:bg-slate-950/50 rounded-xl p-2.5 border border-slate-100 dark:border-slate-800">
                  {info.shortcuts.map((sc, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs gap-2">
                      <span className="text-slate-600 dark:text-slate-400 text-[11px]">
                        {sc.description}
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        {sc.keys.map((k, kIdx) => (
                          <React.Fragment key={kIdx}>
                            <kbd className="inline-block px-1.5 py-0.5 text-[10px] font-mono font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md shadow-2xs">
                              {k}
                            </kbd>
                            {kIdx < sc.keys.length - 1 && (
                              <span className="text-[10px] text-slate-400">+</span>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer note */}
          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500">
            <span>Runs 100% in-browser</span>
            <span>Esc to close</span>
          </div>
        </div>
      )}
    </div>
  );
};
