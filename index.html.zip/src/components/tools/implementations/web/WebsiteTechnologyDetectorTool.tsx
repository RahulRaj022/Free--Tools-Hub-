import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Layers, AlertCircle, Loader2, RotateCcw, CheckCircle, ShieldCheck } from 'lucide-react';

interface TechItem {
  name: string;
  category: 'CMS' | 'Framework' | 'Analytics' | 'CDN & Hosting' | 'Web Server';
  evidence: string;
}

export const WebsiteTechnologyDetectorTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [technologies, setTechnologies] = useState<TechItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  const detectTech = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setTechnologies([]);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to inspect website.');
      }

      const html = (data.html || '').toLowerCase();
      const headers = data.headers || {};
      const found: TechItem[] = [];

      // 1. Web Servers
      const serverHeader = (headers['server'] || '').toLowerCase();
      if (serverHeader.includes('cloudflare')) {
        found.push({ name: 'Cloudflare', category: 'CDN & Hosting', evidence: 'HTTP "server: cloudflare" header' });
      } else if (serverHeader.includes('nginx')) {
        found.push({ name: 'Nginx', category: 'Web Server', evidence: 'HTTP "server: nginx" header' });
      } else if (serverHeader.includes('apache')) {
        found.push({ name: 'Apache HTTP Server', category: 'Web Server', evidence: 'HTTP "server: apache" header' });
      } else if (serverHeader.includes('caddy')) {
        found.push({ name: 'Caddy', category: 'Web Server', evidence: 'HTTP "server: caddy" header' });
      }

      if (headers['x-vercel-id']) {
        found.push({ name: 'Vercel', category: 'CDN & Hosting', evidence: 'HTTP "x-vercel-id" header' });
      }
      if (headers['cf-ray']) {
        if (!found.some((t) => t.name === 'Cloudflare')) {
          found.push({ name: 'Cloudflare Edge CDN', category: 'CDN & Hosting', evidence: 'HTTP "cf-ray" header' });
        }
      }

      // 2. CMS
      if (html.includes('wp-content') || html.includes('wp-includes')) {
        found.push({ name: 'WordPress', category: 'CMS', evidence: 'Public wp-content path references' });
      }
      if (html.includes('cdn.shopify.com')) {
        found.push({ name: 'Shopify', category: 'CMS', evidence: 'Public cdn.shopify.com asset links' });
      }
      if (html.includes('ghost-portal') || html.includes('ghost.org')) {
        found.push({ name: 'Ghost CMS', category: 'CMS', evidence: 'Ghost portal script reference' });
      }
      if (html.includes('wix.com') || html.includes('_wix')) {
        found.push({ name: 'Wix', category: 'CMS', evidence: 'Wix static bundle signatures' });
      }

      // 3. Frontend Frameworks & Libraries
      if (html.includes('__next') || html.includes('_next/static')) {
        found.push({ name: 'Next.js', category: 'Framework', evidence: 'Found Next.js "__next" root element' });
        found.push({ name: 'React', category: 'Framework', evidence: 'React engine used by Next.js' });
      } else if (html.includes('react') || html.includes('data-reactroot')) {
        found.push({ name: 'React', category: 'Framework', evidence: 'Found React DOM attributes' });
      }

      if (html.includes('__nuxt') || html.includes('nuxt.js')) {
        found.push({ name: 'Nuxt.js', category: 'Framework', evidence: 'Nuxt client bundle' });
        found.push({ name: 'Vue.js', category: 'Framework', evidence: 'Vue engine used by Nuxt' });
      } else if (html.includes('vue.js') || html.includes('data-v-')) {
        found.push({ name: 'Vue.js', category: 'Framework', evidence: 'Found Vue template attributes' });
      }

      if (html.includes('tailwindcss') || html.includes('class="flex ') || html.includes('class="grid ')) {
        found.push({ name: 'Tailwind CSS', category: 'Framework', evidence: 'Tailwind utility class patterns' });
      }
      if (html.includes('bootstrap.min.css') || html.includes('bootstrap.bundle')) {
        found.push({ name: 'Bootstrap', category: 'Framework', evidence: 'Bootstrap stylesheet reference' });
      }
      if (html.includes('jquery.min.js') || html.includes('jquery-')) {
        found.push({ name: 'jQuery', category: 'Framework', evidence: 'jQuery script include' });
      }

      // 4. Analytics
      if (html.includes('googletagmanager.com/gtm.js') || html.includes('gtm-')) {
        found.push({ name: 'Google Tag Manager', category: 'Analytics', evidence: 'GTM script tag' });
      }
      if (html.includes('google-analytics.com') || html.includes('gtag(') || html.includes('g-')) {
        found.push({ name: 'Google Analytics 4', category: 'Analytics', evidence: 'Google Analytics / gtag.js loader' });
      }
      if (html.includes('hotjar.com') || html.includes('static.hotjar.com')) {
        found.push({ name: 'Hotjar', category: 'Analytics', evidence: 'Hotjar tracking script' });
      }

      if (found.length === 0) {
        found.push({
          name: 'Vanilla Modern HTML5',
          category: 'Framework',
          evidence: 'Clean semantic markup without heavy third-party framework wrappers',
        });
      }

      setTechnologies(found);
      showToast(`Detected ${found.length} web technologies!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error detecting website technology stack.');
    } finally {
      setLoading(false);
    }
  };

  const categories = ['CMS', 'Framework', 'Analytics', 'CDN & Hosting', 'Web Server'] as const;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Public Website to Inspect
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && detectTech()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={detectTech}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Layers className="h-4 w-4" />}
            <span>{loading ? 'Inspecting...' : 'Detect Technologies'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setTechnologies([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {technologies.length > 0 && (
        <div className="space-y-6 animate-in fade-in">
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Detected Stack ({technologies.length} components)
            </h4>
            <span className="flex items-center gap-1.5 text-xs text-slate-500">
              <ShieldCheck className="h-4 w-4 text-emerald-500" />
              Verified via public observable signals
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categories.map((cat) => {
              const items = technologies.filter((t) => t.category === cat);
              if (items.length === 0) return null;
              return (
                <div
                  key={cat}
                  className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3"
                >
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    {cat}
                  </span>
                  <div className="space-y-2.5">
                    {items.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sm text-slate-900 dark:text-white">
                            {item.name}
                          </span>
                          <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle className="h-3 w-3" /> Detected
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 font-mono">
                          Evidence: {item.evidence}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
