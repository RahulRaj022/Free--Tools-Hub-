import React, { useState, useEffect, useRef } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Play, Pause, RotateCcw, Volume2, Dices, Copy, Check, Sparkles } from 'lucide-react';

interface StudentToolsProps {
  toolSlug: string;
}

export const StudentTools: React.FC<StudentToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // Pomodoro Timer states
  const [timerMode, setTimerMode] = useState<'pomodoro' | 'shortBreak' | 'longBreak'>('pomodoro');
  const [timeLeft, setTimeLeft] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [completedSessions, setCompletedSessions] = useState<number>(0);

  // RNG states
  const [rngMin, setRngMin] = useState<number>(1);
  const [rngMax, setRngMax] = useState<number>(100);
  const [rngCount, setRngCount] = useState<number>(5);
  const [allowDuplicates, setAllowDuplicates] = useState<boolean>(false);
  const [sortResult, setSortResult] = useState<'none' | 'asc' | 'desc'>('none');
  const [randomNumbers, setRandomNumbers] = useState<number[]>([]);

  // Sound generator using Web Audio API
  const playChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.15); // A5

      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 0.6);
    } catch {
      // Audio might be blocked by browser policy until interaction
    }
  };

  // Timer interval effect
  useEffect(() => {
    let interval: any = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      playChime();
      if (timerMode === 'pomodoro') {
        setCompletedSessions((prev) => prev + 1);
        showToast('Pomodoro session completed! Take a break.', 'success');
      } else {
        showToast('Break finished! Ready to focus?', 'info');
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, timerMode, showToast]);

  const switchMode = (mode: 'pomodoro' | 'shortBreak' | 'longBreak') => {
    setTimerMode(mode);
    setIsRunning(false);
    if (mode === 'pomodoro') setTimeLeft(25 * 60);
    else if (mode === 'shortBreak') setTimeLeft(5 * 60);
    else setTimeLeft(15 * 60);
  };

  const resetTimer = () => {
    setIsRunning(false);
    if (timerMode === 'pomodoro') setTimeLeft(25 * 60);
    else if (timerMode === 'shortBreak') setTimeLeft(5 * 60);
    else setTimeLeft(15 * 60);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Total seconds for current mode for progress ring
  const totalModeSeconds = timerMode === 'pomodoro' ? 25 * 60 : timerMode === 'shortBreak' ? 5 * 60 : 15 * 60;
  const progressPercent = ((totalModeSeconds - timeLeft) / totalModeSeconds) * 100;

  // RNG Logic
  const generateNumbers = () => {
    if (rngMin > rngMax) {
      showToast('Min value cannot be greater than Max', 'error');
      return;
    }

    const range = rngMax - rngMin + 1;
    if (!allowDuplicates && rngCount > range) {
      showToast(`Cannot pick ${rngCount} unique numbers in a range of ${range}`, 'error');
      return;
    }

    const results: number[] = [];
    if (allowDuplicates) {
      for (let i = 0; i < rngCount; i++) {
        const rand = Math.floor(Math.random() * range) + rngMin;
        results.push(rand);
      }
    } else {
      const set = new Set<number>();
      while (set.size < rngCount) {
        const rand = Math.floor(Math.random() * range) + rngMin;
        set.add(rand);
      }
      results.push(...Array.from(set));
    }

    if (sortResult === 'asc') results.sort((a, b) => a - b);
    if (sortResult === 'desc') results.sort((a, b) => b - a);

    setRandomNumbers(results);
    showToast('Generated random numbers', 'success');
  };

  useEffect(() => {
    if (toolSlug === 'random-number-generator') {
      generateNumbers();
    }
  }, [rngMin, rngMax, rngCount, allowDuplicates, sortResult]);

  return (
    <div className="space-y-6">
      {/* 1. POMODORO TIMER */}
      {toolSlug === 'pomodoro-timer' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800 dark:bg-slate-900 shadow-xs flex flex-col items-center text-center space-y-6">
          
          {/* Mode Tabs */}
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs sm:text-sm font-semibold">
            <button
              onClick={() => switchMode('pomodoro')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                timerMode === 'pomodoro' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Focus (25m)
            </button>
            <button
              onClick={() => switchMode('shortBreak')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                timerMode === 'shortBreak' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Short Break (5m)
            </button>
            <button
              onClick={() => switchMode('longBreak')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                timerMode === 'longBreak' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Long Break (15m)
            </button>
          </div>

          {/* Time Display */}
          <div className="relative flex flex-col items-center justify-center">
            <div className="text-6xl sm:text-7xl font-extrabold font-mono tracking-tighter text-slate-900 dark:text-white tabular-nums">
              {formatTime(timeLeft)}
            </div>
            <div className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
              {timerMode === 'pomodoro' ? 'Focus Session' : 'Rest Interval'}
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`flex items-center gap-2 px-6 py-3 text-sm font-bold text-white rounded-xl shadow-md transition-all ${
                isRunning
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-indigo-600 hover:bg-indigo-700 hover:scale-105'
              }`}
            >
              {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              <span>{isRunning ? 'Pause' : 'Start Focus'}</span>
            </button>
            <button
              onClick={resetTimer}
              className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Reset Timer"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* Sessions Counter */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-4 text-xs text-slate-500">
            <span>
              Completed Sprints: <strong className="text-indigo-600 dark:text-indigo-400 font-mono text-sm">{completedSessions}</strong>
            </span>
            <button
              onClick={playChime}
              className="flex items-center gap-1 hover:text-slate-800 dark:hover:text-slate-200"
              title="Test audio alert chime"
            >
              <Volume2 className="h-3.5 w-3.5" />
              <span>Test Chime</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. RANDOM NUMBER GENERATOR */}
      {toolSlug === 'random-number-generator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Minimum Value
              </label>
              <input
                type="number"
                value={rngMin}
                onChange={(e) => setRngMin(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Maximum Value
              </label>
              <input
                type="number"
                value={rngMax}
                onChange={(e) => setRngMax(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Quantity of Numbers
              </label>
              <input
                type="number"
                min="1"
                max="100"
                value={rngCount}
                onChange={(e) => setRngCount(Math.max(1, Math.min(100, Number(e.target.value))))}
                className="w-full px-3.5 py-2 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            <div className="flex items-center gap-4 text-xs font-medium text-slate-700 dark:text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowDuplicates}
                  onChange={(e) => setAllowDuplicates(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600"
                />
                Allow Duplicates
              </label>

              <div className="flex items-center gap-1.5">
                <span>Sort:</span>
                <select
                  value={sortResult}
                  onChange={(e) => setSortResult(e.target.value as any)}
                  className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="none">As Rolled</option>
                  <option value="asc">Ascending (Low to High)</option>
                  <option value="desc">Descending (High to Low)</option>
                </select>
              </div>
            </div>

            {/* Presets */}
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-400">Presets:</span>
              <button
                onClick={() => { setRngMin(1); setRngMax(6); setRngCount(1); }}
                className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                1d6
              </button>
              <button
                onClick={() => { setRngMin(1); setRngMax(20); setRngCount(1); }}
                className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                1d20
              </button>
              <button
                onClick={() => { setRngMin(1); setRngMax(100); setRngCount(5); }}
                className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                1-100 (5)
              </button>
            </div>
          </div>

          <button
            onClick={generateNumbers}
            className="flex items-center justify-center gap-2 w-full py-2.5 px-4 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Dices className="h-4 w-4" />
            Generate Numbers
          </button>

          {randomNumbers.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500">
                <span>Result ({randomNumbers.length} numbers):</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(randomNumbers.join(', '));
                    showToast('Copied numbers', 'success');
                  }}
                  className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400"
                >
                  <Copy className="h-3.5 w-3.5" />
                  Copy All
                </button>
              </div>

              <div className="flex flex-wrap gap-2.5 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                {randomNumbers.map((num, idx) => (
                  <div
                    key={idx}
                    className="flex h-12 min-w-12 px-3 items-center justify-center rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-lg font-bold text-slate-900 dark:text-white shadow-xs"
                  >
                    {num}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
