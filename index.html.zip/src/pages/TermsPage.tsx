import React, { useEffect } from 'react';
import { Breadcrumbs } from '../components/layout/Breadcrumbs';
import { BackButton } from '../components/common/BackButton';

interface TermsPageProps {
  navigate: (path: string) => void;
}

export const TermsPage: React.FC<TermsPageProps> = ({ navigate }) => {
  useEffect(() => {
    document.title = 'Terms of Service – Free Tools Hub';
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <BackButton navigate={navigate} fallbackPath="/" />
        <Breadcrumbs items={[{ label: 'Terms of Service' }]} navigate={navigate} />
      </div>

      <div className="border-b border-slate-200/80 pb-6 dark:border-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Terms of Service
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Last updated: October 2026
        </p>
      </div>

      <div className="prose prose-slate dark:prose-invert max-w-none space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            1. Acceptance of Terms
          </h2>
          <p>
            By accessing and using Free Tools Hub, you agree to comply with and be bound by these Terms of Service. If you disagree with any part of these terms, you may refrain from using the website.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            2. Permitted Use
          </h2>
          <p>
            You are granted a free, non-exclusive, revocable license to utilize the utilities provided on Free Tools Hub for personal, educational, and commercial purposes. You agree not to use the tools to produce unlawful, malicious, or abusive materials.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            3. Disclaimer of Warranties
          </h2>
          <p>
            All tools, calculations, conversions, and file processing algorithms are provided &quot;as is&quot; without warranties of any kind, whether express or implied. While we strive for extreme mathematical precision and stability, Free Tools Hub shall not be liable for any inaccuracies, data loss, or damages resulting from the use of our services.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            4. Changes to Service
          </h2>
          <p>
            We reserve the right to modify, introduce new features, or discontinue tools at any time without prior notice.
          </p>
        </section>
      </div>
    </div>
  );
};
