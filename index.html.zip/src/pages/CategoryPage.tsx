import React, { useEffect } from 'react';
import { ToolCategory } from '../types';
import { CATEGORIES, TOOLS_DATA } from '../data/toolsData';
import { ToolCard } from '../components/tools/ToolCard';
import { ToolAppIcon } from '../components/common/ToolAppIcon';
import { Breadcrumbs } from '../components/layout/Breadcrumbs';
import { BackButton } from '../components/common/BackButton';
import { VideoToolsPage } from './VideoToolsPage';

interface CategoryPageProps {
  categorySlug: string;
  navigate: (path: string) => void;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({ categorySlug, navigate }) => {
  if (categorySlug === 'video-tools') {
    return <VideoToolsPage navigate={navigate} />;
  }

  const category = CATEGORIES.find((c) => c.slug === categorySlug);

  useEffect(() => {
    if (category) {
      document.title = `${category.name} Online – Free Browser Utilities | Free Tools Hub`;
      const meta = document.querySelector('meta[name="description"]');
      if (meta) {
        meta.setAttribute('content', `${category.description} Free, client-side, with no signup required.`);
      }
    }
  }, [category]);

  if (!category) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">Category Not Found</h1>
        <button onClick={() => navigate('/tools')} className="mt-4 text-indigo-600 hover:underline">
          Browse all tools
        </button>
      </div>
    );
  }

  const categoryTools = TOOLS_DATA.filter((t) => t.category === category.id);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Top Navigation: Back Button & Breadcrumbs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <BackButton navigate={navigate} fallbackPath="/tools" />
        <Breadcrumbs
          items={[
            { label: 'All Tools', path: '/tools' },
            { label: category.name },
          ]}
          navigate={navigate}
        />
      </div>

      {/* Category Header */}
      <div className="flex items-center gap-4 border-b border-slate-200/80 pb-6 dark:border-slate-800">
        <ToolAppIcon
          category={category.id}
          size="xl"
          alt={category.name}
          interactive={false}
        />
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            {category.name}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {category.description}
          </p>
        </div>
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
        {categoryTools.map((tool) => (
          <ToolCard
            key={tool.id}
            tool={tool}
            onSelect={(slug) => navigate(`/tools/${slug}`)}
          />
        ))}
      </div>
    </div>
  );
};
