import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import {
  UploadCloud,
  Copy,
  Download,
  Trash2,
  Check,
  Search,
  FileText,
  FileCode,
  HardDrive,
  Code,
  Info,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';

interface FileUtilityToolsProps {
  toolSlug: string;
}

const COMMON_MIME_TYPES: Array<{ ext: string; mime: string; desc: string }> = [
  { ext: '.pdf', mime: 'application/pdf', desc: 'Portable Document Format' },
  { ext: '.jpg / .jpeg', mime: 'image/jpeg', desc: 'JPEG Image' },
  { ext: '.png', mime: 'image/png', desc: 'Portable Network Graphics' },
  { ext: '.webp', mime: 'image/webp', desc: 'WebP Next-Gen Image' },
  { ext: '.svg', mime: 'image/svg+xml', desc: 'Scalable Vector Graphics' },
  { ext: '.gif', mime: 'image/gif', desc: 'Graphics Interchange Format' },
  { ext: '.json', mime: 'application/json', desc: 'JavaScript Object Notation' },
  { ext: '.csv', mime: 'text/csv', desc: 'Comma-Separated Values' },
  { ext: '.xml', mime: 'application/xml', desc: 'Extensible Markup Language' },
  { ext: '.html / .htm', mime: 'text/html', desc: 'HyperText Markup Language' },
  { ext: '.css', mime: 'text/css', desc: 'Cascading Style Sheets' },
  { ext: '.js', mime: 'text/javascript', desc: 'JavaScript Source File' },
  { ext: '.ts', mime: 'application/typescript', desc: 'TypeScript Source File' },
  { ext: '.mp3', mime: 'audio/mpeg', desc: 'MP3 Audio Stream' },
  { ext: '.wav', mime: 'audio/wav', desc: 'Waveform Audio File Format' },
  { ext: '.mp4', mime: 'video/mp4', desc: 'MPEG-4 Part 14 Video' },
  { ext: '.webm', mime: 'video/webm', desc: 'WebM Video Container' },
  { ext: '.zip', mime: 'application/zip', desc: 'ZIP Archive' },
  { ext: '.tar', mime: 'application/x-tar', desc: 'Tape Archive' },
  { ext: '.gz', mime: 'application/gzip', desc: 'Gzip Compressed File' },
  { ext: '.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', desc: 'Microsoft Word OpenXML' },
  { ext: '.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', desc: 'Microsoft Excel OpenXML' },
  { ext: '.pptx', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', desc: 'Microsoft PowerPoint OpenXML' },
  { ext: '.wasm', mime: 'application/wasm', desc: 'WebAssembly Binary' },
];

export const FileUtilityTools: React.FC<FileUtilityToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // 1. File Renamer
  const [renamerFiles, setRenamerFiles] = useState<File[]>([]);
  const [renamePrefix, setRenamePrefix] = useState('doc_');
  const [renameSuffix, setRenameSuffix] = useState('');
  const [renameFind, setRenameFind] = useState('');
  const [renameReplace, setRenameReplace] = useState('');
  const [autoNumber, setAutoNumber] = useState(true);

  // 2. File Extension Checker
  const [checkedFile, setCheckedFile] = useState<File | null>(null);
  const [magicHex, setMagicHex] = useState<string>('');
  const [detectedType, setDetectedType] = useState<string>('');

  // 3. File Size Converter
  const [sizeInput, setSizeInput] = useState<number>(1024);
  const [sizeUnit, setSizeUnit] = useState<'B' | 'KB' | 'MB' | 'GB' | 'TB'>('MB');

  // 4. MIME Type Lookup
  const [mimeQuery, setMimeQuery] = useState('');

  // 5. Data URI Generator
  const [dataUriFile, setDataUriFile] = useState<File | null>(null);
  const [generatedUri, setGeneratedUri] = useState<string>('');

  // 6. Data URI Decoder
  const [rawUriInput, setRawUriInput] = useState<string>('');
  const [decodedMime, setDecodedMime] = useState<string>('');
  const [decodedBlobUrl, setDecodedBlobUrl] = useState<string | null>(null);

  // Helper copy
  const copyText = (txt: string, msg = 'Copied to clipboard') => {
    navigator.clipboard.writeText(txt);
    showToast(msg, 'success');
  };

  // Renamer preview list
  const renamedList = useMemo(() => {
    return renamerFiles.map((file, idx) => {
      const extIndex = file.name.lastIndexOf('.');
      const baseName = extIndex !== -1 ? file.name.substring(0, extIndex) : file.name;
      const ext = extIndex !== -1 ? file.name.substring(extIndex) : '';

      let newBase = baseName;
      if (renameFind) {
        newBase = newBase.replaceAll(renameFind, renameReplace);
      }
      const numStr = autoNumber ? `_${(idx + 1).toString().padStart(3, '0')}` : '';
      return `${renamePrefix}${newBase}${renameSuffix}${numStr}${ext}`;
    });
  }, [renamerFiles, renamePrefix, renameSuffix, renameFind, renameReplace, autoNumber]);

  // Handle extension check
  const handleCheckFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setCheckedFile(f);

    const slice = f.slice(0, 16);
    const buf = await slice.arrayBuffer();
    const bytes = new Uint8Array(buf);
    const hex = Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
    setMagicHex(hex);

    // Signature recognition
    if (hex.startsWith('25 50 44 46')) setDetectedType('PDF Document (starts with %PDF)');
    else if (hex.startsWith('FF D8 FF')) setDetectedType('JPEG Image');
    else if (hex.startsWith('89 50 4E 47')) setDetectedType('PNG Image');
    else if (hex.startsWith('47 49 46 38')) setDetectedType('GIF Image');
    else if (hex.startsWith('50 4B 03 04')) setDetectedType('ZIP / Office XML (.docx, .xlsx, .zip)');
    else if (hex.startsWith('1F 8B')) setDetectedType('GZIP Archive');
    else if (hex.startsWith('00 00 00') && hex.includes('66 74 79 70')) setDetectedType('MP4 Video');
    else if (hex.startsWith('1A 45 DF A3')) setDetectedType('WebM / Matroska Media');
    else setDetectedType(f.type || 'Plain Data / Text / Binary Stream');

    showToast(`Analyzed ${f.name}`, 'success');
  };

  // File size calculation table
  const sizeBytes = useMemo(() => {
    const multiplier: Record<string, number> = {
      B: 1,
      KB: 1024,
      MB: 1024 ** 2,
      GB: 1024 ** 3,
      TB: 1024 ** 4,
    };
    return (sizeInput || 0) * (multiplier[sizeUnit] || 1);
  }, [sizeInput, sizeUnit]);

  // Handle Data URI generation
  const handleGenerateDataUri = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setDataUriFile(f);

    const reader = new FileReader();
    reader.onload = () => {
      setGeneratedUri(reader.result as string);
      showToast('Generated Data URI!', 'success');
    };
    reader.readAsDataURL(f);
  };

  // Handle Data URI decoding
  const handleDecodeDataUri = (uri: string) => {
    setRawUriInput(uri);
    try {
      const match = uri.match(/^data:([^;]+);base64,(.+)$/);
      if (!match) {
        setDecodedMime('');
        setDecodedBlobUrl(null);
        return;
      }
      const mime = match[1];
      const b64 = match[2];
      setDecodedMime(mime);

      const byteChars = atob(b64);
      const byteNumbers = new Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) {
        byteNumbers[i] = byteChars.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mime });
      setDecodedBlobUrl(URL.createObjectURL(blob));
      showToast('Decoded Data URI!', 'success');
    } catch {
      setDecodedBlobUrl(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. FILE RENAMER */}
      {toolSlug === 'file-renamer' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <FolderOpen className="h-4 w-4 text-indigo-600" />
            <span>Batch File Renamer</span>
          </div>

          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center">
            <input
              type="file"
              id="renamer-upload"
              multiple
              onChange={(e) => setRenamerFiles(Array.from(e.target.files || []))}
              className="hidden"
            />
            <label htmlFor="renamer-upload" className="cursor-pointer">
              <UploadCloud className="h-8 w-8 text-indigo-600 mx-auto mb-2" />
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Choose files to rename ({renamerFiles.length} selected)
              </div>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Prefix</label>
              <input
                type="text"
                value={renamePrefix}
                onChange={(e) => setRenamePrefix(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Suffix</label>
              <input
                type="text"
                value={renameSuffix}
                onChange={(e) => setRenameSuffix(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Find Text</label>
              <input
                type="text"
                value={renameFind}
                onChange={(e) => setRenameFind(e.target.value)}
                placeholder="Replace matching text"
                className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">Replace With</label>
              <input
                type="text"
                value={renameReplace}
                onChange={(e) => setRenameReplace(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="auto-num"
              checked={autoNumber}
              onChange={(e) => setAutoNumber(e.target.checked)}
              className="accent-indigo-600 rounded"
            />
            <label htmlFor="auto-num" className="text-xs font-medium text-slate-700 dark:text-slate-300">
              Append sequential numbering (_001, _002...)
            </label>
          </div>

          {renamerFiles.length > 0 && (
            <div className="max-h-60 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
              {renamerFiles.map((file, idx) => (
                <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                  <span className="text-slate-400 truncate max-w-xs">{file.name}</span>
                  <span className="font-semibold text-indigo-600 truncate max-w-xs">{renamedList[idx]}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. FILE EXTENSION CHECKER */}
      {toolSlug === 'file-extension-checker' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <Info className="h-4 w-4 text-indigo-600" />
            <span>Binary Magic Byte & Extension Auditor</span>
          </div>

          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center">
            <input type="file" id="ext-upload" onChange={handleCheckFile} className="hidden" />
            <label htmlFor="ext-upload" className="cursor-pointer">
              <UploadCloud className="h-8 w-8 text-indigo-600 mx-auto mb-2" />
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {checkedFile ? checkedFile.name : 'Select any file to verify extension'}
              </div>
            </label>
          </div>

          {checkedFile && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block font-medium">Declared Name:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{checkedFile.name}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Detected Binary Type:</span>
                <span className="font-bold text-emerald-600">{detectedType}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">File Size:</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">
                  {(checkedFile.size / 1024).toFixed(1)} KB ({checkedFile.size} bytes)
                </span>
              </div>
              <div className="sm:col-span-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 block font-medium">Magic Bytes (Hex Signature):</span>
                <span className="font-mono text-indigo-600 tracking-wider text-xs">{magicHex}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. FILE SIZE CONVERTER */}
      {toolSlug === 'file-size-converter' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <HardDrive className="h-4 w-4 text-indigo-600" />
            <span>Digital Storage Units Converter</span>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="number"
              value={sizeInput}
              onChange={(e) => setSizeInput(parseFloat(e.target.value) || 0)}
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-base font-bold text-slate-900 dark:text-white"
            />
            <select
              value={sizeUnit}
              onChange={(e) => setSizeUnit(e.target.value as any)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 font-bold text-xs"
            >
              <option value="B">Bytes (B)</option>
              <option value="KB">Kilobytes (KB)</option>
              <option value="MB">Megabytes (MB)</option>
              <option value="GB">Gigabytes (GB)</option>
              <option value="TB">Terabytes (TB)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { label: 'Bytes (B)', val: sizeBytes.toLocaleString() + ' B' },
              { label: 'Kilobytes (KB / KiB)', val: (sizeBytes / 1024).toFixed(3) + ' KB' },
              { label: 'Megabytes (MB / MiB)', val: (sizeBytes / 1024 ** 2).toFixed(4) + ' MB' },
              { label: 'Gigabytes (GB / GiB)', val: (sizeBytes / 1024 ** 3).toFixed(5) + ' GB' },
              { label: 'Terabytes (TB / TiB)', val: (sizeBytes / 1024 ** 4).toFixed(6) + ' TB' },
              { label: 'Bits (b)', val: (sizeBytes * 8).toLocaleString() + ' bits' },
            ].map((item, idx) => (
              <div
                key={idx}
                onClick={() => copyText(item.val, `Copied ${item.val}`)}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 cursor-pointer hover:border-indigo-400 transition-colors"
              >
                <div className="text-[11px] text-slate-400 font-medium">{item.label}</div>
                <div className="font-mono text-xs font-bold text-slate-900 dark:text-white mt-1 truncate">
                  {item.val}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. MIME TYPE LOOKUP */}
      {toolSlug === 'mime-type-lookup' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <FileCode className="h-4 w-4 text-indigo-600" />
            <span>MIME Content-Type Database</span>
          </div>

          <div className="relative">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={mimeQuery}
              onChange={(e) => setMimeQuery(e.target.value)}
              placeholder="Search by extension (e.g. .pdf, .json, mp4) or MIME name..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-white"
            />
          </div>

          <div className="max-h-80 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
            {COMMON_MIME_TYPES.filter(
              (m) =>
                m.ext.toLowerCase().includes(mimeQuery.toLowerCase()) ||
                m.mime.toLowerCase().includes(mimeQuery.toLowerCase()) ||
                m.desc.toLowerCase().includes(mimeQuery.toLowerCase())
            ).map((item, idx) => (
              <div key={idx} className="p-3 flex items-center justify-between text-xs hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white mr-2">{item.ext}</span>
                  <span className="text-slate-400">{item.desc}</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[11px] text-indigo-600">
                    {item.mime}
                  </code>
                  <button
                    onClick={() => copyText(item.mime, `Copied ${item.mime}`)}
                    className="p-1 hover:text-indigo-600"
                    title="Copy MIME type"
                  >
                    <Copy className="h-3.5 w-3.5 text-slate-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. DATA URI GENERATOR */}
      {toolSlug === 'data-uri-generator' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <Code className="h-4 w-4 text-indigo-600" />
            <span>Generate Base64 Data URI Scheme</span>
          </div>

          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center">
            <input type="file" id="datauri-upload" onChange={handleGenerateDataUri} className="hidden" />
            <label htmlFor="datauri-upload" className="cursor-pointer">
              <UploadCloud className="h-8 w-8 text-indigo-600 mx-auto mb-2" />
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {dataUriFile ? dataUriFile.name : 'Select file or image to encode into Data URI'}
              </div>
            </label>
          </div>

          {generatedUri && (
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-600 dark:text-slate-400">
                <span>Resulting Data URI: ({generatedUri.length.toLocaleString()} chars)</span>
                <button
                  onClick={() => copyText(generatedUri, 'Data URI copied!')}
                  className="flex items-center gap-1 text-indigo-600 font-semibold hover:underline"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy URI</span>
                </button>
              </div>
              <textarea
                readOnly
                value={generatedUri}
                rows={5}
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-[11px] leading-relaxed"
              />
            </div>
          )}
        </div>
      )}

      {/* 6. DATA URI DECODER */}
      {toolSlug === 'data-uri-decoder' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <FileText className="h-4 w-4 text-indigo-600" />
            <span>Decode RFC 2397 Data URI</span>
          </div>

          <textarea
            value={rawUriInput}
            onChange={(e) => handleDecodeDataUri(e.target.value)}
            placeholder="Paste your data:image/...;base64,... URI here"
            rows={5}
            className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
          />

          {decodedBlobUrl && (
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Identified Type: {decodedMime}
                </span>
                <span className="text-[11px] text-slate-500">Binary payload reconstructed successfully</span>
              </div>
              <a
                href={decodedBlobUrl}
                download="decoded_file"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-700 shadow-xs"
              >
                <Download className="h-4 w-4" />
                <span>Download File</span>
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
