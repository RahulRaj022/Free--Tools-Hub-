import React, { useState } from 'react';
import {
  Upload,
  Film,
  Music,
  FileText,
  ShieldCheck,
} from 'lucide-react';

export interface MediaInputSelectorProps {
  mediaType: 'video' | 'audio' | 'subtitle';
  acceptedFormats: string;
  onMediaLoaded: (file: File) => void;
  isLoading?: boolean;
}

export const MediaInputSelector: React.FC<MediaInputSelectorProps> = ({
  mediaType,
  acceptedFormats,
  onMediaLoaded,
  isLoading = false,
}) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onMediaLoaded(e.dataTransfer.files[0]);
    }
  };

  const mediaLabel = mediaType === 'subtitle' ? 'Subtitle' : mediaType === 'audio' ? 'Audio' : 'Video';

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleFileDrop}
        className={`rounded-3xl border-2 border-dashed p-8 sm:p-14 text-center transition-all ${
          isDragging
            ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/40 ring-4 ring-indigo-500/10'
            : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900/70 hover:border-indigo-400 dark:hover:border-indigo-500 shadow-xs'
        }`}
      >
        <div className="mx-auto flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mb-5 shadow-xs">
          {mediaType === 'audio' ? (
            <Music className="h-8 w-8 sm:h-10 sm:w-10" />
          ) : mediaType === 'subtitle' ? (
            <FileText className="h-8 w-8 sm:h-10 sm:w-10" />
          ) : (
            <Film className="h-8 w-8 sm:h-10 sm:w-10" />
          )}
        </div>

        <h3 className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white mb-2">
          Upload your {mediaLabel}
        </h3>

        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6 leading-relaxed">
          Drag & drop your {mediaLabel.toLowerCase()} file here, or click below to choose a file from your device.
        </p>

        <label className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 hover:shadow-lg transition-all cursor-pointer">
          <Upload className="h-4 w-4" />
          <span>Choose {mediaLabel} File</span>
          <input
            type="file"
            accept={acceptedFormats}
            disabled={isLoading}
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                onMediaLoaded(e.target.files[0]);
              }
            }}
          />
        </label>

        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400 dark:text-slate-500">
          <span>Supported: {acceptedFormats.replace(/\*/g, '').replace(/,/g, ', ')}</span>
          <span>•</span>
          <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium">
            <ShieldCheck className="h-3.5 w-3.5" />
            100% Private In-Browser Processing
          </span>
        </div>
      </div>
    </div>
  );
};
