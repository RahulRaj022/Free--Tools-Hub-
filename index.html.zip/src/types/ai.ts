export interface ToolRecommendation {
  name: string;
  slug: string;
  path: string;
  category: string;
  description: string;
}

export interface ToolContext {
  name: string;
  slug: string;
  path: string;
  category?: string;
  description?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  recommendations?: ToolRecommendation[];
  isStreaming?: boolean;
  error?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
  toolContext?: ToolContext;
}

export interface AIServiceStatus {
  available: boolean;
  provider: string;
  model: string;
  status: 'connected' | 'unconfigured';
  message: string;
}
