import React from 'react';

export type ToolIconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface ToolAppIconProps {
  slug?: string;
  category?: string;
  name?: string;
  size?: ToolIconSize;
  className?: string;
  alt?: string;
  interactive?: boolean;
}

const SIZE_CONTAINER_CLASSES: Record<ToolIconSize, string> = {
  xs: 'w-7 h-7 rounded-lg shadow-2xs',
  sm: 'w-8 h-8 rounded-lg shadow-xs',
  md: 'w-10 h-10 sm:w-11 sm:h-11 rounded-xl shadow-xs',
  lg: 'w-14 h-14 sm:w-16 sm:h-16 rounded-2xl shadow-md',
  xl: 'w-16 h-16 sm:w-20 sm:h-20 rounded-2xl sm:rounded-3xl shadow-lg',
};

const SIZE_SVG_CLASSES: Record<ToolIconSize, string> = {
  xs: 'w-3.5 h-3.5',
  sm: 'w-4 h-4',
  md: 'w-5 h-5 sm:w-6 sm:h-6',
  lg: 'w-7 h-7 sm:w-8 sm:h-8',
  xl: 'w-9 h-9 sm:w-11 sm:h-11',
};

/**
 * High-definition vector graphics representing the specific function of each tool.
 * Hand-crafted with clean geometry, subtle depth, and crisp silhouettes.
 */
const renderIconVector = (slug?: string, category?: string) => {
  switch (slug) {
    // ==========================================
    // 1. PDF & DOCUMENT TOOLS (Red/Crimson)
    // ==========================================
    case 'pdf-compressor':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Document Sheet */}
          <path d="M7 4h12l6 6v18a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.18" stroke="white" strokeWidth="2" strokeLinejoin="round" />
          <path d="M19 4v6h6" stroke="white" strokeWidth="2" strokeLinejoin="round" />
          {/* Compression Inward Arrows */}
          <path d="M9 18h4m0 0l-2-2m2 2l-2 2" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M23 18h-4m0 0l2-2m-2 2l2 2" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          {/* Central compact core */}
          <rect x="14" y="15" width="4" height="6" rx="1" fill="white" />
        </svg>
      );

    case 'pdf-to-word':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Red Document */}
          <path d="M5 4h10l5 5v17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M15 4v5h5" stroke="white" strokeWidth="1.75" />
          <text x="6" y="21" fill="white" fontSize="6.5" fontWeight="bold" fontFamily="system-ui, sans-serif">PDF</text>
          {/* Word Overlay Badge */}
          <rect x="15" y="14" width="14" height="14" rx="3" fill="#2563EB" stroke="white" strokeWidth="1.5" />
          <text x="18" y="24.5" fill="white" fontSize="9" fontWeight="900" fontFamily="system-ui, sans-serif">W</text>
        </svg>
      );

    case 'word-to-pdf':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Word Doc Base */}
          <path d="M5 4h10l5 5v17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M15 4v5h5" stroke="white" strokeWidth="1.75" />
          <text x="7" y="21" fill="white" fontSize="7" fontWeight="900" fontFamily="system-ui, sans-serif">W</text>
          {/* PDF Target Badge */}
          <rect x="14" y="14" width="15" height="14" rx="3" fill="#DC2626" stroke="white" strokeWidth="1.5" />
          <text x="16" y="24" fill="white" fontSize="6" fontWeight="bold" fontFamily="system-ui, sans-serif">PDF</text>
        </svg>
      );

    case 'pdf-merger':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Rear Sheet */}
          <rect x="5" y="4" width="14" height="18" rx="2" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="1.75" />
          {/* Middle Sheet */}
          <rect x="9" y="7" width="14" height="18" rx="2" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="1.75" />
          {/* Front Sheet */}
          <rect x="13" y="10" width="14" height="18" rx="2" fill="white" fillOpacity="0.35" stroke="white" strokeWidth="1.75" />
          {/* Merge Arrow Down */}
          <circle cx="20" cy="19" r="4.5" fill="#EF4444" stroke="white" strokeWidth="1.5" />
          <path d="M20 16.5v5m-2-2l2 2 2-2" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'pdf-splitter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Left Page Split */}
          <path d="M4 6a2 2 0 0 1 2-2h7v24H6a2 2 0 0 1-2-2V6z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          {/* Right Page Split */}
          <path d="M19 4h7a2 2 0 0 1 2 2v20a2 2 0 0 1-2 2h-7V4z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          {/* Scissor / Cut divide line */}
          <path d="M16 4v24" stroke="white" strokeWidth="1.5" strokeDasharray="2 2" />
          {/* Scissor icon in center */}
          <circle cx="13" cy="14" r="2" stroke="white" strokeWidth="1.5" />
          <circle cx="13" cy="18" r="2" stroke="white" strokeWidth="1.5" />
          <path d="M14.5 15l4 4m-4 0l4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'pdf-to-jpg':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* PDF Document Base */}
          <path d="M5 4h11l5 5v17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M16 4v5h5" stroke="white" strokeWidth="1.75" />
          {/* Picture Frame Badge */}
          <rect x="13" y="14" width="16" height="14" rx="2.5" fill="#059669" stroke="white" strokeWidth="1.5" />
          <circle cx="17.5" cy="18" r="1.5" fill="#FDE047" />
          <path d="M14 26l4-5 3 3 4-5 3 7h-14z" fill="white" />
        </svg>
      );

    case 'jpg-to-pdf':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Image Frame Base */}
          <rect x="4" y="5" width="17" height="15" rx="2.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <circle cx="9" cy="9.5" r="1.5" fill="#FDE047" />
          <path d="M5 18l4-4 3 3 3-4 5 5H5z" fill="white" fillOpacity="0.8" />
          {/* PDF Target Document */}
          <path d="M14 13h10l5 5v10a2 2 0 0 1-2 2H14a2 2 0 0 1-2-2V15a2 2 0 0 1 2-2z" fill="#DC2626" stroke="white" strokeWidth="1.5" />
          <text x="16" y="24" fill="white" fontSize="5.5" fontWeight="bold" fontFamily="system-ui, sans-serif">PDF</text>
        </svg>
      );

    case 'pdf-page-rotator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Center Document */}
          <rect x="9" y="8" width="14" height="16" rx="2" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="1.75" />
          <path d="M12 13h8M12 16h6M12 19h4" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          {/* Clockwise Rotation Arrow */}
          <path d="M27 12A11 11 0 1 0 25 23" stroke="white" strokeWidth="2.25" strokeLinecap="round" />
          <path d="M28 8l-1 4.5-4.5-1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'pdf-page-numberer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Document Sheet */}
          <path d="M6 4h12l6 6v18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M18 4v6h6" stroke="white" strokeWidth="1.75" />
          <path d="M9 11h6M9 14h10" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          {/* Number Stamp Badge */}
          <rect x="10" y="19" width="16" height="8" rx="2" fill="white" />
          <text x="12" y="25.5" fill="#DC2626" fontSize="6.5" fontWeight="900" fontFamily="system-ui, monospace">1·2·3</text>
        </svg>
      );

    case 'pdf-watermark':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Document */}
          <path d="M6 4h12l6 6v18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M18 4v6h6" stroke="white" strokeWidth="1.75" />
          {/* Angled Watermark Stamp */}
          <g transform="rotate(-30 16 18)">
            <rect x="4" y="15" width="24" height="7" rx="1.5" fill="none" stroke="white" strokeWidth="1.5" strokeDasharray="3 1.5" />
            <text x="6" y="20.5" fill="white" fontSize="5" fontWeight="bold" letterSpacing="0.1em" fontFamily="system-ui, sans-serif">SAMPLE</text>
          </g>
        </svg>
      );

    // ==========================================
    // 2. IMAGE TOOLS (Emerald/Teal/Cyan)
    // ==========================================
    case 'image-compressor':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Photo Frame */}
          <rect x="4" y="4" width="24" height="24" rx="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <circle cx="10" cy="10" r="2" fill="white" />
          <path d="M5 24l7-7 4 4 5-6 6 8H5z" fill="white" fillOpacity="0.8" />
          {/* Corner Inward Compression Arrows */}
          <path d="M7 7l4 4m-4 0v-4h4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M25 7l-4 4m4 0v-4h-4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M7 25l4-4m-4 0v4h4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M25 25l-4-4m4 0v4h-4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'image-resizer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Main Photo Outline */}
          <rect x="4" y="4" width="24" height="24" rx="3.5" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="1.75" strokeDasharray="3 2" />
          {/* Inner Resized Frame */}
          <rect x="4" y="4" width="16" height="15" rx="2.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.75" />
          <circle cx="8.5" cy="8.5" r="1.5" fill="#FDE047" />
          <path d="M5 16l4-4 3 3 4-4 3 4H5z" fill="white" />
          {/* Expand / Resize Dual-Headed Arrow */}
          <path d="M17 16l9 9m0 0v-6m0 6h-6" stroke="white" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'image-cropper':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Photo Backdrop */}
          <rect x="7" y="7" width="18" height="18" rx="2" fill="white" fillOpacity="0.18" />
          <circle cx="12" cy="12" r="1.5" fill="white" />
          <path d="M8 23l4-4 3 3 4-5 5 6H8z" fill="white" fillOpacity="0.5" />
          {/* Prominent Framing Crop Corners */}
          <path d="M3 8h6v-5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M29 8h-6v-5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3 24h6v5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M29 24h-6v5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'jpg-to-png':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Left Solid JPG */}
          <rect x="3" y="6" width="12" height="14" rx="2" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="1.5" />
          <text x="4.5" y="15.5" fill="white" fontSize="5" fontWeight="bold" fontFamily="system-ui, sans-serif">JPG</text>
          {/* Right Checkerboard PNG */}
          <rect x="17" y="12" width="12" height="14" rx="2" fill="#0F172A" stroke="white" strokeWidth="1.5" />
          {/* Checker Pattern */}
          <rect x="17" y="12" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="25" y="12" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="21" y="16.5" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="17" y="21" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="25" y="21" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          {/* Arrow */}
          <path d="M12 16h6m-2-2.5l2.5 2.5-2.5 2.5" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'png-to-jpg':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Left Checkerboard PNG */}
          <rect x="3" y="6" width="12" height="14" rx="2" fill="#0F172A" stroke="white" strokeWidth="1.5" />
          <rect x="3" y="6" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="11" y="6" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="7" y="10.5" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="3" y="15" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          <rect x="11" y="15" width="4" height="4.5" fill="white" fillOpacity="0.4" />
          {/* Right Solid JPG */}
          <rect x="17" y="12" width="12" height="14" rx="2" fill="#0284C7" stroke="white" strokeWidth="1.5" />
          <text x="18.5" y="21.5" fill="white" fontSize="5" fontWeight="bold" fontFamily="system-ui, sans-serif">JPG</text>
          {/* Arrow */}
          <path d="M12 16h6m-2-2.5l2.5 2.5-2.5 2.5" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'webp-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Photo base */}
          <rect x="4" y="4" width="24" height="24" rx="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <circle cx="10" cy="10" r="2" fill="#FDE047" />
          <path d="M5 24l6-6 4 4 5-6 7 8H5z" fill="white" fillOpacity="0.75" />
          {/* WebP modern badge */}
          <rect x="11" y="16" width="17" height="11" rx="3" fill="#0284C7" stroke="white" strokeWidth="1.5" />
          <text x="12.5" y="24" fill="white" fontSize="6" fontWeight="bold" fontFamily="system-ui, sans-serif">WEBP</text>
        </svg>
      );

    case 'image-effects':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Aperture / Filter Ring */}
          <circle cx="16" cy="16" r="11" stroke="white" strokeWidth="2" />
          <circle cx="16" cy="16" r="5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.5" />
          {/* Magic Stars / Effects */}
          <path d="M16 2v4M16 26v4M2 16h4M26 16h4" stroke="white" strokeWidth="1.75" strokeLinecap="round" />
          <path d="M23 7l2-2m-2 2l-2-2m2 2l2 2m-2-2l-2 2" stroke="#FDE047" strokeWidth="1.75" strokeLinecap="round" />
          <path d="M7 23l2 2m0-4l-2 2" stroke="#FDE047" strokeWidth="1.75" strokeLinecap="round" />
        </svg>
      );

    // ==========================================
    // 3. TEXT TOOLS (Indigo/Purple/Violet)
    // ==========================================
    case 'word-counter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Serif "Aa" */}
          <text x="3" y="19" fill="white" fontSize="15" fontWeight="900" fontFamily="Georgia, serif">Aa</text>
          {/* Digital Counter Display */}
          <rect x="3" y="22" width="26" height="7" rx="2" fill="#0F172A" stroke="white" strokeWidth="1.25" />
          <text x="6" y="27.5" fill="#38BDF8" fontSize="5.5" fontWeight="bold" fontFamily="monospace">1,248 W</text>
        </svg>
      );

    case 'character-counter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Clean "ABC" */}
          <text x="3" y="17" fill="white" fontSize="11" fontWeight="900" fontFamily="system-ui, sans-serif" letterSpacing="0.05em">ABC</text>
          {/* Counter pill */}
          <rect x="3" y="21" width="26" height="8" rx="2.5" fill="white" />
          <text x="5" y="27" fill="#4F46E5" fontSize="6.5" fontWeight="900" fontFamily="monospace"># 8,420</text>
        </svg>
      );

    case 'case-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Uppercase A */}
          <text x="4" y="18" fill="white" fontSize="14" fontWeight="bold" fontFamily="system-ui, sans-serif">A</text>
          {/* Lowercase a */}
          <text x="20" y="18" fill="white" fontSize="14" fontWeight="bold" fontFamily="system-ui, sans-serif">a</text>
          {/* Switch arrows */}
          <path d="M12 9h7m0 0l-2-2m2 2l-2 2" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M19 23h-7m0 0l2-2m-2 2l2 2" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'remove-extra-spaces':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Text lines */}
          <path d="M4 8h10M20 8h8" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* Extra space highlighted with scissor/collapse arrow */}
          <path d="M15 8h4" stroke="#F43F5E" strokeWidth="2.5" strokeDasharray="1.5 1.5" />
          <path d="M4 16h24M4 24h18" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* Collapse inward marks */}
          <path d="M13 11l2-3-2-3m5 6l-2-3 2-3" stroke="#FDE047" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'text-reverser':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          <text x="4" y="14" fill="white" fontSize="9" fontWeight="bold" fontFamily="monospace">ABC</text>
          <text x="17" y="27" fill="#FDE047" fontSize="9" fontWeight="bold" fontFamily="monospace">CBA</text>
          <path d="M16 8l5 5-5 5m4-5H8" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'slug-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Link Chain */}
          <path d="M9 16a5 5 0 0 1 5-5h3a5 5 0 0 1 5 5M23 16a5 5 0 0 1-5 5h-3a5 5 0 0 1-5-5" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* URL slug badge */}
          <rect x="3" y="21" width="26" height="8" rx="2" fill="#0F172A" stroke="white" strokeWidth="1.25" />
          <text x="4.5" y="27" fill="#38BDF8" fontSize="5.5" fontWeight="bold" fontFamily="monospace">url-slug-test</text>
        </svg>
      );

    case 'lorem-ipsum-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Document Sheet */}
          <rect x="5" y="4" width="22" height="24" rx="3" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          {/* Large capital initial L */}
          <text x="8" y="16" fill="#FDE047" fontSize="12" fontWeight="900" fontFamily="serif">L</text>
          {/* Text lines */}
          <path d="M16 10h8M16 14h8M9 19h14M9 23h10" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'text-sorter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Letters & Lines */}
          <text x="4" y="10" fill="white" fontSize="6.5" fontWeight="bold" fontFamily="system-ui, sans-serif">A</text>
          <path d="M12 8h10" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <text x="4" y="18" fill="white" fontSize="6.5" fontWeight="bold" fontFamily="system-ui, sans-serif">B</text>
          <path d="M12 16h14" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <text x="4" y="26" fill="white" fontSize="6.5" fontWeight="bold" fontFamily="system-ui, sans-serif">Z</text>
          <path d="M12 24h7" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* Sort Arrow Right */}
          <path d="M27 6v18m0 0l-3-3m3 3l3-3" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'duplicate-line-remover':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Lines */}
          <path d="M5 8h16" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* Duplicate row with strikethrough & trash */}
          <path d="M5 16h16" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeOpacity="0.4" />
          <path d="M3 16h20" stroke="#F43F5E" strokeWidth="1.75" />
          <path d="M5 24h16" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* Minus/Delete Badge */}
          <circle cx="25" cy="16" r="4.5" fill="#EF4444" stroke="white" strokeWidth="1.5" />
          <path d="M23 16h4" stroke="white" strokeWidth="1.75" strokeLinecap="round" />
        </svg>
      );

    // ==========================================
    // 4. CALCULATORS & MATH (Amber/Orange)
    // ==========================================
    case 'percentage-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Bold Percentage Symbol */}
          <circle cx="10" cy="10" r="3.5" stroke="white" strokeWidth="2.5" />
          <circle cx="22" cy="22" r="3.5" stroke="white" strokeWidth="2.5" />
          <path d="M23 8L9 24" stroke="white" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );

    case 'age-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Calendar base */}
          <rect x="4" y="6" width="24" height="22" rx="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M4 12h24" stroke="white" strokeWidth="1.75" />
          <path d="M9 3v4M23 3v4" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* Age digits & birthday star */}
          <text x="8" y="24" fill="white" fontSize="10" fontWeight="900" fontFamily="system-ui, sans-serif">25</text>
          <path d="M22 17l1 2 2 .5-1.5 1.5.5 2-2-1-2 1 .5-2-1.5-1.5 2-.5z" fill="#FDE047" />
        </svg>
      );

    case 'discount-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Retail Tag */}
          <path d="M5 16V6a2 2 0 0 1 2-2h10l12 12-12 12L5 16z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" strokeLinejoin="round" />
          <circle cx="10" cy="9" r="2" fill="white" />
          {/* Discount % cut */}
          <text x="13" y="21" fill="#FDE047" fontSize="8" fontWeight="900" fontFamily="system-ui, sans-serif">-%</text>
        </svg>
      );

    case 'bmi-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Gauge dial */}
          <path d="M5 24a12 12 0 0 1 22 0" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
          {/* Gauge needle */}
          <circle cx="16" cy="24" r="3" fill="white" />
          <path d="M16 24l-3-8" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
          <text x="8.5" y="14" fill="white" fontSize="4.5" fontWeight="bold" fontFamily="system-ui, sans-serif">BMI</text>
        </svg>
      );

    case 'tip-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Receipt slip */}
          <path d="M6 4h15l3 3v21l-3-1.5-3 1.5-3-1.5-3 1.5-3-1.5-3 1.5V4z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M10 10h8M10 14h6" stroke="white" strokeWidth="1.75" strokeLinecap="round" />
          {/* Coin with % Tip */}
          <circle cx="21" cy="21" r="6" fill="#F59E0B" stroke="white" strokeWidth="1.5" />
          <text x="18" y="24" fill="white" fontSize="7" fontWeight="bold">%</text>
        </svg>
      );

    case 'average-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Bar Chart Columns */}
          <rect x="5" y="16" width="5" height="11" rx="1.5" fill="white" fillOpacity="0.4" />
          <rect x="13.5" y="9" width="5" height="18" rx="1.5" fill="white" fillOpacity="0.7" />
          <rect x="22" y="13" width="5" height="14" rx="1.5" fill="white" fillOpacity="0.5" />
          {/* Average horizontal line x̄ */}
          <path d="M3 14h26" stroke="#FDE047" strokeWidth="2" strokeDasharray="3 2" />
          <circle cx="16" cy="14" r="2.5" fill="#FDE047" />
        </svg>
      );

    case 'ratio-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Scale balance beam */}
          <path d="M16 6v18M8 24h16" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <path d="M7 11h18" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* Left Pan A */}
          <path d="M5 16h6l-3-5z" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
          {/* Right Pan B */}
          <path d="M21 16h6l-3-5z" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
          <text x="12" y="28" fill="#FDE047" fontSize="6.5" fontWeight="900" fontFamily="monospace">16:9</text>
        </svg>
      );

    case 'simple-interest-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Coin stack */}
          <ellipse cx="12" cy="10" rx="7" ry="3" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.5" />
          <ellipse cx="12" cy="16" rx="7" ry="3" fill="white" fillOpacity="0.4" stroke="white" strokeWidth="1.5" />
          <ellipse cx="12" cy="22" rx="7" ry="3" fill="white" fillOpacity="0.5" stroke="white" strokeWidth="1.5" />
          {/* Linear Growth Ray */}
          <path d="M12 22l14-14m0 0v6m0-6h-6" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'compound-interest-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Exponential Growth Curve */}
          <path d="M5 25c6 0 12-2 15-7s4-11 7-12" stroke="#FDE047" strokeWidth="3" strokeLinecap="round" />
          <path d="M27 6h-6m6 0v6" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          {/* Investment coins */}
          <circle cx="8" cy="24" r="3" fill="white" fillOpacity="0.5" />
          <circle cx="16" cy="18" r="3.5" fill="white" fillOpacity="0.7" />
          <circle cx="23" cy="11" r="4" fill="white" />
        </svg>
      );

    case 'unit-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Horizontal Measuring Ruler */}
          <rect x="4" y="11" width="24" height="10" rx="2.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M8 11v4M12 11v2.5M16 11v4M20 11v2.5M24 11v4" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          {/* Bidirectional Conversion Arrows */}
          <path d="M7 6h18m0 0l-3-3m3 3l-3 3" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M25 26H7m0 0l3-3m-3 3l3 3" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    // ==========================================
    // 5. DEVELOPER TOOLS (Cyan/Blue/Indigo)
    // ==========================================
    case 'json-formatter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Styled Curly Braces { } */}
          <text x="3" y="24" fill="#38BDF8" fontSize="22" fontWeight="900" fontFamily="monospace">{"{"}</text>
          <text x="20" y="24" fill="#38BDF8" fontSize="22" fontWeight="900" fontFamily="monospace">{"}"}</text>
          {/* Formatted code lines */}
          <path d="M12 11h7M14 16h6M12 21h5" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'base64-encoder':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Binary block */}
          <rect x="3" y="6" width="11" height="20" rx="2" fill="#0F172A" stroke="white" strokeWidth="1.5" />
          <text x="4.5" y="13" fill="#38BDF8" fontSize="4.5" fontWeight="bold" fontFamily="monospace">010</text>
          <text x="4.5" y="20" fill="#38BDF8" fontSize="4.5" fontWeight="bold" fontFamily="monospace">110</text>
          {/* 64 Block */}
          <rect x="18" y="6" width="11" height="20" rx="2" fill="white" />
          <text x="19" y="19" fill="#0284C7" fontSize="10" fontWeight="900" fontFamily="system-ui, sans-serif">64</text>
          {/* Flow arrow */}
          <path d="M13 16h4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'url-encoder-decoder':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Link shape */}
          <path d="M11 12H8a4 4 0 0 0 0 8h3M21 12h3a4 4 0 0 1 0 8h-3" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M11 16h10" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          {/* %20 badge */}
          <rect x="8" y="20" width="16" height="8" rx="2" fill="#FDE047" />
          <text x="10" y="26.5" fill="#0F172A" fontSize="6.5" fontWeight="900" fontFamily="monospace">%20</text>
        </svg>
      );

    case 'uuid-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* UUID blocks */}
          <rect x="4" y="6" width="10" height="7" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <rect x="18" y="6" width="10" height="7" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <rect x="4" y="16" width="7" height="7" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <rect x="14" y="16" width="14" height="7" rx="1.5" fill="#38BDF8" stroke="white" strokeWidth="1.25" />
          <text x="16" y="21.5" fill="#0F172A" fontSize="5" fontWeight="bold" fontFamily="monospace">v4</text>
          <path d="M4 27h24" stroke="#FDE047" strokeWidth="2" strokeDasharray="3 2" />
        </svg>
      );

    case 'hash-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Hash Symbol # */}
          <path d="M11 5v22M21 5v22M5 11h22M5 21h22" stroke="white" strokeWidth="2.75" strokeLinecap="round" />
          {/* Padlock in center */}
          <rect x="11" y="12" width="10" height="8" rx="2" fill="#0284C7" stroke="#FDE047" strokeWidth="1.5" />
          <path d="M13.5 12V9.5a2.5 2.5 0 0 1 5 0V12" stroke="#FDE047" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'timestamp-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Clock Dial */}
          <circle cx="16" cy="14" r="10" stroke="white" strokeWidth="2" />
          <path d="M16 9v5l3.5 2" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" />
          {/* Epoch Unix Numbers */}
          <rect x="4" y="23" width="24" height="6" rx="1.5" fill="#0F172A" stroke="white" strokeWidth="1" />
          <text x="6" y="27.5" fill="#38BDF8" fontSize="4.5" fontWeight="bold" fontFamily="monospace">1718900000</text>
        </svg>
      );

    case 'color-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Multi-color Spectrum Quadrants */}
          <circle cx="16" cy="16" r="11" stroke="white" strokeWidth="2" />
          <path d="M16 5a11 11 0 0 1 11 11h-11z" fill="#EF4444" />
          <path d="M27 16a11 11 0 0 1-11 11v-11z" fill="#10B981" />
          <path d="M16 27a11 11 0 0 1-11-11h11z" fill="#3B82F6" />
          <path d="M5 16A11 11 0 0 1 16 5v11z" fill="#F59E0B" />
          {/* Eyedropper needle */}
          <circle cx="16" cy="16" r="3.5" fill="white" />
        </svg>
      );

    case 'regex-tester':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Delimiters /.* / */}
          <text x="3" y="21" fill="white" fontSize="16" fontWeight="bold" fontFamily="monospace">/</text>
          <text x="25" y="21" fill="white" fontSize="16" fontWeight="bold" fontFamily="monospace">/</text>
          <text x="8.5" y="21" fill="#FDE047" fontSize="11" fontWeight="900" fontFamily="monospace">.*</text>
          <rect x="7" y="24" width="18" height="4" rx="1" fill="#22C55E" />
        </svg>
      );

    // ==========================================
    // 6. DESIGN & COLOR TOOLS (Pink/Rose/Magenta)
    // ==========================================
    case 'color-palette-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Palette Board */}
          <path d="M16 4C9.4 4 4 9.4 4 16c0 5 3.5 9 8.5 9 1.5 0 2.5-1 2.5-2.5 0-.7-.3-1.3-.7-1.8-.4-.5-.6-1-.6-1.7 0-1.4 1.1-2.5 2.5-2.5h2.8c4.4 0 8-3.6 8-8 0-4.7-5-8.5-11-8.5z" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="1.75" />
          {/* Paint Swatches */}
          <circle cx="9" cy="12" r="2.5" fill="#EF4444" />
          <circle cx="15" cy="9" r="2.5" fill="#F59E0B" />
          <circle cx="21" cy="12" r="2.5" fill="#10B981" />
          <circle cx="23" cy="18" r="2.5" fill="#3B82F6" />
        </svg>
      );

    case 'contrast-checker':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Split Half Circle */}
          <circle cx="16" cy="16" r="11" stroke="white" strokeWidth="2" />
          <path d="M16 5a11 11 0 0 0 0 22V5z" fill="white" />
          {/* AAA checkmark badge */}
          <circle cx="22" cy="22" r="5" fill="#10B981" stroke="white" strokeWidth="1.5" />
          <path d="M19.5 22l2 2 3.5-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case 'gradient-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          <defs>
            <linearGradient id="grad-swatch" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#F43F5E" />
              <stop offset="50%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#06B6D4" />
            </linearGradient>
          </defs>
          <rect x="4" y="4" width="24" height="24" rx="5" fill="url(#grad-swatch)" stroke="white" strokeWidth="2" />
          {/* Gradient stops slider pins */}
          <circle cx="7" cy="7" r="2.5" fill="white" />
          <circle cx="16" cy="16" r="2.5" fill="white" />
          <circle cx="25" cy="25" r="2.5" fill="white" />
        </svg>
      );

    case 'box-shadow-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Soft Diffused Shadow */}
          <rect x="8" y="11" width="18" height="15" rx="3" fill="#0F172A" fillOpacity="0.45" />
          {/* Main Elevated Card */}
          <rect x="5" y="6" width="18" height="15" rx="3" fill="white" stroke="#FDE047" strokeWidth="1.5" />
          <path d="M9 11h10M9 15h6" stroke="#94A3B8" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'color-shades-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* 5-step monochromatic tint ramp */}
          <rect x="4" y="5" width="24" height="4" rx="1" fill="#FCE7F3" />
          <rect x="4" y="10" width="24" height="4" rx="1" fill="#F472B6" />
          <rect x="4" y="15" width="24" height="4" rx="1" fill="#DB2777" />
          <rect x="4" y="20" width="24" height="4" rx="1" fill="#9D174D" />
          <rect x="4" y="25" width="24" height="4" rx="1" fill="#500724" />
        </svg>
      );

    // ==========================================
    // 7. DATA & CSV TOOLS (Blue/Teal)
    // ==========================================
    case 'csv-to-json':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Grid table */}
          <rect x="3" y="6" width="13" height="19" rx="2" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.5" />
          <path d="M3 12h13M3 18h13M9 6v19" stroke="white" strokeWidth="1.25" />
          {/* Arrow */}
          <path d="M16 16h3" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" />
          {/* JSON curly */}
          <text x="20" y="22" fill="white" fontSize="16" fontWeight="bold" fontFamily="monospace">{"{}"}</text>
        </svg>
      );

    case 'json-to-csv':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* JSON curly */}
          <text x="3" y="22" fill="white" fontSize="16" fontWeight="bold" fontFamily="monospace">{"{}"}</text>
          {/* Arrow */}
          <path d="M14 16h3" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" />
          {/* Grid table */}
          <rect x="17" y="6" width="12" height="19" rx="2" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.5" />
          <path d="M17 12h12M17 18h12M23 6v19" stroke="white" strokeWidth="1.25" />
        </svg>
      );

    case 'csv-viewer-filter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Table */}
          <rect x="4" y="5" width="24" height="22" rx="3" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M4 11h24M4 18h24M12 5v22M20 5v22" stroke="white" strokeWidth="1.5" />
          {/* Magnifier / Filter Search */}
          <circle cx="21" cy="20" r="5" fill="#0284C7" stroke="#FDE047" strokeWidth="2" />
          <path d="M25 24l4 4" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'xml-to-json':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          <text x="2" y="16" fill="white" fontSize="9" fontWeight="900" fontFamily="monospace">{"</>"}</text>
          <path d="M14 16h4m0 0l-2-2m2 2l-2 2" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <text x="20" y="22" fill="#38BDF8" fontSize="14" fontWeight="bold" fontFamily="monospace">{"{ }"}</text>
        </svg>
      );

    case 'json-to-xml':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          <text x="2" y="22" fill="#38BDF8" fontSize="14" fontWeight="bold" fontFamily="monospace">{"{ }"}</text>
          <path d="M14 16h4m0 0l-2-2m2 2l-2 2" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <text x="19" y="16" fill="white" fontSize="9" fontWeight="900" fontFamily="monospace">{"</>"}</text>
        </svg>
      );

    case 'yaml-json-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* YAML indented key lines */}
          <path d="M4 8h8M7 13h10M7 18h6" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* Bidirectional Arrow */}
          <path d="M18 11l4 5-4 5" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          {/* JSON curly */}
          <text x="22" y="24" fill="white" fontSize="18" fontWeight="bold" fontFamily="monospace">{"}"}</text>
        </svg>
      );

    // ==========================================
    // 8. SEO & WEBSITE TOOLS (Teal/Emerald)
    // ==========================================
    case 'meta-tag-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Browser Window */}
          <rect x="4" y="5" width="24" height="22" rx="3.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M4 11h24" stroke="white" strokeWidth="1.5" />
          <circle cx="8" cy="8" r="1" fill="#FDE047" />
          <circle cx="11" cy="8" r="1" fill="#FDE047" />
          {/* <meta> Tag */}
          <rect x="7" y="15" width="18" height="8" rx="2" fill="#0D9488" stroke="white" strokeWidth="1.25" />
          <text x="8.5" y="21" fill="white" fontSize="5" fontWeight="bold" fontFamily="monospace">&lt;meta&gt;</text>
        </svg>
      );

    case 'robots-txt-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Robot Head */}
          <rect x="7" y="10" width="18" height="15" rx="3" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="1.75" />
          <circle cx="12" cy="16" r="2" fill="#FDE047" />
          <circle cx="20" cy="16" r="2" fill="#FDE047" />
          <path d="M12 21h8" stroke="white" strokeWidth="1.75" strokeLinecap="round" />
          {/* Antenna */}
          <path d="M16 6v4" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <circle cx="16" cy="5" r="1.5" fill="#EF4444" />
        </svg>
      );

    case 'xml-sitemap-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Root node */}
          <rect x="12" y="4" width="8" height="6" rx="1.5" fill="white" />
          {/* Connecting lines */}
          <path d="M16 10v6M7 16h18M7 16v4M16 16v4M25 16v4" stroke="white" strokeWidth="1.75" />
          {/* Child nodes */}
          <rect x="4" y="20" width="6" height="6" rx="1.5" fill="white" fillOpacity="0.4" />
          <rect x="13" y="20" width="6" height="6" rx="1.5" fill="white" fillOpacity="0.4" />
          <rect x="22" y="20" width="6" height="6" rx="1.5" fill="white" fillOpacity="0.4" />
        </svg>
      );

    case 'keyword-density-checker':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="currentColor">
          {/* Text lines */}
          <path d="M4 8h16M4 14h10M4 20h8M4 26h14" stroke="white" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.4" />
          {/* Magnifier with % inside */}
          <circle cx="21" cy="16" r="7" fill="#0D9488" stroke="#FDE047" strokeWidth="2" />
          <text x="18" y="19" fill="white" fontSize="8" fontWeight="bold" fontFamily="system-ui, sans-serif">%</text>
          <path d="M26 21l4 4" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    // ==========================================
    // 9. FINANCE & BUSINESS (Emerald/Green)
    // ==========================================
    case 'loan-mortgage-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* House Roof & Base */}
          <path d="M16 5l-12 9h4v12h16V14h4L16 5z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" strokeLinejoin="round" />
          {/* Dollar & Amortization Bar inside */}
          <text x="12" y="21" fill="#FDE047" fontSize="10" fontWeight="900" fontFamily="system-ui, sans-serif">$</text>
        </svg>
      );

    case 'sales-tax-vat-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Cash Register / Receipt */}
          <rect x="5" y="8" width="22" height="18" rx="3" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M9 13h14M9 17h8" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          {/* VAT / Tax Stamp */}
          <circle cx="21" cy="20" r="5" fill="#059669" stroke="white" strokeWidth="1.5" />
          <text x="18" y="23" fill="white" fontSize="6.5" fontWeight="bold">%</text>
        </svg>
      );

    case 'roi-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Financial Growth Chart */}
          <path d="M4 27h24" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <path d="M6 22l7-7 5 4 8-12" stroke="#FDE047" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M26 7h-6m6 0v6" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <text x="5" y="11" fill="white" fontSize="6.5" fontWeight="900" fontFamily="system-ui, sans-serif">ROI</text>
        </svg>
      );

    case 'break-even-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Intersecting Cost & Revenue Curves */}
          <path d="M4 27h24M4 5v22" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <path d="M5 24L26 8" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M5 14L26 19" stroke="#F43F5E" strokeWidth="2.5" strokeLinecap="round" />
          {/* Equilibrium Point */}
          <circle cx="15.5" cy="16" r="3.5" fill="white" stroke="#0F172A" strokeWidth="1.5" />
        </svg>
      );

    case 'salary-hourly-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Wallet */}
          <rect x="4" y="9" width="24" height="16" rx="3" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M4 14h24" stroke="white" strokeWidth="1.5" />
          {/* Clock Dial overlay */}
          <circle cx="21" cy="19" r="6" fill="#047857" stroke="white" strokeWidth="1.5" />
          <path d="M21 16v3l2 1" stroke="#FDE047" strokeWidth="1.5" strokeLinecap="round" />
          <text x="8" y="22" fill="#FDE047" fontSize="8" fontWeight="bold">$</text>
        </svg>
      );

    // ==========================================
    // 10. TIME & PRODUCTIVITY (Sky/Blue)
    // ==========================================
    case 'world-clock-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Globe Grid */}
          <circle cx="16" cy="16" r="11" stroke="white" strokeWidth="1.75" />
          <ellipse cx="16" cy="16" rx="5" ry="11" stroke="white" strokeWidth="1.25" strokeOpacity="0.5" />
          <path d="M5 16h22" stroke="white" strokeWidth="1.25" strokeOpacity="0.5" />
          {/* Clock Hands */}
          <path d="M16 10v6l4 2.5" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );

    case 'stopwatch-timer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Stopwatch Body */}
          <circle cx="16" cy="17" r="10" stroke="white" strokeWidth="2" fill="white" fillOpacity="0.15" />
          {/* Knurled Top Crown & Lap Button */}
          <path d="M16 7V4M14 4h4M24 7l2-2" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* Stopwatch Hand */}
          <path d="M16 17V11" stroke="#FDE047" strokeWidth="2.25" strokeLinecap="round" />
          <circle cx="16" cy="17" r="2" fill="#FDE047" />
        </svg>
      );

    case 'event-countdown-timer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Calendar milestone */}
          <rect x="4" y="6" width="24" height="22" rx="3.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M4 12h24" stroke="white" strokeWidth="1.5" />
          <path d="M9 3v4M23 3v4" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* Hourglass Inside */}
          <path d="M13 16h6l-3 4 3 4h-6l3-4-3-4z" fill="#FDE047" stroke="white" strokeWidth="1" />
        </svg>
      );

    case 'work-hours-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Timesheet Punch Card */}
          <rect x="5" y="4" width="22" height="24" rx="2.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M9 9h14M9 14h8M9 19h14M9 24h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          {/* Clock stamp */}
          <circle cx="21" cy="20" r="5" fill="#0284C7" stroke="white" strokeWidth="1.5" />
          <path d="M21 17.5v2.5l1.5 1" stroke="#FDE047" strokeWidth="1.25" strokeLinecap="round" />
        </svg>
      );

    case 'pomodoro-timer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Tomato / Focus Timer Dial */}
          <circle cx="16" cy="18" r="10" fill="#EF4444" stroke="white" strokeWidth="2" />
          {/* Green Tomato Leaves */}
          <path d="M16 8c-2-3-6-2-6-2s0 3 3 4c-3 0-5 2-5 2s3 1 5 0c0 3 3 3 4 2 1 1 4 1 4-2 2 1 5 0 5 0s-2-2-5-2c3-1 3-4 3-4s-4-1-6 2z" fill="#22C55E" />
          {/* 25 Min Mark */}
          <text x="11.5" y="22" fill="white" fontSize="8" fontWeight="bold" fontFamily="monospace">25</text>
        </svg>
      );

    // ==========================================
    // 11. SOCIAL MEDIA TOOLS (Rose/Red)
    // ==========================================
    case 'youtube-thumbnail-grabber':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Video Player Display */}
          <rect x="4" y="5" width="24" height="18" rx="4" fill="#DC2626" stroke="white" strokeWidth="1.75" />
          {/* Play Triangle */}
          <polygon points="14,10 20,14 14,18" fill="white" />
          {/* Snapshot grab camera */}
          <circle cx="23" cy="23" r="5" fill="#0F172A" stroke="white" strokeWidth="1.5" />
          <path d="M21 23h4m-2-2v4" stroke="#FDE047" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );

    case 'social-post-formatter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Stylized Font Glyphs */}
          <text x="4" y="15" fill="white" fontSize="12" fontWeight="900" fontFamily="sans-serif">B</text>
          <text x="14" y="15" fill="#FDE047" fontSize="12" fontStyle="italic" fontWeight="bold" fontFamily="serif">I</text>
          <text x="21" y="15" fill="#38BDF8" fontSize="11" fontWeight="bold" fontFamily="monospace">U</text>
          <path d="M4 23h24" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M4 27h16" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeOpacity="0.5" />
        </svg>
      );

    case 'hashtag-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Viral Hashtag # */}
          <path d="M11 6v20M21 6v20M5 12h22M5 20h22" stroke="white" strokeWidth="3" strokeLinecap="round" />
          {/* Trending Sparkles */}
          <path d="M24 6l1.5 2.5L28 9l-2.5 1.5L24 13l-1.5-2.5L20 9l2.5-1.5L24 6z" fill="#FDE047" />
        </svg>
      );

    case 'bio-link-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Smartphone Frame */}
          <rect x="7" y="3" width="18" height="26" rx="3.5" fill="#0F172A" stroke="white" strokeWidth="1.75" />
          {/* Profile Avatar */}
          <circle cx="16" cy="9" r="2.5" fill="#F43F5E" />
          {/* Stacked Bio Link Buttons */}
          <rect x="10" y="14" width="12" height="3" rx="1.5" fill="white" />
          <rect x="10" y="19" width="12" height="3" rx="1.5" fill="#38BDF8" />
          <rect x="10" y="24" width="12" height="3" rx="1.5" fill="#FDE047" />
        </svg>
      );

    // ==========================================
    // 12. EDUCATION & LEARNING (Violet/Purple)
    // ==========================================
    case 'gpa-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Graduation Cap */}
          <polygon points="16,5 4,11 16,17 28,11" fill="white" stroke="white" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M8 13.5v7c0 4 8 4 8 4s8 0 8-4v-7" stroke="white" strokeWidth="1.75" />
          <path d="M26 11v9" stroke="#FDE047" strokeWidth="1.75" strokeLinecap="round" />
          {/* A+ Badge */}
          <rect x="11" y="20" width="10" height="7" rx="2" fill="#FDE047" />
          <text x="12" y="26" fill="#0F172A" fontSize="6.5" fontWeight="900" fontFamily="sans-serif">A+</text>
        </svg>
      );

    case 'roman-numeral-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Roman Pillar Base & Inscription */}
          <path d="M6 6h20M8 6v20M24 6v20M6 26h20" stroke="white" strokeWidth="2" strokeLinecap="round" />
          <text x="10" y="18" fill="#FDE047" fontSize="10" fontWeight="900" fontFamily="serif" letterSpacing="0.05em">IVX</text>
        </svg>
      );

    case 'morse-code-translator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Morse Dots and Dashes */}
          <circle cx="8" cy="12" r="2.5" fill="white" />
          <circle cx="16" cy="12" r="2.5" fill="white" />
          <circle cx="24" cy="12" r="2.5" fill="white" />
          <rect x="5" y="19" width="6" height="4" rx="1.5" fill="#FDE047" />
          <rect x="13" y="19" width="6" height="4" rx="1.5" fill="#FDE047" />
          <rect x="21" y="19" width="6" height="4" rx="1.5" fill="#FDE047" />
        </svg>
      );

    case 'binary-text-converter':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Binary 01 stream */}
          <text x="3" y="13" fill="#38BDF8" fontSize="8" fontWeight="bold" fontFamily="monospace">0100</text>
          <path d="M12 18l4 4-4 4" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          {/* Letter A */}
          <text x="21" y="24" fill="white" fontSize="13" fontWeight="900" fontFamily="system-ui, sans-serif">A</text>
        </svg>
      );

    case 'fraction-calculator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Numerator */}
          <text x="9" y="13" fill="white" fontSize="10" fontWeight="900" fontFamily="system-ui, sans-serif">1</text>
          {/* Fraction Bar */}
          <path d="M7 16h18" stroke="#FDE047" strokeWidth="3" strokeLinecap="round" />
          {/* Denominator */}
          <text x="9" y="27" fill="white" fontSize="10" fontWeight="900" fontFamily="system-ui, sans-serif">2</text>
          {/* Math + sign */}
          <text x="20" y="22" fill="white" fontSize="9" fontWeight="bold">+</text>
        </svg>
      );

    case 'random-number-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Rolling Die */}
          <rect x="5" y="5" width="22" height="22" rx="4" fill="white" fillOpacity="0.25" stroke="white" strokeWidth="2" />
          {/* 5 Dots Pattern */}
          <circle cx="10" cy="10" r="2" fill="white" />
          <circle cx="22" cy="10" r="2" fill="white" />
          <circle cx="16" cy="16" r="2.5" fill="#FDE047" />
          <circle cx="10" cy="22" r="2" fill="white" />
          <circle cx="22" cy="22" r="2" fill="white" />
        </svg>
      );

    // ==========================================
    // 13. AI & SMART TOOLS (Fuchsia/Violet)
    // ==========================================
    case 'headline-analyzer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Newspaper sheet */}
          <rect x="5" y="4" width="22" height="24" rx="3" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          <path d="M8 8h16" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M8 13h10M8 17h10M8 21h6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeOpacity="0.6" />
          {/* Rating Score Badge */}
          <circle cx="21" cy="20" r="5.5" fill="#10B981" stroke="white" strokeWidth="1.5" />
          <text x="17.5" y="23" fill="white" fontSize="6.5" fontWeight="900" fontFamily="sans-serif">92</text>
        </svg>
      );

    case 'ai-prompt-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Structured Prompt Card */}
          <rect x="5" y="5" width="22" height="22" rx="3.5" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="1.75" />
          {/* Role, Task, Context lines */}
          <path d="M9 10h8M9 15h14M9 20h10" stroke="white" strokeWidth="2" strokeLinecap="round" />
          {/* AI Neural Star Wand */}
          <path d="M22 6l1.5 2.5L26 10l-2.5 1.5L22 14l-1.5-2.5L18 10l2.5-1.5L22 6z" fill="#FDE047" />
        </svg>
      );

    case 'text-summarizer':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Wide input lines */}
          <path d="M4 6h24M4 11h24M4 16h16" stroke="white" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.4" />
          {/* Summarizer Funnel & Arrow */}
          <path d="M16 18v5m0 0l-2.5-2.5m2.5 2.5l2.5-2.5" stroke="#FDE047" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          {/* Concentrated 3 bullet takeaways */}
          <circle cx="6" cy="26" r="1.5" fill="#38BDF8" />
          <path d="M10 26h16" stroke="white" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    // ==========================================
    // 14. SECURITY TOOLS (Violet/Slate/Indigo)
    // ==========================================
    case 'password-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Key */}
          <path d="M18 12a5 5 0 1 0-7 4.5V23h4v-3h3v-3h1.5a5 5 0 0 0-1.5-5z" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.75" />
          <circle cx="14" cy="11" r="1.75" fill="#0F172A" />
          {/* Password Bullet Dots •••••• */}
          <rect x="4" y="24" width="24" height="5" rx="2" fill="#0F172A" stroke="white" strokeWidth="1" />
          <circle cx="8" cy="26.5" r="1" fill="#FDE047" />
          <circle cx="12" cy="26.5" r="1" fill="#FDE047" />
          <circle cx="16" cy="26.5" r="1" fill="#FDE047" />
          <circle cx="20" cy="26.5" r="1" fill="#FDE047" />
          <circle cx="24" cy="26.5" r="1" fill="#FDE047" />
        </svg>
      );

    case 'password-strength-checker':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Armored Shield */}
          <path d="M16 4l10 4v7c0 7-5 11-10 13-5-2-10-6-10-13V8l10-4z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" strokeLinejoin="round" />
          {/* 4-Level Strength Meter Bars */}
          <rect x="10" y="16" width="2.5" height="4" rx="0.5" fill="#22C55E" />
          <rect x="13.5" y="14" width="2.5" height="6" rx="0.5" fill="#22C55E" />
          <rect x="17" y="12" width="2.5" height="8" rx="0.5" fill="#22C55E" />
          <rect x="20.5" y="10" width="2.5" height="10" rx="0.5" fill="#22C55E" />
        </svg>
      );

    case 'random-string-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* Tumbler lock tiles */}
          <rect x="4" y="8" width="6.5" height="16" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <rect x="12.5" y="8" width="6.5" height="16" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <rect x="21" y="8" width="6.5" height="16" rx="1.5" fill="white" fillOpacity="0.3" stroke="white" strokeWidth="1.25" />
          <text x="5.5" y="18" fill="white" fontSize="7" fontWeight="bold" fontFamily="monospace">x</text>
          <text x="14" y="18" fill="#FDE047" fontSize="7" fontWeight="bold" fontFamily="monospace">9</text>
          <text x="22.5" y="18" fill="#38BDF8" fontSize="7" fontWeight="bold" fontFamily="monospace">K</text>
        </svg>
      );

    // ==========================================
    // 15. QR CODE & UTILITIES
    // ==========================================
    case 'qr-code-generator':
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          {/* 3 Corner Finder Patterns */}
          <rect x="4" y="4" width="9" height="9" rx="1.5" stroke="white" strokeWidth="2" />
          <rect x="6.5" y="6.5" width="4" height="4" fill="white" />
          <rect x="19" y="4" width="9" height="9" rx="1.5" stroke="white" strokeWidth="2" />
          <rect x="21.5" y="6.5" width="4" height="4" fill="white" />
          <rect x="4" y="19" width="9" height="9" rx="1.5" stroke="white" strokeWidth="2" />
          <rect x="6.5" y="21.5" width="4" height="4" fill="white" />
          {/* QR Data Pixels */}
          <rect x="15" y="5" width="2" height="2" fill="white" />
          <rect x="15" y="9" width="2" height="2" fill="white" />
          <rect x="19" y="15" width="3" height="3" fill="#FDE047" />
          <rect x="24" y="15" width="3" height="3" fill="white" />
          <rect x="15" y="19" width="2" height="2" fill="white" />
          <rect x="23" y="20" width="4" height="4" fill="#FDE047" />
          <rect x="15" y="25" width="4" height="2" fill="white" />
        </svg>
      );

    // ==========================================
    // CATEGORY GENERIC DEFAULTS
    // ==========================================
    default:
      if (category === 'pdf') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <path d="M7 4h12l6 6v18a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" />
            <path d="M19 4v6h6" stroke="white" strokeWidth="2" />
            <text x="8" y="21" fill="white" fontSize="7" fontWeight="bold" fontFamily="system-ui, sans-serif">PDF</text>
          </svg>
        );
      }
      if (category === 'image') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <rect x="4" y="4" width="24" height="24" rx="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" />
            <circle cx="10" cy="10" r="2" fill="#FDE047" />
            <path d="M5 24l7-7 4 4 5-6 6 8H5z" fill="white" />
          </svg>
        );
      }
      if (category === 'calculator') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <rect x="5" y="4" width="22" height="24" rx="4" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" />
            <rect x="8" y="7" width="16" height="6" rx="1.5" fill="#0F172A" />
            <circle cx="10" cy="17" r="1.5" fill="white" />
            <circle cx="16" cy="17" r="1.5" fill="white" />
            <circle cx="22" cy="17" r="1.5" fill="#FDE047" />
            <circle cx="10" cy="23" r="1.5" fill="white" />
            <circle cx="16" cy="23" r="1.5" fill="white" />
            <circle cx="22" cy="23" r="1.5" fill="#FDE047" />
          </svg>
        );
      }
      if (category === 'developer') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <path d="M10 9l-6 7 6 7M22 9l6 7-6 7M18 6l-4 20" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      }
      if (category === 'text') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <text x="5" y="21" fill="white" fontSize="16" fontWeight="bold" fontFamily="serif">Aa</text>
            <path d="M5 25h22" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        );
      }
      if (category === 'video' || slug?.startsWith('video-') || slug?.startsWith('subtitle-')) {
        if (slug === 'video-splitter') {
          return (
            <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="4" y="6" width="24" height="20" rx="3" strokeWidth="2" fill="white" fillOpacity="0.15" />
              <line x1="16" y1="4" x2="16" y2="28" stroke="#38BDF8" strokeWidth="2.5" strokeDasharray="3 3" />
              <path d="M11 13l-4 3 4 3M21 13l4 3-4 3" />
            </svg>
          );
        }
        if (slug === 'video-crop') {
          return (
            <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7 3v18a2 2 0 0 0 2 2h18" strokeWidth="2.5" />
              <path d="M25 29V11a2 2 0 0 0-2-2H5" strokeWidth="2.5" />
              <rect x="11" y="11" width="10" height="10" rx="1" fill="white" fillOpacity="0.3" stroke="#FDE047" strokeWidth="1.5" />
            </svg>
          );
        }
        if (slug?.includes('subtitle')) {
          return (
            <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
              <rect x="4" y="6" width="24" height="20" rx="3" fill="white" fillOpacity="0.15" stroke="white" strokeWidth="2" />
              <line x1="8" y1="18" x2="24" y2="18" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" />
              <line x1="11" y1="22" x2="21" y2="22" stroke="white" strokeWidth="2" strokeLinecap="round" />
            </svg>
          );
        }
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <rect x="4" y="6" width="24" height="20" rx="3" fill="white" fillOpacity="0.18" stroke="white" strokeWidth="2" />
            <polygon points="13,11 21,16 13,21" fill="#38BDF8" />
            <circle cx="8" cy="9" r="1" fill="white" />
            <circle cx="24" cy="9" r="1" fill="white" />
          </svg>
        );
      }
      if (category === 'audio' || slug?.startsWith('audio-') || slug?.startsWith('stereo-') || slug?.startsWith('mono-') || slug?.startsWith('bpm-') || slug?.startsWith('id3-')) {
        if (slug === 'audio-equalizer') {
          return (
            <svg viewBox="0 0 32 32" fill="none" className="w-full h-full" stroke="white" strokeWidth="2.5" strokeLinecap="round">
              <line x1="8" y1="6" x2="8" y2="26" />
              <circle cx="8" cy="18" r="3" fill="#A855F7" stroke="white" strokeWidth="1.5" />
              <line x1="16" y1="6" x2="16" y2="26" />
              <circle cx="16" cy="11" r="3" fill="#38BDF8" stroke="white" strokeWidth="1.5" />
              <line x1="24" y1="6" x2="24" y2="26" />
              <circle cx="24" cy="21" r="3" fill="#F43F5E" stroke="white" strokeWidth="1.5" />
            </svg>
          );
        }
        if (slug?.includes('waveform') || slug === 'bpm-detector') {
          return (
            <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
              <path d="M4 16h4l3-8 5 16 4-12 3 7h5" stroke="#38BDF8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          );
        }
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <path d="M12 24a4 4 0 1 1-4-4 4 4 0 0 1 4 4zm12-4a4 4 0 1 1-4-4 4 4 0 0 1 4 4z" fill="white" fillOpacity="0.2" stroke="white" strokeWidth="2" />
            <path d="M12 20V7l12-3v13" stroke="white" strokeWidth="2" strokeLinejoin="round" />
            <path d="M12 11l12-3" stroke="#A855F7" strokeWidth="2.5" />
          </svg>
        );
      }
      if (category === 'web') {
        return (
          <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
            <circle cx="16" cy="16" r="11" stroke="white" strokeWidth="2" fill="white" fillOpacity="0.15" />
            <ellipse cx="16" cy="16" rx="5" ry="11" stroke="white" strokeWidth="1.5" />
            <path d="M5 16h22M6 11h20M6 21h20" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        );
      }
      // Ultimate fallback: polished tool spark
      return (
        <svg viewBox="0 0 32 32" fill="none" className="w-full h-full">
          <path d="M16 4l2.5 8.5L27 15l-8.5 2.5L16 26l-2.5-8.5L5 15l8.5-2.5L16 4z" fill="white" />
          <circle cx="24" cy="24" r="3" fill="#FDE047" />
        </svg>
      );
  }
};

/**
 * Returns consistent rich background gradients based on tool category.
 */
const getCategoryGradient = (category?: string, slug?: string): string => {
  // Slug-specific overrides for heightened recognition
  if (slug === 'qr-code-generator') {
    return 'from-indigo-600 via-purple-600 to-indigo-800 shadow-indigo-500/25';
  }
  if (slug?.startsWith('pdf-') || slug?.endsWith('-pdf')) {
    return 'from-red-500 via-rose-600 to-red-700 shadow-red-500/25';
  }

  switch (category) {
    case 'web':
      return 'from-blue-600 via-indigo-600 to-cyan-600 shadow-blue-500/25';
    case 'video':
      return 'from-rose-500 via-pink-600 to-indigo-600 shadow-rose-500/25';
    case 'audio':
      return 'from-violet-600 via-purple-600 to-indigo-700 shadow-violet-600/25';
    case 'pdf':
      return 'from-rose-500 via-red-600 to-rose-700 shadow-rose-500/25';
    case 'image':
      return 'from-emerald-500 via-teal-600 to-cyan-700 shadow-emerald-500/25';
    case 'design':
      return 'from-pink-500 via-rose-500 to-purple-600 shadow-pink-500/25';
    case 'text':
      return 'from-indigo-500 via-indigo-600 to-violet-700 shadow-indigo-500/25';
    case 'calculator':
      return 'from-amber-500 via-orange-500 to-amber-600 shadow-amber-500/25';
    case 'developer':
      return 'from-cyan-600 via-blue-600 to-indigo-700 shadow-cyan-500/25';
    case 'data':
      return 'from-blue-600 via-indigo-600 to-cyan-700 shadow-blue-500/25';
    case 'seo':
      return 'from-teal-500 via-emerald-600 to-teal-700 shadow-teal-500/25';
    case 'finance':
      return 'from-emerald-600 via-green-600 to-teal-700 shadow-emerald-500/25';
    case 'productivity':
      return 'from-sky-500 via-blue-500 to-indigo-600 shadow-sky-500/25';
    case 'social':
      return 'from-rose-500 via-red-500 to-pink-600 shadow-rose-500/25';
    case 'education':
      return 'from-violet-500 via-purple-600 to-indigo-600 shadow-violet-500/25';
    case 'conversion':
      return 'from-amber-600 via-orange-600 to-rose-600 shadow-amber-500/25';
    case 'security':
      return 'from-violet-600 via-slate-700 to-indigo-800 shadow-violet-600/25';
    case 'ai':
      return 'from-fuchsia-500 via-purple-600 to-indigo-600 shadow-fuchsia-500/25';
    case 'student':
      return 'from-purple-500 via-violet-600 to-indigo-600 shadow-purple-500/25';
    default:
      return 'from-indigo-500 via-purple-600 to-blue-600 shadow-indigo-500/25';
  }
};

export const ToolAppIcon: React.FC<ToolAppIconProps> = ({
  slug,
  category,
  size = 'md',
  className = '',
  alt,
  interactive = true,
}) => {
  const containerSizeClass = SIZE_CONTAINER_CLASSES[size] || SIZE_CONTAINER_CLASSES.md;
  const svgSizeClass = SIZE_SVG_CLASSES[size] || SIZE_SVG_CLASSES.md;
  const gradientClass = getCategoryGradient(category, slug);

  return (
    <div
      role={alt ? 'img' : 'presentation'}
      aria-label={alt}
      className={`relative shrink-0 flex items-center justify-center bg-gradient-to-br ${gradientClass} text-white ring-1 ring-inset ring-white/20 dark:ring-white/10 ${containerSizeClass} ${
        interactive ? 'group-hover:scale-105 group-hover:shadow-lg transition-all duration-200' : ''
      } ${className}`}
    >
      {/* Subtle top glare reflection highlight for app-icon realism */}
      <div className="absolute inset-x-0 top-0 h-1/2 rounded-t-[inherit] bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />

      {/* SVG Icon Artwork */}
      <div className={`relative z-10 flex items-center justify-center ${svgSizeClass}`}>
        {renderIconVector(slug, category)}
      </div>
    </div>
  );
};
