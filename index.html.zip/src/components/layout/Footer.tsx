import React from 'react';
import { ShieldCheck, Heart } from 'lucide-react';
import { Logo } from '../common/Logo';

interface FooterProps {
  navigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="border-t border-slate-200/80 bg-white dark:border-slate-800/80 dark:bg-slate-900 transition-colors">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 lg:gap-12">
          
          {/* Brand info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <Logo className="h-8 w-8 rounded-xl shadow-xs" />
              <span className="font-bold text-lg tracking-tight text-slate-900 dark:text-white">
                Free Tools Hub
              </span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
              Powerful Free Online Tools. No Signup. No Hassle. Client-side processing ensures your data and files remain private and secure on your device.
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 pt-1">
              <ShieldCheck className="h-4 w-4 text-emerald-500" />
              <span>100% In-Browser Privacy · No Data Harvested</span>
            </div>
          </div>

          {/* Tools column 1 */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Popular Suites
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => navigate('/pdf-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  PDF & Documents
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/image-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Image Tools
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/design-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Design & Color
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/text-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Text Tools
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/calculators')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Calculators
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/developer-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Developer Tools
                </button>
              </li>
            </ul>
          </div>

          {/* Tools column 2 */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Specialized Suites
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => navigate('/data-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Data & CSV
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/seo-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  SEO & Website
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/finance-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Finance & Business
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/productivity-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Time & Productivity
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/ai-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  AI & Smart Tools
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/ai-assistant')}
                  className="text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 font-semibold transition-colors"
                >
                  🤖 AI Assistant
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/security-tools')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Security & Privacy
                </button>
              </li>
            </ul>
          </div>

          {/* Company column */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Company
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => navigate('/about')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/contact')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Contact & Feedback
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/privacy')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/terms')}
                  className="text-slate-600 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
                >
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div>
            © 2026 Free Tools Hub. All rights reserved.
          </div>
          <div className="flex items-center gap-1.5 font-medium">
            <span>Made with <span className="text-rose-500 inline-block">❤️</span> by <span className="font-semibold text-slate-800 dark:text-slate-200">Rahul Raj</span></span>
          </div>
        </div>
      </div>
    </footer>
  );
};
