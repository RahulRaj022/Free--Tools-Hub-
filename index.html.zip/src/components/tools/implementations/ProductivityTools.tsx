import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Clock, Play, Pause, RotateCcw, Calendar, Plus, Trash2, Check, Download, Globe } from 'lucide-react';

interface ProductivityToolsProps {
  toolSlug: string;
}

export const ProductivityTools: React.FC<ProductivityToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // --- 1. World Clock Converter State ---
  const [sliderHour, setSliderHour] = useState<number>(() => new Date().getUTCHours());
  const CITIES = [
    { name: 'UTC (Universal)', zone: 'UTC', offset: 0 },
    { name: 'London (GMT/BST)', zone: 'Europe/London', offset: 1 },
    { name: 'New York (EDT/EST)', zone: 'America/New_York', offset: -4 },
    { name: 'San Francisco (PDT)', zone: 'America/Los_Angeles', offset: -7 },
    { name: 'Tokyo (JST)', zone: 'Asia/Tokyo', offset: 9 },
    { name: 'Sydney (AEST)', zone: 'Australia/Sydney', offset: 10 },
    { name: 'Dubai (GST)', zone: 'Asia/Dubai', offset: 4 },
    { name: 'Singapore (SGT)', zone: 'Asia/Singapore', offset: 8 },
  ];

  // --- 2. Stopwatch State ---
  const [stopwatchTime, setStopwatchTime] = useState<number>(0);
  const [stopwatchRunning, setStopwatchRunning] = useState<boolean>(false);
  const [laps, setLaps] = useState<number[]>([]);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    if (stopwatchRunning) {
      const start = Date.now() - stopwatchTime;
      timerRef.current = setInterval(() => {
        setStopwatchTime(Date.now() - start);
      }, 10);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [stopwatchRunning]);

  const formatStopwatch = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const centis = Math.floor((ms % 1000) / 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${centis.toString().padStart(2, '0')}`;
  };

  const handleLap = () => {
    if (stopwatchTime > 0) {
      setLaps([stopwatchTime, ...laps]);
      showToast(`Recorded Lap ${laps.length + 1}`, 'info');
    }
  };

  // --- 3. Event Countdown State ---
  const [targetDateStr, setTargetDateStr] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 16);
  });
  const [countdownRemaining, setCountdownRemaining] = useState<{ days: number; hours: number; mins: number; secs: number }>({
    days: 0,
    hours: 0,
    mins: 0,
    secs: 0,
  });

  useEffect(() => {
    const updateCountdown = () => {
      const target = new Date(targetDateStr).getTime();
      const diff = Math.max(0, target - Date.now());
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);
      setCountdownRemaining({ days, hours, mins, secs });
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [targetDateStr]);

  // --- 4. Timesheet / Work Hours Calculator State ---
  const [timesheetDays, setTimesheetDays] = useState([
    { day: 'Monday', in: '09:00', out: '17:00', lunch: 60 },
    { day: 'Tuesday', in: '09:00', out: '17:00', lunch: 60 },
    { day: 'Wednesday', in: '09:00', out: '17:00', lunch: 60 },
    { day: 'Thursday', in: '09:00', out: '17:00', lunch: 60 },
    { day: 'Friday', in: '09:00', out: '17:00', lunch: 60 },
  ]);
  const [hourlyWageTimesheet, setHourlyWageTimesheet] = useState<string>('35');

  const timesheetSummary = useMemo(() => {
    let totalMinutes = 0;
    const dayTotals = timesheetDays.map((d) => {
      if (!d.in || !d.out) return 0;
      const [inH, inM] = d.in.split(':').map(Number);
      const [outH, outM] = d.out.split(':').map(Number);
      const diffMins = (outH * 60 + outM) - (inH * 60 + inM) - d.lunch;
      const validMins = Math.max(0, diffMins);
      totalMinutes += validMins;
      return validMins;
    });

    const totalHours = totalMinutes / 60;
    const regularHours = Math.min(40, totalHours);
    const overtimeHours = Math.max(0, totalHours - 40);
    const wage = parseFloat(hourlyWageTimesheet) || 0;
    const grossPay = (regularHours * wage) + (overtimeHours * wage * 1.5);

    return { totalHours, regularHours, overtimeHours, grossPay, dayTotals };
  }, [timesheetDays, hourlyWageTimesheet]);

  return (
    <div className="space-y-6">
      {/* 1. WORLD CLOCK & TIMEZONE CONVERTER */}
      {toolSlug === 'world-clock-converter' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Scrub Global Time Slider (UTC {sliderHour.toString().padStart(2, '0')}:00)
              </span>
              <button
                onClick={() => setSliderHour(new Date().getUTCHours())}
                className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold"
              >
                Reset to Current Live Time
              </button>
            </div>
            <input
              type="range"
              min="0"
              max="23"
              value={sliderHour}
              onChange={(e) => setSliderHour(parseInt(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CITIES.map((city) => {
              const localHour = (sliderHour + city.offset + 24) % 24;
              const isWorkHours = localHour >= 9 && localHour <= 17;
              return (
                <div
                  key={city.name}
                  className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2"
                >
                  <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                    <span>{city.name}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${isWorkHours ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'}`}>
                      {isWorkHours ? 'Business' : 'Off Hours'}
                    </span>
                  </div>
                  <div className="text-3xl font-extrabold font-mono text-slate-900 dark:text-white">
                    {localHour.toString().padStart(2, '0')}:00
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    {city.offset >= 0 ? `+${city.offset}` : city.offset} hrs from UTC
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. STOPWATCH TIMER */}
      {toolSlug === 'stopwatch-timer' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="p-8 rounded-3xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-sm text-center space-y-6">
            <div className="text-6xl sm:text-7xl font-mono font-black tracking-tight text-slate-900 dark:text-white">
              {formatStopwatch(stopwatchTime)}
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setStopwatchRunning(!stopwatchRunning)}
                className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-white font-bold text-sm shadow-md transition-all ${
                  stopwatchRunning ? 'bg-amber-600 hover:bg-amber-700' : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {stopwatchRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                <span>{stopwatchRunning ? 'Pause' : 'Start'}</span>
              </button>

              <button
                onClick={handleLap}
                disabled={!stopwatchRunning}
                className="px-5 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 font-bold text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 disabled:opacity-40 transition-colors"
              >
                Lap Split
              </button>

              <button
                onClick={() => {
                  setStopwatchRunning(false);
                  setStopwatchTime(0);
                  setLaps([]);
                }}
                className="p-3 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-500 hover:bg-slate-50 transition-colors"
                title="Reset Stopwatch"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Laps List */}
          {laps.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                Recorded Lap Splits
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800/80 max-h-60 overflow-y-auto">
                {laps.map((lapTime, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between text-xs font-mono">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Lap {laps.length - idx}</span>
                    <span className="font-bold text-slate-900 dark:text-white">{formatStopwatch(lapTime)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. EVENT COUNTDOWN TIMER */}
      {toolSlug === 'event-countdown-timer' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="p-5 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-2">
            <label className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Target Date & Time
            </label>
            <input
              type="datetime-local"
              value={targetDateStr}
              onChange={(e) => setTargetDateStr(e.target.value)}
              className="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-medium"
            />
          </div>

          <div className="grid grid-cols-4 gap-3 sm:gap-4 text-center">
            {[
              { label: 'Days', val: countdownRemaining.days },
              { label: 'Hours', val: countdownRemaining.hours },
              { label: 'Minutes', val: countdownRemaining.mins },
              { label: 'Seconds', val: countdownRemaining.secs },
            ].map((unit) => (
              <div key={unit.label} className="p-5 sm:p-6 rounded-3xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-sm">
                <div className="text-3xl sm:text-5xl font-black font-mono text-indigo-600 dark:text-indigo-400">
                  {unit.val.toString().padStart(2, '0')}
                </div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-2">
                  {unit.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. WORK HOURS TIMESHEET CALCULATOR */}
      {toolSlug === 'work-hours-calculator' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">Hourly Wage ($):</label>
              <input
                type="number"
                value={hourlyWageTimesheet}
                onChange={(e) => setHourlyWageTimesheet(e.target.value)}
                className="w-24 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
              />
            </div>
            <div className="flex items-center gap-4 text-xs font-mono">
              <span>Total: <strong className="text-indigo-600 dark:text-indigo-400">{timesheetSummary.totalHours.toFixed(2)} hrs</strong></span>
              <span>Gross Pay: <strong className="text-emerald-600 dark:text-emerald-400">${timesheetSummary.grossPay.toFixed(2)}</strong></span>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300">
                  <th className="p-3 font-semibold">Day</th>
                  <th className="p-3 font-semibold">Start Time</th>
                  <th className="p-3 font-semibold">End Time</th>
                  <th className="p-3 font-semibold">Break (Mins)</th>
                  <th className="p-3 font-semibold text-right">Daily Hours</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {timesheetDays.map((row, idx) => (
                  <tr key={row.day}>
                    <td className="p-3 font-semibold text-slate-900 dark:text-white">{row.day}</td>
                    <td className="p-3">
                      <input
                        type="time"
                        value={row.in}
                        onChange={(e) => {
                          const updated = [...timesheetDays];
                          updated[idx].in = e.target.value;
                          setTimesheetDays(updated);
                        }}
                        className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
                      />
                    </td>
                    <td className="p-3">
                      <input
                        type="time"
                        value={row.out}
                        onChange={(e) => {
                          const updated = [...timesheetDays];
                          updated[idx].out = e.target.value;
                          setTimesheetDays(updated);
                        }}
                        className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
                      />
                    </td>
                    <td className="p-3">
                      <input
                        type="number"
                        value={row.lunch}
                        onChange={(e) => {
                          const updated = [...timesheetDays];
                          updated[idx].lunch = parseInt(e.target.value) || 0;
                          setTimesheetDays(updated);
                        }}
                        className="w-16 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 dark:bg-slate-950 font-mono"
                      />
                    </td>
                    <td className="p-3 font-mono font-bold text-right text-indigo-600 dark:text-indigo-400">
                      {(timesheetSummary.dayTotals[idx] / 60).toFixed(2)} hrs
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
