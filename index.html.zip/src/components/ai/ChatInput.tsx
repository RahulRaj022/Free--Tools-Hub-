import React, { useState, useRef, useEffect } from 'react';
import { ArrowUp, Square, X } from 'lucide-react';

interface ChatInputProps {
  onSend: (text: string) => void;
  isStreaming: boolean;
  onStop: () => void;
  disabled?: boolean;
  placeholder?: string;
  maxLength?: number;
}

export const ChatInput: React.FC<ChatInputProps> = React.memo(({
  onSend,
  isStreaming,
  onStop,
  disabled = false,
  placeholder = 'Ask anything... (Shift + Enter for new line)',
  maxLength = 4000,
}) => {
  // Localized typing state: typing NEVER re-renders parent or message history!
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-grow textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [text]);

  // Global shortcut: Ctrl/Cmd + K focuses input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        textareaRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    const trimmed = text.trim();
    if (!isStreaming && trimmed && !disabled) {
      onSend(trimmed);
      setText('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleClear = () => {
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.focus();
    }
  };

  const canSend = !isStreaming && text.trim().length > 0 && !disabled;
  const charCount = text.length;
  const isNearLimit = charCount > maxLength * 0.85;

  return (
    <div className="relative w-full rounded-2xl sm:rounded-3xl border border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm focus-within:border-slate-400 dark:focus-within:border-slate-600 focus-within:ring-2 focus-within:ring-slate-100 dark:focus-within:ring-slate-800 transition-all">
      <div className="flex items-end gap-2 p-2 sm:p-3">
        {/* Auto-growing Textarea */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, maxLength))}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          rows={1}
          className="flex-1 max-h-48 resize-none bg-transparent px-3 py-1.5 text-sm sm:text-[15px] text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none scrollbar-thin leading-relaxed"
        />

        {/* Clear Button */}
        {text.length > 0 && !isStreaming && (
          <button
            type="button"
            onClick={handleClear}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors cursor-pointer rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Clear text"
          >
            <X className="h-4 w-4" />
          </button>
        )}

        {/* Stop or Send Action Button */}
        {isStreaming ? (
          <button
            type="button"
            onClick={onStop}
            className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:opacity-90 transition-all cursor-pointer shrink-0"
            title="Stop generating"
          >
            <Square className="h-3.5 w-3.5 fill-current" />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleSend}
            disabled={!canSend}
            className={`flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-full transition-all shrink-0 cursor-pointer ${
              canSend
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:opacity-90 shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-300 dark:text-slate-600 cursor-not-allowed'
            }`}
            title="Send prompt (Enter)"
          >
            <ArrowUp className="h-4 w-4 sm:h-5 sm:w-5 stroke-[2.5]" />
          </button>
        )}
      </div>

      {/* Subtle Bottom Bar (Char Count & Hints) */}
      <div className="flex items-center justify-between px-4 pb-2 text-[11px] text-slate-400 dark:text-slate-500 font-sans">
        <div className="hidden sm:flex items-center gap-2">
          <span>Free Tools Hub AI can make mistakes. Verify important info.</span>
        </div>
        <div className={`ml-auto font-mono text-[10px] ${isNearLimit ? 'text-amber-500 font-semibold' : ''}`}>
          {charCount > 0 ? `${charCount} / ${maxLength.toLocaleString()}` : ''}
        </div>
      </div>
    </div>
  );
});
