import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { RefreshCw, Calculator, ArrowRightLeft, Plus, Trash2, Check, Copy } from 'lucide-react';

interface CalculatorsProps {
  toolSlug: string;
}

export const Calculators: React.FC<CalculatorsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();

  // Percentage calculator states
  const [percMode, setPercMode] = useState<'whatIs' | 'isWhat' | 'change'>('whatIs');
  const [percX, setPercX] = useState<string>('15');
  const [percY, setPercY] = useState<string>('200');

  // Age calculator states
  const [birthDate, setBirthDate] = useState<string>('1998-05-15');
  const [targetDate, setTargetDate] = useState<string>(() => new Date().toISOString().split('T')[0]);

  // Discount calculator states
  const [originalPrice, setOriginalPrice] = useState<string>('120');
  const [discountPercent, setDiscountPercent] = useState<string>('20');
  const [salesTaxPercent, setSalesTaxPercent] = useState<string>('8.5');

  // BMI states
  const [bmiSystem, setBmiSystem] = useState<'metric' | 'imperial'>('metric');
  const [bmiHeightMetric, setBmiHeightMetric] = useState<string>('175'); // cm
  const [bmiWeightMetric, setBmiWeightMetric] = useState<string>('70'); // kg
  const [bmiFeet, setBmiFeet] = useState<string>('5');
  const [bmiInches, setBmiInches] = useState<string>('9');
  const [bmiWeightImperial, setBmiWeightImperial] = useState<string>('154'); // lbs

  // Tip calculator states
  const [tipBill, setTipBill] = useState<string>('85.00');
  const [tipPercent, setTipPercent] = useState<number>(18);
  const [tipPeople, setTipPeople] = useState<number>(2);

  // Average calculator states
  const [avgInput, setAvgInput] = useState<string>('12, 18, 25, 30, 42, 50, 65');

  // GPA calculator states
  const [courses, setCourses] = useState<Array<{ id: string; name: string; grade: string; credits: number }>>([
    { id: '1', name: 'Computer Science 101', grade: 'A', credits: 4 },
    { id: '2', name: 'Calculus I', grade: 'B+', credits: 4 },
    { id: '3', name: 'Physics Mechanics', grade: 'A-', credits: 3 },
    { id: '4', name: 'Technical Writing', grade: 'A', credits: 3 },
  ]);

  // Ratio calculator states
  const [ratioA, setRatioA] = useState<string>('1920');
  const [ratioB, setRatioB] = useState<string>('1080');
  const [ratioC, setRatioC] = useState<string>('1280');

  // Simple interest states
  const [siPrincipal, setSiPrincipal] = useState<string>('10000');
  const [siRate, setSiRate] = useState<string>('6.5');
  const [siTime, setSiTime] = useState<string>('3');

  // Compound interest states
  const [ciPrincipal, setCiPrincipal] = useState<string>('10000');
  const [ciRate, setCiRate] = useState<string>('7.0');
  const [ciTime, setCiTime] = useState<string>('5');
  const [ciFreq, setCiFreq] = useState<number>(12); // monthly

  // Unit converter states
  const [unitCategory, setUnitCategory] = useState<'length' | 'weight' | 'temp' | 'speed' | 'volume' | 'area'>('length');
  const [unitValue, setUnitValue] = useState<string>('100');
  const [unitFrom, setUnitFrom] = useState<string>('m');
  const [unitTo, setUnitTo] = useState<string>('ft');

  // Ratio calculation logic
  const ratioResult = useMemo(() => {
    const a = parseFloat(ratioA);
    const b = parseFloat(ratioB);
    const c = parseFloat(ratioC);
    if (isNaN(a) || isNaN(b) || a === 0) return null;

    let d = 0;
    if (!isNaN(c)) {
      d = (b * c) / a;
    }

    // Simplify ratio A:B
    const gcd = (x: number, y: number): number => (y === 0 ? x : gcd(y, x % y));
    const roundedA = Math.round(a);
    const roundedB = Math.round(b);
    const divisor = Math.abs(gcd(roundedA, roundedB)) || 1;
    const simplifiedA = roundedA / divisor;
    const simplifiedB = roundedB / divisor;

    return {
      d: d ? (Number.isInteger(d) ? d : d.toFixed(2)) : 0,
      simplified: `${simplifiedA} : ${simplifiedB}`,
      decimal: (a / b).toFixed(4),
    };
  }, [ratioA, ratioB, ratioC]);

  // Simple interest calculation logic
  const siResult = useMemo(() => {
    const p = parseFloat(siPrincipal);
    const r = parseFloat(siRate);
    const t = parseFloat(siTime);
    if (isNaN(p) || isNaN(r) || isNaN(t)) return null;

    const interest = (p * r * t) / 100;
    const total = p + interest;
    const monthlyPayment = t > 0 ? total / (t * 12) : total;

    return {
      interest,
      total,
      monthlyPayment,
    };
  }, [siPrincipal, siRate, siTime]);

  // Compound interest calculation logic
  const ciResult = useMemo(() => {
    const p = parseFloat(ciPrincipal);
    const r = parseFloat(ciRate) / 100;
    const t = parseFloat(ciTime);
    const n = ciFreq;
    if (isNaN(p) || isNaN(r) || isNaN(t) || n <= 0) return null;

    const total = p * Math.pow(1 + r / n, n * t);
    const interest = total - p;

    return {
      total,
      interest,
    };
  }, [ciPrincipal, ciRate, ciTime, ciFreq]);

  // 1. Percentage Calculation Logic
  const percResult = useMemo(() => {
    const x = parseFloat(percX);
    const y = parseFloat(percY);
    if (isNaN(x) || isNaN(y)) return null;

    if (percMode === 'whatIs') {
      const res = (x / 100) * y;
      return {
        answer: res,
        formatted: `${x}% of ${y} = ${res}`,
        formula: `(${x} ÷ 100) × ${y} = ${res}`,
      };
    } else if (percMode === 'isWhat') {
      if (y === 0) return { answer: 0, formatted: 'Cannot divide by zero', formula: 'Error' };
      const res = (x / y) * 100;
      return {
        answer: res,
        formatted: `${x} is ${res.toFixed(2)}% of ${y}`,
        formula: `(${x} ÷ ${y}) × 100 = ${res.toFixed(2)}%`,
      };
    } else {
      if (x === 0) return { answer: 0, formatted: 'Original value cannot be zero', formula: 'Error' };
      const change = ((y - x) / Math.abs(x)) * 100;
      const type = change >= 0 ? 'increase' : 'decrease';
      return {
        answer: change,
        formatted: `${Math.abs(change).toFixed(2)}% ${type}`,
        formula: `((${y} - ${x}) ÷ |${x}|) × 100 = ${change.toFixed(2)}%`,
      };
    }
  }, [percMode, percX, percY]);

  // 2. Age Calculation Logic
  const ageResult = useMemo(() => {
    const bDate = new Date(birthDate);
    const tDate = new Date(targetDate);
    if (isNaN(bDate.getTime()) || isNaN(tDate.getTime())) return null;

    let years = tDate.getFullYear() - bDate.getFullYear();
    let months = tDate.getMonth() - bDate.getMonth();
    let days = tDate.getDate() - bDate.getDate();

    if (days < 0) {
      months -= 1;
      const prevMonth = new Date(tDate.getFullYear(), tDate.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    const diffMs = tDate.getTime() - bDate.getTime();
    const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;

    // Next birthday countdown
    const nextBday = new Date(tDate.getFullYear(), bDate.getMonth(), bDate.getDate());
    if (nextBday.getTime() < tDate.getTime()) {
      nextBday.setFullYear(tDate.getFullYear() + 1);
    }
    const daysUntilNext = Math.ceil((nextBday.getTime() - tDate.getTime()) / (1000 * 60 * 60 * 24));

    const dayOfWeek = bDate.toLocaleDateString('en-US', { weekday: 'long' });

    return {
      years,
      months,
      days,
      totalDays,
      totalHours,
      totalMinutes,
      daysUntilNext,
      dayOfWeek,
    };
  }, [birthDate, targetDate]);

  // 3. Discount Calculation
  const discountResult = useMemo(() => {
    const original = parseFloat(originalPrice) || 0;
    const disc = parseFloat(discountPercent) || 0;
    const tax = parseFloat(salesTaxPercent) || 0;

    const discountAmount = original * (disc / 100);
    const discountedPrice = original - discountAmount;
    const taxAmount = discountedPrice * (tax / 100);
    const finalPrice = discountedPrice + taxAmount;

    return {
      discountAmount,
      discountedPrice,
      taxAmount,
      finalPrice,
    };
  }, [originalPrice, discountPercent, salesTaxPercent]);

  // 4. BMI Calculation
  const bmiResult = useMemo(() => {
    let weightKg = 0;
    let heightM = 0;

    if (bmiSystem === 'metric') {
      heightM = (parseFloat(bmiHeightMetric) || 0) / 100;
      weightKg = parseFloat(bmiWeightMetric) || 0;
    } else {
      const feet = parseFloat(bmiFeet) || 0;
      const inches = parseFloat(bmiInches) || 0;
      const totalInches = feet * 12 + inches;
      heightM = totalInches * 0.0254;
      weightKg = (parseFloat(bmiWeightImperial) || 0) * 0.45359237;
    }

    if (heightM <= 0 || weightKg <= 0) return null;

    const bmi = weightKg / (heightM * heightM);
    let category = 'Normal';
    let color = 'text-emerald-600 dark:text-emerald-400';
    let bg = 'bg-emerald-50 dark:bg-emerald-950/50';

    if (bmi < 18.5) {
      category = 'Underweight';
      color = 'text-amber-600 dark:text-amber-400';
      bg = 'bg-amber-50 dark:bg-amber-950/50';
    } else if (bmi >= 25 && bmi < 29.9) {
      category = 'Overweight';
      color = 'text-orange-600 dark:text-orange-400';
      bg = 'bg-orange-50 dark:bg-orange-950/50';
    } else if (bmi >= 30) {
      category = 'Obese';
      color = 'text-rose-600 dark:text-rose-400';
      bg = 'bg-rose-50 dark:bg-rose-950/50';
    }

    return {
      bmi: bmi.toFixed(1),
      category,
      color,
      bg,
    };
  }, [bmiSystem, bmiHeightMetric, bmiWeightMetric, bmiFeet, bmiInches, bmiWeightImperial]);

  // 5. Average & Statistics Calculation
  const statsResult = useMemo(() => {
    const nums = avgInput
      .split(/[\s,;\n]+/)
      .map(Number)
      .filter((n) => !isNaN(n));

    if (nums.length === 0) return null;

    const count = nums.length;
    const sum = nums.reduce((acc, val) => acc + val, 0);
    const mean = sum / count;

    const sorted = [...nums].sort((a, b) => a - b);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const range = max - min;

    let median = 0;
    if (count % 2 === 0) {
      median = (sorted[count / 2 - 1] + sorted[count / 2]) / 2;
    } else {
      median = sorted[Math.floor(count / 2)];
    }

    // Standard deviation
    const variance = nums.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / count;
    const stdDev = Math.sqrt(variance);

    return {
      count,
      sum,
      mean: mean.toFixed(2),
      median: median.toFixed(2),
      min,
      max,
      range,
      stdDev: stdDev.toFixed(2),
    };
  }, [avgInput]);

  // 6. GPA Calculation
  const GRADE_POINTS: Record<string, number> = {
    'A+': 4.0,
    A: 4.0,
    'A-': 3.7,
    'B+': 3.3,
    B: 3.0,
    'B-': 2.7,
    'C+': 2.3,
    C: 2.0,
    'C-': 1.7,
    'D+': 1.3,
    D: 1.0,
    F: 0.0,
  };

  const gpaResult = useMemo(() => {
    let totalCredits = 0;
    let totalQualityPoints = 0;

    courses.forEach((c) => {
      const pts = GRADE_POINTS[c.grade] ?? 0;
      totalCredits += c.credits;
      totalQualityPoints += pts * c.credits;
    });

    const gpa = totalCredits > 0 ? totalQualityPoints / totalCredits : 0;
    return {
      gpa: gpa.toFixed(2),
      totalCredits,
      totalQualityPoints: totalQualityPoints.toFixed(1),
    };
  }, [courses]);

  // 7. Unit Converter Tables
  const UNIT_CONFIG = {
    length: {
      units: [
        { id: 'm', label: 'Meters (m)', factor: 1 },
        { id: 'km', label: 'Kilometers (km)', factor: 1000 },
        { id: 'cm', label: 'Centimeters (cm)', factor: 0.01 },
        { id: 'mm', label: 'Millimeters (mm)', factor: 0.001 },
        { id: 'in', label: 'Inches (in)', factor: 0.0254 },
        { id: 'ft', label: 'Feet (ft)', factor: 0.3048 },
        { id: 'yd', label: 'Yards (yd)', factor: 0.9144 },
        { id: 'mi', label: 'Miles (mi)', factor: 1609.344 },
      ],
    },
    weight: {
      units: [
        { id: 'kg', label: 'Kilograms (kg)', factor: 1 },
        { id: 'g', label: 'Grams (g)', factor: 0.001 },
        { id: 'mg', label: 'Milligrams (mg)', factor: 0.000001 },
        { id: 'lb', label: 'Pounds (lbs)', factor: 0.45359237 },
        { id: 'oz', label: 'Ounces (oz)', factor: 0.02834952 },
        { id: 'ton', label: 'Metric Tonnes', factor: 1000 },
      ],
    },
    temp: {
      units: [
        { id: 'c', label: 'Celsius (°C)' },
        { id: 'f', label: 'Fahrenheit (°F)' },
        { id: 'k', label: 'Kelvin (K)' },
      ],
    },
    speed: {
      units: [
        { id: 'mps', label: 'Meters/sec (m/s)', factor: 1 },
        { id: 'kph', label: 'Kilometers/hour (km/h)', factor: 0.277778 },
        { id: 'mph', label: 'Miles/hour (mph)', factor: 0.44704 },
        { id: 'knot', label: 'Knots', factor: 0.514444 },
      ],
    },
    volume: {
      units: [
        { id: 'l', label: 'Liters (L)', factor: 1 },
        { id: 'ml', label: 'Milliliters (mL)', factor: 0.001 },
        { id: 'gal', label: 'US Gallons', factor: 3.78541 },
        { id: 'cup', label: 'US Cups', factor: 0.236588 },
        { id: 'floz', label: 'Fluid Ounces', factor: 0.0295735 },
      ],
    },
    area: {
      units: [
        { id: 'sqm', label: 'Square Meters (m²)', factor: 1 },
        { id: 'sqft', label: 'Square Feet (ft²)', factor: 0.092903 },
        { id: 'sqkm', label: 'Square Kilometers (km²)', factor: 1000000 },
        { id: 'acre', label: 'Acres', factor: 4046.86 },
        { id: 'ha', label: 'Hectares', factor: 10000 },
      ],
    },
  };

  const unitConvertedResult = useMemo(() => {
    const val = parseFloat(unitValue);
    if (isNaN(val)) return '0';

    if (unitCategory === 'temp') {
      let c = val;
      if (unitFrom === 'f') c = ((val - 32) * 5) / 9;
      if (unitFrom === 'k') c = val - 273.15;

      let target = c;
      if (unitTo === 'f') target = (c * 9) / 5 + 32;
      if (unitTo === 'k') target = c + 273.15;
      return target.toFixed(2);
    }

    const currentCat = UNIT_CONFIG[unitCategory];
    const fromUnit = currentCat.units.find((u) => u.id === unitFrom) as any;
    const toUnit = currentCat.units.find((u) => u.id === unitTo) as any;

    if (!fromUnit || !toUnit) return '0';

    // Base value
    const base = val * fromUnit.factor;
    const res = base / toUnit.factor;
    return res > 1000000 || (res < 0.0001 && res > 0) ? res.toExponential(4) : res.toLocaleString(undefined, { maximumFractionDigits: 4 });
  }, [unitCategory, unitValue, unitFrom, unitTo]);

  // Swap units handler
  const handleSwapUnits = () => {
    const temp = unitFrom;
    setUnitFrom(unitTo);
    setUnitTo(temp);
  };

  // Ensure default unit options match when switching category
  const handleCategoryChange = (cat: any) => {
    setUnitCategory(cat);
    const catUnits = UNIT_CONFIG[cat as keyof typeof UNIT_CONFIG].units;
    setUnitFrom(catUnits[0].id);
    setUnitTo(catUnits[1] ? catUnits[1].id : catUnits[0].id);
  };

  return (
    <div className="space-y-6">
      {/* 1. PERCENTAGE CALCULATOR */}
      {toolSlug === 'percentage-calculator' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl">
            <button
              onClick={() => setPercMode('whatIs')}
              className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                percMode === 'whatIs' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              What is X% of Y?
            </button>
            <button
              onClick={() => setPercMode('isWhat')}
              className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                percMode === 'isWhat' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              X is what % of Y?
            </button>
            <button
              onClick={() => setPercMode('change')}
              className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg transition-colors ${
                percMode === 'change' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              % Increase / Decrease
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {percMode === 'whatIs' ? 'Percentage (X)' : percMode === 'isWhat' ? 'Value (X)' : 'Initial Value (From)'}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={percX}
                    onChange={(e) => setPercX(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {percMode === 'whatIs' && (
                    <span className="absolute right-3.5 top-2.5 text-sm font-medium text-slate-400">%</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {percMode === 'whatIs' ? 'Total (Y)' : percMode === 'isWhat' ? 'Total (Y)' : 'Final Value (To)'}
                </label>
                <input
                  type="number"
                  value={percY}
                  onChange={(e) => setPercY(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {percResult && (
              <div className="mt-6 p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 dark:bg-indigo-950/40 dark:border-indigo-900/60">
                <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-1">
                  Result
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white">
                  {percResult.formatted}
                </div>
                <div className="mt-2 text-xs font-mono text-slate-600 dark:text-slate-400">
                  Formula: {percResult.formula}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. AGE CALCULATOR */}
      {toolSlug === 'age-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Date of Birth
              </label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Age at Date
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {ageResult && (
            <div className="space-y-4">
              <div className="p-5 rounded-xl bg-indigo-50/70 border border-indigo-100 dark:bg-indigo-950/40 dark:border-indigo-900/60 text-center">
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Exact Chronological Age
                </span>
                <div className="mt-2 text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  {ageResult.years} <span className="text-base font-normal text-slate-500">years</span>, {ageResult.months} <span className="text-base font-normal text-slate-500">months</span>, {ageResult.days} <span className="text-base font-normal text-slate-500">days</span>
                </div>
                <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Born on a {ageResult.dayOfWeek}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="text-base sm:text-lg font-bold font-mono text-slate-900 dark:text-white">
                    {ageResult.totalDays.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500">Total Days</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="text-base sm:text-lg font-bold font-mono text-slate-900 dark:text-white">
                    {ageResult.totalHours.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500">Total Hours</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="text-base sm:text-lg font-bold font-mono text-slate-900 dark:text-white">
                    {ageResult.totalMinutes.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500">Total Minutes</div>
                </div>
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
                  <div className="text-base sm:text-lg font-bold font-mono text-indigo-600 dark:text-indigo-400">
                    {ageResult.daysUntilNext}
                  </div>
                  <div className="text-xs text-slate-500">Days to Next Birthday</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. DISCOUNT CALCULATOR */}
      {toolSlug === 'discount-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Original Price ($)
              </label>
              <input
                type="number"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Discount (%)
              </label>
              <input
                type="number"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Sales Tax (%, Optional)
              </label>
              <input
                type="number"
                value={salesTaxPercent}
                onChange={(e) => setSalesTaxPercent(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Final Price</div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                ${discountResult.finalPrice.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Total Savings</div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
                ${discountResult.discountAmount.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Estimated Tax</div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-700 dark:text-slate-300">
                ${discountResult.taxAmount.toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. BMI CALCULATOR */}
      {toolSlug === 'bmi-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="flex justify-center">
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs font-semibold">
              <button
                onClick={() => setBmiSystem('metric')}
                className={`px-4 py-1.5 rounded-md transition-colors ${
                  bmiSystem === 'metric' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Metric (cm / kg)
              </button>
              <button
                onClick={() => setBmiSystem('imperial')}
                className={`px-4 py-1.5 rounded-md transition-colors ${
                  bmiSystem === 'imperial' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-xs' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Imperial (ft / lbs)
              </button>
            </div>
          </div>

          {bmiSystem === 'metric' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Height (cm)
                </label>
                <input
                  type="number"
                  value={bmiHeightMetric}
                  onChange={(e) => setBmiHeightMetric(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  value={bmiWeightMetric}
                  onChange={(e) => setBmiWeightMetric(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Feet
                </label>
                <input
                  type="number"
                  value={bmiFeet}
                  onChange={(e) => setBmiFeet(e.target.value)}
                  className="w-full px-3 py-2 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Inches
                </label>
                <input
                  type="number"
                  value={bmiInches}
                  onChange={(e) => setBmiInches(e.target.value)}
                  className="w-full px-3 py-2 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Weight (lbs)
                </label>
                <input
                  type="number"
                  value={bmiWeightImperial}
                  onChange={(e) => setBmiWeightImperial(e.target.value)}
                  className="w-full px-3 py-2 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          )}

          {bmiResult && (
            <div className={`p-5 rounded-xl border text-center ${bmiResult.bg}`}>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Your Body Mass Index (BMI)
              </div>
              <div className="mt-2 text-4xl font-extrabold font-mono text-slate-900 dark:text-white">
                {bmiResult.bmi}
              </div>
              <div className={`mt-1 text-sm font-bold ${bmiResult.color}`}>
                {bmiResult.category}
              </div>
              <div className="mt-3 text-xs text-slate-500">
                Healthy BMI range: 18.5 – 24.9
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. TIP CALCULATOR */}
      {toolSlug === 'tip-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Bill Subtotal ($)
              </label>
              <input
                type="number"
                value={tipBill}
                onChange={(e) => setTipBill(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Number of People Splitting
              </label>
              <input
                type="number"
                min="1"
                value={tipPeople}
                onChange={(e) => setTipPeople(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
              Select Tip Percentage
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[10, 15, 18, 20, 25].map((p) => (
                <button
                  key={p}
                  onClick={() => setTipPercent(p)}
                  className={`py-2 text-xs sm:text-sm font-semibold rounded-lg border transition-colors ${
                    tipPercent === p
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-300'
                      : 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {p}%
                </button>
              ))}
            </div>
          </div>

          {(() => {
            const bill = parseFloat(tipBill) || 0;
            const tipTotal = bill * (tipPercent / 100);
            const totalWithTip = bill + tipTotal;
            const perPerson = totalWithTip / tipPeople;
            const tipPerPerson = tipTotal / tipPeople;

            return (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-center">
                <div>
                  <div className="text-xs text-slate-500">Tip Total</div>
                  <div className="text-lg sm:text-xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
                    ${tipTotal.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Total with Tip</div>
                  <div className="text-lg sm:text-xl font-bold font-mono text-slate-900 dark:text-white">
                    ${totalWithTip.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Tip / Person</div>
                  <div className="text-lg sm:text-xl font-bold font-mono text-slate-700 dark:text-slate-300">
                    ${tipPerPerson.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Total / Person</div>
                  <div className="text-lg sm:text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                    ${perPerson.toFixed(2)}
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* 6. AVERAGE & STATISTICS CALCULATOR */}
      {toolSlug === 'average-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Enter Numbers (separated by commas, spaces, or lines)
            </label>
            <textarea
              value={avgInput}
              onChange={(e) => setAvgInput(e.target.value)}
              rows={4}
              placeholder="e.g. 10, 20, 30, 45.5, 50"
              className="w-full px-3.5 py-2.5 text-sm font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {statsResult && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-xl sm:text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
                  {statsResult.mean}
                </div>
                <div className="text-xs text-slate-500">Mean (Average)</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.median}
                </div>
                <div className="text-xs text-slate-500">Median</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.range}
                </div>
                <div className="text-xs text-slate-500">Range ({statsResult.min} - {statsResult.max})</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.stdDev}
                </div>
                <div className="text-xs text-slate-500">Std Deviation (σ)</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.count}
                </div>
                <div className="text-xs text-slate-500">Total Count</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.sum}
                </div>
                <div className="text-xs text-slate-500">Sum</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.min}
                </div>
                <div className="text-xs text-slate-500">Minimum</div>
              </div>
              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-center">
                <div className="text-lg font-bold font-mono text-slate-900 dark:text-white">
                  {statsResult.max}
                </div>
                <div className="text-xs text-slate-500">Maximum</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 7. GPA CALCULATOR */}
      {toolSlug === 'gpa-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
              Enrolled Courses
            </h4>
            <button
              onClick={() => {
                const id = Date.now().toString();
                setCourses([...courses, { id, name: `Course ${courses.length + 1}`, grade: 'A', credits: 3 }]);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              Add Course
            </button>
          </div>

          <div className="space-y-2.5">
            {courses.map((course, idx) => (
              <div key={course.id} className="flex items-center gap-2 sm:gap-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40">
                <input
                  type="text"
                  value={course.name}
                  onChange={(e) => {
                    const next = [...courses];
                    next[idx].name = e.target.value;
                    setCourses(next);
                  }}
                  className="flex-1 px-3 py-1.5 text-xs sm:text-sm rounded border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <select
                  value={course.grade}
                  onChange={(e) => {
                    const next = [...courses];
                    next[idx].grade = e.target.value;
                    setCourses(next);
                  }}
                  className="w-20 px-2 py-1.5 text-xs sm:text-sm rounded border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                >
                  {Object.keys(GRADE_POINTS).map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={course.credits}
                    onChange={(e) => {
                      const next = [...courses];
                      next[idx].credits = parseInt(e.target.value) || 1;
                      setCourses(next);
                    }}
                    className="w-16 px-2 py-1.5 text-xs sm:text-sm rounded border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-center"
                  />
                  <span className="text-[11px] text-slate-400">cr</span>
                </div>
                {courses.length > 1 && (
                  <button
                    onClick={() => setCourses(courses.filter((c) => c.id !== course.id))}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded"
                    title="Remove course"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="p-5 rounded-xl bg-indigo-50/70 border border-indigo-100 dark:bg-indigo-950/40 dark:border-indigo-900/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Calculated Grade Point Average
              </div>
              <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 dark:text-white mt-1">
                {gpaResult.gpa} <span className="text-sm font-normal text-slate-500">/ 4.0</span>
              </div>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-400 text-right sm:border-l sm:border-indigo-200 dark:sm:border-indigo-900/60 sm:pl-6 space-y-1">
              <div>Total Credits: <span className="font-mono font-bold text-slate-900 dark:text-white">{gpaResult.totalCredits}</span></div>
              <div>Quality Points: <span className="font-mono font-bold text-slate-900 dark:text-white">{gpaResult.totalQualityPoints}</span></div>
            </div>
          </div>
        </div>
      )}

      {/* 8. UNIT CONVERTER */}
      {toolSlug === 'unit-converter' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-100 dark:border-slate-800">
            {[
              { id: 'length', label: 'Length' },
              { id: 'weight', label: 'Weight' },
              { id: 'temp', label: 'Temperature' },
              { id: 'speed', label: 'Speed' },
              { id: 'volume', label: 'Volume' },
              { id: 'area', label: 'Area' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategoryChange(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  unitCategory === cat.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center">
            {/* From */}
            <div className="md:col-span-5 space-y-2">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                From
              </label>
              <input
                type="number"
                value={unitValue}
                onChange={(e) => setUnitValue(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
              <select
                value={unitFrom}
                onChange={(e) => setUnitFrom(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                {UNIT_CONFIG[unitCategory].units.map((u) => (
                  <option key={u.id} value={u.id}>{u.label}</option>
                ))}
              </select>
            </div>

            {/* Swap Button */}
            <div className="md:col-span-1 flex justify-center pt-5">
              <button
                onClick={handleSwapUnits}
                className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600 transition-colors"
                title="Swap units"
              >
                <ArrowRightLeft className="h-4 w-4" />
              </button>
            </div>

            {/* To */}
            <div className="md:col-span-5 space-y-2">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                To
              </label>
              <div className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-indigo-600 dark:text-indigo-400 font-bold truncate">
                {unitConvertedResult}
              </div>
              <select
                value={unitTo}
                onChange={(e) => setUnitTo(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                {UNIT_CONFIG[unitCategory].units.map((u) => (
                  <option key={u.id} value={u.id}>{u.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* 9. RATIO CALCULATOR */}
      {toolSlug === 'ratio-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Aspect Ratio Presets:</span>
            <div className="flex items-center gap-1.5 text-xs">
              {[
                { label: '16:9 (Widescreen)', a: '16', b: '9' },
                { label: '4:3 (Standard)', a: '4', b: '3' },
                { label: '1:1 (Square)', a: '1', b: '1' },
                { label: '21:9 (Ultrawide)', a: '21', b: '9' },
                { label: '1920×1080 (FHD)', a: '1920', b: '1080' },
              ].map((p) => (
                <button
                  key={p.label}
                  onClick={() => {
                    setRatioA(p.a);
                    setRatioB(p.b);
                  }}
                  className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-center">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Value A
              </label>
              <input
                type="number"
                value={ratioA}
                onChange={(e) => setRatioA(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Value B
              </label>
              <input
                type="number"
                value={ratioB}
                onChange={(e) => setRatioB(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Value C (New Width)
              </label>
              <input
                type="number"
                value={ratioC}
                onChange={(e) => setRatioC(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Value D (New Height)
              </label>
              <div className="w-full px-3.5 py-2.5 text-base font-mono font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-indigo-600 dark:text-indigo-400">
                {ratioResult ? ratioResult.d : '...'}
              </div>
            </div>
          </div>

          {ratioResult && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-500">Simplified Ratio:</span>{' '}
                <strong className="font-mono text-slate-900 dark:text-white text-sm ml-1">{ratioResult.simplified}</strong>
              </div>
              <div>
                <span className="text-slate-500">Decimal Equivalent:</span>{' '}
                <strong className="font-mono text-slate-900 dark:text-white text-sm ml-1">{ratioResult.decimal}</strong>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 10. SIMPLE INTEREST CALCULATOR */}
      {toolSlug === 'simple-interest-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Principal Amount ($)
              </label>
              <input
                type="number"
                value={siPrincipal}
                onChange={(e) => setSiPrincipal(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Annual Interest Rate (% APR)
              </label>
              <input
                type="number"
                step="0.1"
                value={siRate}
                onChange={(e) => setSiRate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Time Period (Years)
              </label>
              <input
                type="number"
                step="0.5"
                value={siTime}
                onChange={(e) => setSiTime(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {siResult && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-center">
              <div>
                <div className="text-xs text-slate-500">Total Interest Earned</div>
                <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5">
                  ${siResult.interest.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Total Repayment Amount</div>
                <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
                  ${siResult.total.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Monthly Payoff</div>
                <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                  ${siResult.monthlyPayment.toFixed(2)}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 11. COMPOUND INTEREST CALCULATOR */}
      {toolSlug === 'compound-interest-calculator' && (
        <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Initial Principal ($)
              </label>
              <input
                type="number"
                value={ciPrincipal}
                onChange={(e) => setCiPrincipal(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Annual Interest Rate (% APY)
              </label>
              <input
                type="number"
                step="0.1"
                value={ciRate}
                onChange={(e) => setCiRate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Compounding Frequency
              </label>
              <select
                value={ciFreq}
                onChange={(e) => setCiFreq(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
              >
                <option value={1}>Annually (1x/year)</option>
                <option value={4}>Quarterly (4x/year)</option>
                <option value={12}>Monthly (12x/year)</option>
                <option value={365}>Daily (365x/year)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Investment Period (Years)
              </label>
              <input
                type="number"
                value={ciTime}
                onChange={(e) => setCiTime(e.target.value)}
                className="w-full px-3.5 py-2.5 text-base font-mono rounded-lg border border-slate-300 dark:border-slate-700 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {ciResult && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-center">
              <div>
                <div className="text-xs text-slate-500">Initial Principal</div>
                <div className="text-2xl font-bold font-mono text-slate-700 dark:text-slate-300 mt-0.5">
                  ${parseFloat(ciPrincipal).toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Total Compound Interest</div>
                <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5">
                  ${ciResult.interest.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500">Future Balance</div>
                <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
                  ${ciResult.total.toFixed(2)}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
