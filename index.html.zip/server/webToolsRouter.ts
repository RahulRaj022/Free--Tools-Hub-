import { Router, Request, Response } from 'express';
import {
  validateSafeUrl,
  fetchSafePage,
  lookupDnsRecords,
  checkSslCertificate,
  traceRedirectChain,
  checkLinksBatch,
} from './webToolsService.js';

export const webToolsRouter = Router();

// 1. Safe Page Fetcher (Powers color extractor, font detector, word counter, accessibility, tech detector, performance, open graph)
webToolsRouter.post('/proxy-page', async (req: Request, res: Response) => {
  const { url } = req.body;
  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'A valid target URL is required.' });
  }

  try {
    const result = await fetchSafePage(url);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to fetch webpage.' });
  }
});

// 2. Screenshot Generation & Download Proxy
webToolsRouter.get('/screenshot', async (req: Request, res: Response) => {
  const targetUrl = req.query.url as string;
  const viewport = (req.query.viewport as string) || 'desktop';
  const download = req.query.download === 'true';

  if (!targetUrl) {
    return res.status(400).json({ error: 'URL query parameter is required.' });
  }

  const validation = await validateSafeUrl(targetUrl);
  if (!validation.safe || !validation.url) {
    return res.status(400).json({ error: validation.error || 'Blocked or invalid URL.' });
  }

  const safeUrl = validation.url.toString();
  const width = viewport === 'mobile' ? 390 : 1280;
  const height = viewport === 'mobile' ? 844 : 800;

  // Real rendered screenshot proxy via high-reliability engine
  // Microlink provides clean headless screenshots with full viewport controls
  const screenshotSource = `https://api.microlink.io?url=${encodeURIComponent(
    safeUrl
  )}&screenshot=true&meta=false&embed=screenshot.url&viewport.width=${width}&viewport.height=${height}&viewport.isMobile=${viewport === 'mobile'}`;

  if (download) {
    try {
      const imgRes = await fetch(screenshotSource);
      if (!imgRes.ok) {
        throw new Error('Screenshot provider error');
      }
      const buffer = await imgRes.arrayBuffer();
      const domainName = validation.url.hostname.replace(/[^a-z0-9]/gi, '_');

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', `attachment; filename="screenshot_${domainName}_${viewport}.png"`);
      return res.send(Buffer.from(buffer));
    } catch {
      return res.redirect(screenshotSource);
    }
  }

  res.json({
    url: safeUrl,
    viewport,
    width,
    height,
    imageUrl: screenshotSource,
    downloadUrl: `/api/web/screenshot?url=${encodeURIComponent(safeUrl)}&viewport=${viewport}&download=true`,
  });
});

// 3. DNS Lookup
webToolsRouter.get('/dns', async (req: Request, res: Response) => {
  const domain = req.query.domain as string;
  if (!domain) {
    return res.status(400).json({ error: 'Domain parameter is required.' });
  }

  try {
    const result = await lookupDnsRecords(domain);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'DNS lookup failed.' });
  }
});

// 4. SSL Certificate Checker
webToolsRouter.get('/ssl', async (req: Request, res: Response) => {
  const domain = req.query.domain as string;
  if (!domain) {
    return res.status(400).json({ error: 'Domain parameter is required.' });
  }

  try {
    const cert = await checkSslCertificate(domain);
    res.json(cert);
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'SSL inspection failed.' });
  }
});

// 5. HTTP Status Code Checker
webToolsRouter.post('/http-status', async (req: Request, res: Response) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'URL parameter is required.' });
  }

  const validation = await validateSafeUrl(url);
  if (!validation.safe || !validation.url) {
    return res.status(400).json({ error: validation.error || 'Blocked URL.' });
  }

  const start = Date.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch(validation.url.toString(), {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) FreeToolsHub/1.0',
      },
      redirect: 'manual', // do not follow redirect so we observe the exact initial status
    });
    clearTimeout(timeout);
    const elapsed = Date.now() - start;

    const headersRecord: Record<string, string> = {};
    response.headers.forEach((v, k) => {
      headersRecord[k.toLowerCase()] = v;
    });

    res.json({
      url: validation.url.toString(),
      statusCode: response.status,
      statusText: response.statusText || `${response.status}`,
      responseTimeMs: elapsed,
      headers: headersRecord,
      location: response.headers.get('location') || null,
      isRedirect: [301, 302, 303, 307, 308].includes(response.status),
    });
  } catch (err: any) {
    clearTimeout(timeout);
    res.status(400).json({
      error: `Failed to connect to ${validation.url.hostname}: ${err?.message || 'Network error'}`,
    });
  }
});

// 6. Trace Redirect Chain
webToolsRouter.post('/redirect-chain', async (req: Request, res: Response) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'URL is required.' });
  }

  try {
    const chain = await traceRedirectChain(url);
    res.json(chain);
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Redirect check failed.' });
  }
});

// 7. Check Links Batch
webToolsRouter.post('/check-links', async (req: Request, res: Response) => {
  const { urls } = req.body;
  if (!Array.isArray(urls) || urls.length === 0) {
    return res.status(400).json({ error: 'urls must be a non-empty array of URL strings.' });
  }

  try {
    const results = await checkLinksBatch(urls);
    res.json({ results });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Link check failed.' });
  }
});
