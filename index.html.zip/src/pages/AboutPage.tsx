import React, { useEffect } from 'react';
import { Breadcrumbs } from '../components/layout/Breadcrumbs';
import { BackButton } from '../components/common/BackButton';
import { ShieldCheck, Zap, Heart, Check, ArrowRight } from 'lucide-react';

interface AboutPageProps {
  navigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ navigate }) => {
  useEffect(() => {
    document.title = 'About Us – Free Tools Hub';
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 space-y-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <BackButton navigate={navigate} fallbackPath="/" />
        <Breadcrumbs items={[{ label: 'About Us' }]} navigate={navigate} />
      </div>

      <div className="space-y-4">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
          Simple Tools. Built for Everyone.
        </h1>
        <p className="text-base sm:text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
          Free Tools Hub was created with a clear objective: build high-speed, private, and frictionless browser utilities for students, developers, office workers, and everyday creators.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-2">
          <Zap className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Fast & Instant</h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            No waiting queues or artificial download timers. Calculations and conversions run in milliseconds using your local computer resources.
          </p>
        </div>

        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs space-y-2">
          <ShieldCheck className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Private by Design</h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Your files, PDFs, passwords, and numbers are processed entirely within the browser. We never sell or harvest your data.
          </p>
        </div>
      </div>

      <div className="rounded-3xl border border-slate-200/90 bg-white dark:border-slate-800 dark:bg-slate-900 p-8 sm:p-10 space-y-4">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          Our Core Principles
        </h2>
        <div className="space-y-3 text-sm text-slate-700 dark:text-slate-300">
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <strong>No Signup Walls:</strong> You should never have to surrender your email address just to convert an image or count words in an essay.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <strong>Accessible Everywhere:</strong> Responsive on every screen size, compliant with contrast and keyboard standards, and optimized for mobile devices.
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <strong>No AI Slop:</strong> We build practical utilities that do real work, accurately and cleanly.
            </div>
          </div>
        </div>
      </div>

      <div className="text-center pt-6">
        <button
          onClick={() => navigate('/tools')}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 text-white font-semibold text-sm hover:bg-indigo-700 transition-colors shadow-xs"
        >
          <span>Explore Free Tools</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};
