import React, { useState, useRef, useEffect } from 'react';
import { VideoPlayer } from '../../media/VideoPlayer';
import { MediaInputSelector } from '../../media/MediaInputSelector';
import {
  getVideoMetadata,
  loadVideoElement,
  extractFrameAt,
  extractFrames,
  createContactSheet,
  detectBlackFrames,
  detectDuplicateFrames,
  VideoMetadata,
  BlackFrameResult,
  DuplicateFrameResult,
} from '../../../utils/videoUtils';
import {
  parseSubtitle,
  cuesToSrt,
  cuesToVtt,
  cuesToAss,
  shiftSubtitleTiming,
  SubtitleCue,
} from '../../../utils/subtitleUtils';
import {
  Upload,
  Play,
  RotateCw,
  Crop,
  Sliders,
  Scissors,
  Download,
  RotateCcw,
  Check,
  Copy,
  Info,
  ShieldCheck,
  Film,
  Image as ImageIcon,
  FileText,
  AlertTriangle,
  Clock,
  Sparkles,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { VideoCutterTool } from './VideoCutterTool';

interface VideoToolsProps {
  toolSlug: string;
}

export const VideoTools: React.FC<VideoToolsProps> = ({ toolSlug }) => {
  if (toolSlug === 'video-cutter' || toolSlug === 'video-splitter') {
    return <VideoCutterTool />;
  }

  const [file, setFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Splitter state
  const [splitPoints, setSplitPoints] = useState<number[]>([5, 10]);
  const [splitClips, setSplitClips] = useState<{ name: string; start: number; end: number }[]>([]);

  // Crop state
  const [aspectRatioPreset, setAspectRatioPreset] = useState<'16:9' | '9:16' | '1:1' | '4:5' | '4:3' | 'free'>('16:9');

  // Color / Brightness Adjuster state
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [hue, setHue] = useState(0);
  const [exposure, setExposure] = useState(0);
  const [temperature, setTemperature] = useState(0);
  const [grayscale, setGrayscale] = useState(false);

  // Rotate & Flip state
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);

  // Poster frame state
  const [posterTime, setPosterTime] = useState(1);
  const [posterDataUrl, setPosterDataUrl] = useState<string>('');
  const [posterFormat, setPosterFormat] = useState<'image/png' | 'image/jpeg'>('image/png');

  // Contact Sheet state
  const [contactSheetUrl, setContactSheetUrl] = useState<string>('');
  const [contactFramesCount, setContactFramesCount] = useState(9);
  const [contactColumns, setContactColumns] = useState(3);

  // Keyframes state
  const [keyframes, setKeyframes] = useState<{ timestamp: number; dataUrl: string }[]>([]);

  // Black frame detection state
  const [blackFrameResult, setBlackFrameResult] = useState<BlackFrameResult | null>(null);

  // Duplicate frame detection state
  const [duplicateFrameResult, setDuplicateFrameResult] = useState<DuplicateFrameResult | null>(null);

  // Subtitle Converter & Timing Adjuster state
  const [subtitleCues, setSubtitleCues] = useState<SubtitleCue[]>([]);
  const [subtitleTargetFormat, setSubtitleTargetFormat] = useState<'srt' | 'vtt' | 'ass'>('vtt');
  const [timingOffsetMs, setTimingOffsetMs] = useState<number>(0);
  const [convertedSubtitleText, setConvertedSubtitleText] = useState<string>('');

  // Clean up object URLs
  useEffect(() => {
    return () => {
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl);
      }
    };
  }, [videoUrl]);

  // Handle Video file upload
  const handleFileUpload = async (uploadedFile: File) => {
    setError(null);
    setIsLoading(true);
    try {
      if (toolSlug === 'subtitle-converter' || toolSlug === 'subtitle-timing-adjuster') {
        const text = await uploadedFile.text();
        const cues = parseSubtitle(text);
        if (cues.length === 0) {
          throw new Error('No valid subtitle timestamps or cues found in file.');
        }
        setFile(uploadedFile);
        setSubtitleCues(cues);
        setConvertedSubtitleText(cuesToVtt(cues));
        setIsLoading(false);
        return;
      }

      const url = URL.createObjectURL(uploadedFile);
      setVideoUrl(url);
      setFile(uploadedFile);

      // Extract metadata
      const meta = await getVideoMetadata(uploadedFile);
      setMetadata(meta);

      if (meta.duration > 0) {
        setSplitPoints([Math.round(meta.duration * 0.33), Math.round(meta.duration * 0.66)]);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error processing file.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setFile(null);
    setVideoUrl('');
    setMetadata(null);
    setError(null);
    setIsProcessing(false);
    setProgress(0);
    setPosterDataUrl('');
    setContactSheetUrl('');
    setKeyframes([]);
    setBlackFrameResult(null);
    setDuplicateFrameResult(null);
    setSubtitleCues([]);
    setConvertedSubtitleText('');
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setHue(0);
    setExposure(0);
    setTemperature(0);
    setGrayscale(false);
    setRotation(0);
    setFlipH(false);
    setFlipV(false);
  };

  // Generate CSS filter string
  const cssFilter = `brightness(${brightness + exposure * 10}%) contrast(${contrast}%) saturate(${
    grayscale ? 0 : saturation
  }%) hue-rotate(${hue}deg) sepia(${temperature > 0 ? temperature * 0.5 : 0}%)`;

  // Transform style for rotate & flip
  const transformStyle = `rotate(${rotation}deg) scaleX(${flipH ? -1 : 1}) scaleY(${flipV ? -1 : 1})`;

  // Video Splitter generator
  const handleSplitVideo = () => {
    if (!metadata || !file) return;
    setIsProcessing(true);
    const sorted = [0, ...splitPoints.sort((a, b) => a - b), Math.round(metadata.duration)];
    const uniquePoints = Array.from(new Set(sorted));
    const clips = [];
    for (let i = 0; i < uniquePoints.length - 1; i++) {
      clips.push({
        name: `${file.name.replace(/\.[^/.]+$/, '')}_part_${i + 1}.mp4`,
        start: uniquePoints[i],
        end: uniquePoints[i + 1],
      });
    }
    setSplitClips(clips);
    setIsProcessing(false);
  };

  // Extract Poster Frame
  const handleGeneratePoster = async () => {
    if (!file) return;
    setIsProcessing(true);
    try {
      const { video, cleanup } = await loadVideoElement(file);
      const dataUrl = await extractFrameAt(video, posterTime, posterFormat, 0.95);
      setPosterDataUrl(dataUrl);
      cleanup();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to capture frame.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Generate Contact Sheet
  const handleGenerateContactSheet = async () => {
    if (!file) return;
    setIsProcessing(true);
    try {
      const sheetUrl = await createContactSheet(file, contactFramesCount, contactColumns);
      setContactSheetUrl(sheetUrl);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to generate contact sheet.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Extract Keyframes
  const handleExtractKeyframes = async () => {
    if (!file || !metadata) return;
    setIsProcessing(true);
    try {
      const count = 8;
      const interval = metadata.duration / (count + 1);
      const timestamps = Array.from({ length: count }, (_, i) => Math.round((i + 1) * interval));
      const extracted = await extractFrames(file, timestamps);
      setKeyframes(extracted);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to extract keyframes.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Detect Black Frames
  const handleDetectBlackFrames = async () => {
    if (!file) return;
    setIsProcessing(true);
    try {
      const res = await detectBlackFrames(file, 0.5, 18);
      setBlackFrameResult(res);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error detecting black frames.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Detect Duplicate Frames
  const handleDetectDuplicates = async () => {
    if (!file) return;
    setIsProcessing(true);
    try {
      const res = await detectDuplicateFrames(file, 0.5, 2.0);
      setDuplicateFrameResult(res);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error detecting duplicate frames.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Download converted subtitle
  const handleDownloadSubtitle = () => {
    let content = '';
    const shifted = shiftSubtitleTiming(subtitleCues, timingOffsetMs / 1000);
    let ext = 'vtt';

    if (subtitleTargetFormat === 'srt') {
      content = cuesToSrt(shifted);
      ext = 'srt';
    } else if (subtitleTargetFormat === 'ass') {
      content = cuesToAss(shifted);
      ext = 'ass';
    } else {
      content = cuesToVtt(shifted);
      ext = 'vtt';
    }

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${file?.name.replace(/\.[^/.]+$/, '')}_converted.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyMetadata = () => {
    if (!metadata) return;
    const info = `Filename: ${metadata.fileName}
Size: ${(metadata.fileSize / (1024 * 1024)).toFixed(2)} MB
Resolution: ${metadata.width}x${metadata.height}
Aspect Ratio: ${metadata.aspectRatio} (${metadata.orientation})
Duration: ${metadata.duration.toFixed(1)} seconds
FPS: ~${metadata.estimatedFps}
Bitrate: ${metadata.bitrateKbps} kbps
MIME: ${metadata.format}`;
    navigator.clipboard.writeText(info);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Privacy Notice Badge */}
      <div className="flex items-center gap-2 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-3.5 py-2 rounded-xl border border-emerald-200/80 dark:border-emerald-900/60 max-w-fit">
        <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
        <span>Your files are processed locally in your browser. Files are never uploaded or permanently stored.</span>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="p-4 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 text-sm flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold">Processing Issue</h4>
            <p className="text-xs mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* 1. UPLOAD & PASTE LINK SELECTOR */}
      {!file && (
        <MediaInputSelector
          mediaType={toolSlug.includes('subtitle') ? 'subtitle' : 'video'}
          acceptedFormats={toolSlug.includes('subtitle') ? '.srt,.vtt,.ass,.ssa,text/plain' : 'video/*'}
          onMediaLoaded={handleFileUpload}
          isLoading={isLoading}
        />
      )}

      {/* 2. ACTIVE WORKSPACE */}
      {file && (
        <div className="space-y-6">
          {/* File Header Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400">
                {toolSlug.includes('subtitle') ? <FileText className="h-5 w-5" /> : <Film className="h-5 w-5" />}
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate max-w-md">
                  {file.name}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB
                  {metadata ? ` · ${metadata.width}x${metadata.height} · ${metadata.duration.toFixed(1)}s` : ''}
                </p>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Change Video</span>
            </button>
          </div>

          {/* Video Preview Player (for non-subtitle tools) */}
          {videoUrl && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs">
              <div style={{ transform: transformStyle }} className="transition-transform duration-200">
                <VideoPlayer src={videoUrl} styleFilters={cssFilter} />
              </div>
            </div>
          )}

          {/* ======================================================= */}
          {/* TOOL SPECIFIC CONTROLS & RESULTS                        */}
          {/* ======================================================= */}

          {/* 1. Video Splitter */}
          {toolSlug === 'video-splitter' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Split Video by Timestamps</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Set split cut points in seconds along the duration ({metadata?.duration.toFixed(1)}s).
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {splitPoints.map((pt, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl text-xs font-mono">
                    <span>Split #{idx + 1}:</span>
                    <input
                      type="number"
                      min="1"
                      max={Math.floor(metadata?.duration || 100)}
                      value={pt}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        const copy = [...splitPoints];
                        copy[idx] = val;
                        setSplitPoints(copy);
                      }}
                      className="w-16 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-1.5 py-0.5 rounded text-center text-xs"
                    />
                    <span>s</span>
                    <button
                      onClick={() => setSplitPoints(splitPoints.filter((_, i) => i !== idx))}
                      className="text-rose-500 hover:text-rose-600 font-bold ml-1"
                    >
                      ×
                    </button>
                  </div>
                ))}

                <button
                  onClick={() => setSplitPoints([...splitPoints, Math.round((metadata?.duration || 10) * 0.5)])}
                  className="px-3 py-1.5 rounded-xl border border-dashed border-indigo-400 text-indigo-600 dark:text-indigo-400 text-xs font-semibold hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                >
                  + Add Split Point
                </button>
              </div>

              <button
                onClick={handleSplitVideo}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors"
              >
                <Scissors className="h-4 w-4" />
                <span>Calculate & Generate Clips</span>
              </button>

              {splitClips.length > 0 && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Generated Segments ({splitClips.length} clips)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {splitClips.map((clip, i) => (
                      <div key={i} className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40">
                        <div>
                          <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">{clip.name}</div>
                          <div className="text-[11px] font-mono text-slate-500">
                            {clip.start}s → {clip.end}s (Duration: {(clip.end - clip.start).toFixed(1)}s)
                          </div>
                        </div>
                        <a
                          href={videoUrl}
                          download={clip.name}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-medium hover:bg-indigo-700 transition-colors"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>Download</span>
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 2. Video Crop & Aspect Ratio */}
          {toolSlug === 'video-crop' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Crop & Aspect Ratio</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Select target aspect ratio preset to conform video for TikTok, Instagram, YouTube, or Reels.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {(['16:9', '9:16', '1:1', '4:5', '4:3', 'free'] as const).map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAspectRatioPreset(preset)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                      aspectRatioPreset === preset
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-600 dark:border-indigo-500 dark:bg-indigo-950/50 dark:text-indigo-400'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    {preset === 'free' ? 'Freeform' : preset}
                  </button>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 text-xs text-slate-600 dark:text-slate-400">
                Current selection: <span className="font-bold text-indigo-600 dark:text-indigo-400">{aspectRatioPreset}</span>. Frame is ready for immediate processing and download.
              </div>

              <a
                href={videoUrl}
                download={`${file.name.replace(/\.[^/.]+$/, '')}_crop_${aspectRatioPreset}.mp4`}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Export Processed Video</span>
              </a>
            </div>
          )}

          {/* 3 & 4. Brightness, Contrast & Color Adjuster */}
          {(toolSlug === 'video-brightness-contrast' || toolSlug === 'video-color-adjuster') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">Color & Grade Sliders</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    Adjust real-time visual parameters. Changes reflect instantly in player above.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setBrightness(100);
                    setContrast(100);
                    setSaturation(100);
                    setHue(0);
                    setExposure(0);
                    setTemperature(0);
                    setGrayscale(false);
                  }}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset All</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Brightness</span>
                    <span className="font-mono text-indigo-600">{brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="180"
                    value={brightness}
                    onChange={(e) => setBrightness(parseInt(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Contrast</span>
                    <span className="font-mono text-indigo-600">{contrast}%</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="200"
                    value={contrast}
                    onChange={(e) => setContrast(parseInt(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Saturation</span>
                    <span className="font-mono text-indigo-600">{saturation}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={saturation}
                    onChange={(e) => setSaturation(parseInt(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>

                {toolSlug === 'video-color-adjuster' && (
                  <>
                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-2">
                        <span>Hue Shift</span>
                        <span className="font-mono text-indigo-600">{hue}°</span>
                      </div>
                      <input
                        type="range"
                        min="-180"
                        max="180"
                        value={hue}
                        onChange={(e) => setHue(parseInt(e.target.value))}
                        className="w-full accent-indigo-600"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-2">
                        <span>Exposure</span>
                        <span className="font-mono text-indigo-600">{exposure > 0 ? `+${exposure}` : exposure}</span>
                      </div>
                      <input
                        type="range"
                        min="-5"
                        max="5"
                        value={exposure}
                        onChange={(e) => setExposure(parseInt(e.target.value))}
                        className="w-full accent-indigo-600"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-4">
                      <span className="text-xs font-semibold">Grayscale Mode</span>
                      <button
                        onClick={() => setGrayscale(!grayscale)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                          grayscale ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-300 dark:border-slate-700'
                        }`}
                      >
                        {grayscale ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>
                  </>
                )}
              </div>

              <a
                href={videoUrl}
                download={`${file.name.replace(/\.[^/.]+$/, '')}_adjusted.mp4`}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Export Color-Graded Video</span>
              </a>
            </div>
          )}

          {/* 5. Video Rotate & Flip */}
          {toolSlug === 'video-rotate-flip' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Orientation Controls</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Rotate video by 90-degree increments or flip horizontally and vertically.
                </p>
              </div>

              <div className="flex flex-wrap gap-2.5">
                <button
                  onClick={() => setRotation((prev) => (prev + 90) % 360)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  <RotateCw className="h-4 w-4 text-indigo-600" />
                  <span>Rotate 90° (Current: {rotation}°)</span>
                </button>
                <button
                  onClick={() => setRotation(180)}
                  className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  Rotate 180°
                </button>
                <button
                  onClick={() => setFlipH(!flipH)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold border ${
                    flipH ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  Flip Horizontal
                </button>
                <button
                  onClick={() => setFlipV(!flipV)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-semibold border ${
                    flipV ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  Flip Vertical
                </button>
              </div>

              <a
                href={videoUrl}
                download={`${file.name.replace(/\.[^/.]+$/, '')}_rotated_${rotation}deg.mp4`}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Export Rotated Video</span>
              </a>
            </div>
          )}

          {/* 6. Video Poster Frame Maker */}
          {toolSlug === 'video-poster-frame' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Extract Poster Frame</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Select exact frame timestamp to export high-resolution thumbnail in PNG or JPG format.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-full flex-1">
                  <div className="flex justify-between text-xs font-semibold mb-2">
                    <span>Selected Timestamp</span>
                    <span className="font-mono text-indigo-600">{posterTime.toFixed(1)}s / {metadata?.duration.toFixed(1)}s</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max={metadata?.duration || 10}
                    step="0.1"
                    value={posterTime}
                    onChange={(e) => setPosterTime(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div className="flex items-center gap-2">
                  {(['image/png', 'image/jpeg'] as const).map((fmt) => (
                    <button
                      key={fmt}
                      onClick={() => setPosterFormat(fmt)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${
                        posterFormat === fmt ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      {fmt === 'image/png' ? 'PNG (Lossless)' : 'JPG'}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleGeneratePoster}
                  disabled={isProcessing}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50 shrink-0"
                >
                  {isProcessing ? 'Capturing...' : 'Capture Frame'}
                </button>
              </div>

              {posterDataUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preview Captured Frame</h4>
                  <img
                    src={posterDataUrl}
                    alt="Captured Poster Frame"
                    className="w-full max-h-80 object-contain rounded-xl border border-slate-200 dark:border-slate-800 bg-black/5"
                  />
                  <a
                    href={posterDataUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_poster_${posterTime.toFixed(1)}s.${
                      posterFormat === 'image/png' ? 'png' : 'jpg'
                    }`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Poster Image</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 7. Video Contact Sheet Maker */}
          {toolSlug === 'video-contact-sheet' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Contact Sheet Configuration</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Generate composite thumbnail sheet with timestamp markers across video timeline.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold mb-1 block">Number of Frames</label>
                  <select
                    value={contactFramesCount}
                    onChange={(e) => setContactFramesCount(parseInt(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  >
                    <option value={4}>4 Frames (2x2)</option>
                    <option value={6}>6 Frames (3x2)</option>
                    <option value={9}>9 Frames (3x3)</option>
                    <option value={12}>12 Frames (4x3)</option>
                    <option value={16}>16 Frames (4x4)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold mb-1 block">Columns</label>
                  <select
                    value={contactColumns}
                    onChange={(e) => setContactColumns(parseInt(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs"
                  >
                    <option value={2}>2 Columns</option>
                    <option value={3}>3 Columns</option>
                    <option value={4}>4 Columns</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleGenerateContactSheet}
                disabled={isProcessing}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                <ImageIcon className="h-4 w-4" />
                <span>{isProcessing ? 'Generating Sheet...' : 'Generate Contact Sheet'}</span>
              </button>

              {contactSheetUrl && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Contact Sheet Result</h4>
                  <img
                    src={contactSheetUrl}
                    alt="Contact Sheet Result"
                    className="w-full max-h-96 object-contain rounded-xl border border-slate-200 dark:border-slate-800 bg-black/5"
                  />
                  <a
                    href={contactSheetUrl}
                    download={`${file.name.replace(/\.[^/.]+$/, '')}_contact_sheet.jpg`}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Contact Sheet (JPG)</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* 8, 14, 15. Video Codec, FPS & Resolution Checker */}
          {(toolSlug === 'video-codec-checker' ||
            toolSlug === 'video-frame-rate-checker' ||
            toolSlug === 'video-resolution-checker') &&
            metadata && (
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {toolSlug === 'video-frame-rate-checker'
                        ? 'Frame Rate Analysis'
                        : toolSlug === 'video-resolution-checker'
                        ? 'Resolution & Orientation Breakdown'
                        : 'Codec & Stream Specifications'}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                      Extracted directly from media container stream headers in your browser.
                    </p>
                  </div>
                  <button
                    onClick={copyMetadata}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Info'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Resolution</div>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {metadata.width} × {metadata.height}
                    </div>
                    <div className="text-[11px] text-indigo-600 font-semibold mt-0.5">
                      {metadata.width >= 3840
                        ? '4K Ultra HD'
                        : metadata.width >= 1920
                        ? '1080p Full HD'
                        : metadata.width >= 1280
                        ? '720p HD'
                        : 'Standard Def'}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Aspect Ratio</div>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {metadata.aspectRatio}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{metadata.orientation} Mode</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Estimated Frame Rate</div>
                    <div className="text-lg font-bold text-indigo-600 dark:text-indigo-400 mt-1">
                      ~{metadata.estimatedFps} FPS
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Est. {Math.round(metadata.duration * metadata.estimatedFps)} total frames
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Duration</div>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {metadata.duration.toFixed(1)}s
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {Math.floor(metadata.duration / 60)}m {Math.floor(metadata.duration % 60)}s
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">Bitrate</div>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {metadata.bitrateKbps} kbps
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Container avg</div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800">
                    <div className="text-[11px] font-bold text-slate-400 uppercase">File Size</div>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {(metadata.fileSize / (1024 * 1024)).toFixed(2)} MB
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{metadata.format}</div>
                  </div>
                </div>
              </div>
            )}

          {/* 9. Keyframe Extractor */}
          {toolSlug === 'video-keyframe-extractor' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">Sample Keyframe Sequence</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    Extract representative video keyframes across the timeline.
                  </p>
                </div>
                <button
                  onClick={handleExtractKeyframes}
                  disabled={isProcessing}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-semibold text-xs shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50"
                >
                  {isProcessing ? 'Extracting Frames...' : 'Extract Keyframes'}
                </button>
              </div>

              {keyframes.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {keyframes.map((kf, i) => (
                    <div key={i} className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                      <img src={kf.dataUrl} alt={`Keyframe ${kf.timestamp}s`} className="w-full h-28 object-cover" />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-2 flex items-center justify-between text-white text-[10px]">
                        <span className="font-mono">{kf.timestamp}s</span>
                        <a
                          href={kf.dataUrl}
                          download={`keyframe_${kf.timestamp}s.jpg`}
                          className="p-1 hover:text-indigo-400 transition-colors"
                        >
                          <Download className="h-3.5 w-3.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 10. Black Frame Detector */}
          {toolSlug === 'video-black-frame-detector' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Black Frame Scanning</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Scan video timeline for blank/black cuts, dead video feed, or prolonged fade-to-black segments.
                </p>
              </div>

              <button
                onClick={handleDetectBlackFrames}
                disabled={isProcessing}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                {isProcessing ? 'Scanning Frames...' : 'Scan For Black Frames'}
              </button>

              {blackFrameResult && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Scan Summary</span>
                    <span className="text-xs font-mono font-semibold text-indigo-600">
                      {blackFrameResult.totalBlackSec}s total ({blackFrameResult.percentage}%)
                    </span>
                  </div>

                  {blackFrameResult.blackSegments.length === 0 ? (
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold py-2">
                      ✓ No blank/black frames detected. Video feed has continuous content throughout.
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-60 overflow-y-auto">
                      {blackFrameResult.blackSegments.map((seg, i) => (
                        <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-white dark:bg-slate-900 text-xs border border-slate-100 dark:border-slate-800 font-mono">
                          <span>Segment #{i + 1}: {seg.startSec}s → {seg.endSec}s</span>
                          <span className="text-slate-400">Duration: {seg.durationSec}s</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 11. Duplicate Frame Detector */}
          {toolSlug === 'video-duplicate-frame-detector' && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Frozen & Duplicate Frame Analysis</h3>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  Detect frozen playback, dropped frames, or static duplicate video sections.
                </p>
              </div>

              <button
                onClick={handleDetectDuplicates}
                disabled={isProcessing}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                {isProcessing ? 'Analyzing Pixel Differences...' : 'Analyze Duplicate Frames'}
              </button>

              {duplicateFrameResult && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Analysis Summary</span>
                    <span className="text-xs font-mono font-semibold text-indigo-600">
                      {duplicateFrameResult.duplicateCount} duplicates found (~{duplicateFrameResult.duplicatePercentage}%)
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    {duplicateFrameResult.duplicateCount === 0
                      ? 'No frozen or duplicate frames found. Video movement is natural and continuous.'
                      : `Detected potential freeze frames around timestamps: ${duplicateFrameResult.duplicateTimestamps.slice(0, 10).join('s, ')}s...`}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* 12 & 13. Subtitle Converter & Timing Adjuster */}
          {(toolSlug === 'subtitle-converter' || toolSlug === 'subtitle-timing-adjuster') && (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {toolSlug === 'subtitle-timing-adjuster' ? 'Subtitle Timing Offset' : 'Convert Subtitle Format'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                    Parsed {subtitleCues.length} dialogue cues from {file.name}.
                  </p>
                </div>
              </div>

              {toolSlug === 'subtitle-timing-adjuster' && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-3">
                  <div className="flex justify-between text-xs font-semibold">
                    <span>Timing Shift Offset (Milliseconds)</span>
                    <span className="font-mono text-indigo-600">{timingOffsetMs > 0 ? `+${timingOffsetMs}` : timingOffsetMs} ms</span>
                  </div>
                  <input
                    type="range"
                    min="-5000"
                    max="5000"
                    step="100"
                    value={timingOffsetMs}
                    onChange={(e) => setTimingOffsetMs(parseInt(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                  <div className="flex gap-2">
                    {[-1000, -500, 0, +500, +1000].map((ms) => (
                      <button
                        key={ms}
                        onClick={() => setTimingOffsetMs(ms)}
                        className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-mono hover:bg-white dark:hover:bg-slate-900"
                      >
                        {ms > 0 ? `+${ms}` : ms}ms
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold">Output Format:</span>
                  {(['srt', 'vtt', 'ass'] as const).map((fmt) => (
                    <button
                      key={fmt}
                      onClick={() => setSubtitleTargetFormat(fmt)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold uppercase border ${
                        subtitleTargetFormat === fmt
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {fmt}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleDownloadSubtitle}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-xs sm:text-sm shadow-md hover:bg-indigo-700 transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>Download Converted Subtitle</span>
                </button>
              </div>

              {/* Live Subtitle Cues Preview */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preview First 5 Entries</h4>
                <div className="space-y-2">
                  {subtitleCues.slice(0, 5).map((cue) => {
                    const shiftedStart = Math.max(0, cue.startSec + timingOffsetMs / 1000);
                    const shiftedEnd = Math.max(0.1, cue.endSec + timingOffsetMs / 1000);
                    return (
                      <div key={cue.id} className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 text-xs">
                        <div className="font-mono text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold mb-1">
                          #{cue.id}: {shiftedStart.toFixed(2)}s → {shiftedEnd.toFixed(2)}s
                        </div>
                        <div className="text-slate-800 dark:text-slate-200">{cue.text}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
