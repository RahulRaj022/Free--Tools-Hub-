import React, { useState, useMemo } from 'react';
import { useTools } from '../../../context/ToolsContext';
import { Copy, Download, Trash2, Check, FileUp, Database, ArrowRightLeft, Table, Search, Filter } from 'lucide-react';

interface DataToolsProps {
  toolSlug: string;
}

export const DataTools: React.FC<DataToolsProps> = ({ toolSlug }) => {
  const { showToast } = useTools();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Raw inputs and outputs
  const [inputData, setInputData] = useState<string>(() => {
    if (toolSlug === 'csv-to-json' || toolSlug === 'csv-viewer-filter') {
      return `id,name,role,department,salary\n1,Alice Johnson,Lead Engineer,Tech,125000\n2,Bob Smith,Product Manager,Product,115000\n3,Charlie Brown,UX Designer,Design,95000\n4,Diana Prince,Security Specialist,Security,130000\n5,Evan Wright,Data Analyst,Data,90000`;
    }
    if (toolSlug === 'json-to-csv' || toolSlug === 'json-to-xml') {
      return `[\n  {\n    "id": 1,\n    "name": "Alice Johnson",\n    "role": "Lead Engineer",\n    "department": "Tech",\n    "salary": 125000\n  },\n  {\n    "id": 2,\n    "name": "Bob Smith",\n    "role": "Product Manager",\n    "department": "Product",\n    "salary": 115000\n  }\n]`;
    }
    if (toolSlug === 'xml-to-json') {
      return `<company>\n  <employee id="1">\n    <name>Alice Johnson</name>\n    <role>Lead Engineer</role>\n    <salary>125000</salary>\n  </employee>\n  <employee id="2">\n    <name>Bob Smith</name>\n    <role>Product Manager</role>\n    <salary>115000</salary>\n  </employee>\n</company>`;
    }
    if (toolSlug === 'yaml-json-converter') {
      return `version: "3.8"\nservices:\n  web:\n    image: nginx:alpine\n    ports:\n      - "80:80"\n    environment:\n      NODE_ENV: production`;
    }
    return '';
  });

  const [delimiter, setDelimiter] = useState<',' | '\t' | ';'>((','));
  const [hasHeader, setHasHeader] = useState<boolean>(true);
  const [tableFilter, setTableFilter] = useState<string>('');
  const [sortCol, setSortCol] = useState<number | null>(null);
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // --- CSV Parser Helper ---
  const parseCsv = (csvText: string, sep: string) => {
    const lines = csvText.trim().split(/\r?\n/).filter(Boolean);
    if (lines.length === 0) return [];
    return lines.map((line) => {
      const row: string[] = [];
      let inQuotes = false;
      let curr = '';
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' && (i === 0 || line[i - 1] !== '\\')) {
          inQuotes = !inQuotes;
        } else if (char === sep && !inQuotes) {
          row.push(curr.trim());
          curr = '';
        } else {
          curr += char;
        }
      }
      row.push(curr.trim());
      return row;
    });
  };

  // 1. CSV TO JSON
  const csvToJsonResult = useMemo(() => {
    if (!inputData.trim()) return '';
    try {
      const rows = parseCsv(inputData, delimiter);
      if (rows.length === 0) return '[]';
      if (hasHeader && rows.length > 1) {
        const headers = rows[0];
        const dataRows = rows.slice(1);
        const jsonArray = dataRows.map((r) => {
          const obj: Record<string, any> = {};
          headers.forEach((h, idx) => {
            const val = r[idx] !== undefined ? r[idx] : '';
            // auto parse number/boolean
            if (val === 'true') obj[h] = true;
            else if (val === 'false') obj[h] = false;
            else if (!isNaN(Number(val)) && val !== '') obj[h] = Number(val);
            else obj[h] = val;
          });
          return obj;
        });
        return JSON.stringify(jsonArray, null, 2);
      } else {
        return JSON.stringify(rows, null, 2);
      }
    } catch (e: any) {
      return `Error parsing CSV: ${e.message}`;
    }
  }, [inputData, delimiter, hasHeader]);

  // 2. JSON TO CSV
  const jsonToCsvResult = useMemo(() => {
    if (!inputData.trim()) return '';
    try {
      const parsed = JSON.parse(inputData);
      const arr = Array.isArray(parsed) ? parsed : [parsed];
      if (arr.length === 0) return '';
      const headers = Array.from(
        new Set(arr.flatMap((item) => (typeof item === 'object' && item !== null ? Object.keys(item) : ['value'])))
      );
      const csvLines = [headers.join(',')];
      arr.forEach((item) => {
        if (typeof item === 'object' && item !== null) {
          const row = headers.map((h) => {
            const val = item[h] !== undefined ? String(item[h]) : '';
            return val.includes(',') || val.includes('"') || val.includes('\n')
              ? `"${val.replace(/"/g, '""')}"`
              : val;
          });
          csvLines.push(row.join(','));
        } else {
          csvLines.push(String(item));
        }
      });
      return csvLines.join('\n');
    } catch (e: any) {
      return `Invalid JSON: ${e.message}`;
    }
  }, [inputData]);

  // 3. XML TO JSON
  const xmlToJsonResult = useMemo(() => {
    if (!inputData.trim()) return '';
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(inputData, 'text/xml');
      const parseError = xmlDoc.getElementsByTagName('parsererror');
      if (parseError.length > 0) {
        return `XML Syntax Error: ${parseError[0].textContent}`;
      }

      const nodeToObject = (node: Node): any => {
        if (node.nodeType === Node.TEXT_NODE) {
          const val = node.nodeValue?.trim();
          return val ? val : null;
        }
        const obj: Record<string, any> = {};
        if (node instanceof Element && node.attributes.length > 0) {
          obj['@attributes'] = {};
          for (let i = 0; i < node.attributes.length; i++) {
            const attr = node.attributes[i];
            obj['@attributes'][attr.name] = attr.value;
          }
        }
        let hasChildren = false;
        node.childNodes.forEach((child) => {
          if (child.nodeType === Node.ELEMENT_NODE) {
            hasChildren = true;
            const childName = child.nodeName;
            const childObj = nodeToObject(child);
            if (obj[childName]) {
              if (!Array.isArray(obj[childName])) {
                obj[childName] = [obj[childName]];
              }
              obj[childName].push(childObj);
            } else {
              obj[childName] = childObj;
            }
          } else if (child.nodeType === Node.TEXT_NODE && !hasChildren) {
            const textVal = child.nodeValue?.trim();
            if (textVal) {
              if (Object.keys(obj).length === 0) return textVal;
              obj['#text'] = textVal;
            }
          }
        });
        return Object.keys(obj).length === 0 ? null : obj;
      };

      const result = nodeToObject(xmlDoc.documentElement);
      return JSON.stringify({ [xmlDoc.documentElement.nodeName]: result }, null, 2);
    } catch (e: any) {
      return `XML Parsing error: ${e.message}`;
    }
  }, [inputData]);

  // 4. JSON TO XML
  const jsonToXmlResult = useMemo(() => {
    if (!inputData.trim()) return '';
    try {
      const parsed = JSON.parse(inputData);
      const toXml = (obj: any, rootName = 'root'): string => {
        if (obj === null || obj === undefined) return `<${rootName}/>`;
        if (typeof obj !== 'object') return `<${rootName}>${obj}</${rootName}>`;
        if (Array.isArray(obj)) {
          return obj.map((item) => toXml(item, 'item')).join('\n');
        }
        let inner = '';
        for (const key of Object.keys(obj)) {
          inner += `\n  ${toXml(obj[key], key)}`;
        }
        return `<${rootName}>${inner}\n</${rootName}>`;
      };
      return `<?xml version="1.0" encoding="UTF-8"?>\n${toXml(parsed, 'data')}`;
    } catch (e: any) {
      return `JSON Syntax Error: ${e.message}`;
    }
  }, [inputData]);

  // 5. YAML TO JSON / JSON TO YAML
  const yamlJsonResult = useMemo(() => {
    if (!inputData.trim()) return '';
    // Lightweight parser/converter
    try {
      if (inputData.trim().startsWith('{') || inputData.trim().startsWith('[')) {
        // Convert JSON to YAML
        const obj = JSON.parse(inputData);
        const toYaml = (val: any, indent = 0): string => {
          const spaces = ' '.repeat(indent);
          if (val === null) return 'null';
          if (typeof val === 'string') return val.includes(':') || val.includes('\n') ? `"${val}"` : val;
          if (typeof val !== 'object') return String(val);
          if (Array.isArray(val)) {
            return val.map((v) => `\n${spaces}- ${toYaml(v, indent + 2).trimStart()}`).join('');
          }
          return Object.entries(val)
            .map(([k, v]) => `\n${spaces}${k}: ${toYaml(v, indent + 2)}`)
            .join('');
        };
        return toYaml(obj).trimStart();
      } else {
        // Simple YAML line converter
        const lines = inputData.split('\n');
        const resObj: Record<string, any> = {};
        lines.forEach((line) => {
          const match = line.match(/^(\s*)([^:]+):\s*(.*)$/);
          if (match) {
            const key = match[2].trim();
            const val = match[3].trim().replace(/^["']|["']$/g, '');
            if (val) resObj[key] = isNaN(Number(val)) ? val : Number(val);
          }
        });
        return JSON.stringify(resObj, null, 2);
      }
    } catch (e: any) {
      return `Conversion error: ${e.message}`;
    }
  }, [inputData]);

  // 6. CSV TABLE VIEWER & FILTER
  const tableData = useMemo(() => {
    const rows = parseCsv(inputData, delimiter);
    if (rows.length === 0) return { headers: [], rows: [] };
    const headers = hasHeader ? rows[0] : rows[0].map((_, i) => `Col ${i + 1}`);
    const bodyRows = hasHeader ? rows.slice(1) : rows;

    let filtered = bodyRows;
    if (tableFilter.trim()) {
      const q = tableFilter.toLowerCase();
      filtered = bodyRows.filter((r) => r.some((cell) => cell.toLowerCase().includes(q)));
    }

    if (sortCol !== null) {
      filtered = [...filtered].sort((a, b) => {
        const valA = a[sortCol] || '';
        const valB = b[sortCol] || '';
        return sortAsc ? valA.localeCompare(valB, undefined, { numeric: true }) : valB.localeCompare(valA, undefined, { numeric: true });
      });
    }

    return { headers, rows: filtered };
  }, [inputData, delimiter, hasHeader, tableFilter, sortCol, sortAsc]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast('Copied to clipboard!', 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${filename}`, 'success');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setInputData(event.target?.result as string || '');
      showToast(`Loaded ${file.name}`, 'success');
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* CSV VIEWER & FILTER */}
      {toolSlug === 'csv-viewer-filter' ? (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter rows..."
                  value={tableFilter}
                  onChange={(e) => setTableFilter(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 dark:bg-slate-950 w-48 sm:w-64"
                />
              </div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasHeader}
                  onChange={(e) => setHasHeader(e.target.checked)}
                  className="rounded accent-indigo-600"
                />
                <span>First row is header</span>
              </label>
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 cursor-pointer">
                <FileUp className="h-3.5 w-3.5" />
                <span>Upload CSV</span>
                <input type="file" accept=".csv,.txt" onChange={handleFileUpload} className="hidden" />
              </label>
              <button
                onClick={() => downloadFile(inputData, 'data-export.csv', 'text/csv')}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download CSV</span>
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/60 text-slate-700 dark:text-slate-300">
                  {tableData.headers.map((h, idx) => (
                    <th
                      key={idx}
                      onClick={() => {
                        if (sortCol === idx) setSortAsc(!sortAsc);
                        else {
                          setSortCol(idx);
                          setSortAsc(true);
                        }
                      }}
                      className="p-3 font-semibold cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800 select-none whitespace-nowrap"
                    >
                      <div className="flex items-center gap-1">
                        <span>{h}</span>
                        {sortCol === idx && (
                          <span className="text-indigo-600 font-bold">{sortAsc ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {tableData.rows.length === 0 ? (
                  <tr>
                    <td colSpan={Math.max(1, tableData.headers.length)} className="p-8 text-center text-slate-400">
                      No matching records found.
                    </td>
                  </tr>
                ) : (
                  tableData.rows.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors">
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="p-3 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <div className="text-xs text-slate-500 font-mono">
            Showing {tableData.rows.length} rows
          </div>
        </div>
      ) : (
        /* TWO COLUMN CONVERTER (CSV <-> JSON, XML <-> JSON, YAML <-> JSON) */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Input Data
              </span>
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 cursor-pointer font-medium">
                  <FileUp className="h-3.5 w-3.5" />
                  <span>Upload File</span>
                  <input type="file" onChange={handleFileUpload} className="hidden" />
                </label>
                <button
                  onClick={() => setInputData('')}
                  className="text-xs text-rose-500 hover:text-rose-600 font-medium"
                >
                  Clear
                </button>
              </div>
            </div>
            <textarea
              value={inputData}
              onChange={(e) => setInputData(e.target.value)}
              rows={16}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 font-mono text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-xs"
              placeholder="Paste raw data here..."
            />
          </div>

          {/* Output Box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Converted Output
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const output =
                      toolSlug === 'csv-to-json'
                        ? csvToJsonResult
                        : toolSlug === 'json-to-csv'
                        ? jsonToCsvResult
                        : toolSlug === 'xml-to-json'
                        ? xmlToJsonResult
                        : toolSlug === 'json-to-xml'
                        ? jsonToXmlResult
                        : yamlJsonResult;
                    copyToClipboard(output, 'data-out');
                  }}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50"
                >
                  {copiedKey === 'data-out' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>Copy</span>
                </button>
                <button
                  onClick={() => {
                    const isJson = toolSlug.endsWith('-to-json');
                    const isCsv = toolSlug === 'json-to-csv';
                    const isXml = toolSlug === 'json-to-xml';
                    const output =
                      toolSlug === 'csv-to-json'
                        ? csvToJsonResult
                        : toolSlug === 'json-to-csv'
                        ? jsonToCsvResult
                        : toolSlug === 'xml-to-json'
                        ? xmlToJsonResult
                        : toolSlug === 'json-to-xml'
                        ? jsonToXmlResult
                        : yamlJsonResult;
                    downloadFile(
                      output,
                      isJson ? 'converted.json' : isCsv ? 'converted.csv' : isXml ? 'converted.xml' : 'converted.txt',
                      isJson ? 'application/json' : isCsv ? 'text/csv' : 'text/plain'
                    );
                  }}
                  className="flex items-center gap-1 px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 shadow-xs"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
            <textarea
              readOnly
              value={
                toolSlug === 'csv-to-json'
                  ? csvToJsonResult
                  : toolSlug === 'json-to-csv'
                  ? jsonToCsvResult
                  : toolSlug === 'xml-to-json'
                  ? xmlToJsonResult
                  : toolSlug === 'json-to-xml'
                  ? jsonToXmlResult
                  : yamlJsonResult
              }
              rows={16}
              className="w-full p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-200 focus:outline-none shadow-xs"
            />
          </div>
        </div>
      )}
    </div>
  );
};
