import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { Search, Copy, Check, AlertCircle, Loader2, RotateCcw, Info } from 'lucide-react';

interface DnsRecord {
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS' | 'SOA';
  value: string;
  priority?: number;
  ttl?: number;
}

const RECORD_EXPLANATIONS: Record<string, string> = {
  A: 'IPv4 Address: Maps your domain name to an IPv4 hosting server address.',
  AAAA: 'IPv6 Address: Maps your domain name to a modern 128-bit IPv6 address.',
  CNAME: 'Canonical Name: Points an alias hostname to another true domain name.',
  MX: 'Mail Exchange: Directs inbound emails to your mail server (e.g. Google Workspace).',
  TXT: 'Text Record: Stores arbitrary text for SPF spam protection and domain verification.',
  NS: 'Name Server: Delegates a DNS zone to use given authoritative name servers.',
  SOA: 'Start of Authority: Core metadata including primary NS, admin contact, and serial.',
};

export const DnsLookupTool: React.FC = () => {
  const { showToast } = useTools();
  const [domain, setDomain] = useState('freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [records, setRecords] = useState<DnsRecord[]>([]);
  const [activeType, setActiveType] = useState<string>('ALL');
  const [copiedValue, setCopiedValue] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const lookupDns = async () => {
    let clean = domain.trim().replace(/^https?:\/\//i, '').split('/')[0];
    if (!clean) {
      setError('Please enter a domain name.');
      return;
    }
    setDomain(clean);

    setLoading(true);
    setError(null);
    setRecords([]);

    try {
      const res = await fetch(`/api/web/dns?domain=${encodeURIComponent(clean)}`);
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to lookup DNS records.');
      }

      setRecords(data.records || []);
      showToast(`Resolved ${data.records?.length || 0} DNS record(s)!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error querying DNS records.');
    } finally {
      setLoading(false);
    }
  };

  const copyRecord = (val: string) => {
    navigator.clipboard.writeText(val);
    setCopiedValue(val);
    showToast('Copied record value!', 'success');
    setTimeout(() => setCopiedValue(null), 2000);
  };

  const typesList = ['ALL', 'A', 'AAAA', 'MX', 'TXT', 'NS', 'CNAME', 'SOA'];
  const filteredRecords = records.filter((r) => activeType === 'ALL' || r.type === activeType);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Domain Name
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && lookupDns()}
            placeholder="example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={lookupDns}
            disabled={loading || !domain.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            <span>{loading ? 'Resolving...' : 'Lookup DNS'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setDomain('');
              setRecords([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {records.length > 0 && (
        <div className="space-y-4 animate-in fade-in">
          {/* Record Type Filters */}
          <div className="flex flex-wrap items-center gap-1.5">
            {typesList.map((type) => {
              const count = type === 'ALL' ? records.length : records.filter((r) => r.type === type).length;
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => setActiveType(type)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeType === type
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <span>{type}</span>
                  <span className="ml-1.5 opacity-70">({count})</span>
                </button>
              );
            })}
          </div>

          {/* Records Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500">
                <tr>
                  <th className="px-4 py-3 font-semibold w-24">Type</th>
                  <th className="px-4 py-3 font-semibold">Value / Target</th>
                  <th className="px-4 py-3 font-semibold text-right w-20">Copy</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                {filteredRecords.map((r, i) => {
                  const isCopied = copiedValue === r.value;
                  return (
                    <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 font-bold">
                          {r.type}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-900 dark:text-slate-100 break-all select-all">
                        {r.value}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => copyRecord(r.value)}
                          className="p-1 rounded-md text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                          title="Copy value"
                        >
                          {isCopied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* DNS Reference Info */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Info className="h-3.5 w-3.5" />
              DNS Record Types Explained
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              {Object.entries(RECORD_EXPLANATIONS).map(([k, desc]) => (
                <div key={k} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 mr-2">{k}</span>
                  <span className="text-slate-600 dark:text-slate-300">{desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
