import React, { useState } from 'react';
import { useTools } from '../../../../context/ToolsContext';
import { ExternalLink, Copy, Check, Download, Search, AlertCircle, Loader2, RotateCcw } from 'lucide-react';

interface ExtractedLink {
  url: string;
  anchorText: string;
  isExternal: boolean;
  rel?: string;
}

export const LinkExtractorTool: React.FC = () => {
  const { showToast } = useTools();
  const [url, setUrl] = useState('https://freetoolshub.com');
  const [loading, setLoading] = useState(false);
  const [links, setLinks] = useState<ExtractedLink[]>([]);
  const [filter, setFilter] = useState<'all' | 'internal' | 'external'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const extractLinks = async () => {
    let target = url.trim();
    if (!target) {
      setError('Please enter a website URL.');
      return;
    }
    if (!target.startsWith('http://') && !target.startsWith('https://')) {
      target = 'https://' + target;
      setUrl(target);
    }

    setLoading(true);
    setError(null);
    setLinks([]);

    try {
      const res = await fetch('/api/web/proxy-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: target }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to fetch webpage.');
      }

      const html = data.html || '';
      const baseUrl = new URL(data.url || target);

      // Match <a> tags
      const aTagRegex = /<a\b([^>]*)>(.*?)<\/a>/gis;
      const foundList: ExtractedLink[] = [];
      const seen = new Set<string>();
      let match;

      while ((match = aTagRegex.exec(html)) !== null) {
        const attributes = match[1];
        const rawContent = match[2];

        const hrefMatch = attributes.match(/\bhref=["']([^"']+)["']/i);
        const relMatch = attributes.match(/\brel=["']([^"']*)["']/i);

        if (hrefMatch && hrefMatch[1]) {
          const rawHref = hrefMatch[1].trim();
          if (
            rawHref &&
            !rawHref.startsWith('#') &&
            !rawHref.startsWith('javascript:') &&
            !rawHref.startsWith('mailto:') &&
            !rawHref.startsWith('tel:')
          ) {
            try {
              const fullUrl = new URL(rawHref, baseUrl).toString();
              if ((fullUrl.startsWith('http://') || fullUrl.startsWith('https://')) && !seen.has(fullUrl)) {
                seen.add(fullUrl);
                const isExternal = new URL(fullUrl).hostname !== baseUrl.hostname;
                const cleanText = rawContent.replace(/<[^>]+>/g, '').trim() || '(No anchor text)';

                foundList.push({
                  url: fullUrl,
                  anchorText: cleanText.slice(0, 80),
                  isExternal,
                  rel: relMatch ? relMatch[1] : undefined,
                });
              }
            } catch {}
          }
        }
      }

      if (foundList.length === 0) {
        setError('No hyperlinks were found on this webpage.');
        return;
      }

      setLinks(foundList);
      showToast(`Extracted ${foundList.length} unique hyperlinks!`, 'success');
    } catch (err: any) {
      setError(err?.message || 'Error extracting links.');
    } finally {
      setLoading(false);
    }
  };

  const copyLink = (linkUrl: string) => {
    navigator.clipboard.writeText(linkUrl);
    setCopiedUrl(linkUrl);
    showToast('Copied URL to clipboard!', 'success');
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const exportCsv = () => {
    const header = 'Resolved URL,Anchor Text,Classification,Rel Attributes\n';
    const rows = links
      .map(
        (l) =>
          `"${l.url}","${l.anchorText.replace(/"/g, '""')}",${l.isExternal ? 'External' : 'Internal'},"${l.rel || ''}"`
      )
      .join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `extracted_links_${url.replace(/[^a-z0-9]/gi, '_')}.csv`;
    a.click();
    URL.revokeObjectURL(u);
    showToast('Exported links CSV!', 'success');
  };

  const internalCount = links.filter((l) => !l.isExternal).length;
  const externalCount = links.filter((l) => l.isExternal).length;

  const filtered = links.filter((l) => {
    if (filter === 'internal' && l.isExternal) return false;
    if (filter === 'external' && !l.isExternal) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return l.url.toLowerCase().includes(q) || l.anchorText.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-xs">
        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
          Webpage URL to Extract Links From
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && extractLinks()}
            placeholder="https://example.com"
            className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={extractLinks}
            disabled={loading || !url.trim()}
            className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 disabled:opacity-50 transition-all cursor-pointer shrink-0"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ExternalLink className="h-4 w-4" />}
            <span>{loading ? 'Extracting...' : 'Extract Links'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setUrl('');
              setLinks([]);
              setError(null);
            }}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 py-2.5 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 flex items-start gap-2.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {links.length > 0 && (
        <div className="space-y-4 animate-in fade-in">
          {/* Summary Filter Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div
              onClick={() => setFilter('all')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'all'
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <span className="text-xs text-slate-500">Total Unique Links</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                {links.length}
              </div>
            </div>

            <div
              onClick={() => setFilter('internal')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'internal'
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <span className="text-xs text-slate-500">Internal Links</span>
              <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5">
                {internalCount}
              </div>
            </div>

            <div
              onClick={() => setFilter('external')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                filter === 'external'
                  ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
              }`}
            >
              <span className="text-xs text-slate-500">External Links</span>
              <div className="text-2xl font-bold font-mono text-cyan-600 dark:text-cyan-400 mt-0.5">
                {externalCount}
              </div>
            </div>
          </div>

          {/* Search & Export Toolbar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search link URL or anchor text..."
                className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="button"
              onClick={exportCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          {/* Links Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-500">
                  <tr>
                    <th className="px-4 py-3 font-semibold w-24">Type</th>
                    <th className="px-4 py-3 font-semibold">Anchor Text</th>
                    <th className="px-4 py-3 font-semibold">Destination URL</th>
                    <th className="px-4 py-3 font-semibold text-right w-16">Copy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {filtered.map((link, idx) => {
                    const isCopied = copiedUrl === link.url;
                    return (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-md font-sans text-[11px] font-semibold ${
                              link.isExternal
                                ? 'bg-cyan-50 dark:bg-cyan-950/40 text-cyan-700 dark:text-cyan-400'
                                : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400'
                            }`}
                          >
                            {link.isExternal ? 'External' : 'Internal'}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-sans text-slate-700 dark:text-slate-300 max-w-xs truncate">
                          {link.anchorText}
                        </td>
                        <td className="px-4 py-3 max-w-md truncate text-slate-900 dark:text-slate-100 font-sans">
                          <a
                            href={link.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline flex items-center gap-1"
                          >
                            <span className="truncate">{link.url}</span>
                            <ExternalLink className="h-3 w-3 shrink-0 opacity-40" />
                          </a>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => copyLink(link.url)}
                            className="p-1 rounded-md text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                            title="Copy URL"
                          >
                            {isCopied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
