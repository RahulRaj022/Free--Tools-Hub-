import React from 'react';
import { useTools } from '../context/ToolsContext';
import { TOOLS_DATA } from '../data/toolsData';
import { ToolCard } from '../components/tools/ToolCard';
import { Star, ArrowRight } from 'lucide-react';
import { BackButton } from '../components/common/BackButton';

interface FavoritesPageProps {
  navigate: (path: string) => void;
}

export const FavoritesPage: React.FC<FavoritesPageProps> = ({ navigate }) => {
  const { favorites } = useTools();

  const favoriteTools = TOOLS_DATA.filter((tool) => favorites.includes(tool.id));

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <div className="flex items-center">
        <BackButton navigate={navigate} fallbackPath="/" />
      </div>

      <div className="border-b border-slate-200/80 pb-6 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500 mb-1">
          <Star className="h-4 w-4 fill-amber-500" />
          <span>Personal Workspace</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          My Favorite Tools
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Quickly access your saved tools from any session. Stored privately on your device.
        </p>
      </div>

      {favoriteTools.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {favoriteTools.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              onSelect={(slug) => navigate(`/tools/${slug}`)}
            />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 max-w-xl mx-auto">
          <Star className="h-12 w-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            You haven&apos;t saved any tools yet
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Click the star icon (★) on any tool card to add it to your favorites for instant access anytime.
          </p>
          <button
            onClick={() => navigate('/tools')}
            className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 text-xs sm:text-sm font-semibold text-white hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <span>Explore All Tools</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
};
