export type ToolCategory = 
  | 'pdf'
  | 'image'
  | 'audio'
  | 'video'
  | 'design'
  | 'text'
  | 'calculator'
  | 'developer'
  | 'data'
  | 'seo'
  | 'finance'
  | 'productivity'
  | 'social'
  | 'education'
  | 'conversion'
  | 'security'
  | 'ai'
  | 'student'
  | 'web'
  | 'other';

export interface CategoryInfo {
  id: ToolCategory;
  name: string;
  slug: string;
  description: string;
  iconName: string;
  color: string;
}

export interface ToolFAQ {
  question: string;
  answer: string;
}

export interface ToolInstructionStep {
  title: string;
  description: string;
}

export interface ToolItem {
  id: string;
  slug: string;
  name: string;
  category: ToolCategory;
  description: string;
  shortDescription: string;
  iconName: string;
  popular?: boolean;
  featured?: boolean;
  addedDate?: string;
  seoTitle: string;
  seoDescription: string;
  keywords: string[];
  steps: ToolInstructionStep[];
  features: string[];
  whyUse?: string;
  quickTip?: string;
  faqs: ToolFAQ[];
  relatedSlugs: string[];
}

export interface ToastMessage {
  id: string;
  text: string;
  type?: 'success' | 'info' | 'error';
}
